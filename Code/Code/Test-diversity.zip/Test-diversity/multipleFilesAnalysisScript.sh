 #!/bin/bash         

export PATH=$PATH:/home/islam/MyWork/Code/defects4j/framework/bin
export PATH=$PATH:/home/islam/MyWork/Code/defects4j/framework/util

dirs=( "/home/islam/MyWork/TestDir/JacksonDatabind/EvoSuite/Euclidean/EvoSuite/size44" "/home/islam/MyWork/TestDir/JacksonDatabind/EvoSuite/Euclidean/EvoSuite/size76" "/home/islam/MyWork/TestDir/JacksonDatabind/EvoSuite/Euclidean/EvoSuite/size108")

times=()

id="JacksonDatabind"

for k in "${dirs[@]}"
do

  cd $k

  SECONDS=0

  for i in *
  do
      echo "***Working on file $i***"
      now=$(date +"%r")
      echo "Current time : $now"
      #fix_test_suite.pl -p $id -d $k/$i/
      run_mutation.pl -p $id -d $k/$i/ -o $k/$i/
  
      run_coverage.pl -p $id -d $k/$i/ -o $k/$i/
  done

  duration=$SECONDS
  times+=($duration)
  #echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."

done

for t in "${times[@]}"
do
  echo "$(($t / 60)) minutes and $(($t % 60)) seconds elapsed."
done
