 #!/bin/bash         

export PATH=$PATH:/home/islam/MyWork/Code/defects4j/framework/bin

if [ $# -eq 0 ]
  then
	read -p "Please enter id of project: " id
  read -p "Please enter version id: " verID
  read -p "Please enter the root directory: " dir
	
  elif [ $# -eq 1 ]
    then
    	id=$1
    	read -p "Please enter version id: " verID
      read -p "Please enter the root directory: " dir
  elif [ $# -eq 2 ]
    then
      id=$1
      verID=$2
      read -p "Please enter the root directory: " dir
  else
  	id=$1
    verID=$2
    dir=$3
fi

budget=3000

SECONDS=0

for i in {1..30}
do
    echo "***Working on test suite $i***"
    now=$(date +"%r")
    echo "Current time : $now"
    
  gen_tests.pl -g "randoop" -p $id -v $verID -n $i -o $dir -b $budget -s $(shuf -i 20-650 -n 1)
  
  gen_tests.pl -g "evosuite" -p $id -v $verID -n $i -o $dir -b $budget -s $(shuf -i 20-650 -n 1)
done

duration=$SECONDS
echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."

