package coverage.code;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.List;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.junit.Test;

import components.DataLoader;
import components.Sequence;
import components.TarFile;
import junit.framework.Assert;
import similaritymetrics.NCDMetric;
import stringdistances.StringDistance;

public class StringDistanceTest {

	@Test
	public void testBuiltInHammingDistanceEqualSize() {
		String first  = "contain" + '\0' + '\0' + '\0' + '\0';
		String second = "chamberlain";
		org.apache.commons.text.similarity.HammingDistance distance = new org.apache.commons.text.similarity.HammingDistance();
		Assert.assertEquals(2, (int) distance.apply(first, second));
	}

	@Test
	public void testBuiltInLevenshteinDistanceEqualSize() {
		String first = "contain";
		String second = "chamberlain";
		org.apache.commons.text.similarity.LevenshteinDistance distance = new org.apache.commons.text.similarity.LevenshteinDistance();
		Assert.assertEquals(2, (int) distance.apply(first, second));

		first = "frog";
		second = "fog";
		Assert.assertEquals(1, (int) distance.apply(first, second));

		first = "Y. Ledru";
		second = "Yves Ledru";
		Assert.assertEquals(3, (int) distance.apply(first, second));
	}

	@Test
	public void testHammingDistanceEqualSize() {
		String first = "abab";
		String second = "abcd";
		Assert.assertEquals(2, StringDistance.getHammingDistance(first, second));
	}

	@Test
	public void testHammingFirstStringLarger() {
		String first = "ab";
		String second = "abcde";
		Assert.assertEquals(3, StringDistance.getHammingDistance(first, second));
	}

	@Test
	public void testHammingSecondStringLarger() {
		String first = "abcde";
		String second = "ab";
		Assert.assertEquals(3, StringDistance.getHammingDistance(first, second));
	}

	@Test
	public void testHammingDistanceSequenceEqualSize() {
		Sequence testCase1 = new Sequence("test1");
		Sequence testCase2 = new Sequence("test2");
		testCase1.addLine("abbd");
		testCase1.addLine("ab");
		testCase1.addLine("ab");
		testCase1.addLine("abbd");

		testCase2.addLine("abxd");
		testCase2.addLine("ab");
		testCase2.addLine("abbd");
		testCase2.addLine("ab");
		Assert.assertEquals(5, StringDistance.getHammingDistance(testCase1, testCase2));
	}

	@Test
	public void testHammingDistanceSequenceDifferentSize() {
		Sequence testCase1 = new Sequence("test1");
		Sequence testCase2 = new Sequence("test2");
		testCase1.addLine("abbd");
		testCase1.addLine("ab");
		testCase1.addLine("ab");
		testCase1.addLine("abbd");

		testCase2.addLine("abxd");
		testCase2.addLine("ab");
		testCase2.addLine("abbd");
		testCase2.addLine("ab");
		testCase2.addLine("abc");
		testCase2.addLine("ab");
		Assert.assertEquals(10, StringDistance.getHammingDistance(testCase1, testCase2));
	}
/*
	@Test
	public void testEuclidanDistanceSequenceDifferentSize() {
		Sequence testCase1 = new Sequence("test1");
		Sequence testCase2 = new Sequence("test2");
		testCase1.addLine("void test1()");
		testCase1.addLine("{");
		testCase1.addLine("int x=2;");
		testCase1.addLine("System.out.println(x);");
		testCase1.addLine("}");

		testCase2.addLine("void test2()");
		testCase2.addLine("{");
		testCase2.addLine("int x=20;");
		testCase2.addLine("System.out.println(x);");
		testCase2.addLine("}");

		String test1 = "void test1(){int x=2;System.out.println(x);}";
		String test2 = "void test2(){int x=20;System.out.println(x);}";

		double value1 =  StringDistance.getEuclideanDistance(testCase1, testCase2);
		double value2 = StringDistance.getEuclideanDistance(test1, test2);
		System.out.println("Euclidean: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getHammingDistance(testCase1, testCase2);
		value2 = StringDistance.getHammingDistance(test1, test2);
		System.out.println("Hamming: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getLevenshteinDistance(testCase1, testCase2);
		value2 = StringDistance.getLevenshteinDistance(test1, test2);
		System.out.println("Levenshtein: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getManhattanDistance(testCase1, testCase2);
		value2 = StringDistance.getManhattanDistance(test1, test2);
		System.out.println("Manhattan: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		try {
			NCDMetric metric = new NCDMetric(null, null);

			test1 = "{int x=2;System.out.println(x);}";
			test2 = "{int x=20;System.out.println(x);}";

			value1 =  metric.pairWise(testCase1, testCase2);
			value2 = metric.pairWise(test1, test2);
			System.out.println("NCD: ");
			System.out.println("first: " + value1);
			System.out.println("second: " + value2);
		}
		catch(IOException ex) {

		}
	}*/
	
	@Test
	public void testSequencesWithTwoOptions() {
		Sequence testCase1 = new Sequence("test1");
		Sequence testCase2 = new Sequence("test2");
		testCase1.addLine("public void test000118() throws Throwable {");
		testCase1.addLine("if (debug)");
		testCase1.addLine("System.out.format(\"%n%s%n\", \"RegressionTest0.test000118\");");
		testCase1.addLine("byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 0);");
		testCase1.addLine("org.junit.Assert.assertTrue(\"'\" + byte3 + \"' != '\" + (byte) 100 + \"'\", byte3 == (byte) 100);");
		testCase1.addLine("}");

		testCase2.addLine("public void test000170() throws Throwable {");
		testCase2.addLine("if (debug)");
		testCase2.addLine("System.out.format(\"%n%s%n\", \"RegressionTest0.test000170\");");
		testCase2.addLine("byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 100);");
		testCase2.addLine("org.junit.Assert.assertTrue(\"'\" + byte3 + \"' != '\" + (byte) 100 + \"'\", byte3 == (byte) 100);");
		testCase2.addLine("}");

		String test1 = testCase1.getAsOneString();
		String test2 = testCase2.getAsOneString();

		double value1 =  StringDistance.getEuclideanDistance(testCase1, testCase2);
		double value2 = StringDistance.getEuclideanDistance(test1, test2);
		System.out.println("Euclidean: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getHammingDistance(testCase1, testCase2);
		value2 = StringDistance.getHammingDistance(test1, test2);
		System.out.println("Hamming: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getLevenshteinDistance(testCase1, testCase2);
		value2 = StringDistance.getLevenshteinDistance(test1, test2);
		System.out.println("Levenshtein: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		value1 =  StringDistance.getManhattanDistance(testCase1, testCase2);
		value2 = StringDistance.getManhattanDistance(test1, test2);
		System.out.println("Manhattan: ");
		System.out.println("first: " + value1);
		System.out.println("second: " + value2);

		try {
			NCDMetric metric = new NCDMetric(null, null);

			test1 = "{int x=2;System.out.println(x);}";
			test2 = "{int x=20;System.out.println(x);}";

			value1 =  metric.pairWise(testCase1, testCase2);
			value2 = metric.pairWise(test1, test2);
			System.out.println("NCD: ");
			System.out.println("first: " + value1);
			System.out.println("second: " + value2);
		}
		catch(IOException ex) {

		}
	}
/*
	@Test
	public void untarTest()
	{
		TarFile tf = new TarFile("/home/vaio/MyWork/testdir/Lang/randoop/170/Lang-1f-randoop.160.tar.bz2");
		tf.untar();
	}

	@Test
	public void testFilesInFolder()
	{
		File folder = new File("/home/vaio/MyWork/testdir/testing.");
		listFilesForFolder(folder);
	}

	public void listFilesForFolder(final File folder) {
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				System.out.println(fileEntry.getName());
			}
		}
	}*/
}
