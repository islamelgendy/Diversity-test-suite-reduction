package coverage.code;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.junit.Test;

import components.DataLoader;
import components.Sequence;
import components.SequenceWriter;
import junit.framework.Assert;
import similaritymetrics.NCDMetric;
import similaritymetrics.SimilarityMetric;

public class CodeCoverageTest {

	public static boolean debug = true;
	
	@Test
	public void testMain()
	{
		try {
			final String METRIC = SimilarityMetric.HAMMING_METRIC;
			final String CSVFILE = "HammingMetric.csv";
			final int REDUCED_SIZE = 50;
			DataLoader dataLoader = new DataLoader("/home/vaio/MyWork/Code/Test-diversity/src/test/java/testsubjects/CalculatorFullRegressionTest2.java");
			dataLoader.parseFile();
			System.out.print("Parsing file...");
			System.out.print("Parsing file...");
			List<String> heading = dataLoader.parseFile();
			System.out.println("Done!");
			//System.out.print("Enter the file name of the output file for NCD values: ");
			//String outputNCD = input.nextLine();
			
			System.out.print("Writing into CSV file...");
			long startTime = System.currentTimeMillis();
			Number[][] NCDValues = DataLoader.writeMetricValuesIntoCSV(dataLoader, METRIC, CSVFILE, false);
			long endTime = System.currentTimeMillis();
			double totalTimeMins = (endTime - startTime) / 1000.0;
			System.out.println("...Done in " + totalTimeMins + " seconds");
			
			System.out.print("Test suite reduction...");
			startTime = System.currentTimeMillis();
			//DataLoader.testSuiteReduction(dataLoader, METRIC, NCDValues, REDUCED_SIZE);
			endTime = System.currentTimeMillis();
			totalTimeMins = (endTime - startTime) / 1000.0;
			System.out.print("...Done in " + totalTimeMins + " seconds");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
