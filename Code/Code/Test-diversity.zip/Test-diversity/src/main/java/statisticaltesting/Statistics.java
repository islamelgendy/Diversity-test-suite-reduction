package statisticaltesting;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.math3.stat.inference.MannWhitneyUTest;

public class Statistics {
	
	/**
	 * A12EffectSize calculates the effect size based on the Vargha
	 * and Delaney's A12, which is a non parametric statistic test.
	 * 
	 * @param X The first sample data
	 * @param Y The second sample data
	 * @param n the number of observations
	 * @return the A12 effect size.
	 */
	public static double A12EffectSize(Double [] X, Double [] Y, int n)
	{
		double R1 = Utils.sumRanks(getRankForSample1(X, Y));
		
		double A12 = (R1/n - (n+1)/2.)/n;
		
		return A12;
	}
	
	/**
	 * getRankForSample1 calculate the ranks for the first data sample.
	 * 
	 * @param X The first sample data.
	 * @param Y The second sample data.
	 * @return an array of the ranks for the first sample data.
	 */
	public static int [] getRankForSample1(Double [] X, Double [] Y)
	{
		String [] S1 = Utils.nameArray(X, 'X');
		String [] S2 = Utils.nameArray(X, 'Y');
		Double [] combinedValues = Utils.combine(X, Y).toArray(new Double[0]);
		String [] combinedNames = Utils.combine(S1, S2).toArray(new String[0]);
		Utils.sortCombined(combinedValues, combinedNames);
		int [] rank1 = Utils.findRank(S1, combinedNames);
		return rank1;
	}
	
	public static double getPValue(Double [] X, Double [] Y)
	{
		MannWhitneyUTest nonParObj = new MannWhitneyUTest();
		
		return nonParObj.mannWhitneyUTest(ArrayUtils.toPrimitive(X), ArrayUtils.toPrimitive(Y));
	}
	
	public static double getPValue(double [] X, double [] Y)
	{
		MannWhitneyUTest nonParObj = new MannWhitneyUTest();
		
		return nonParObj.mannWhitneyUTest(X, Y);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Double [] X = {42.,11.,7.};
		Double [] Y = {1.,20.,5.};
		String [] S1 = Utils.nameArray(X, 'X');
		String [] S2 = Utils.nameArray(X, 'Y');
		Double [] combinedValues = Utils.combine(X, Y).toArray(new Double[0]);
		String [] combinedNames = Utils.combine(S1, S2).toArray(new String[0]);
		System.out.println("Before sorting:");
		for(Double d : combinedValues)
			System.out.print(d + " ");
		System.out.println();
		for(String s : combinedNames)
			System.out.print(s + " ");
		
		Utils.sortCombined(combinedValues, combinedNames);
		
		System.out.println("\nAfter sorting:");
		for(Double d : combinedValues)
			System.out.print(d + " ");
		System.out.println();
		for(String s : combinedNames)
			System.out.print(s + " ");
		System.out.println();
		
		int [] rank1 = Utils.findRank(S1, combinedNames);
		int [] rank2 = Utils.findRank(S2, combinedNames);
		
		System.out.println("\nRanks:");
		for(int r : rank1)
			System.out.print(r + " ");
		System.out.println();
		for(int r : rank2)
			System.out.print(r + " ");
		System.out.println();
		
		System.out.println("A12 = " + A12EffectSize(X, Y, 3));
		
		System.out.println("p-value = " + getPValue(X, Y));
	}

}
