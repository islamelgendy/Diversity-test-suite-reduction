package statisticaltesting;

import java.util.ArrayList;
import java.util.List;

/**
 * Utils class contains multiple helper methods to be used in the 
 * Statistics class.
 * 
 * @author Islam Elgendy 17.02.2021
 *
 */
public class Utils {

	/**
	 * sortCombined Sort the array of doubles, and any swap is made in 
	 * the double array is also made in the named array to be used later
	 *  to calculate the ranks of the values.
	 * @param arrValues The combined double values of the samples.
	 * @param arrNames The combined names of the samples.
	 */
	public static void sortCombined(Double [] arrValues, String [] arrNames)
	{
		for(int i=0;i<arrValues.length;i++)
		{
			int minPos = findMinIndex(arrValues,i);
			swap(arrValues, i, minPos);
			swap(arrNames, i, minPos);
		}
	}
	
	public static int findMinIndex(Double [] arr, int start)
	{
		int min = start;
		for(int i=start+1;i<arr.length;i++)
		{
			if(arr[i] < arr[min])
				min = i;
		}
		return min;
	}
	
	public static final <T> void swap (T[] a, int i, int j) {
		T t = a[i];
		a[i] = a[j];
		a[j] = t;
	}
	
	// Given an array of doubles, this method create a named array.
	// This named array will be used to calculate the ranks.
	public static String [] nameArray(Double [] arr, char ch)
	{
		String [] names = new String[arr.length];
		for(int i=0;i<arr.length;i++)
			names[i] = Character.toString(ch) + i;
		return names;
	}
	
	// Combine two arrays into a single list.
	public static final <T> List<T> combine (T[] arr1, T[] arr2) {
		List<T> arr = new ArrayList<T>();
		for(T elem : arr1)
			arr.add(elem);
		for(T elem : arr2)
			arr.add(elem);
		return arr;
	}
	
	// Calculate the ranks of the sample data.
	public static int[] findRank(String [] namedArray, String [] combinedSortedNamedArray)
	{
		int [] rank = new int[namedArray.length];
		
		for(int i=0;i<rank.length;i++)
		{
			rank[i] = indexOf(combinedSortedNamedArray, namedArray[i])+1;
		}
		
		return rank;
	}
	
	public static final <T> int indexOf(T[] arr, T key) {
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i].equals(key))
				return i;
		}
		return -1;
	}
	
	// Returns the sum of the ranks
	public static int sumRanks(int [] arr)
	{
		int total = 0;
		for(int x : arr)
			total += x;
		return total;
	}
	
	public static double getAvg(List<Double> list)
	{
		double total = 0;
		for(Double value : list)
		{
			if(!value.isNaN())
				total += value;
		}
		return total / list.size();
	}
}
