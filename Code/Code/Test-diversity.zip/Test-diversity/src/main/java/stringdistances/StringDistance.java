package stringdistances;

import org.apache.commons.text.similarity.LevenshteinDistance;

import components.Sequence;

public class StringDistance {

	/**
	 * getHammingDistance method calculates the hamming distance between two strings.
	 * It calculates the number of different characters between the two strings. 
	 * @param x The first string.
	 * @param y The second string.
	 * @return The hamming distance between the two strings x and y.
	 */
	public static int getHammingDistance(String x, String y)
	{
		int hammingDistance = 0;
		if(x.length() >= y.length())
		{
			int i=0;
			for(i=0;i<y.length();i++)
			{
				if( Character.toLowerCase(x.charAt(i)) != Character.toLowerCase(y.charAt(i)) )
					hammingDistance++;
			}
			hammingDistance += x.length()-i;
		}
		else
		{
			int i=0;
			for(i=0;i<x.length();i++)
			{
				if( Character.toLowerCase(x.charAt(i)) != Character.toLowerCase(y.charAt(i)) )
					hammingDistance++;
			}
			hammingDistance += y.length()-i;
		}
		return hammingDistance;
	}
	
	/**
	 * getHammingDistance method calculates the hamming distance between two Sequence objects 
	 * (test cases). The method goes through each line in the sequence, and it calculates the 
	 * number of different characters between the two corresponding lines. 
	 * @param x The first Sequence or test case.
	 * @param y The second Sequence or test case.
	 * @return The hamming distance between the two sequences x and y.
	 */
	public static int getHammingDistance(Sequence x, Sequence y)
	{
		int hammingDistance = 0;
		if(x.getNumberOfLines() >= y.getNumberOfLines())
		{
			int i=0;
			for(i=0;i<y.getNumberOfLines();i++)
				hammingDistance += getHammingDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<x.getNumberOfLines())
			{
				hammingDistance += x.getLines().get(i).length();
				i++;
			}
		}
		else
		{
			int i=0;
			for(i=0;i<x.getNumberOfLines();i++)
				hammingDistance += getHammingDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<y.getNumberOfLines())
			{
				hammingDistance += y.getLines().get(i).length();
				i++;
			}
		}
		return hammingDistance;
	}

	/**
	 * getLevenshteinDistance method calculates the Levenshtein distance between two strings. 
	 * The method calls the built in java implementation of the Levenshtein distance.
	 * @param x The first string.
	 * @param y The second string.
	 * @return The Levenshtein distance between the two strings x and y.
	 */
	public static int getLevenshteinDistance(String x, String y)
	{
		LevenshteinDistance distance = new LevenshteinDistance();
		return distance.apply(x,y);
	}
	
	/**
	 * getLevenshteinDistance method calculates the Levenshtein distance between two Sequence objects 
	 * (test cases). The method calls the built in java implementation of the Levenshtein distance.
	 * @param x The first Sequence or test case.
	 * @param y The second Sequence or test case.
	 * @return The Levenshtein distance between the two sequences x and y.
	 */
	public static int getLevenshteinDistance(Sequence x, Sequence y)
	{
		int levenshteinDistance = 0;
		LevenshteinDistance distance = new LevenshteinDistance();
		if(x.getNumberOfLines() >= y.getNumberOfLines())
		{
			int i=0;
			for(i=0;i<y.getNumberOfLines();i++)
				levenshteinDistance += distance.apply(x.getLines().get(i), y.getLines().get(i));
			
			while(i<x.getNumberOfLines())
			{
				levenshteinDistance += x.getLines().get(i).length();
				i++;
			}
		}
		else
		{
			int i=0;
			for(i=0;i<x.getNumberOfLines();i++)
				levenshteinDistance += distance.apply(x.getLines().get(i), y.getLines().get(i));
			
			while(i<y.getNumberOfLines())
			{
				levenshteinDistance += y.getLines().get(i).length();
				i++;
			}
		}
		return levenshteinDistance;
	}
	
	/**
	 * getEuclideanDistance method calculates the Euclidean distance between two strings.
	 * It calculates the square root of the total sum of the square difference between the 
	 * ASCII of the characters between the two strings. 
	 * @param x The first string.
	 * @param y The second string.
	 * @return The Euclidean distance between the two strings x and y.
	 */
	public static double getEuclideanDistance(String x, String y)
	{
		// Make sure the two strings are all capital letters.
		x = x.toUpperCase();
		y = y.toUpperCase();
		
		double sum = 0;
		if(x.length() >= y.length())
		{
			int i=0;
			for(i=0;i<y.length();i++)
			{
				sum += Math.pow(x.charAt(i) - y.charAt(i),2);
			}
			while(i<x.length())
			{
				sum += x.charAt(i) * x.charAt(i);
				i++;
			}
			
		}
		else
		{
			int i=0;
			for(i=0;i<x.length();i++)
			{
				sum += Math.pow(y.charAt(i) - x.charAt(i),2);
			}
			while(i<y.length())
			{
				sum += y.charAt(i) * y.charAt(i);
				i++;
			}
		}
		return Math.sqrt(sum);
	}
	
	/**
	 * getManhattanDistance method calculates the Manhattan distance between two strings.
	 * It calculates the total sum of the absolute difference between the ASCII of the 
	 * characters between the two strings. 
	 * @param x The first string.
	 * @param y The second string.
	 * @return The Manhattan distance between the two strings x and y.
	 */
	public static int getManhattanDistance(String x, String y)
	{
		// Make sure the two strings are all capital letters.
		x = x.toUpperCase();
		y = y.toUpperCase();
		
		int sum = 0;
		if(x.length() >= y.length())
		{
			int i=0;
			for(i=0;i<y.length();i++)
			{
				sum += Math.abs(x.charAt(i) - y.charAt(i));
			}
			while(i<x.length())
			{
				sum += x.charAt(i);
				i++;
			}
			
		}
		else
		{
			int i=0;
			for(i=0;i<x.length();i++)
			{
				sum += Math.abs(y.charAt(i) - x.charAt(i));
			}
			while(i<y.length())
			{
				sum += y.charAt(i);
				i++;
			}
		}
		return sum;
	}
	
	/**
	 * getEuclideanDistance method calculates the Euclidean distance between two Sequence objects 
	 * (test cases). The method goes through each line in the sequence, and it calculates the 
	 * Euclidean distance between the two corresponding lines. 
	 * @param x The first Sequence or test case.
	 * @param y The second Sequence or test case.
	 * @return The Euclidean distance between the two sequences x and y.
	 */
	public static double getEuclideanDistance(Sequence x, Sequence y)
	{
		double euclideanDistance = 0;
		if(x.getNumberOfLines() >= y.getNumberOfLines())
		{
			int i=0;
			for(i=0;i<y.getNumberOfLines();i++)
				euclideanDistance += getEuclideanDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<x.getNumberOfLines())
			{
				euclideanDistance += getEuclideanDistance(x.getLines().get(i),"");
				i++;
			}
		}
		else
		{
			int i=0;
			for(i=0;i<x.getNumberOfLines();i++)
				euclideanDistance += getEuclideanDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<y.getNumberOfLines())
			{
				euclideanDistance += getEuclideanDistance(y.getLines().get(i),"");
				i++;
			}
		}
		return euclideanDistance;
	}
	
	/**
	 * getManhattanDistance method calculates the Manhattan distance between two Sequence objects 
	 * (test cases). The method goes through each line in the sequence, and it calculates the 
	 * Manhattan distance between the two corresponding lines. 
	 * @param x The first Sequence or test case.
	 * @param y The second Sequence or test case.
	 * @return The Manhattan distance between the two sequences x and y.
	 */
	public static int getManhattanDistance(Sequence x, Sequence y)
	{
		int manhattanDistance = 0;
		if(x.getNumberOfLines() >= y.getNumberOfLines())
		{
			int i=0;
			for(i=0;i<y.getNumberOfLines();i++)
				manhattanDistance += getManhattanDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<x.getNumberOfLines())
			{
				manhattanDistance += getManhattanDistance(x.getLines().get(i),"");
				i++;
			}
		}
		else
		{
			int i=0;
			for(i=0;i<x.getNumberOfLines();i++)
				manhattanDistance += getManhattanDistance(x.getLines().get(i), y.getLines().get(i));
			
			while(i<y.getNumberOfLines())
			{
				manhattanDistance += getManhattanDistance(y.getLines().get(i),"");
				i++;
			}
		}
		return manhattanDistance;
	}
}
