package similaritymetrics;

import java.io.IOException;
import java.util.List;

import components.Sequence;
import stringdistances.StringDistance;

public class HammingMetric extends IntegerSimilarityMetric{

	public HammingMetric(Integer[][] values, List<Sequence> sequences) {
		super(values, sequences);
		// TODO Auto-generated constructor stub
	}
	
	public Integer pairWise(Sequence x, Sequence y) throws IOException
	{		
		return StringDistance.getHammingDistance(x, y);
	}

	@Override
	public Integer pairWise(String x, String y) throws IOException {
		// TODO Auto-generated method stub
		return StringDistance.getHammingDistance(x, y);
	}

}
