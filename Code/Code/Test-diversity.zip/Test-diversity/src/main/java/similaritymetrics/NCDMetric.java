package similaritymetrics;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.zip.GZIPOutputStream;

import components.Sequence;

public class NCDMetric extends DoubleSimilarityMetric {

	public NCDMetric(Double[][] values, List<Sequence> sequences) {
		super(values, sequences);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * compress method compresses a test cases using GZIP. The Sequence object is converted
	 * to a string, and then compressed.
	 * 
	 * @param seq The original test case as a Sequence object.
	 * @return The compressed string of the test case.
	 * @throws IOException
	 */
	public static String compress(Sequence seq) throws IOException
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip = new GZIPOutputStream(out);
        gzip.write(seq.toString().getBytes());
        gzip.close();
        return out.toString("ISO-8859-1");
	}
	
	public Double pairWise(Sequence x, Sequence y) throws IOException
	{
		Sequence xy = x.combineSequences(y);
		// NCD is the normalized compression distance
		double NCD = 0;
		int Cxy = compress(xy).length();
		int Cx = compress(x).length();
		int Cy = compress(y).length();
		
		NCD = (Cxy - (double)Math.min(Cx,Cy)) / Math.max(Cx, Cy);
		
		return NCD;
	}
	
	public Double pairWise(String x, String y) throws IOException
	{
		Sequence testCase1 = new Sequence("test1");
		testCase1.addLine(x);
		
		Sequence testCase2 = new Sequence("test2");
		testCase2.addLine(y);
		
		return pairWise(testCase1, testCase2);
	}
}
