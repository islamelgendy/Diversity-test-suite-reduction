package similaritymetrics;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import components.Sequence;

public abstract class IntegerSimilarityMetric extends SimilarityMetric{

	private Integer[][] values;
	
	public IntegerSimilarityMetric(Integer[][] values, List<Sequence> sequences) {
		super(sequences);
		this.values = values;
	}
	
	public Integer[][] getValues()
	{
		return values;
	}
	
	public void setValues(Number[][] values)
	{
		this.values = new Integer[values.length][values.length];
		for(int i=0;i<values.length;i++)
		{
			for(int j=0;j<values[i].length;j++)
				this.values[i][j] = values[i][j].intValue();
		}
	}
	
	public Double getAvgValue()
	{
		double sum = 0;
		int count = values.length*values.length-values.length;
		for(int r=0;r<values.length;r++)
		{
			for(int c=0;c<values[r].length;c++)
			{
				if(r!=c)
				{
					sum += values[r][c];
				}
			}
		}
		return sum/count;
	}
	
	public Number[][] getRandomDiverse(int newSize)
	{
		deepCopyRandomDiverseSequences();
		if(newSize >= getValues().length)
			return getValues();
		
		Random rand = new Random(System.currentTimeMillis());
		
		Number[][] random = getValues();
		int diff = getValues().length-newSize;
		int choiceMax = getValues().length;
		for(int i=0;i<diff;i++)
		{
			int choice = rand.nextInt(choiceMax--);
			random = removeIndex(random, choice);
			getRandomDiverseSequences().remove(choice);
		}
		return random;
	}
	
	public Number[][] getMostDiverse(int newSize)
	{
		deepCopyMostDiverseSequences();
		if(newSize >= getValues().length)
			return getValues();
		System.out.println("Processing most diverse...");
		
		Number[][] mostDiverse = getValues();
		int diff = getValues().length-newSize;
		for(int i=0;i<diff;i++)
		{
			int minPos = getMinIndexInteger(mostDiverse);
			mostDiverse = removeIndex(mostDiverse, minPos);
			getMostDiverseSequences().remove(minPos);
			//System.out.printf("\r%.2f%s",((double)i/diff*100),"%");
		}
		return mostDiverse;
	}
	
	public Number[][] getLeastDiverse(int newSize)
	{
		deepCopyLeastDiverseSequences();
		if(newSize >= getValues().length)
			return getValues();
		System.out.println("Processing least diverse...");
		
		Number[][] leastDiverse = getValues();
		int diff = getValues().length-newSize;
		for(int i=0;i<diff;i++)
		{
			int maxPos = getMaxIndexInteger(leastDiverse);
			leastDiverse = removeIndex(leastDiverse, maxPos);
			getLeastDiverseSequences().remove(maxPos);
			//System.out.printf("\r%.2f%s",((double)i/diff*100),"%");
		}
		return leastDiverse;
	}
	
	/**
	 * pairWise method computes the similarity metric between
	 * two test cases x and y. The values closer 
	 * to 0 indicates that the two test cases are very similar.
	 * 
	 * @param x The first test case 
	 * @param y The second test case
	 * @return Return the similarity value between x and y
	 * @throws IOException
	 */
	public abstract Integer pairWise(Sequence x, Sequence y) throws IOException;
	
	public abstract Integer pairWise(String x, String y) throws IOException;

	/**
	 * getAllPairWise method calculates all similarity values between the test cases, and return the
	 * values as a two dimensional array. For example, the index [2,5] will contain the
	 * similarity value of the third and sixth test cases.
	 * 
	 * @param sequences A list of sequences (test cases) objects
	 * @return Two dimensional array of double values for all the similarity values.
	 * @throws IOException
	 */
	public Integer[][] getAllPairWise() throws IOException
	{
		Integer [][] metricValues = new Integer[sequences.size()][sequences.size()];
		
		for(int i=0;i<sequences.size();i++)
		{
			System.out.printf("\r%.2f%s",((double)i/sequences.size()*100),"%");
			for(int j=i;j<sequences.size();j++){
				if(i==j)
					metricValues[i][j] = 0;
				else
					// remove the .getAsOneString() method in the parameter to use the other way of
					// calculating the metric line by line.
					metricValues[i][j] = metricValues[j][i] = pairWise(sequences.get(i).getAsOneString(), 
							sequences.get(j).getAsOneString());
			}
			//System.out.printf("\r%.2f%s",((double)i/sequences.size()*100),"%");
		}
		
		return metricValues;
	}
}
