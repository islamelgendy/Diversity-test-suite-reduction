package similaritymetrics;

import java.io.IOException;
import java.util.List;

import components.Sequence;
import stringdistances.StringDistance;

public class ManhattanMetric extends IntegerSimilarityMetric{

	public ManhattanMetric(Integer[][] values, List<Sequence> sequences) {
		super(values, sequences);
		// TODO Auto-generated constructor stub
	}
	
	public Integer pairWise(Sequence x, Sequence y) throws IOException
	{		
		return StringDistance.getManhattanDistance(x, y);
	}
	
	@Override
	public Integer pairWise(String x, String y) throws IOException {
		// TODO Auto-generated method stub
		return StringDistance.getManhattanDistance(x, y);
	}
}
