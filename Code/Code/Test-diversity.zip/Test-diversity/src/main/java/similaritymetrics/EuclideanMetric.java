package similaritymetrics;

import java.io.IOException;
import java.util.List;

import components.Sequence;
import stringdistances.StringDistance;

public class EuclideanMetric extends DoubleSimilarityMetric{

	public EuclideanMetric(Double[][] values, List<Sequence> sequences) {
		super(values, sequences);
		// TODO Auto-generated constructor stub
	}
		
	public Double pairWise(Sequence x, Sequence y) throws IOException
	{		
		return StringDistance.getEuclideanDistance(x, y);
	}

	@Override
	public Double pairWise(String x, String y) throws IOException {
		
		return StringDistance.getEuclideanDistance(x, y);
	}
}
