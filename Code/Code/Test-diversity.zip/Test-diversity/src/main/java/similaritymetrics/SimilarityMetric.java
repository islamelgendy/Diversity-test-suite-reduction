package similaritymetrics;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.opencsv.CSVWriter;

import components.Sequence;

public abstract class SimilarityMetric {

	protected List<Sequence> sequences;
	private List<Sequence> mostDiverseSequences;
	private List<Sequence> leastDiverseSequences;
	private List<Sequence> randomDiverseSequences;
	
	public static final String NCD_METRIC = "NCD";
	public static final String HAMMING_METRIC = "Hamming";
	public static final String LEVENSHTEIN_METRIC = "Levenshtein";
	public static final String EUCLIDEAN_METRIC = "Euclidean";
	public static final String MANHATTAN_METRIC = "Manhattan";
	
	public SimilarityMetric(List<Sequence> sequences)
	{
		this.sequences = sequences;
	}
	
	protected void deepCopyRandomDiverseSequences()
	{
		randomDiverseSequences = new ArrayList<Sequence>();
		for(Sequence s : sequences)
		{
			randomDiverseSequences.add(new Sequence(s));
		}
	}
	
	protected void deepCopyMostDiverseSequences()
	{
		mostDiverseSequences = new ArrayList<Sequence>();
		for(Sequence s : sequences)
		{
			mostDiverseSequences.add(new Sequence(s));
		}
	}
	
	protected void deepCopyLeastDiverseSequences()
	{
		leastDiverseSequences = new ArrayList<Sequence>();
		for(Sequence s : sequences)
		{
			leastDiverseSequences.add(new Sequence(s));
		}
	}
	
	public List<Sequence> getMostDiverseSequences()
	{
		return mostDiverseSequences;
	}
	
	public List<Sequence> getLeastDiverseSequences()
	{
		return leastDiverseSequences;
	}
	
	public List<Sequence> getRandomDiverseSequences()
	{
		return randomDiverseSequences;
	}
	
	/**
	 * getAvgValue method gets the average of the metric values calculated for a certain 
	 * test suite. The average ignores the values of the diagonal, as these are
	 * the values between the same test cases. 
	 * 
	 * @return The average values of the metric, disregarding the values in the diagonal.
	 */
	public abstract Double getAvgValue();
	
	/**
	 * getRandomDiverse method returns a new two dimensional array of the random test cases.
	 * The method discards from the original test suite the random test cases, until the new size is reached.
	 * 
	 * @param newSize The desired size of the random diverse test cases.
	 * @return The random diverse test cases are returned. If the new size is larger than
	 * or equal to the size of the original test suite, the original is returned without 
	 * modifications.
	 */
	public abstract Number[][] getRandomDiverse(int newSize);
	
	
	/**
	 * getMostDiverse method returns a new two dimensional array of the most diverse
	 * values of the test suites. The method discards from the original test suite the 
	 * test cases with the smallest values (most similar), until the new size is reached.
	 * 
	 * @param newSize The desired size of the most diverse test cases.
	 * @return The most diverse test cases are returned. If the new size is larger than
	 * or equal to the size of the original test suite, the original is returned without 
	 * modifications.
	 */
	public abstract Number[][] getMostDiverse(int newSize);
	
	
	/**
	 * getLeastDiverse method returns a new two dimensional array of the least diverse
	 * values of the test suites. The method discards from the original test suite the 
	 * test cases with the largest values (most dissimilar), until the new size is reached.
	 * 
	 * @param newSize The desired size of the most diverse test cases.
	 * @return The least diverse test cases are returned. If the new size is larger than
	 * or equal to the size of the original test suite, the original is returned without 
	 * modifications.
	 */
	public abstract Number[][] getLeastDiverse(int newSize);
	
	
	protected Number[][] removeIndex(Number[][] input, int index)
	{
		if(index >= input.length)
			return input;
		Number[][] output = new Number[input.length-1][input.length-1];
		
		for(int i=0;i<output.length;i++)
		{
			for(int j=0;j<output[i].length;j++)
			{
				if(i<index && j<index)
					output[i][j] = input[i][j];				
				else if(i<index && j>=index)
					output[i][j] = input[i][j+1];
				else if(i>=index && j<index)
					output[i][j] = input[i+1][j];
				else
					output[i][j] = input[i+1][j+1];	
			}
		}
		
		return output;
	}
	
	protected static int getMinIndexDouble(Number[][] input)
	{
		int minRow=0, minCol=1;
		for(int i=0;i<input.length;i++)
			for(int j=0;j<input[i].length;j++)
			{
				if(i!=j && input[i][j].doubleValue() < input[minRow][minCol].doubleValue())
				{
					minRow=i;
					minCol=j;
				}
			}
		Random r = new Random();
		if(r.nextInt(2) == 0)
			return minRow;
		else 
			return minCol;
	}
	
	protected static int getMaxIndexDouble(Number[][] input)
	{
		int maxRow=0, maxCol=1;
		for(int i=0;i<input.length;i++)
			for(int j=0;j<input[i].length;j++)
			{
				if(i!=j && input[i][j].doubleValue() > input[maxRow][maxCol].doubleValue())
				{
					maxRow=i;
					maxCol=j;
				}
			}
		Random r = new Random();
		if(r.nextInt(2) == 0)
			return maxRow;
		else 
			return maxCol;
	}
	
	protected static int getMinIndexInteger(Number[][] input)
	{
		int minRow=0, minCol=1;
		for(int i=0;i<input.length;i++)
			for(int j=0;j<input[i].length;j++)
			{
				if(i!=j && input[i][j].intValue() < input[minRow][minCol].intValue())
				{
					minRow=i;
					minCol=j;
				}
			}
		Random r = new Random();
		if(r.nextInt(2) == 0)
			return minRow;
		else 
			return minCol;
	}
	
	protected static int getMaxIndexInteger(Number[][] input)
	{
		int maxRow=0, maxCol=1;
		for(int i=0;i<input.length;i++)
			for(int j=0;j<input[i].length;j++)
			{
				if(i!=j && input[i][j].intValue() > input[maxRow][maxCol].intValue())
				{
					maxRow=i;
					maxCol=j;
				}
			}
		Random r = new Random();
		if(r.nextInt(2) == 0)
			return maxRow;
		else 
			return maxCol;
	}
	
	/**
	 * getCSVReadyData method takes the metric values and return it in a format
	 * ready for writing in CSV files.
	 * @param metricValues the metric values as a two dimensional array of integers or doubles.
	 * @param sequences The list of test cases each represented as a Sequence object.
	 * @return A list of strings, where each string represents a row in the CSV file.
	 */
	public static List<String[]> getCSVReadyData(Number [][] metricValues, List<Sequence> sequences)
	{
		List<String[]> data = new ArrayList<String[]>();
		String[] header = new String[sequences.size()+1];
		header[0] = "";
		for(int i=0;i<sequences.size();i++)
		{
			header[i+1] = sequences.get(i).getName();
		}
		data.add(header);
		
		for(int r=0;r<metricValues.length;r++)
		{
			String [] newRow = new String[metricValues[r].length+1];
			newRow[0] = header[r+1];
			for(int c=0;c<metricValues[r].length;c++)
				newRow[c+1] = metricValues[r][c].toString();
			
			data.add(newRow);
		}
		
		return data;
	}
	
	/**
	 * writeValuesIntoCSV method takes the data ready values and writes these values
	 * into a CSV file. You might need to call getCSVReadyData method first.
	 * @param values The metric values in a ready format. 
	 * @param filePath The CSV complete file name and path.
	 */
	public static void writeValuesIntoCSV(List<String[]> values, String filePath)
	{
		// first create file object for file placed at location 
	    // specified by filepath 
	    File file = new File(filePath); 
	    try { 
	        // create FileWriter object with file as parameter 
	        FileWriter outputfile = new FileWriter(file); 
	  
	        // create CSVWriter object filewriter object as parameter 
	        CSVWriter writer = new CSVWriter(outputfile); 
	  
	        // add data to csv 
	        for(String[] data : values)
	        {
	        	writer.writeNext(data);
	        }
	        
	        // closing writer connection 
	        writer.close(); 
	    } 
	    catch (IOException e) { 
	        // TODO Auto-generated catch block 
	        e.printStackTrace(); 
	    } 
	}
}
