package resultsanalysis;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.StringTokenizer;

public class ResultGroup implements Comparable<ResultGroup> {
	
	protected File mutationFile;
	protected File coverageFile;
	protected File mutationLogFile;
	protected SampleResult result;
	protected String folderName;
	
	public File getMutationFile() {
		return mutationFile;
	}
	public void setMutationFile(File mutationFile) {
		this.mutationFile = mutationFile;
	}
	public File getCoverageFile() {
		return coverageFile;
	}
	public void setCoverageFile(File coverageFile) {
		this.coverageFile = coverageFile;
	}
	public File getMutationLogFile() {
		return mutationLogFile;
	}
	public void setMutationLogFile(File mutationLogFile) {
		this.mutationLogFile = mutationLogFile;
	}
	public SampleResult getResult() {
		return result;
	}
	public void setFile(String fileName, File file)
	{
		if(fileName.equals("coverage"))
			setCoverageFile(file);
		else if(fileName.equals("mutation"))
			setMutationFile(file);
		else
			setMutationLogFile(file);
	}
	public void createSampleResult()
	{
		result = new SampleResult();
		
		try {
			parseMutationFile();
			parseMutationLogFile();
			parseCoverageFile();
			result.setFolderName(folderName);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	protected void parseMutationFile() throws IOException
	{
		Path path = Paths.get(mutationFile.getPath());
		List<String> lines = Files.readAllLines(path);
		String [] tokens = lines.get(1).split(",");
		result.setProjectID(tokens[0].trim());
		result.setTestSuiteSource(tokens[2].trim());
		result.setMutGenerated(parseNumber(tokens[4].trim()));
		result.setMutExcluded(parseNumber(tokens[5].trim()));
		result.setMutCovered(parseNumber(tokens[6].trim()));
		result.setMutKilled(parseNumber(tokens[7].trim()));
		result.calculateMS();
	}
	protected void parseMutationLogFile() throws IOException
	{
		int min,sec,totalSec;

		Path path = Paths.get(mutationLogFile.getPath());
		List<String> lines = Files.readAllLines(path);
		for(String line : lines)
		{
			if(line.startsWith("Total time: "))
			{
				String time = line.substring(line.indexOf(':')+1).trim();
				try {
					StringTokenizer strToken = new StringTokenizer(time, " ");
					min = Integer.parseInt(strToken.nextToken().trim());
					String unit = strToken.nextToken();
					if(unit.equals("seconds"))
					{
						sec = min;
						min = 0;
					}
					else if(strToken.hasMoreTokens()) {
						sec = Integer.parseInt(strToken.nextToken().trim());
						strToken.nextToken();
					}
					else
						sec = 0;

					totalSec = min*60 + sec;
					result.setMutRuntime(totalSec);
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
	}
	protected void parseCoverageFile() throws IOException
	{
		Path path = Paths.get(coverageFile.getPath());
		List<String> lines = Files.readAllLines(path);
		String [] tokens = lines.get(1).split(",");
		result.setLineTotal(parseNumber(tokens[4].trim()));
		result.setLinesCovered(parseNumber(tokens[5].trim()));
		result.setBranchesTotal(parseNumber(tokens[6].trim()));
		result.setBranchesCovered(parseNumber(tokens[7].trim()));
	}
	private int parseNumber(String str)
	{
		try
		{
			return Integer.parseInt(str);
		}
		catch(NumberFormatException ex)
		{
			return 0;
		}
	}
	public void parse(String parentFolder)
	{
		int slashPos = parentFolder.lastIndexOf('/');
		parentFolder = parentFolder.substring(slashPos+1);
		folderName = parentFolder;
	}
	@Override
	public String toString() {
		return "ResultGroup [result=" + result + ", folderName=" + folderName + "]";
	}
	@Override
	public int compareTo(ResultGroup o) {
		// TODO Auto-generated method stub
		return folderName.compareTo(o.folderName);
	}
	
}
