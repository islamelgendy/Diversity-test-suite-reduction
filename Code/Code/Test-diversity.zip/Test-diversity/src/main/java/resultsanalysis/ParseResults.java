package resultsanalysis;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.opencsv.CSVWriter;
import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import statisticaltesting.Statistics;
import statisticaltesting.Utils;

public class ParseResults {

	private List<ResultGroup> attemptGroups;
	private List<File> allFiles;
	private List<ArrayList<File>> testResults;
	private boolean parsingAttempts;

	public ParseResults(boolean parseAttempts)
	{
		this.parsingAttempts = parseAttempts;
		attemptGroups = new ArrayList<ResultGroup>();
		testResults = new ArrayList<ArrayList<File>>();
	}

	public int getSize(String folderName)
	{
		int size = 0;
		String trimmed = folderName.substring(4);
		try {
			size = Integer.parseInt(trimmed);
		}
		catch(NumberFormatException ex)
		{
			System.err.println("Error in folder name");
		}
		return size;
	}

	/**
	 * The method parseFolderName sets the used similarity metric, attempt number, and
	 * test suite size. 
	 * @param folderName the name of the folder containing the test result.
	 * @param record An object of the SampleResult, which is changed with the new info.
	 */
	public void parseFolderName(String folderName, SampleResult record)
	{
		if(folderName.contains("DiverseTestSuiteSize"))
		{
			// parse the similarity metric out of the folder name
			int leastMostPos = folderName.indexOf("Least");
			if(leastMostPos == -1)
				leastMostPos = folderName.indexOf("Most");

			String metric = folderName.substring(0, leastMostPos);
			record.setSimilarityMetric(metric);

			// parse the attempt number out of the folder name
			int numPos = folderName.indexOf("Num");
			if(numPos != -1)
			{
				String attempt = folderName.substring(numPos+3).trim();
				record.setAttemptNumber(Integer.parseInt(attempt));
			}

			// parse the test suite size out of the folder name
			int sizePos = folderName.indexOf("Size");
			if(numPos != -1 && sizePos != -1)
			{
				String size = folderName.substring(sizePos+4, numPos).trim();
				record.setTestSuiteSize(Integer.parseInt(size));
			}
		}
	}

	public List<File> listFiles(File rootFolder)
	{
		allFiles = new ArrayList<File>();

		return listFilesForFolder(rootFolder);
	}

	public List<File> listFilesForFolder(final File folder) {
		for (final File fileEntry : folder.listFiles()) {

			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				if(fileEntry.getName().endsWith(".log") 
						&& !fileEntry.getName().contains("pl.log")
						&& !fileEntry.getName().contains("mutants.log")
						&& !fileEntry.getName().contains("failing.log")
						&& !fileEntry.getName().contains("fix_test_suite"))
					allFiles.add(fileEntry);
				else if(fileEntry.getName().equals("coverage") 
						|| fileEntry.getName().equals("mutation") )
				{
					allFiles.add(fileEntry);
				}
			}
		}
		return allFiles;
	}

	public void addTestResult(ArrayList<File> files) {
		testResults.add(files);
	}

	private void groupFiles()
	{
		String parent = null;
		ResultGroup group;
		for(ArrayList<File> list : testResults)
		{

				group = new ResultGroup();
				// first file (prob coverage file)
				File f1 = list.get(0);
				group.setFile(f1.getName(), f1);

				// second file (prob mutation.log file)
				File f2 = list.get(1);

				group.setFile(f2.getName(), f2);

				// third file (prob mutation file)
				File f3 = list.get(2);
				group.setFile(f3.getName(), f3);

				if(f1.getName().contains("coverage"))
					parent = f1.getParent();
				else if(f2.getName().contains("coverage"))
					parent = f2.getParent();
				else
					parent = f3.getParent();

				group.parse(parent);

				if(parsingAttempts) { 
					AttemptGroup aGroup = new AttemptGroup(group);
					aGroup.parse(parent); 
					attemptGroups.add(aGroup); 
				} 
				else
					attemptGroups.add(group);
			
		}
		attemptGroups.sort(null);
	}

	public void writeIntoCSVFiles()
	{
		groupFiles();

		for(ArrayList<File> list : testResults)
		{
			File correctFile=null;
			if(list.get(0).getName().contains("coverage"))
				correctFile = list.get(0);
			else if(list.get(1).getName().contains("coverage"))
				correctFile = list.get(1);
			else
				correctFile = list.get(2);
			try {
				if(parsingAttempts)
					writeIntoCSVFileInOrder(correctFile.getParentFile().getParent());
				else
					writeIntoCSVFile(correctFile.getParentFile().getParent());
			}
			catch(IndexOutOfBoundsException ex)
			{
				System.err.println("No results found.");
			}
		}
	}

	private void writeIntoCSVFile(String filePath)
	{
		// first create file object for file placed at location 
		// specified by filepath 
		File file = new File(filePath + "/results.csv"); 
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter object filewriter object as parameter 
			CSVWriter writer = new CSVWriter(outputfile); 

			writer.writeNext(SampleResult.getResultHeader());

			// add data to csv 
			for(ResultGroup group : attemptGroups)
			{
				group.createSampleResult();

				writer.writeNext(group.getResult().getResultRecord());	
			}

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}

	private void writeIntoCSVFiles(String filePath)
	{
		// first create file object for file placed at location 
		// specified by filepath 
		File mostDiverseFile = new File(filePath + "/mostDiverse.csv");
		File leastDiverseFile = new File(filePath + "/leastDiverse.csv");
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputMostFile = new FileWriter(mostDiverseFile);
			FileWriter outputLeastFile = new FileWriter(leastDiverseFile);

			// create CSVWriter object filewriter object as parameter 
			CSVWriter mostDiverseWriter = new CSVWriter(outputMostFile); 
			CSVWriter leastDiverseWriter = new CSVWriter(outputLeastFile);

			mostDiverseWriter.writeNext(SampleResult.getAttemptHeader());
			leastDiverseWriter.writeNext(SampleResult.getAttemptHeader());

			// add data to csv 
			for(ResultGroup group : attemptGroups)
			{
				group.createSampleResult();

				if(parsingAttempts)
				{
					AttemptGroup aGroup = (AttemptGroup)group;
					// If the group belongs to the same size folder
					if(aGroup.getSize() == getSize(mostDiverseFile.getParentFile().getName()))
					{
						if(aGroup.getLeastOrMostDiverse().equals("Least diverse"))
							leastDiverseWriter.writeNext(aGroup.getResult().getAttemptRecord());
						else
							mostDiverseWriter.writeNext(aGroup.getResult().getAttemptRecord());
					}
				}
			}

			// closing writer connection 
			mostDiverseWriter.close(); 
			leastDiverseWriter.close();
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}

	private void writeIntoCSVFileInOrder(String filePath)
	{
		// first create file object for file placed at location 
		// specified by filepath 
		File file = new File(filePath + "/resultsInOrder.csv"); 
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter object filewriter object as parameter 
			CSVWriter writer = new CSVWriter(outputfile); 

			writer.writeNext(SampleResult.getHeaderInOrder());
			List<String[]> lines = new ArrayList<String[]>();

			ArrayList<String> record = new ArrayList<String>();

			// Define the MS arrayValues to later get the statistical analysis
			ArrayList<Double> mostDiverseMS = new ArrayList<Double>();
			ArrayList<Double> leastDiverseMS = new ArrayList<Double>();

			// add data to csv 
			for(ResultGroup group : attemptGroups)
			{
				group.createSampleResult();

				if(parsingAttempts)
				{
					AttemptGroup aGroup = (AttemptGroup)group;
					// If the group belongs to the same size folder
					if(aGroup.getSize() == getSize(file.getParentFile().getName()))
					{
						if(aGroup.getLeastOrMostDiverse().equals("Least diverse"))
						{
							record = new ArrayList<String>();
							String [] values = aGroup.getResult().getLeastDiverseRecord();
							Double MS = Double.parseDouble(values[10]);
							if(MS.isNaN())
								leastDiverseMS.add(0.);
							else
								leastDiverseMS.add(MS);
							record.addAll(Arrays.asList(values));
						}
						else
						{
							String [] values = aGroup.getResult().getMostDiverseRecord();
							Double MS = Double.parseDouble(values[3]);
							if(MS.isNaN())
								mostDiverseMS.add(0.);
							else
								mostDiverseMS.add(MS);
							record.addAll(Arrays.asList(values));
							lines.add(record.toArray(new String[0]));
						}
					}
				}
			}
			// Calculate the average for the MS
			double leastAvg = Utils.getAvg(leastDiverseMS);
			double mostAvg = Utils.getAvg(mostDiverseMS);
			String [] avgLine = new String[] {"","","","","","","","","","Least Avg MS",
					""+leastAvg, "", "", "", "", "", "", "", "", "Most Avg MS", ""+mostAvg};
			lines.add(avgLine);

			// calculate the pvalue and effect size using the MS values
			// and add them to the list of lines.
			double pvalue = Statistics.getPValue(mostDiverseMS.toArray(new Double[0]), 
					leastDiverseMS.toArray(new Double[0]));
			double effectSize = Statistics.A12EffectSize(mostDiverseMS.toArray(new Double[0]), 
					leastDiverseMS.toArray(new Double[0]), leastDiverseMS.size());
			lines.add(new String[] {"p-value:", ""+pvalue});
			lines.add(new String[] {"A12 Effect size:", ""+effectSize});

			writer.writeAll(lines);

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}
}
