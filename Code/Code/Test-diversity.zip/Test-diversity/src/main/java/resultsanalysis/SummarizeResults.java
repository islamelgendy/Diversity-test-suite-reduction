package resultsanalysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.opencsv.CSVWriter;

import statisticaltesting.Statistics;
import statisticaltesting.Utils;

/**
 * This class searches for the CSV files named resultsInOrder.csv
 * and parses these files to extract the summary information needed
 * which are the least diverse average, most diverse average, p-value,
 * and effect size.
 * The data is written into a new CSV file that contains these summary info
 * and Python file is created that plots the data into a box plots.
 * 
 * @author 
 *
 */
public class SummarizeResults {

	private List<SummaryDataRecord> randoopList;
	private List<SummaryDataRecord> evosuiteList;
	private Set<String> fileKeys;
	private Map<String, File> resultsMap;
	private Map<String, File> totalTimesMap;
	private double randoopOrginalValue;
	private double evosuiteOrginalValue;

	public SummarizeResults(double randoopOrgValue, double evosuiteOrgValue)
	{
		this.randoopOrginalValue = randoopOrgValue;
		this.evosuiteOrginalValue = evosuiteOrgValue;
		randoopList = new ArrayList<SummaryDataRecord>();
		evosuiteList = new ArrayList<SummaryDataRecord>();
		fileKeys = new HashSet<String>();
		resultsMap = new LinkedHashMap<>();
		totalTimesMap = new LinkedHashMap<>();
	}

	public Map<String, File> getResultsMap() {
		return resultsMap;
	}

	public Map<String, File> getTotalTimesMap() {
		return totalTimesMap;
	}

	public Set<String> getFileKeys() {
		return fileKeys;
	}

	public List<SummaryDataRecord> getRandoopList() {
		return randoopList;
	}

	public List<SummaryDataRecord> getEvosuiteList() {
		return evosuiteList;
	}

	public void listFilesForFolder(final File folder) {
		for (final File fileEntry : folder.listFiles()) {

			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				if(fileEntry.getName().equals("resultsInOrder.csv"))
				{
					fileKeys.add(fileEntry.getParent());
					resultsMap.put(fileEntry.getParent(), fileEntry);
				}
				else if(fileEntry.getName().equals("total time"))
					totalTimesMap.put(fileEntry.getParent(), fileEntry);
			}
		}
	}

	public void buildFileMaps(File rootFolder)
	{
		// Loop through the folders in the root directory
		// Loop through each folder and build the results and total times maps
		for (final File fileEntry : rootFolder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			}
		}
	}

	public SummaryDataRecord extractInfo(String fileKey)
	{
		SummaryDataRecord dataRecord = new SummaryDataRecord();
		File results = resultsMap.get(fileKey);
		File totalTime = totalTimesMap.get(fileKey);
		extractTimeInfo(totalTime, dataRecord);
		extractResultsInfo(results, dataRecord);

		//Extract the used metric
		String metric = getUsedMetric(fileKey);
		dataRecord.setMetricUsed(metric);

		//Extract the test suite size
		int size = getTestSuiteSize(fileKey);
		dataRecord.setTestSuiteSize(size);

		return dataRecord;
	}

	public void extractTimeInfo(File totalTimeFile, SummaryDataRecord dataRecord)
	{
		try (BufferedReader br = new BufferedReader(new FileReader(totalTimeFile.getAbsolutePath()))) {
			String line;
			while ((line = br.readLine()) != null) {
				// process the line.
				if(line.startsWith("Time for reduction:"))
				{
					int colonPos = line.indexOf(':');
					int secondsPos = line.indexOf("seconds");
					String time = line.substring(colonPos+1, secondsPos).trim();
					dataRecord.setReductionTime(Double.parseDouble(time));
				}
				else if(line.startsWith("Time to analyis the mutation and coverage:"))
				{
					int colonPos = line.indexOf(':');
					int minsPos = line.indexOf("minutes");
					int lastandPos = line.lastIndexOf("and") + 3;
					int secondsPos = line.indexOf("seconds");
					String min = line.substring(colonPos+1, minsPos).trim();
					String sec = line.substring(lastandPos+1, secondsPos).trim();
					dataRecord.setAnalysisTime(min + " min " + sec + " sec");
					int totalSeconds = Integer.parseInt(min)*60 + Integer.parseInt(sec);
					dataRecord.setAnalysisTimeInSeconds(totalSeconds);
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void extractResultsInfo(File resultsFile, SummaryDataRecord dataRecord)
	{
		try (BufferedReader br = new BufferedReader(new FileReader(resultsFile.getAbsolutePath()))) {
			String line;
			while ((line = br.readLine()) != null) {
				// process the line.
				if(line.contains("Least Avg MS"))
				{
					String[] data = line.split(",");
					//Least diverse average value is at index 10
					String leastMS = removeDoubleQuotes(data[10]);
					dataRecord.setLeastDiverseAvg(Double.parseDouble(leastMS));

					//Most diverse average value is at index 20
					String mostMS = removeDoubleQuotes(data[20]);
					dataRecord.setMostDiverseAvg(Double.parseDouble(mostMS));
				}
				else if(line.contains("p-value"))
				{
					String[] data = line.split(",");
					String stringValue = removeDoubleQuotes(data[1]);
					dataRecord.setpValue(Double.parseDouble(stringValue));
				}
				else if(line.contains("Effect size"))
				{
					String[] data = line.split(",");
					String stringValue = removeDoubleQuotes(data[1]);
					dataRecord.setEffectSize(Double.parseDouble(stringValue));
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getUsedMetric(String fileName)
	{
		if(fileName.contains("Euclidean"))
			return "Euclidean";
		else if(fileName.contains("Hamming"))
			return "Hamming";
		else if(fileName.contains("Levenshtein"))
			return "Levenshtein";
		else if(fileName.contains("Manhattan"))
			return "Manhattan";
		else if(fileName.contains("NCD"))
			return "NCD";

		return null;
	}

	public int getTestSuiteSize(String fileName)
	{
		int sizePos = fileName.lastIndexOf("size");
		String size = fileName.substring(sizePos + 4);
		return Integer.parseInt(size.trim());
	}

	public String removeDoubleQuotes(String str)
	{
		return str.substring(1, str.length()-1);
	}

	public void extractInfo()
	{
		SummaryDataRecord record;
		for(String key : fileKeys)
		{
			record = extractInfo(key);
			if(key.contains("EvoSuite"))
				evosuiteList.add(record);
			else if(key.contains("Randoop"))
				randoopList.add(record);
		}
		randoopList.sort(null);
		evosuiteList.sort(null);
	}

	public static String [] getSummaryLine()
	{
		return new String[] { "Metric", "Size", "Time of reduction in sec", "Analysis time",
				"Least Diverse Avg", "Most Diverse Avg", "P-Value", "Effect Size"}; 
	}

	public static String [] getSummaryFirstLine(String project)
	{
		return new String[] { project, "", "Time of reduction in sec", "", "Analysis time", "",
				"Least Diverse Avg", "", "Most Diverse Avg", "", "P-Value", "", "Effect Size", ""}; 
	}

	public static String [] getSummarySecondLine()
	{
		return new String[] { "", "Size", "Randoop", "EvoSuite", "Randoop", "EvoSuite"
				, "Randoop", "EvoSuite", "Randoop", "EvoSuite", "Randoop", "EvoSuite", "Randoop", "EvoSuite"}; 
	}

	public void writeIntoSummaryCSVFileInOrder(String filePath)
	{
		// first create file object for file placed at location 
		// specified by filepath 
		File file = new File(filePath + "/summary.csv"); 
		double totalAnalysisRandoopTime = 0;
		double totalAnalysisEvoSuiteTime = 0;
		double totalAnalysisTime = 0;
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter object filewriter object as parameter 
			CSVWriter writer = new CSVWriter(outputfile); 

			//get project name
			int lastSlashPos = filePath.lastIndexOf('/');
			String projectName = filePath.substring(lastSlashPos+1);

			if(getRandoopList().size() == getEvosuiteList().size()) {
				writer.writeNext(getSummaryFirstLine(projectName));
				writer.writeNext(getSummarySecondLine());

				for(int i=0;i<getRandoopList().size();i++)
				{
					writer.writeNext(SummaryDataRecord.toCSVRecord(getRandoopList().get(i),
							getEvosuiteList().get(i)));
					totalAnalysisRandoopTime += getRandoopList().get(i).getAnalysisTimeInSeconds();
					totalAnalysisEvoSuiteTime += getEvosuiteList().get(i).getAnalysisTimeInSeconds();
				}
				totalAnalysisTime = totalAnalysisRandoopTime + totalAnalysisEvoSuiteTime;
				writer.writeNext(new String[] {"Total", "in sec", "", "", ""+totalAnalysisRandoopTime, 
						""+totalAnalysisEvoSuiteTime, ""+totalAnalysisTime});
				totalAnalysisRandoopTime /= 60;
				totalAnalysisEvoSuiteTime /= 60;
				totalAnalysisTime /= 60;
				writer.writeNext(new String[] {"Total", "in min", "", "", ""+totalAnalysisRandoopTime, 
						""+totalAnalysisEvoSuiteTime, ""+totalAnalysisTime});
			}
			else {
				writer.writeNext(new String[] {"Project",projectName});
				writer.writeNext(new String[] {"",""});
				writer.writeNext(new String[] {"Tool", "EvoSuite",""});
				writer.writeNext(getSummaryLine());

				for(int i=0;i<getEvosuiteList().size();i++)
				{
					writer.writeNext(getEvosuiteList().get(i).toCSVRecord());
				}

				writer.writeNext(new String[] {"",""});
				writer.writeNext(new String[] {"Tool", "Randoop",""});
				writer.writeNext(getSummaryLine());
				for(int i=0;i<getRandoopList().size();i++)
				{
					writer.writeNext(getRandoopList().get(i).toCSVRecord());
				}
			}

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}

	private void writeIntoTexFile(File texFile, String projectName)
	{
		try { 
			// create FileWriter object with file as parameter 
			PrintWriter writer = new PrintWriter(texFile);

			writer.println("\\begin{table*}[ht]");
			writer.println("\t\\centering");
			writer.println();
			writer.println("\t\\caption{");
			writer.println("\t\t\\label{table:" + projectName + "-table}");
			writer.println("\t\tThe reduction analysis for the " + projectName + " project. $\\alpha$ denotes a value <0.0001.");
			writer.println("\t}");

			writer.println("\t\\begin{tabular}{ l*{13}{r} }");
			writer.println("\t\\toprule");
			writer.println("\t\t{\\bf Metric}  &");
			writer.println("\t\t{\\bf \\makecell{Size} } &");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf \\makecell{Reduction time \\\\ in seconds} } &");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf \\makecell{Analysis time \\\\ in seconds} } &");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf \\makecell{Least diverse \\\\ avg} } &");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf \\makecell{Most diverse \\\\ avg} }&");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf p-Value} &");
			writer.println("\t\t\\multicolumn{2}{c}{\\bf Effect size} \\\\");
			writer.println();
			writer.println("\t\t & & Rand & Evo & Rand & Evo & Rand & Evo & Rand & Evo & Rand & Evo & Rand & Evo \\\\");
			writer.println("\t\\midrule");
			writer.println();
			writer.println("\t\\input table-data/" + projectName + "-data");
			writer.println();
			writer.println("\t\\bottomrule");
			writer.println("\t\\end{tabular}");
			writer.println();
			writer.println("\\end{table*}");

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}
	}
	
	private void writeIntoTexDataFile(File texDataFile, String projectName)
	{
		try { 
			// create FileWriter object with file as parameter 
			PrintWriter writer = new PrintWriter(texDataFile);
			String metricUsed = "";
			for(int i=0;i<getRandoopList().size();i++)
			{
				SummaryDataRecord randoopRecord = getRandoopList().get(i);
				SummaryDataRecord evosuiteRecord = getEvosuiteList().get(i);

				if(!metricUsed.equals(randoopRecord.getMetricUsed()))
				{
					metricUsed = randoopRecord.getMetricUsed();
					writer.print("\\multirow{3}{*}{" + metricUsed + "} ");
				}
				String randoopFormattedString = String.format("%.1f", randoopRecord.getReductionTime());
				String evosuiteFormattedString = String.format("%.1f", evosuiteRecord.getReductionTime());
				writer.println("& " + randoopRecord.getTestSuiteSize() + " & " + 
						randoopFormattedString + " & " + 
						evosuiteFormattedString + " & ");
				
				randoopFormattedString = String.format("%d", randoopRecord.getAnalysisTimeInSeconds());
				evosuiteFormattedString = String.format("%d", evosuiteRecord.getAnalysisTimeInSeconds());
				writer.println(randoopFormattedString + " & " + evosuiteFormattedString + " & ");
				
				randoopFormattedString = String.format("%.1f", randoopRecord.getLeastDiverseAvg());
				evosuiteFormattedString = String.format("%.1f", evosuiteRecord.getLeastDiverseAvg());
				writer.println(randoopFormattedString + " & " + evosuiteFormattedString + " & ");
				
				randoopFormattedString = String.format("%.1f", randoopRecord.getMostDiverseAvg());
				evosuiteFormattedString = String.format("%.1f", evosuiteRecord.getMostDiverseAvg());
				writer.println(randoopFormattedString + " & " + evosuiteFormattedString + " & ");
				
				if(randoopRecord.getpValue() < 0.001)
					randoopFormattedString = "$\\alpha$";
				else
					randoopFormattedString = String.format("%.3f", randoopRecord.getpValue());
				if(evosuiteRecord.getpValue() < 0.001)
					evosuiteFormattedString = "$\\alpha$";
				else
					evosuiteFormattedString = String.format("%.3f", evosuiteRecord.getpValue());
				writer.println(randoopFormattedString + " & " + evosuiteFormattedString + " & ");
				
				randoopFormattedString = String.format("%.2f", randoopRecord.getEffectSize());
				evosuiteFormattedString = String.format("%.2f", evosuiteRecord.getEffectSize());
				writer.println(randoopFormattedString + " & " + evosuiteFormattedString + " \\\\ ");
				
				if(i<getRandoopList().size()-1 && (!metricUsed.equals(getRandoopList().get(i+1).getMetricUsed())))
					writer.println("\\midrule");
			}

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}
	}

	public void writeIntoTexFiles(String filePath)
	{
		//get project name
		int lastSlashPos = filePath.lastIndexOf('/');
		String projectName = filePath.substring(lastSlashPos+1);

		// create tex files placed at location specified by filepath 
		File texFile = new File(filePath + "/" + projectName + ".tex");
		File texDataFile = new File(filePath + "/" + projectName + "-data.tex");
		File texRandoopDataFile = new File(filePath + "/" + projectName + "-randoop-data.tex");
		File texEvoSuiteDataFile = new File(filePath + "/" + projectName + "-evosuite-data.tex");
		
		writeIntoTexFile(texFile, projectName);
		writeIntoTexDataFile(texDataFile, projectName);
		writeIntoTexRandoopDataFile(texRandoopDataFile, projectName);
		writeIntoTexEvosuiteDataFile(texEvoSuiteDataFile, projectName);
	}

	public void writeIntoPythonFile(String filePath)
	{
		//get project name
		int lastSlashPos = filePath.lastIndexOf('/');
		String projectName = filePath.substring(lastSlashPos+1);

		try { 
			PrintWriter pw = new PrintWriter("/home/islam/MyWork/Code/hello/" + projectName+ "plot.py");
			writePythonHeader(pw);

			//Write down the Euclidean values
			pw.println("#" + projectName + " Euclidean");
			writeDataSection(pw, "Euclidean", 1);

			//Write down the Hamming values
			pw.println("#" + projectName + " Hamming");
			writeDataSection(pw, "Hamming", 2);

			//Write down the Levenshtein values
			pw.println("#" + projectName + " Levenshtein");
			writeDataSection(pw, "Levenshtein", 3);

			//Write down the Manhattan values
			pw.println("#" + projectName + " Manhattan");
			writeDataSection(pw, "Manhattan", 4);

			//Write down the NCD values
			pw.println("#" + projectName + " NCD");
			writeDataSection(pw, "NCD", 5);

			pw.println();
			//Write down the figure sections
			writeFigureSection(pw, projectName, "Euclidean", 1);
			writeFigureSection(pw, projectName, "Hamming", 2);
			writeFigureSection(pw, projectName, "Levenshtein", 3);
			writeFigureSection(pw, projectName, "Manhattan", 4);
			writeFigureSection(pw, projectName, "NCD", 5);
			writeCombinedFigureSection(pw, projectName);

			pw.close();
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}

	private void writePythonHeader(PrintWriter pw)
	{
		pw.println("import numpy as np");
		pw.println("import matplotlib.pyplot as plt");
		pw.println();
		pw.println("plt.style.use('ggplot')");

		pw.println("extraticks=[" + randoopOrginalValue + ", " + evosuiteOrginalValue + "]");
		pw.println();
	}

	private List<Double> getLeastValuesForMetric(List<SummaryDataRecord> listDataRecord, String metricUsed)
	{
		List<Double> values = new ArrayList<Double>();
		for(SummaryDataRecord record : listDataRecord)
		{
			if(record.getMetricUsed().equals(metricUsed))
				values.add(record.getLeastDiverseAvg());
		}

		return values;
	}

	private List<Double> getMostValuesForMetric(List<SummaryDataRecord> listDataRecord, String metricUsed)
	{
		List<Double> values = new ArrayList<Double>();
		for(SummaryDataRecord record : listDataRecord)
		{
			if(record.getMetricUsed().equals(metricUsed))
				values.add(record.getMostDiverseAvg());
		}

		return values;
	}

	private void writeValues(PrintWriter pw, List<Double> values)
	{
		pw.print("[");
		if(values.size()>0) {
			for(int i=0;i<values.size()-1;i++)
				pw.print(values.get(i) + ", ");

			pw.println(values.get(values.size()-1) + "]");
		}
		else
			pw.println("]");
	}

	private void writeDataSection(PrintWriter pw, String metricUsed, int index)
	{
		List<Double> randoopLeastValues = getLeastValuesForMetric(randoopList, metricUsed);
		List<Double> randoopMostValues = getMostValuesForMetric(randoopList, metricUsed);
		pw.print("RL" + index + " = ");
		writeValues(pw, randoopLeastValues);
		pw.print("RM" + index + " = ");
		writeValues(pw, randoopMostValues);

		List<Double> evosuiteLeastValues = getLeastValuesForMetric(evosuiteList, metricUsed);
		List<Double> evosuiteMostValues = getMostValuesForMetric(evosuiteList, metricUsed);
		pw.print("EL" + index + " = ");
		writeValues(pw, evosuiteLeastValues);
		pw.print("EM" + index + " = ");
		writeValues(pw, evosuiteMostValues);
	}

	private void writeFigureSection(PrintWriter pw, String projectName, String metricUsed, int index)
	{
		pw.println("newdata = [RL" + index + ", RM" + index + ", EL" + index + ", EM" + index + "]");
		pw.println("fig" + index + ", ax" + index + " = plt.subplots()");
		pw.println("ax" + index + ".axvline(" + randoopOrginalValue + ", color='b')");
		pw.println("ax" + index + ".axvline(" + evosuiteOrginalValue + ")");
		//pw.println("ax" + index + ".set_xticks([10,20,30,40,50,60,70,80,90] + extraticks)");
		pw.println("ax" + index + ".text(" + (randoopOrginalValue-1) + ", 4.6, '" + randoopOrginalValue + "')");
		pw.println("ax" + index + ".text(" + (randoopOrginalValue-5) + ", 4.8, 'Randoop_Org')");
		pw.println("ax" + index + ".text(" + (evosuiteOrginalValue-1) + ", 4.6, '" + evosuiteOrginalValue + "')");
		pw.println("ax" + index + ".text(" + (evosuiteOrginalValue-5) + ", 4.8, 'EvoSuite_Org')");
		pw.println("plt.subplots_adjust(right=0.95)");
		pw.println("fig = plt.gcf()");
		pw.println("fig.set_size_inches(8.5, 5)");
		pw.println("ax" + index + ".set_xlabel('Mutation Score')");
		pw.println("ax" + index + ".set_ylabel('" + metricUsed + "')");
		pw.println("ax" + index + ".set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])");
		//pw.println("ax" + index + ".set_title(' " + projectName + "analysis')");
		pw.println("ax" + index + ".boxplot(newdata, vert=False)");
		pw.println();
		pw.println("fig.savefig('images/" + projectName + "_" + metricUsed + ".jpg', dpi=100)");
		pw.println();
	}

	private void writeCombinedFigureSection(PrintWriter pw, String projectName)
	{
		pw.println("newdata = [RL1, RL2, RL3, RL4, RL5,");
		pw.println("\t\tRM1, RM2, RM3, RM4, RM5,");
		pw.println("\t\tEL1, EL2, EL3, EL4, EL5,");
		pw.println("\t\tEM1, EM2, EM3, EM4, EM5]");
		pw.println("fig6, ax6 = plt.subplots()");
		pw.println("ax6.axvline(" + randoopOrginalValue + ", color='b')");
		pw.println("ax6.axvline(" + evosuiteOrginalValue + ")");
		pw.println("ax6.text(" + (randoopOrginalValue-1) + ", 21, '" + randoopOrginalValue + "')");
		pw.println("ax6.text(" + (randoopOrginalValue-5) + ", 22, 'Randoop_Org')");
		pw.println("ax6.text(" + (evosuiteOrginalValue-1) + ", 21, '" + evosuiteOrginalValue + "')");
		pw.println("ax6.text(" + (evosuiteOrginalValue-5) + ", 22, 'EvoSuite_Org')");
		//pw.println("ax6.set_xticks([10,20,30,40,50,60,70,80,90] + extraticks)");
		pw.println("plt.subplots_adjust(right=0.95)");
		pw.println("fig = plt.gcf()");
		pw.println("fig.set_size_inches(8.5, 5)");
		pw.println("ax6.set_xlabel('Mutation Score')");
		pw.println("ax6.set_yticklabels(['Euc_RL','Ham_RL','Lev_RL','Man_RL','Ncd_RL',");
		pw.println("\t\t\t'Euc_RM','Ham_RM','Lev_RM','Man_RM','Ncd_RM',");
		pw.println("\t\t\t'Euc_EL','Ham_EL','Lev_EL','Man_EL','Ncd_EL',");
		pw.println("\t\t\t'Euc_EM','Ham_EM','Lev_EM','Man_EM','Ncd_EM'])");
		//pw.println("ax6.set_title(' " + projectName + "analysis')");
		pw.println("ax6.boxplot(newdata, vert=False)");
		pw.println();
		pw.println("fig.savefig('images/" + projectName + ".jpg', dpi=100)");
	}

	private void writeIntoTexRandoopDataFile(File texDataFile, String projectName)
	{
		
		try { 
			// create FileWriter object with file as parameter 
			PrintWriter writer = new PrintWriter(texDataFile);
			
			writer.print("\\multirow{5}{*}{" + projectName + "} & ");
			String metricUsed = "";
			for(int i=0;i<getRandoopList().size();i++)
			{
				SummaryDataRecord randoopRecord = getRandoopList().get(i);
				SummaryDataRecord evosuiteRecord = getRandoopList().get(i);

				if(!metricUsed.equals(randoopRecord.getMetricUsed()))
				{
					metricUsed = randoopRecord.getMetricUsed();
					if(i==0)
						writer.println(metricUsed + " & ");
					else
						writer.println("\t & " + metricUsed + " & ");
				}
				
				String leastFormattedString = String.format("%.1f", randoopRecord.getLeastDiverseAvg());
				String mostFormattedString = String.format("%.1f", evosuiteRecord.getMostDiverseAvg());
				String effectSizeFormattedString = String.format("%.2f", randoopRecord.getEffectSize());
				//evosuiteFormattedString = String.format("%.2f", evosuiteRecord.getEffectSize());
				if(randoopRecord.getpValue() > 0.01)
				{
					effectSizeFormattedString = "*" + effectSizeFormattedString;
					//mostFormattedString = "*" + mostFormattedString;
				}
				writer.print("\t" + leastFormattedString + " & " + mostFormattedString + " & " + effectSizeFormattedString );
				
				if(i<getRandoopList().size()-1 && (!metricUsed.equals(getRandoopList().get(i+1).getMetricUsed())))
					writer.println(" \\\\");
				else if(i == getRandoopList().size()-1)
					writer.println(" \\\\");
				else if(i<getRandoopList().size()-1)
					writer.println(" &");
			}

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}
	}
	
	private void writeIntoTexEvosuiteDataFile(File texDataFile, String projectName)
	{
		
		try { 
			// create FileWriter object with file as parameter 
			PrintWriter writer = new PrintWriter(texDataFile);
			
			writer.print("\\multirow{5}{*}{" + projectName + "} & ");
			String metricUsed = "";
			for(int i=0;i<getEvosuiteList().size();i++)
			{
				SummaryDataRecord evosuiteRecord = getEvosuiteList().get(i);

				if(!metricUsed.equals(evosuiteRecord.getMetricUsed()))
				{
					metricUsed = evosuiteRecord.getMetricUsed();
					if(i==0)
						writer.println(metricUsed + " & ");
					else
						writer.println("\t & " + metricUsed + " & ");
				}
				
				String leastFormattedString = String.format("%.1f", evosuiteRecord.getLeastDiverseAvg());
				String mostFormattedString = String.format("%.1f", evosuiteRecord.getMostDiverseAvg());
				String effectSizeFormattedString = String.format("%.2f", evosuiteRecord.getEffectSize());
				//evosuiteFormattedString = String.format("%.2f", evosuiteRecord.getEffectSize());
				if(evosuiteRecord.getpValue() > 0.01)
				{
					effectSizeFormattedString = "*" + effectSizeFormattedString;
					//mostFormattedString = "*" + mostFormattedString;
				}
				writer.print("\t" + leastFormattedString + " & " + mostFormattedString + " & " + effectSizeFormattedString );
				
				if(i<getEvosuiteList().size()-1 && (!metricUsed.equals(getEvosuiteList().get(i+1).getMetricUsed())))
					writer.println(" \\\\");
				else if(i == getEvosuiteList().size()-1)
					writer.println(" \\\\");
				else if(i<getEvosuiteList().size()-1)
					writer.println(" &");
			}

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}
	}
	
	public static void main(String[] args) {
		// Read the root directory for the test results
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the root directory for the test results: ");
		String rootDir = input.nextLine();

		/*System.out.print("Enter the mutation score for the original Randoop test suite: ");
		double orgValue1 = input.nextDouble();
		System.out.print("Enter the mutation score for the original EvoSuite test suite: ");
		double orgValue2 = input.nextDouble();*/
		input.close();

		File rootFolder = new File(rootDir);
		SummarizeResults obj = new SummarizeResults(0, 0);

		System.out.print("Building maps...");
		obj.buildFileMaps(rootFolder);
		System.out.println("Done!");

		System.out.print("Extracting required information...");
		obj.extractInfo();
		System.out.println("Done!");

		System.out.print("Writing info into CSV file...");
		obj.writeIntoSummaryCSVFileInOrder(rootDir);
		System.out.println("Done!");
		
		System.out.print("Writing info into Tex files...");
		obj.writeIntoTexFiles(rootDir);
		System.out.println("Done!");

		/*System.out.print("Writing figures into Python file...");
		obj.writeIntoPythonFile(rootDir);
		System.out.println("Done!");*/

	}
}
