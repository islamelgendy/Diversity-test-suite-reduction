package resultsanalysis;

public class SummaryDataRecord implements Comparable<SummaryDataRecord>{

	private String metricUsed;
	private int testSuiteSize;
	private double leastDiverseAvg;
	private double mostDiverseAvg;
	private double pValue;
	private double effectSize;
	private double reductionTime;
	private String analysisTime;
	private int analysisTimeInSeconds;
	
	public SummaryDataRecord()
	{
		
	}
	public SummaryDataRecord(String metricUsed, int testSuiteSize, double leastDiverseAvg, double mostDiverseAvg,
			double pValue, double effectSize, double reductionTime, String analysisTime,
			int analysisTimeInSeconds) {
		this.metricUsed = metricUsed;
		this.testSuiteSize = testSuiteSize;
		this.leastDiverseAvg = leastDiverseAvg;
		this.mostDiverseAvg = mostDiverseAvg;
		this.pValue = pValue;
		this.effectSize = effectSize;
		this.reductionTime = reductionTime;
		this.analysisTime = analysisTime;
		this.analysisTimeInSeconds = analysisTimeInSeconds;
	}
	public String getMetricUsed() {
		return metricUsed;
	}
	public void setMetricUsed(String metricUsed) {
		this.metricUsed = metricUsed;
	}
	public int getTestSuiteSize() {
		return testSuiteSize;
	}
	public void setTestSuiteSize(int testSuiteSize) {
		this.testSuiteSize = testSuiteSize;
	}
	public double getLeastDiverseAvg() {
		return leastDiverseAvg;
	}
	public void setLeastDiverseAvg(double leastDiverseAvg) {
		this.leastDiverseAvg = leastDiverseAvg;
	}
	public double getMostDiverseAvg() {
		return mostDiverseAvg;
	}
	public void setMostDiverseAvg(double mostDiverseAvg) {
		this.mostDiverseAvg = mostDiverseAvg;
	}
	public double getpValue() {
		return pValue;
	}
	public void setpValue(double pValue) {
		this.pValue = pValue;
	}
	public double getEffectSize() {
		return effectSize;
	}
	public void setEffectSize(double effectSize) {
		this.effectSize = effectSize;
	}
	public double getReductionTime() {
		return reductionTime;
	}
	public void setReductionTime(double reductionTime) {
		this.reductionTime = reductionTime;
	}
	public String getAnalysisTime() {
		return analysisTime;
	}
	public void setAnalysisTime(String analysisTime) {
		this.analysisTime = analysisTime;
	}
	public int getAnalysisTimeInSeconds() {
		return analysisTimeInSeconds;
	}
	public void setAnalysisTimeInSeconds(int analysisTimeInSeconds) {
		this.analysisTimeInSeconds = analysisTimeInSeconds;
	}
	@Override
	public String toString() {
		return "SummaryDataRecord [metricUsed=" + metricUsed + ", testSuiteSize=" + testSuiteSize + ", leastDiverseAvg="
				+ leastDiverseAvg + ", mostDiverseAvg=" + mostDiverseAvg + ", pValue=" + pValue + ", effectSize="
				+ effectSize + ", reductionTime=" + reductionTime + ", analysisTime=" + analysisTime
				+ ", analysisTimeInSeconds=" + analysisTimeInSeconds + "]";
	}
	
	public String [] toCSVRecord() {
		return new String[] { getMetricUsed(), ""+getTestSuiteSize(), ""+getReductionTime(), ""+getAnalysisTime(), ""+getLeastDiverseAvg(),
				""+getMostDiverseAvg(), ""+getpValue(), ""+getEffectSize()};
	}
	
	public static String [] toCSVRecord(SummaryDataRecord randoopRecord, SummaryDataRecord evosuiteRecord) {
		return new String[] { randoopRecord.getMetricUsed() , ""+randoopRecord.getTestSuiteSize() , ""+randoopRecord.getReductionTime()
		 , ""+evosuiteRecord.getReductionTime() , randoopRecord.getAnalysisTime() , evosuiteRecord.getAnalysisTime()
		 , ""+randoopRecord.getLeastDiverseAvg() , ""+evosuiteRecord.getLeastDiverseAvg()
		 , ""+randoopRecord.getMostDiverseAvg() , ""+evosuiteRecord.getMostDiverseAvg() , ""+randoopRecord.getpValue()
		 , ""+evosuiteRecord.getpValue() , ""+randoopRecord.getEffectSize() , ""+evosuiteRecord.getEffectSize()};
	}
	
	@Override
	public int compareTo(SummaryDataRecord o) {
		if(metricUsed.compareTo(o.metricUsed) != 0)
			return metricUsed.compareTo(o.metricUsed);
		else
			return testSuiteSize - o.testSuiteSize;
	}
	
	
}
