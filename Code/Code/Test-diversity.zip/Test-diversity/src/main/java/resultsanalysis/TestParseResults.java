package resultsanalysis;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import similaritymetrics.SimilarityMetric;

public class TestParseResults {

	public static void main(String[] args) {
		// set true if parsing attempts with least and most diverse,
		// set false if parsing normal test suites' results
		boolean parseAttemps = true;
		// Read the root directory for the test results
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the root directory for the test results: ");
		String rootDir = input.nextLine();
		System.out.print("Enter 1 for parsing reduced attempts, or 2 for parsing repeated test suites: ");
		int result = input.nextInt();
		if(result == 2)
			parseAttemps = false;
		else
			parseAttemps = true;
		input.nextLine();
		input.close();


		String curDir = rootDir;
		long startTime = System.currentTimeMillis();

		File rootFolder = new File(curDir);

		ParseResults obj = new ParseResults(parseAttemps);

		// Loop through the folders in the root directory
		// Loop through each folder of the attempts listing all the files there
		for (final File fileEntry : rootFolder.listFiles()) {
			if (fileEntry.isDirectory()) {
				ArrayList<File> files = (ArrayList<File>) obj.listFiles(fileEntry);
				obj.addTestResult(files);
				System.out.println("Done for " + fileEntry.getName());
			}
		}
		obj.writeIntoCSVFiles();
		long endTime = System.currentTimeMillis();
		double timeMins = (endTime - startTime) / 1000.0;
		System.out.println("Done in " + timeMins + " seconds");

	}
}
