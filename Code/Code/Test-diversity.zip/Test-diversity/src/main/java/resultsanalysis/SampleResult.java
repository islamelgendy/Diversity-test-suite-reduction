package resultsanalysis;

public class SampleResult {

	private int attemptNumber;
	private String projectID;
	private String folderName;
	private String testSuiteSource;
	private String similarityMetric;
	private String diversity;
	private int testSuiteSize;
	private int mutGenerated;
	private int mutCovered;
	private int mutKilled;
	private int mutExcluded;
	private double MS;
	private double mutRuntime;
	private int lineTotal;
	private int linesCovered;
	private int branchesTotal;
	private int branchesCovered;
	
	public int getAttemptNumber() {
		return attemptNumber;
	}
	public void setAttemptNumber(int attemptNumber) {
		this.attemptNumber = attemptNumber;
	}
	public String getProjectID() {
		return projectID;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}
	public int getTestSuiteSize() {
		return testSuiteSize;
	}
	public void setTestSuiteSize(int testSuiteSize) {
		this.testSuiteSize = testSuiteSize;
	}
	public String getTestSuiteSource() {
		return testSuiteSource;
	}
	public void setTestSuiteSource(String testSuiteSource) {
		this.testSuiteSource = testSuiteSource;
	}
	public String getSimilarityMetric() {
		return similarityMetric;
	}
	public void setSimilarityMetric(String similarityMetric) {
		this.similarityMetric = similarityMetric;
	}
	public int getMutGenerated() {
		return mutGenerated;
	}
	public void setMutGenerated(int mutGenerated) {
		this.mutGenerated = mutGenerated;
	}
	public int getMutCovered() {
		return mutCovered;
	}
	public void setMutCovered(int mutCovered) {
		this.mutCovered = mutCovered;
	}
	public int getMutKilled() {
		return mutKilled;
	}
	public void setMutKilled(int mutKilled) {
		this.mutKilled = mutKilled;
	}
	public int getMutExcluded() {
		return mutExcluded;
	}
	public void setMutExcluded(int mutExcluded) {
		this.mutExcluded = mutExcluded;
	}
	public double getMS() {
		return MS;
	}
	public void calculateMS() {
		MS = (double)mutKilled / mutGenerated * 100;
	}
	public double getMutRuntime() {
		return mutRuntime;
	}
	public void setMutRuntime(double mutRuntime) {
		this.mutRuntime = mutRuntime;
	}
	public int getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(int lineTotal) {
		this.lineTotal = lineTotal;
	}
	public int getLinesCovered() {
		return linesCovered;
	}
	public void setLinesCovered(int linesCovered) {
		this.linesCovered = linesCovered;
	}
	public int getBranchesTotal() {
		return branchesTotal;
	}
	public void setBranchesTotal(int branchesTotal) {
		this.branchesTotal = branchesTotal;
	}
	public int getBranchesCovered() {
		return branchesCovered;
	}
	public void setBranchesCovered(int branchesCovered) {
		this.branchesCovered = branchesCovered;
	}	
	public String getDiversity() {
		return diversity;
	}
	public void setDiversity(String leastOrMostDiverse) {
		this.diversity = leastOrMostDiverse;
	}
	@Override
	public String toString() {
		return "SampleResult [attemptNumber=" + attemptNumber + ", projectID=" + projectID + ", testSuiteSize="
				+ testSuiteSize + ", mutGenerated=" + mutGenerated + ", mutCovered=" + mutCovered + ", mutKilled="
				+ mutKilled + ", mutExcluded=" + mutExcluded + ", MS=" + MS + ", mutRuntime=" + mutRuntime
				+ ", lineTotal=" + lineTotal + ", linesCovered=" + linesCovered + ", branchesTotal=" + branchesTotal
				+ ", branchesCovered=" + branchesCovered + "]";
	}
	
	public String getRecored()
	{
		return getProjectID() + "," + getTestSuiteSource() + "," + getSimilarityMetric() + "," +  getAttemptNumber() 
				+ "," +  getTestSuiteSize() + "," +  getMutGenerated() + "," 
				+  getMutExcluded() + "," +  getMutCovered() + "," 
				+  getMutKilled() + "," +  getMS() + "," + getMutRuntime() 
				+ "," +  getLineTotal() + "," +  getLinesCovered() + "," 
				+  getBranchesTotal() + "," + getBranchesCovered(); 
	}
	
	public String[] getAttemptRecord()
	{
		return new String[] { getProjectID() , getTestSuiteSource() , getSimilarityMetric() , getDiversity() ,
					String.valueOf(getAttemptNumber()) , String.valueOf(getTestSuiteSize()) , 
					String.valueOf(getMutGenerated()) , String.valueOf(getMutExcluded()) ,
					String.valueOf(getMutCovered()) , String.valueOf(getMutKilled()) , 
					String.valueOf(getMS()) , String.valueOf(getMutRuntime()) ,  
					String.valueOf(getLineTotal()) , String.valueOf(getLinesCovered()) ,
					String.valueOf(getBranchesTotal()) , String.valueOf(getBranchesCovered()) }; 
	}
	
	public String[] getLeastDiverseRecord()
	{
		return new String[] { getProjectID() , getTestSuiteSource() , getSimilarityMetric() ,
					String.valueOf(getAttemptNumber()) , String.valueOf(getTestSuiteSize()) , 
					String.valueOf(getMutGenerated()) , String.valueOf(getMutExcluded()) ,
					getDiversity(),	String.valueOf(getMutCovered()) , String.valueOf(getMutKilled()) , 
					String.valueOf(getMS()) , String.valueOf(getMutRuntime()) ,  
					String.valueOf(getLineTotal()) , String.valueOf(getLinesCovered()) ,
					String.valueOf(getBranchesTotal()) , String.valueOf(getBranchesCovered()) , ""}; 
	}
	
	public String[] getMostDiverseRecord()
	{
		return new String[] { getDiversity(),	String.valueOf(getMutCovered()) , String.valueOf(getMutKilled()) , 
					String.valueOf(getMS()) , String.valueOf(getMutRuntime()) ,  
					String.valueOf(getLineTotal()) , String.valueOf(getLinesCovered()) ,
					String.valueOf(getBranchesTotal()) , String.valueOf(getBranchesCovered())}; 
	}
	
	public static String getHeaderLine()
	{
		return "project_ID, test_suite_source, similarity_metric, attempt_number, num_test_cases, "
				+ "mut_generated, mut_excluded, mut_covered, mut_killed, MS, " 
				+ "mut_Runtime, lines_total, lines_covered, branches_total, " 
				+ "branches_covered";
	}
	
	public static String [] getAttemptHeader()
	{
		return new String[] { "project_ID", "test_suite_source", "similarity_metric", "Diversity" , "attempt_number", "num_test_cases",
				"mut_generated", "mut_excluded", "mut_covered", "mut_killed", "MS", 
				"mut_Runtime", "lines_total", "lines_covered", "branches_total", "branches_covered"}; 
	}
	
	public static String [] getResultHeader()
	{
		return new String[] { "project_ID", "Folder", "test_suite_source", "mut_generated", "mut_excluded", "mut_covered", "mut_killed", "MS", 
				"mut_Runtime", "lines_total", "lines_covered", "branches_total", "branches_covered"}; 
	}
	
	public String[] getResultRecord()
	{
		return new String[] { getProjectID(), getFolderName() , getTestSuiteSource() ,  
					String.valueOf(getMutGenerated()) , String.valueOf(getMutExcluded()) ,
					String.valueOf(getMutCovered()) , String.valueOf(getMutKilled()) , 
					String.valueOf(getMS()) , String.valueOf(getMutRuntime()) ,  
					String.valueOf(getLineTotal()) , String.valueOf(getLinesCovered()) ,
					String.valueOf(getBranchesTotal()) , String.valueOf(getBranchesCovered()) }; 
	}
	
	// Return the header with the format of least and most in a single row
	public static String [] getHeaderInOrder()
	{
		return new String[] { "project_ID", "test_suite_source", "similarity_metric", "attempt_number", "num_test_cases",
				"mut_generated", "mut_excluded", "Diversity", "mut_covered", "mut_killed", "MS", 
				"mut_Runtime", "lines_total", "lines_covered", "branches_total", "branches_covered"
				, "", "Diversity", "mut_covered", "mut_killed", "MS", 
				"mut_Runtime", "lines_total", "lines_covered", "branches_total", "branches_covered"}; 
	}
}
