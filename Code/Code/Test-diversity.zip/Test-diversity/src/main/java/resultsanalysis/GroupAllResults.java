package resultsanalysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GroupAllResults {

	private List<Double> RandoopLeast;
	private List<Double> RandoopMost;
	private List<Double> EvoSuiteLeast;
	private List<Double> EvoSuiteMost;

	public GroupAllResults()
	{
		RandoopLeast = new ArrayList<Double>();
		RandoopMost = new ArrayList<Double>();
		EvoSuiteLeast = new ArrayList<Double>();
		EvoSuiteMost = new ArrayList<Double>();
	}

	public String removeDoubleQuotes(String str)
	{
		return str.substring(1, str.length()-1);
	}

	public void extractSummaryInfo(File summaryFile)
	{
		try (BufferedReader br = new BufferedReader(new FileReader(summaryFile.getAbsolutePath()))) {
			String line;
			while ((line = br.readLine()) != null) {
				// process the line.
				if(line.contains("min") && line.contains("sec"))
				{
					String[] data = line.split(",");
					//Randoop Least diverse average value is at index 6
					String leastRanMS = removeDoubleQuotes(data[6]);
					//EvoSuite Least diverse average value is at index 7
					String leastEvoMS = removeDoubleQuotes(data[7]);
					//Randoop Most diverse average value is at index 8
					String mostRanMS = removeDoubleQuotes(data[8]);
					//EvoSuite Most diverse average value is at index 9
					String mostEvoMS = removeDoubleQuotes(data[9]);

					RandoopLeast.add(Double.parseDouble(leastRanMS));
					EvoSuiteLeast.add(Double.parseDouble(leastEvoMS));
					RandoopMost.add(Double.parseDouble(mostRanMS));
					EvoSuiteMost.add(Double.parseDouble(mostEvoMS));
				}

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void listFilesForFolder(final File folder) {
		for (final File fileEntry : folder.listFiles()) {

			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				if(fileEntry.getName().equals("summary.csv"))
				{
					extractSummaryInfo(fileEntry);
				}
			}
		}
	}

	public void parse(File rootFolder)
	{
		// Loop through the folders in the root directory
		// Loop through each folder and build the results summary
		for (final File fileEntry : rootFolder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			}
		}
	}

	public void writeIntoFile(String filePath)
	{
		//get project name
		int lastSlashPos = filePath.lastIndexOf('/');
		String projectName = filePath.substring(lastSlashPos+1);
		try { 
			PrintWriter pw = new PrintWriter(filePath+ "/" + projectName + "-all.text");

			writeList(pw, projectName+"_Ran_Least", RandoopLeast);
			writeList(pw, projectName+"_Evo_Least", EvoSuiteLeast);
			writeList(pw, projectName+"_Ran_Most", RandoopMost);
			writeList(pw, projectName+"_Evo_Most", EvoSuiteMost);

			pw.close();
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		}

	}

	public void writeList(PrintWriter pw, String startLine, List<Double> list)
	{
		String formattedString = "";
		pw.print(startLine + " = [");
		for(int i=0;i<list.size()-1;i++)
		{
			formattedString = String.format("%.2f", list.get(i));
			pw.print(formattedString + ", ");
		}
		formattedString = String.format("%.2f", list.get(list.size()-1));
		pw.println(formattedString + "]");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Read the root directory for the test results
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the root directory for the test results: ");
		String rootDir = input.nextLine();

		File rootFolder = new File(rootDir);

		GroupAllResults obj = new GroupAllResults();

		System.out.print("Extracting required information...");
		obj.parse(rootFolder);
		System.out.println("Done!");

		System.out.print("Writing info into data file...");
		obj.writeIntoFile(rootDir);
		System.out.println("Done!");

		input.close();
	}

}
