package resultsanalysis;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.hadoop.util.Options.StringOption;

public class AttemptGroup extends ResultGroup{

	private int attemptNumber;
	private int size;
	private String similarityMetric;
	private String leastOrMostDiverse;

	public AttemptGroup()
	{		
	}
	public AttemptGroup(int attemptNumber)
	{
		this.attemptNumber = attemptNumber;
	}
	public AttemptGroup(ResultGroup group)
	{		
		this.setMutationFile(group.getMutationFile());
		this.setCoverageFile(group.getCoverageFile());
		this.setMutationLogFile(group.getMutationLogFile());
		this.result = group.result;
	}

	public int getAttemptNumber() {
		return attemptNumber;
	}

	public void setAttemptNumber(int attemptNumber) {
		this.attemptNumber = attemptNumber;
	}
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getSimilarityMetric() {
		return similarityMetric;
	}
	public void setSimilarityMetric(String similarityMetric) {
		this.similarityMetric = similarityMetric;
	}
	public String getLeastOrMostDiverse() {
		return leastOrMostDiverse;
	}
	
	@Override
	public void parse(String parentFolder)
	{
		int slashPos = parentFolder.lastIndexOf('/');
		parentFolder = parentFolder.substring(slashPos+1);
		int leastMostPos = parentFolder.indexOf("Least");
		leastOrMostDiverse = "Least diverse";
		if(leastMostPos == -1)
		{
			leastMostPos = parentFolder.indexOf("Most");
			leastOrMostDiverse = "Most diverse";
		}
		similarityMetric = parentFolder.substring(0,leastMostPos);
		int numPos = parentFolder.indexOf("Num");
		String num = parentFolder.substring(numPos+3);
		attemptNumber = Integer.parseInt(num);

		int sizePos = parentFolder.indexOf("Size");
		size = Integer.parseInt(parentFolder.substring(sizePos+4,numPos));
	}
	
	@Override
	public String toString() {
		return "AttemptGroup [size=" + size + ", attemptNumber=" + attemptNumber + ", mutationFile=" + mutationFile
				+ ", coverageFile=" + coverageFile + ", mutationLogFile=" + mutationLogFile + "]";
	}

	@Override
	public void createSampleResult()
	{
		result = new SampleResult();
		result.setAttemptNumber(attemptNumber);
		result.setTestSuiteSize(size);
		result.setSimilarityMetric(similarityMetric);
		result.setDiversity(leastOrMostDiverse);
		try {
			parseMutationFile();
			parseMutationLogFile();
			parseCoverageFile();
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	@Override
	public int compareTo(ResultGroup o) {
		int res = attemptNumber - ((AttemptGroup)o).attemptNumber;
		if(res == 0) {
			res = leastOrMostDiverse.compareTo(((AttemptGroup)o).leastOrMostDiverse);			
		}
		return res;
	}
}
