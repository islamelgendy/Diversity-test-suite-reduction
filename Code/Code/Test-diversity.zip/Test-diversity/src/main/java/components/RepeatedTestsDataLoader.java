package components;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import similaritymetrics.SimilarityMetric;

public class RepeatedTestsDataLoader extends DataLoader {

	public RepeatedTestsDataLoader(String filename) throws FileNotFoundException
	{
		super(filename);
	}

	public static void main(String[]args)
	{
		List<ReductionSizesPerTestSuite> reductionList = new ArrayList<ReductionSizesPerTestSuite>();
		List<ReductionSizesPerTestSuite> evosuiteReductionList = new ArrayList<ReductionSizesPerTestSuite>();

		boolean newFolderFlag = true;
		boolean keepWorking = true;
		// Use this array to set the different sizes for the reduction
		String outputDir = "";
		int [] reductionSizes = {7, 13, 18, 0};

		String [] metrics = {SimilarityMetric.EUCLIDEAN_METRIC, SimilarityMetric.HAMMING_METRIC,
				SimilarityMetric.LEVENSHTEIN_METRIC, SimilarityMetric.MANHATTAN_METRIC, SimilarityMetric.NCD_METRIC};
		final String CSVFILE = "NCDMetric.csv";

		//	/home/islam/MyWork/TestDir/all-original-tests/tests/JacksonDatabind/evosuite/size128/JacksonDatabind-2f-evosuite.3000.tar.bz2

		// Read the compressed file of the test suite
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the working directory of all repeated test suites: ");
		String workingDir = input.nextLine();
		File parentFolder = new File(workingDir);
		input.close();

		// Check if we are working on EvoSuite or Randoop
		boolean evosuite = workingDir.contains("evosuite");

		// Get all the subfolders in the working directory. Each subfolder is the parent folder
		// that contains the compressed file
		List<File> testFolders = new ArrayList<File>();
		for (final File fileEntry : parentFolder.listFiles()) {
			if (fileEntry.isDirectory()) {
				testFolders.add(fileEntry);
			} 
		}

		for(File testSuiteFolder : testFolders)
		{
			ReductionSizesPerTestSuite reductionRecord = new ReductionSizesPerTestSuite();
			newFolderFlag = true;
			allFiles = new ArrayList<File>();
			subFolders = new ArrayList<String>();
			scaffoldingFiles = new ArrayList<File>();

			// This is going to be the root directory for the output files
			String ROOT_DIR = "/home/islam/MyWork/TestDir/repeatedOutputDir/";

			// List all the files with that folder and choose the compressed file
			String fileName = "";
			for(File file : testSuiteFolder.listFiles())
			{
				if(file.getName().endsWith(".tar.bz2"))
				{
					fileName = file.getAbsolutePath();
					break;
				}
			}

			// Decompress the file using an object of the TarFile class
			TarFile tarFile = new TarFile(fileName);
			System.out.print("Extracting files ... ");
			String targetPath = tarFile.untar();
			System.out.println("done!");

			// Get all java files in the folder
			File folder = new File(targetPath);
			allFiles = listFilesForFolder(folder);
			SequenceWriter.setCompressedFileName(folder.getName());

			// Get the project name and add to the root directory
			ROOT_DIR += getProjectName(folder) + "/";
			outputDir = ROOT_DIR;

			// Get the reduction list for Randoop
			if(!evosuite)
				evosuiteReductionList = getReductionRecordsFromFile(outputDir);

			// Get the name of the parent folder to add it to the root directory
			String parent = testSuiteFolder.getName();
			ROOT_DIR += parent + "/";

			// set the projectID with the parent folder name which is a number
			try {
				reductionRecord.setProjectID(Integer.parseInt(parent));
			}
			catch(NumberFormatException ex)
			{
				ex.printStackTrace();
			}

			//Attach to the root directory the word randoop or evosuite
			if(folder.getName().contains("randoop"))
				ROOT_DIR += "Randoop/";
			else if(folder.getName().contains("evosuite"))
				ROOT_DIR += "EvoSuite/";
			String curRootDir = ROOT_DIR;

			// Loop through all five similarity metrics
			for(String METRIC : metrics)
			{
				int count = 0;
				int reducedSize = reductionSizes[count];
				ROOT_DIR = curRootDir +  METRIC + "/";

				//Initialize the most and least diverse sequences
				listOfMostDiverseSequences = new ArrayList<ArrayList<Sequence>>();
				listOfLeastDiverseSequences = new ArrayList<ArrayList<Sequence>>();

				try
				{
					long startTime = System.currentTimeMillis();
					double calcSimilarityTimeMins = 0;
					List<String> heading = null;
					ArrayList<Sequence> mostDiverseSequence = null;
					ArrayList<Sequence> leastDiverseSequence = null;
					ArrayList<Sequence> randomDiverseSequence = null;
					Number[][] metricValues = null;
					DataLoader dataLoader = null;
					boolean firstFile = true;

					do {
						if(keepWorking)
						{
							//Initialize the most and least diverse sequences for another reduction

							listOfMostDiverseSequences = new ArrayList<ArrayList<Sequence>>();
							listOfLeastDiverseSequences = new ArrayList<ArrayList<Sequence>>();
						}
						for(File file : allFiles)
						{
							if(!firstFile)
								metricValues = null;


							//System.out.print("Enter the file name of the output file for NCD values: ");
							//String outputNCD = input.nextLine();

							if(metricValues == null) {
								dataLoader = new DataLoader(file.getAbsolutePath());
								System.out.print("Parsing file " + file.getName() + " ...");
								heading = dataLoader.parseFile();
								System.out.println("Done!");

								// Get the size and check for the reduction sizes
								int testSuiteSize = dataLoader.getSequences().size();
								reductionSizes[0] = (int)(testSuiteSize * 0.35);
								reductionSizes[1] = (int)(testSuiteSize * 0.6);
								reductionSizes[2] = (int)(testSuiteSize * 0.85);
								reducedSize = reductionSizes[count];

								// Save the reduction sizes to later use in Randoop
								if(newFolderFlag)
								{
									reductionRecord.setSize1(reductionSizes[0]);
									reductionRecord.setSize2(reductionSizes[1]);
									reductionRecord.setSize3(reductionSizes[2]);
									newFolderFlag = false;
									reductionList.add(reductionRecord);
								}

								// If not EvoSuite, then retrieve the reduction sizes from the reductionSizes file
								if(!evosuite)
								{
									reductionRecord = getReductionRecord(reductionRecord.getProjectID(), evosuiteReductionList);
									reductionSizes[0] = reductionRecord.getSize1();
									reductionSizes[1] = reductionRecord.getSize2();
									reductionSizes[2] = reductionRecord.getSize3();
									reducedSize = reductionSizes[count];
								}

								long calcSimilarityStartTime = System.currentTimeMillis();
								System.out.print("Calculating similarity values ...");

								metricValues = DataLoader.writeMetricValuesIntoCSV(dataLoader, METRIC, CSVFILE, false);
								long calcSimilarityEndTime = System.currentTimeMillis();
								calcSimilarityTimeMins = (calcSimilarityEndTime - calcSimilarityStartTime) / 1000.0;
								System.out.println("Done in " + calcSimilarityTimeMins + " seconds");
							}

							System.out.print("Test suite reduction...");
							startTime = System.currentTimeMillis();

							long reduceStartTime = System.currentTimeMillis();
							//				System.out.print("Calculating similarity values ...");

							for(int attemptNum = 0;attemptNum<1;attemptNum++)
							{
								// For the first file, use the null lists for most and least diverse
								if(firstFile)
								{
									// Initialize the parameter lists if they are null on the first call,
									// otherwise continue to append on it.
									mostDiverseSequence = new ArrayList<Sequence>();
									leastDiverseSequence = new ArrayList<Sequence>();

									listOfMostDiverseSequences.add(mostDiverseSequence);
									listOfLeastDiverseSequences.add(leastDiverseSequence);
								}
								// For the rest of files, use the already defined lists to append to them
								// more sequences
								else
								{
									mostDiverseSequence = listOfMostDiverseSequences.get(attemptNum);
									leastDiverseSequence = listOfLeastDiverseSequences.get(attemptNum);
								}

								DataLoader.testSuiteReduction(dataLoader, METRIC, metricValues, reducedSize, 
										mostDiverseSequence, leastDiverseSequence);
								System.out.println(attemptNum + " done.");
							}

							long reduceEndTime = System.currentTimeMillis();
							double reduceTimeMins = (reduceEndTime - reduceStartTime) / 1000.0;
							System.out.println("Done in " + reduceTimeMins + " seconds");

							firstFile = false;
						}

						System.out.print("Writing into files...");


						// Start writing the most and least diverse sequences into a test class
						for(int index = 0;index<listOfMostDiverseSequences.size();index++)
						{
							SequenceWriter sw = new SequenceWriter(ROOT_DIR, subFolders ,listOfMostDiverseSequences.get(index));
							sw.writeIntoFile(METRIC + "MostDiverseTestSuiteSize" + listOfMostDiverseSequences.get(index).size() + "Num" + index, heading);

							sw = new SequenceWriter(ROOT_DIR, subFolders ,listOfLeastDiverseSequences.get(index));
							sw.writeIntoFile(METRIC + "LeastDiverseTestSuiteSize" + listOfLeastDiverseSequences.get(index).size() + "Num"  + index, heading);
						}

						long endTime = System.currentTimeMillis();
						double totalTimeMins = (endTime - startTime) / 1000.0 + calcSimilarityTimeMins;
						System.out.println("...Done in " + totalTimeMins + " seconds");
						saveFinalTime(totalTimeMins, ROOT_DIR + "/size" + listOfLeastDiverseSequences.get(0).size());

						/* Uncomment these two lines if you want the size read from tester*/
						//System.out.print("Enter a positive number as a new size for another reduction, else the program will terminate: ");
						//reducedSize = Integer.parseInt(input.nextLine());
						reducedSize = reductionSizes[++count];
						firstFile = true;
						keepWorking = (reducedSize > 0)?true:false;

					}while(keepWorking);

				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalArgumentException e)
				{
					e.printStackTrace();
				}
			}
		}

		// Sort and save the reductionList
		if(evosuite)
		{
			reductionList.sort(null);
			saveReductionList(reductionList, outputDir);
		}
	}

	private static String getProjectName(File folder)
	{
		String name = folder.getName();
		int dashPos = name.indexOf('-');
		String projectName = name.substring(0,dashPos);
		return projectName;
	}

	private static void saveReductionList(List<ReductionSizesPerTestSuite> list, String path)
	{
		try
		{
			PrintWriter pw = new PrintWriter(path + "/reductionSizes.txt");
			for(ReductionSizesPerTestSuite record : list)
			{
				pw.println(record.toString());
			}
			pw.close();
		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
	}

	private static List<ReductionSizesPerTestSuite> getReductionRecordsFromFile(String path)
	{
		List<ReductionSizesPerTestSuite> list = new ArrayList<ReductionSizesPerTestSuite>();

		try
		{
			File inputFile = new File(path + "/reductionSizes.txt");
			Scanner input = new Scanner(inputFile);
			while(input.hasNext())
			{
				ReductionSizesPerTestSuite record = new ReductionSizesPerTestSuite();

				String line = input.nextLine();
				record.parse(line);
				list.add(record);
			}
			input.close();
		}
		catch(FileNotFoundException ex)
		{
			ex.printStackTrace();
		}
		return list;
	}

	private static ReductionSizesPerTestSuite getReductionRecord(int id, List<ReductionSizesPerTestSuite> list)
	{
		for(ReductionSizesPerTestSuite record : list)
		{
			if(record.getProjectID() == id)
				return record;
		}

		return null;
	}

}
