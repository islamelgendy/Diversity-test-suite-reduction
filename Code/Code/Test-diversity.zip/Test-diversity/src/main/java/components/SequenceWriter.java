package components;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import com.google.common.io.Files;

public class SequenceWriter {

	private String rootDir;
	private List<String> subFolders;
	private List<Sequence> sequences;
	private static String firstLine;
	private static String className;
	private static String compressedFileName;
	
	public SequenceWriter(String rootPath, List<String> subFolders, List<Sequence> sequences)
	{
		//this.firstLine = null;
		//this.className = null;
		this.rootDir = rootPath;
		this.subFolders = subFolders;
		this.sequences = sequences;
		this.rootDir += "/size" + this.sequences.size();
	}
	
	public static void setCompressedFileName(String compressFileName)
	{
		compressedFileName = compressFileName;
	}
	
	private String createDirectory(String parentFolder)
	{
		String  folder = "/";
		for(String dir : subFolders)
			folder += dir + "/";
		
		String fullPath = parentFolder + folder;
		File directory = new File(fullPath);
	    if (! directory.exists()){
	        directory.mkdirs();
	        // If you require it to make the entire directory path including parents,
	        // use directory.mkdirs(); here instead.
	    }
	    return fullPath;
	}
	
	public void writeIntoFile(String folderName, List<String> startingLines)
	{
		
		if(startingLines.get(0).contains("public class"))
		{
			firstLine = startingLines.remove(0);
			className = extractClassName(firstLine);
		}
		String parentFolderPath = rootDir + "/" + folderName;
		
		String fullPath = createDirectory(parentFolderPath);
	    
		try {
			String fullFileName = fullPath + className + ".java";
			PrintWriter pw = new PrintWriter(fullFileName);
			//writeStartingRandoopFile(className, pw);
			//Write the starting lines up to the first test case
			for(String ln : startingLines)
				pw.println(ln);

			// start writing the sequences into the file
			for(Sequence seq : sequences)
				pw.println(seq);
			
			pw.println("}");
			pw.close();
			
			// Copy the scaffolding file if it exists
			if(DataLoader.scaffoldingFiles != null)
			{
				for(File fileEntry : DataLoader.scaffoldingFiles)
				{
					// look for a scaffolding file that contains the same
					// class name
					if(fileEntry.getName().contains(className))
					{
						// copy that file into the same folder
						File cpyFile = new File(fullPath + fileEntry.getName());
						Files.copy(fileEntry, cpyFile);
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {

            // tar.gz a folder
            Path source = Paths.get(parentFolderPath);
         // get folder name as zip file name
            String tarFileName = parentFolderPath + "/" + compressedFileName + ".tar.bz2";
            Path target = Paths.get(tarFileName);
            TarFile.createTarBz2Folder(source, target);

        } catch (IOException e) {
            e.printStackTrace();
        }
		catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	private String extractClassName(String fileName)
	{
		String className = "";
		int extendsPos = fileName.indexOf(" extends");
		int bracePos = fileName.indexOf("{");
		if(fileName.contains("public class"))
		{
			int classPos = fileName.lastIndexOf("class");
			if(classPos<extendsPos)
				className = fileName.substring(classPos+6,extendsPos).trim();
			else if(classPos<bracePos)
				className = fileName.substring(classPos+6,bracePos).trim();
			else
				return null;
		}
		return className;
	}
	
	private void writeStartingRandoopFile(String className, PrintWriter pw)
	{
		pw.println("package minimizedtestsubjects;\n");
		pw.println("import org.junit.FixMethodOrder;");
		pw.println("import org.junit.Test;");
		pw.println("import org.junit.runners.MethodSorters;");
		pw.println();
		pw.println("@FixMethodOrder(MethodSorters.NAME_ASCENDING)");
		pw.println("public class " + className + " {");
		pw.println();
		pw.println("\tpublic static boolean debug = false;");
	}
}
