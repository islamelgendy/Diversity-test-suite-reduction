package components;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

/**
 * TestSuiteStandarizer class works on certain test suites produced from the 
 * defects4j framework, and then reduce them into only 1500 test cases in 
 * a single file.
 * 
 * @author 
 *
 */
public class TestSuiteStandarizer {

	private static List<File> allFiles = null;
	private static List<String> subFolders = null;
	public static List<File> scaffoldingFiles = null;
	private List<Sequence> allSequences;
	private String workingDir;
	private String outputDir;

	public TestSuiteStandarizer(String w, String o)
	{
		workingDir = w;
		outputDir = o;
		allSequences = new ArrayList<Sequence>();
	}

	public static List<File> listFilesForFolder(final File folder) {
		if(allFiles == null)
			allFiles = new ArrayList<File>();
		if(subFolders == null)
			subFolders = new ArrayList<String>();

		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				subFolders.add(fileEntry.getName());
				listFilesForFolder(fileEntry);
			} else {
				if(fileEntry.getName().endsWith(".java") 
						&& !fileEntry.getName().contains("scaffolding.java"))
					allFiles.add(fileEntry);
				else if(fileEntry.getName().endsWith(".java") 
						&& fileEntry.getName().contains("scaffolding.java"))
				{
					if(scaffoldingFiles == null)
						scaffoldingFiles = new ArrayList<File>();
					scaffoldingFiles.add(fileEntry);
				}
			}
		}
		return allFiles;
	}

	public void start()
	{
		// Loop through the folders in the working directory
		File folder = new File(workingDir);
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				File compressedFile = getCompressedFile(fileEntry);
				reworkTestSuite(compressedFile);
			} 
		}
	}

	public File getCompressedFile(File parentFolder)
	{
		File compressedFile = null;
		for (final File fileEntry : parentFolder.listFiles()) {
			if (fileEntry.isDirectory() && compressedFile==null) {
				compressedFile = getCompressedFile(fileEntry);
			} 
			else if(fileEntry.getName().contains(".tar.bz2"))
				compressedFile = fileEntry;
		}
		return compressedFile;
	}

	public void reworkTestSuite(File curCompressedTestSuite)
	{
		// Decompress the file using an object of the TarFile class
		TarFile tarFile = new TarFile(curCompressedTestSuite.getAbsolutePath());
		System.out.print("Extracting files from " + curCompressedTestSuite.getName() + "... ");
		String targetPath = tarFile.untar();
		System.out.println("done!");

		// Get all java files in the folder
		File folder = new File(targetPath);
		allFiles = null;
		subFolders = null;
		allFiles = listFilesForFolder(folder);
		SequenceWriter.setCompressedFileName(folder.getName());

		try {
			// standarize the evosuite with multiple files into a single file
			if(scaffoldingFiles != null && scaffoldingFiles.size()>1)
			{
				TreeSet<String> combinedImports = mergeImports();
				List<String> heading = null;
				DataLoader dataLoader = null;
				String folderName = "";
				allSequences = new ArrayList<Sequence>();

				for(File file : allFiles)
				{
					dataLoader = new DataLoader(file.getAbsolutePath());
					if(heading == null)
						heading = dataLoader.parseFile();
					else
						dataLoader.parseFile();
					allSequences.addAll(dataLoader.getSequences());
				}
				/*
				allSequences.sort(null);
				//Save only the first 1500 test cases
				while(allSequences.size()>1500)
					allSequences.remove(allSequences.size()-1);*/
				reworkSequences();

				heading = reworkHeading(heading, combinedImports);
				folderName = getFolderName(targetPath);
				DataLoader.scaffoldingFiles = scaffoldingFiles;
				setSubFolders(heading);
				SequenceWriter sw = new SequenceWriter(outputDir, subFolders , allSequences);
				sw.writeIntoFile(folderName, heading);
			}
			else {

				List<String> heading = null;
				DataLoader dataLoader = null;
				String folderName = "";
				allSequences = new ArrayList<Sequence>();

				for(File file : allFiles)
				{
					dataLoader = new DataLoader(file.getAbsolutePath());
					heading = dataLoader.parseFile();
					allSequences.addAll(dataLoader.getSequences());
				}
				for(int i=0;i<allSequences.size();i++)
				{
					if(allSequences.get(i).getName() == null)
					{
						System.out.println(allSequences.get(i));
					}
				}
				allSequences.sort(null);
				//Save only the first 1500 test cases
				while(allSequences.size()>1500)
					allSequences.remove(allSequences.size()-1);

				folderName = getFolderName(targetPath);
				SequenceWriter sw = new SequenceWriter(outputDir, subFolders , allSequences);
				sw.writeIntoFile(folderName, heading);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e)
		{
			e.printStackTrace();
		}

	}

	private String getFolderName(String path)
	{
		// process path to get the ID folder name
		int lastDotPos = path.lastIndexOf('.');
		return path.substring(lastDotPos+1);
	}

	private TreeSet<String> mergeImports() throws FileNotFoundException, IOException
	{
		TreeSet<String> imports = new TreeSet<String>();
		for(File file : allFiles)
		{
			List<String> fileImports = getImports(file);
			imports.addAll(fileImports);
		}
		return imports;
	}

	private List<String> getImports(File file) throws FileNotFoundException, IOException
	{
		List<String> listOfImports = new ArrayList<String>();

		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = br.readLine()) != null) {
				// process the line.
				if(line.startsWith("import"))
					listOfImports.add(line);
			}
		}

		return listOfImports;
	}

	private void reworkSequences()
	{
		for(int i=0;i<allSequences.size();i++)
		{
			allSequences.get(i).renameSequence(i);
		}
	}
	
	private List<String> reworkHeading(List<String> heading, TreeSet<String> importedList)
	{
		List<String> newHeading = new ArrayList<String>();
		int firstImportPos=-1;
		int lastImportPos=-1;
		
		//Find the position of the first import in the heading 
		//Also, add all the lines before the first import
		for(int i=0;i<heading.size();i++)
		{
			if(heading.get(i).startsWith("import"))
			{
				firstImportPos = i;
				break;
			}
			else
				newHeading.add(heading.get(i));
		}
		// add the merged import list
		newHeading.addAll(importedList);
		
		//Find the position of the last import in the heading		
		for(int i=heading.size()-1;i>=0;i--)
		{
			if(heading.get(i).startsWith("import"))
			{
				lastImportPos = i;
				break;
			}
		}
		
		//Start after the last import and continue adding the lines of the heading
		for(int i=lastImportPos+1;i<heading.size();i++)
			newHeading.add(heading.get(i));
		
		return newHeading;
	}
	
	private void setSubFolders(List<String> heading)
	{
		for(String line : heading)
		{
			if(line.trim().startsWith("package"))
			{
				String packageLine = line.trim().substring(8);
				packageLine = packageLine.substring(0, packageLine.length()-1);
				String [] tokens = packageLine.split("\\.");
				subFolders = new ArrayList<String>();
				for(int i=0;i<tokens.length;i++)
					subFolders.add(tokens[i]);
				break;
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Read the compressed file of the test suite
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the working directory: ");
		String workingDir = input.nextLine();

		System.out.print("Enter the output directory: ");
		String outputDir = input.nextLine();

		TestSuiteStandarizer testObject = new TestSuiteStandarizer(workingDir, outputDir);
		testObject.start();

		input.close();
	}

}
