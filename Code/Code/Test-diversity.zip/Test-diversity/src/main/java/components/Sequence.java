package components;

import java.util.ArrayList;
import java.util.List;

/**
 * Sequence.java
 *
 * Provides the structure of a single test case from Randoop tool
 * The name "Sequence" is the name used by the tool to represent the test case,
 * as it is a sequence of calls.
 *
 * @version 1.0  01/06/2020
 *
 * @author 
 */
public class Sequence implements Comparable<Sequence>{
	private String name;
	private List<String> lines;
	
	public Sequence(String name)
	{
		this.name = name;
		lines = new ArrayList<String>();
	}
	
	public Sequence(Sequence seq)
	{
		this.name = new String(seq.name);
		lines = new ArrayList<String>();
		for(String line : seq.lines)
			lines.add(line);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumberOfLines() {
		return lines.size();
	}

	public List<String> getLines() {
		return lines;
	}

	public void setLines(List<String> lines) {
		this.lines = lines;
	}
	
	public void addLine(String line)
	{
		lines.add(line);
	}
	
	public void renameSequence(int methodNumber)
	{
		for(int i=0;i<lines.size();i++)
		{
			if(lines.get(i).trim().startsWith("public void test"))
				lines.set(i, renameMethod(methodNumber));
		}
	}
	
	private String renameMethod(int number)
	{
		return "  public void test" + String.format("%02d", number) + "()  throws Throwable  {";
	}
	
	/**
	 * removeLastFewLines will trim the method of the last few lines from
	 * the last } to the end
	 */
	public void removeLastFewLines()
	{
		int lastBracePos = lines.lastIndexOf("}");
		for(int i=lastBracePos;i<lines.size();i++)
			lines.remove(i);
	}
	
	/**
	 * 
	 * @param seq The sequence (test case) given to concatenate it with the 
	 * current sequence 
	 * @return A new sequence of the two combined sequences.
	 */
	public Sequence combineSequences(Sequence seq)
	{
		Sequence combinedSequence = new Sequence(this.name + seq.name);
		combinedSequence.lines.addAll(lines);
		combinedSequence.lines.addAll(seq.lines);
		/*for(String line : lines)
			combinedSequence.addLine(line);
		for(String line : seq.lines)
			combinedSequence.addLine(line);*/
		return combinedSequence;
	}
	
	public String getAsOneString()
	{
		String output = "";
		for(String line : lines)
			output += line.trim();
		return output;
	}
	
	@Override
	public String toString()
	{
		String output = "";
		for(String line : lines)
			output += line + "\r\n";
		return output;
	}

	@Override
	public int compareTo(Sequence o) {
		return name.compareTo(o.name);
	}
}
