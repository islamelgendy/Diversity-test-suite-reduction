package components;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream;
import org.apache.commons.compress.utils.IOUtils;

/**
 * TarFile class is used to decompress a .tar.bz2 file.
 * The decompressed contents go to the same folder of the compressed file.
 * The constructor requires the absolute full path of the compressed file.
 *  
 * @author 
 *
 */
public class TarFile {

	private String archiveFileName;
	private String currentPath;
	private String folderName;
	
	public TarFile(String archiveFileName)
	{
		this.archiveFileName = archiveFileName;
		currentPath = getCurrentPath();
		folderName = getFolderName();
	}
	
	public String getCurrentPath()
	{
		int lastSlashPos = archiveFileName.lastIndexOf("/");
		return archiveFileName.substring(0,lastSlashPos+1);
	}
	
	public String getFolderName()
	{
		int lastSlashPos = archiveFileName.lastIndexOf("/");
		String fileName = archiveFileName.substring(lastSlashPos+1);
		int dotPos = fileName.indexOf(".tar");
		return fileName.substring(0,dotPos);
	}
	
	private String fileName(File targetDir, ArchiveEntry entry) {
		// TODO Auto-generated method stub
		String entryName = entry.getName();
		if(entryName.startsWith("./"))
			entryName = entry.getName().substring(1);
		else
			entryName = "/" + entryName;
		return targetDir.getAbsolutePath() + "/" + folderName + entryName;
	}
	
	public String untar()
	{
		String rootPath = null;
		File targetDir = new File(currentPath);

		// 1st InputStream from your compressed file
		FileInputStream in;
		try {
			in = new FileInputStream(archiveFileName);

			// wrap in a 2nd InputStream that deals with compression
			BZip2CompressorInputStream bzIn = new BZip2CompressorInputStream(in);
			// wrap in a 3rd InputStream that deals with tar
			TarArchiveInputStream tarIn = new TarArchiveInputStream(bzIn);
			ArchiveEntry entry = null;

			while (null != (entry = tarIn.getNextEntry())){
				if (entry.getSize() < 1){
					continue;
				}
				if (!tarIn.canReadEntryData(entry)) {
					// log something?
					continue;
				}
				String name = fileName(targetDir, entry);
				File f = new File(name);
				if (entry.isDirectory()) {
					if (!f.isDirectory() && !f.mkdirs()) {
						throw new IOException("failed to create directory " + f);
					}
				} else {
					File parent = f.getParentFile();
					if (!parent.isDirectory() && !parent.mkdirs()) {
						throw new IOException("failed to create directory " + parent);
					}
					try (OutputStream o = Files.newOutputStream(f.toPath())) {
						IOUtils.copy(tarIn, o);
					}
				}
			}

			tarIn.close();
			rootPath = currentPath + folderName;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rootPath;
	}
	
	// tar.bz2 few files
    public static void createTarBz2Files(List<Path> paths, Path output)
        throws IOException {

        try (OutputStream fOut = Files.newOutputStream(output);
             BufferedOutputStream buffOut = new BufferedOutputStream(fOut);
        		BZip2CompressorOutputStream gzOut = new BZip2CompressorOutputStream(buffOut);
             TarArchiveOutputStream tOut = new TarArchiveOutputStream(gzOut)) {

            for (Path path : paths) {

                if (!Files.isRegularFile(path)) {
                    throw new IOException("Support only file!");
                }

                TarArchiveEntry tarEntry = new TarArchiveEntry(
                                                  path.toFile(),
                                                  path.getFileName().toString());

                tOut.putArchiveEntry(tarEntry);

                // copy file to TarArchiveOutputStream
                Files.copy(path, tOut);

                tOut.closeArchiveEntry();

            }

            tOut.finish();

        }

    }
    
    // generate .tar.bz2 file at the current working directory
    // tar.bz2 a folder
    public static void createTarBz2Folder(final Path source, Path output)  throws IOException {

        if (!Files.isDirectory(source)) {
            throw new IOException("Please provide a directory.");
        }

        try (OutputStream fOut = Files.newOutputStream(output);
             BufferedOutputStream buffOut = new BufferedOutputStream(fOut);
        		BZip2CompressorOutputStream gzOut = new BZip2CompressorOutputStream(buffOut);
             TarArchiveOutputStream tOut = new TarArchiveOutputStream(gzOut)) {

            Files.walkFileTree(source, new SimpleFileVisitor<Path>() {

                @Override
                public FileVisitResult visitFile(Path file,
                                            BasicFileAttributes attributes) {

                    // only copy files, no symbolic links
                    if (attributes.isSymbolicLink()) {
                        return FileVisitResult.CONTINUE;
                    }

                    // get filename
                    Path targetFile = source.relativize(file);

                    try {
                        TarArchiveEntry tarEntry = new TarArchiveEntry(
                                file.toFile(), targetFile.toString());

                        tOut.putArchiveEntry(tarEntry);

                        Files.copy(file, tOut);

                        tOut.closeArchiveEntry();

                        System.out.printf("file : %s%n", file);

                    } catch (IOException e) {
                        System.err.printf("Unable to tar.bz2 : %s%n%s%n", file, e);
                    }

                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    System.err.printf("Unable to tar.bz2 : %s%n%s%n", file, exc);
                    return FileVisitResult.CONTINUE;
                }

            });

            tOut.finish();
        }

    }
    
    public static void main(String[] args) {
/*
        try {

            Path path1 = Paths.get("/home/vaio/MyWork/RegressionTest0.java");
            //Path path2 = Paths.get("/home/vaio/MyWork/RegressionTest1.java");
            Path output = Paths.get("/home/vaio/MyWork/output.tar.bz2");

            List<Path> paths = Arrays.asList(path1);//, path2);
            createTarBz2Files(paths, output);

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Done");
        */
        try {

            // tar.gz a folder
            Path source = Paths.get("/home/vaio/MyWork/testing/Compress-1f-evosuite.3000");
         // get folder name as zip file name
            String tarFileName = "/home/vaio/MyWork/testing/" + source.getFileName().toString() + ".tar.bz2";
            Path target = Paths.get(tarFileName);
            createTarBz2Folder(source, target);

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Done");
    }
}
