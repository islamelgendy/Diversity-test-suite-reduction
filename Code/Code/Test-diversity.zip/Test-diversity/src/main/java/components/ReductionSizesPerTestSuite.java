package components;

public class ReductionSizesPerTestSuite implements Comparable<ReductionSizesPerTestSuite>{
	private int projectID;
	private int size1;
	private int size2;
	private int size3;
	
	public ReductionSizesPerTestSuite()
	{ }
	
	public ReductionSizesPerTestSuite(int projectFolderName, int size1, int size2, int size3) {
		super();
		this.projectID = projectFolderName;
		this.size1 = size1;
		this.size2 = size2;
		this.size3 = size3;
	}
	public int getProjectID() {
		return projectID;
	}
	public void setProjectID(int projectFolderName) {
		this.projectID = projectFolderName;
	}
	public int getSize1() {
		return size1;
	}
	public void setSize1(int size1) {
		this.size1 = size1;
	}
	public int getSize2() {
		return size2;
	}
	public void setSize2(int size2) {
		this.size2 = size2;
	}
	public int getSize3() {
		return size3;
	}
	public void setSize3(int size3) {
		this.size3 = size3;
	}
	// Convert a string into an object
	public void parse(String line) throws NumberFormatException
	{
		int colonPos = line.indexOf(':');
		String ID = line.substring(0, colonPos);
		projectID = Integer.parseInt(ID.trim());
		
		line = line.substring(colonPos+3, line.length()-1);
		String [] sizes = line.split(",");
		size1 = Integer.parseInt(sizes[0].trim());
		size2 = Integer.parseInt(sizes[1].trim());
		size3 = Integer.parseInt(sizes[2].trim());
	}
	@Override
	public String toString() {
		return projectID + ": [" + size1 + ", "
				+ size2 + ", " + size3 + "]";
	}
	@Override
	public int compareTo(ReductionSizesPerTestSuite o) {
		// TODO Auto-generated method stub
		return projectID - o.projectID;
	}

}
