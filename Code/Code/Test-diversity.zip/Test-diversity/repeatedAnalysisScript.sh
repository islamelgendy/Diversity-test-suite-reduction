 #!/bin/bash         

export PATH=$PATH:/home/islam/MyWork/Code/defects4j/framework/bin


if [ $# -eq 0 ]
  then
	read -p "Please enter the root directory: " dir
	read -p "Please enter id of project: " id
  elif [ $# -eq 1 ]
    then
    	dir=$1
    	read -p "Please enter id of project: " id
  else
  	dir=$1
  	id=$2
fi

cd $dir

times=()

for i in *
do
	cd $i
	echo "*** Metric $i***"
	for k in *
	do
		cd $k
		echo "*** Folder $k***"
		SECONDS=0
		for j in *
		do
			echo "***Working on file $j***"
			now=$(date +"%r")
			echo "Current time : $now"
			run_mutation.pl -p $id -d $dir/$i/$k/$j/ -o $dir/$i/$k/$j/
  
			run_coverage.pl -p $id -d $dir/$i/$k/$j/ -o $dir/$i/$k/$j/
		done
		duration=$SECONDS
		times+=($duration)
		echo "$(($duration / 60)) minutes and $(($duration % 60)) seconds elapsed."
		cd ..
	done 
	cd ..
done

echo "Displaying times..."

for t in "${times[@]}"
do
  echo "$(($t / 60)) minutes and $(($t % 60)) seconds elapsed."
done

