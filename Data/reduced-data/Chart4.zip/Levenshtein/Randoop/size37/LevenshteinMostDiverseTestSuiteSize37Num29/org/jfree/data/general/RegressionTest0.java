package org.jfree.data.general;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 100.0f, "Range[0.0,100.0]", ' ', 10.0f, (byte) 100 };
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[]");
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray8), "[]");
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[]");
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray10), "[]");
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray11), "[]");
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        double[] doubleArray8 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray39 = new double[][] { doubleArray8, doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        int int41 = categoryDataset40.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset40);
        org.jfree.data.general.DatasetGroup datasetGroup44 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset40.setGroup(datasetGroup44);
        java.util.List list46 = categoryDataset40.getRowKeys();
        double[] doubleArray54 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray60 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray66 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray72 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray78 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray84 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray85 = new double[][] { doubleArray54, doubleArray60, doubleArray66, doubleArray72, doubleArray78, doubleArray84 };
        org.jfree.data.category.CategoryDataset categoryDataset86 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray85);
        int int87 = categoryDataset86.getRowCount();
        org.jfree.data.Range range89 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset86, (double) 10);
        try {
            org.jfree.data.Range range91 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, list46, range89, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray8), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray54), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray60), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray66), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray72), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray78), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray84), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(categoryDataset86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
        org.junit.Assert.assertNotNull(range89);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray9 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray15 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray21 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray27 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray33 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray39 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray40 = new double[][] { doubleArray9, doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset41, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo44 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset41, datasetChangeInfo44);
        xYIntervalSeriesCollection0.notifyListeners(datasetChangeEvent45);
        org.jfree.data.general.DatasetGroup datasetGroup47 = xYIntervalSeriesCollection0.getGroup();
        int int48 = xYIntervalSeriesCollection0.getSeriesCount();
        double[] doubleArray56 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray62 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray68 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray74 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray80 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray86 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray87 = new double[][] { doubleArray56, doubleArray62, doubleArray68, doubleArray74, doubleArray80, doubleArray86 };
        org.jfree.data.category.CategoryDataset categoryDataset88 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray87);
        int int89 = categoryDataset88.getRowCount();
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset88);
        org.jfree.data.general.DatasetGroup datasetGroup92 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset88.setGroup(datasetGroup92);
        java.util.List list94 = categoryDataset88.getRowKeys();
        try {
            org.jfree.data.Range range96 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0, list94, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray15), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray21), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray27), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray33), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray39), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(datasetGroup47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray56), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray62), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray68), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray74), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray80), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray86), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(categoryDataset88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
        org.junit.Assert.assertNotNull(range90);
        org.junit.Assert.assertNotNull(list94);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray44 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray45 = new double[][] { doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset46, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener49 = null;
        categoryDataset46.addChangeListener(datasetChangeListener49);
        double[] doubleArray59 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray65 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray71 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray77 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray83 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray89 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray90 = new double[][] { doubleArray59, doubleArray65, doubleArray71, doubleArray77, doubleArray83, doubleArray89 };
        org.jfree.data.category.CategoryDataset categoryDataset91 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray90);
        org.jfree.data.Range range93 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset91, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo94 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent95 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset91, datasetChangeInfo94);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent96 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) boolean6, (org.jfree.data.general.Dataset) categoryDataset46, datasetChangeInfo94);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray44), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray59), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray65), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray71), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray77), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray83), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray89), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(categoryDataset91);
        org.junit.Assert.assertNotNull(range93);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        double[] doubleArray50 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray56 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray62 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray68 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray74 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray80 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray81 = new double[][] { doubleArray50, doubleArray56, doubleArray62, doubleArray68, doubleArray74, doubleArray80 };
        org.jfree.data.category.CategoryDataset categoryDataset82 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray81);
        int int83 = categoryDataset82.getRowCount();
        org.jfree.data.Range range84 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset82);
        org.jfree.data.general.DatasetGroup datasetGroup86 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset82.setGroup(datasetGroup86);
        java.util.List list88 = categoryDataset82.getRowKeys();
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset39, list88, false);
        try {
            org.jfree.data.pie.PieDataset pieDataset92 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray50), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray56), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray62), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray68), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray74), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray80), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(categoryDataset82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(range84);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(range90);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        xYIntervalSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem12 = new org.jfree.data.xy.XYIntervalDataItem(0.0d, (double) (byte) 100, (double) 100L, (double) (short) 0, (double) (-1.0f), 0.0d);
        xYIntervalSeries3.setKey((java.lang.Comparable) (byte) 100);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection14 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray23 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray29 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray35 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray41 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray47 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray53 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray54 = new double[][] { doubleArray23, doubleArray29, doubleArray35, doubleArray41, doubleArray47, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset55, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo58 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent59 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset55, datasetChangeInfo58);
        xYIntervalSeriesCollection14.notifyListeners(datasetChangeEvent59);
        org.jfree.data.general.DatasetGroup datasetGroup61 = xYIntervalSeriesCollection14.getGroup();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener62 = null;
        xYIntervalSeriesCollection14.removeChangeListener(datasetChangeListener62);
        try {
            xYIntervalSeries3.removeChangeListener((org.jfree.data.event.SeriesChangeListener) xYIntervalSeriesCollection14);
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray23), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray29), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray35), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray41), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray47), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray53), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(datasetGroup61);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 310.0d, 1200.0d, 0, (java.lang.Comparable) "org.jfree.data.event.DatasetChangeEvent[source=-1.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Object obj0 = null;
        double[] doubleArray8 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray39 = new double[][] { doubleArray8, doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset40, false);
        org.jfree.data.pie.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset40, (int) (byte) 0);
        int int46 = pieDataset44.getIndex((java.lang.Comparable) (byte) 0);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection47 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray56 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray62 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray68 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray74 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray80 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray86 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray87 = new double[][] { doubleArray56, doubleArray62, doubleArray68, doubleArray74, doubleArray80, doubleArray86 };
        org.jfree.data.category.CategoryDataset categoryDataset88 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray87);
        org.jfree.data.Range range90 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset88, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo91 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent92 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset88, datasetChangeInfo91);
        xYIntervalSeriesCollection47.notifyListeners(datasetChangeEvent92);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo94 = datasetChangeEvent92.getInfo();
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent95 = new org.jfree.data.event.DatasetChangeEvent(obj0, (org.jfree.data.general.Dataset) pieDataset44, datasetChangeInfo94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray8), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(pieDataset44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray56), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray62), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray68), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray74), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray80), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray86), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(categoryDataset88);
        org.junit.Assert.assertNotNull(range90);
        org.junit.Assert.assertNotNull(datasetChangeInfo94);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.ComparableObjectSeries comparableObjectSeries1 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        comparableObjectSeries1.addChangeListener(seriesChangeListener2);
        int int4 = comparableObjectSeries1.getMaximumItemCount();
        java.lang.String str5 = comparableObjectSeries1.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        comparableObjectSeries1.removeChangeListener(seriesChangeListener6);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection8 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray17 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray23 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray29 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray35 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray41 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray47 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray48 = new double[][] { doubleArray17, doubleArray23, doubleArray29, doubleArray35, doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray48);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset49, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo52 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent53 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset49, datasetChangeInfo52);
        xYIntervalSeriesCollection8.notifyListeners(datasetChangeEvent53);
        org.jfree.data.general.DatasetGroup datasetGroup55 = xYIntervalSeriesCollection8.getGroup();
        int int56 = xYIntervalSeriesCollection8.getSeriesCount();
        int int57 = xYIntervalSeriesCollection8.getSeriesCount();
        int int59 = xYIntervalSeriesCollection8.indexOf((java.lang.Comparable) 32.0d);
        try {
            comparableObjectSeries1.removeChangeListener((org.jfree.data.event.SeriesChangeListener) xYIntervalSeriesCollection8);
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray17), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray23), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray29), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray35), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray41), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray47), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertNotNull(datasetGroup55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        double[] doubleArray22 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray28 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray34 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray40 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray46 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray52 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray53 = new double[][] { doubleArray22, doubleArray28, doubleArray34, doubleArray40, doubleArray46, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray53);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset54, false);
        org.jfree.data.pie.PieDataset pieDataset58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset54, (int) (byte) 0);
        int int60 = pieDataset58.getIndex((java.lang.Comparable) (byte) 0);
        org.jfree.data.pie.PieDataset pieDataset64 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset58, (java.lang.Comparable) "Range[0.0,100.0]", 310.0d, 10);
        org.jfree.data.category.CategoryDataset categoryDataset65 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) (byte) 0, (org.jfree.data.KeyedValues) pieDataset64);
        java.util.List list66 = pieDataset64.getKeys();
        try {
            org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0, list66, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray22), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray28), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray34), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray40), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray46), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray52), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(pieDataset58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(pieDataset64);
        org.junit.Assert.assertNotNull(categoryDataset65);
        org.junit.Assert.assertNotNull(list66);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        double[][] doubleArray47 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray47);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset48);
        double[] doubleArray57 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray63 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray69 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray75 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray81 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray87 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray88 = new double[][] { doubleArray57, doubleArray63, doubleArray69, doubleArray75, doubleArray81, doubleArray87 };
        org.jfree.data.category.CategoryDataset categoryDataset89 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray88);
        int int90 = categoryDataset89.getRowCount();
        org.jfree.data.Range range91 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset89);
        org.jfree.data.general.DatasetGroup datasetGroup93 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset89.setGroup(datasetGroup93);
        java.util.List list95 = categoryDataset89.getRowKeys();
        org.jfree.data.Range range97 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset48, list95, false);
        org.jfree.data.Range range99 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset39, list95, true);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertEquals("'" + number44 + "' != '" + 600.0d + "'", number44, 600.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray57), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray63), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray69), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray75), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray81), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray87), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(categoryDataset89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 6 + "'", int90 == 6);
        org.junit.Assert.assertNotNull(range91);
        org.junit.Assert.assertNotNull(list95);
        org.junit.Assert.assertNull(range97);
        org.junit.Assert.assertNotNull(range99);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset39);
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem53 = new org.jfree.data.xy.XYIntervalDataItem((double) 1, (double) 0.0f, (double) (short) -1, (double) ' ', (double) '#', (double) 1.0f);
        double double54 = xYIntervalDataItem53.getXLowValue();
        try {
            java.lang.Number number56 = categoryDataset39.getValue((java.lang.Comparable) xYIntervalDataItem53, (java.lang.Comparable) '4');
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (org.jfree.data.xy.XYIntervalDataItem@5f00b26d) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray9 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray15 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray21 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray27 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray33 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray39 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray40 = new double[][] { doubleArray9, doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset41, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo44 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset41, datasetChangeInfo44);
        xYIntervalSeriesCollection0.notifyListeners(datasetChangeEvent45);
        org.jfree.data.general.DatasetGroup datasetGroup47 = xYIntervalSeriesCollection0.getGroup();
        int int48 = xYIntervalSeriesCollection0.getSeriesCount();
        int int49 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection50 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException52 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("hi!");
        seriesException52.addSuppressed((java.lang.Throwable) seriesException54);
        boolean boolean56 = xYIntervalSeriesCollection50.equals((java.lang.Object) seriesException52);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection57 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean58 = xYIntervalSeriesCollection50.hasListener((java.util.EventListener) xYIntervalSeriesCollection57);
        boolean boolean59 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection50);
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection50, false);
        boolean boolean62 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection50);
        try {
            java.lang.Number number65 = xYIntervalSeriesCollection0.getStartY((int) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray15), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray21), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray27), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray33), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray39), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(datasetGroup47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        double[] doubleArray18 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray24 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray30 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray36 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray42 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray48 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray49 = new double[][] { doubleArray18, doubleArray24, doubleArray30, doubleArray36, doubleArray42, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray49);
        int int51 = categoryDataset50.getRowCount();
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset50);
        org.jfree.data.general.DatasetGroup datasetGroup54 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset50.setGroup(datasetGroup54);
        java.util.List list56 = categoryDataset50.getRowKeys();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) categoryDataset50);
        xYIntervalSeriesCollection0.seriesChanged(seriesChangeEvent57);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray18), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray24), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray30), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray36), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray42), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray48), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(list56);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str5 = datasetGroup4.getID();
        xYIntervalSeriesCollection0.setGroup(datasetGroup4);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = null;
        xYIntervalSeriesCollection0.setSelectionState(xYDatasetSelectionState7);
        double[] doubleArray16 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray22 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray28 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray34 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray40 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray46 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray47 = new double[][] { doubleArray16, doubleArray22, doubleArray28, doubleArray34, doubleArray40, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray47);
        org.jfree.data.Range range50 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset48, false);
        java.lang.Number number51 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset48);
        java.util.List list52 = categoryDataset48.getColumnKeys();
        double[] doubleArray60 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray66 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray72 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray78 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray84 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray90 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray91 = new double[][] { doubleArray60, doubleArray66, doubleArray72, doubleArray78, doubleArray84, doubleArray90 };
        org.jfree.data.category.CategoryDataset categoryDataset92 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray91);
        org.jfree.data.Range range94 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset92, false);
        org.jfree.data.Range range96 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset92, true);
        double double97 = range96.getUpperBound();
        try {
            org.jfree.data.Range range99 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0, list52, range96, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "hi!" + "'", str5, "hi!");
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray16), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray22), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray28), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray34), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray40), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray46), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertEquals("'" + number51 + "' != '" + 0.0d + "'", number51, 0.0d);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray60), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray66), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray72), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray78), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray84), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray90), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(categoryDataset92);
        org.junit.Assert.assertNotNull(range94);
        org.junit.Assert.assertNotNull(range96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 100.0d + "'", double97 == 100.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int4 = xYIntervalSeries3.getItemCount();
        boolean boolean5 = xYIntervalSeries3.isEmpty();
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray44 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray45 = new double[][] { doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset46, false);
        org.jfree.data.Range range51 = org.jfree.data.Range.expand(range48, (double) (-1L), (double) (short) 0);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection52 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException54 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException56 = new org.jfree.data.general.SeriesException("hi!");
        seriesException54.addSuppressed((java.lang.Throwable) seriesException56);
        boolean boolean58 = xYIntervalSeriesCollection52.equals((java.lang.Object) seriesException54);
        int int60 = xYIntervalSeriesCollection52.indexOf((java.lang.Comparable) false);
        java.lang.Object obj61 = xYIntervalSeriesCollection52.clone();
        xYIntervalSeries3.firePropertyChange("hi!", (java.lang.Object) range48, obj61);
        try {
            double double64 = xYIntervalSeries3.getYLowValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray44), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0, true);
        int int12 = xYIntervalSeriesCollection0.indexOf((java.lang.Comparable) 10.0d);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0, seriesChangeInfo14);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo16 = null;
        seriesChangeEvent15.setSummary(seriesChangeInfo16);
        xYIntervalSeriesCollection0.seriesChanged(seriesChangeEvent15);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int4 = xYIntervalSeries3.getItemCount();
        int int5 = xYIntervalSeries3.getItemCount();
        xYIntervalSeries3.add(0.0d, (double) (-1.0f), 0.0d, (double) (byte) -1, (double) (-1L), (double) (byte) 1);
        xYIntervalSeries3.add((double) 5, 101.0d, 10.0d, (double) (short) 1, 600.0d, (double) 1.0f);
        int int20 = xYIntervalSeries3.getItemCount();
        double[] doubleArray28 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray34 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray40 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray46 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray52 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray58 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray59 = new double[][] { doubleArray28, doubleArray34, doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray59);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset60, false);
        java.lang.String str63 = range62.toString();
        org.jfree.data.Range range65 = org.jfree.data.Range.expandToInclude(range62, (double) (-1.0f));
        boolean boolean66 = xYIntervalSeries3.equals((java.lang.Object) range65);
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem73 = new org.jfree.data.xy.XYIntervalDataItem((double) 1, (double) 0.0f, (double) (short) -1, (double) ' ', (double) '#', (double) 1.0f);
        double double74 = xYIntervalDataItem73.getXLowValue();
        java.lang.Object obj75 = xYIntervalDataItem73.clone();
        double double76 = xYIntervalDataItem73.getXLowValue();
        double double77 = xYIntervalDataItem73.getYLowValue();
        boolean boolean78 = xYIntervalSeries3.equals((java.lang.Object) xYIntervalDataItem73);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray28), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray34), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray40), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray46), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray52), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray58), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertEquals("'" + str63 + "' != '" + "Range[0.0,100.0]" + "'", str63, "Range[0.0,100.0]");
        org.junit.Assert.assertNotNull(range65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 35.0d + "'", double77 == 35.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int4 = xYIntervalSeries3.getItemCount();
        boolean boolean5 = xYIntervalSeries3.isEmpty();
        xYIntervalSeries3.clear();
        int int8 = xYIntervalSeries3.indexOf((java.lang.Comparable) 5);
        double[] doubleArray17 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray23 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray29 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray35 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray41 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray47 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray48 = new double[][] { doubleArray17, doubleArray23, doubleArray29, doubleArray35, doubleArray41, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray48);
        java.lang.Number number50 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset49);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset49);
        java.lang.Comparable comparable53 = categoryDataset49.getRowKey(2);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset49);
        org.jfree.data.general.DatasetGroup datasetGroup56 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.data.general.SeriesException seriesException58 = new org.jfree.data.general.SeriesException("hi!");
        boolean boolean59 = datasetGroup56.equals((java.lang.Object) seriesException58);
        org.jfree.data.general.SeriesException seriesException61 = new org.jfree.data.general.SeriesException("Range[0.0,100.0]");
        seriesException58.addSuppressed((java.lang.Throwable) seriesException61);
        xYIntervalSeries3.firePropertyChange("org.jfree.data.event.SeriesChangeEvent[source=0]", (java.lang.Object) categoryDataset49, (java.lang.Object) seriesException61);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray17), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray23), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray29), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray35), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray41), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray47), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertEquals("'" + number50 + "' != '" + 0.0d + "'", number50, 0.0d);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertEquals("'" + comparable53 + "' != '" + "hi!3" + "'", comparable53, "hi!3");
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.ComparableObjectSeries comparableObjectSeries9 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        comparableObjectSeries9.addChangeListener(seriesChangeListener10);
        int int13 = comparableObjectSeries9.indexOf((java.lang.Comparable) 100);
        org.jfree.data.ComparableObjectSeries comparableObjectSeries16 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        comparableObjectSeries16.addChangeListener(seriesChangeListener17);
        int int19 = comparableObjectSeries16.getMaximumItemCount();
        comparableObjectSeries16.fireSeriesChanged();
        double[] doubleArray28 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray34 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray40 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray46 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray52 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray58 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray59 = new double[][] { doubleArray28, doubleArray34, doubleArray40, doubleArray46, doubleArray52, doubleArray58 };
        org.jfree.data.category.CategoryDataset categoryDataset60 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray59);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset60, false);
        org.jfree.data.general.DatasetGroup datasetGroup64 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset60.setGroup(datasetGroup64);
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset60);
        comparableObjectSeries9.firePropertyChange("", (java.lang.Object) comparableObjectSeries16, (java.lang.Object) categoryDataset60);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent69 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) '4');
        comparableObjectSeries16.notifyListeners(seriesChangeEvent69);
        xYIntervalSeriesCollection0.seriesChanged(seriesChangeEvent69);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray28), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray34), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray40), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray46), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray52), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray58), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(categoryDataset60);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertNotNull(range66);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!1");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10.0f, (short) 1, 2147483647 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,100.0]", "", numberArray8);
        java.lang.Comparable comparable11 = categoryDataset9.getColumnKey((int) (short) 1);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset9);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) 2, (double) (short) 1);
        boolean boolean16 = datasetGroup1.equals((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass17 = datasetGroup1.getClass();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertEquals("'" + comparable11 + "' != '" + "2" + "'", comparable11, "2");
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        int int14 = xYIntervalSeriesCollection0.getSeriesCount();
        int int15 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem22 = new org.jfree.data.xy.XYIntervalDataItem((double) (-1.0f), (double) 10L, (double) 10L, (double) (byte) 0, (double) (byte) 10, 310.0d);
        double double23 = xYIntervalDataItem22.getXHighValue();
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries24 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) xYIntervalDataItem22);
        xYIntervalSeriesCollection0.removeSeries(xYIntervalSeries24);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.jfree.data.pie.PieDataset pieDataset44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (short) 0);
        int int45 = pieDataset44.getItemCount();
        java.lang.Comparable comparable47 = pieDataset44.getKey(1);
        org.jfree.data.pie.PieDatasetSelectionState pieDatasetSelectionState48 = pieDataset44.getSelectionState();
        java.lang.Number number50 = pieDataset44.getValue((int) '#');
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(pieDataset44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertEquals("'" + comparable47 + "' != '" + "hi!2" + "'", comparable47, "hi!2");
        org.junit.Assert.assertNotNull(pieDatasetSelectionState48);
        org.junit.Assert.assertNull(number50);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem10 = new org.jfree.data.xy.XYIntervalDataItem(0.0d, (double) (byte) 100, (double) 100L, (double) (short) 0, (double) (-1.0f), 0.0d);
        int int12 = xYIntervalDataItem10.compareTo((java.lang.Object) "hi!");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0, seriesChangeInfo14);
        org.jfree.data.ComparableObjectItem comparableObjectItem16 = new org.jfree.data.ComparableObjectItem((java.lang.Comparable) int12, (java.lang.Object) seriesChangeEvent15);
        int int17 = xYIntervalSeriesCollection0.indexOf((java.lang.Comparable) int12);
        org.jfree.data.DomainOrder domainOrder18 = xYIntervalSeriesCollection0.getDomainOrder();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(domainOrder18);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray9 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray15 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray21 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray27 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray33 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray39 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray40 = new double[][] { doubleArray9, doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset41, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo44 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset41, datasetChangeInfo44);
        xYIntervalSeriesCollection0.notifyListeners(datasetChangeEvent45);
        org.jfree.data.general.DatasetGroup datasetGroup47 = xYIntervalSeriesCollection0.getGroup();
        int int48 = xYIntervalSeriesCollection0.getSeriesCount();
        int int49 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener50 = null;
        xYIntervalSeriesCollection0.addChangeListener(datasetChangeListener50);
        boolean boolean52 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray15), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray21), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray27), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray33), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray39), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(datasetGroup47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        xYIntervalSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0, seriesChangeInfo7);
        xYIntervalSeries3.notifyListeners(seriesChangeEvent8);
        int int10 = xYIntervalSeries3.getItemCount();
        double[] doubleArray18 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray24 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray30 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray36 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray42 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray48 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray49 = new double[][] { doubleArray18, doubleArray24, doubleArray30, doubleArray36, doubleArray42, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray49);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset50, false);
        int int54 = categoryDataset50.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset50);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo56 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) range55, seriesChangeInfo56);
        java.lang.Object obj58 = seriesChangeEvent57.getSource();
        xYIntervalSeries3.notifyListeners(seriesChangeEvent57);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray18), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray24), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray30), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray36), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray42), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray48), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(obj58);
        org.junit.Assert.assertEquals(obj58.toString(), "Range[0.0,600.0]");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj58), "Range[0.0,600.0]");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj58), "Range[0.0,600.0]");
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) (short) 1);
        org.jfree.data.ComparableObjectSeries comparableObjectSeries48 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        boolean boolean49 = range46.equals((java.lang.Object) comparableObjectSeries48);
        comparableObjectSeries48.fireSeriesChanged();
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection51 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException53 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException55 = new org.jfree.data.general.SeriesException("hi!");
        seriesException53.addSuppressed((java.lang.Throwable) seriesException55);
        boolean boolean57 = xYIntervalSeriesCollection51.equals((java.lang.Object) seriesException53);
        java.lang.Number number58 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection51);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState59 = xYIntervalSeriesCollection51.getSelectionState();
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection51);
        boolean boolean61 = comparableObjectSeries48.equals((java.lang.Object) xYIntervalSeriesCollection51);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(number58);
        org.junit.Assert.assertNull(xYDatasetSelectionState59);
        org.junit.Assert.assertNull(number60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem6 = new org.jfree.data.xy.XYIntervalDataItem((double) 1, (double) 0.0f, (double) (short) -1, (double) ' ', (double) '#', (double) 1.0f);
        double double7 = xYIntervalDataItem6.getXLowValue();
        double[] doubleArray15 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray21 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray27 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray33 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray39 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray45 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray46 = new double[][] { doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray46);
        int int48 = categoryDataset47.getRowCount();
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset47);
        org.jfree.data.general.DatasetGroup datasetGroup51 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset47.setGroup(datasetGroup51);
        java.util.List list53 = categoryDataset47.getRowKeys();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener54 = null;
        categoryDataset47.addChangeListener(datasetChangeListener54);
        boolean boolean56 = xYIntervalDataItem6.equals((java.lang.Object) datasetChangeListener54);
        org.jfree.data.ComparableObjectSeries comparableObjectSeries59 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) xYIntervalDataItem6, false, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray15), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray21), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray27), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray33), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray39), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray45), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.DomainOrder domainOrder3 = xYIntervalSeriesCollection0.getDomainOrder();
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection4 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        boolean boolean10 = xYIntervalSeriesCollection4.equals((java.lang.Object) seriesException6);
        boolean boolean11 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection4);
        int int12 = xYIntervalSeriesCollection0.getSeriesCount();
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.DomainOrder domainOrder3 = xYIntervalSeriesCollection0.getDomainOrder();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection5 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray44 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray45 = new double[][] { doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset46, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo49 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent50 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset46, datasetChangeInfo49);
        xYIntervalSeriesCollection5.notifyListeners(datasetChangeEvent50);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo52 = datasetChangeEvent50.getInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo52);
        try {
            double double56 = xYIntervalSeriesCollection0.getYValue(6, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNotNull(domainOrder3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray44), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(datasetChangeInfo52);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem50 = new org.jfree.data.xy.XYIntervalDataItem(0.0d, (double) (byte) 100, (double) 100L, (double) (short) 0, (double) (-1.0f), 0.0d);
        int int51 = categoryDataset39.getColumnIndex((java.lang.Comparable) 0.0d);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries56 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int57 = xYIntervalSeries56.getItemCount();
        int int58 = xYIntervalSeries56.getItemCount();
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries63 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int64 = xYIntervalSeries63.getItemCount();
        boolean boolean65 = xYIntervalSeries63.isEmpty();
        xYIntervalSeries63.clear();
        int int67 = xYIntervalSeries63.getMaximumItemCount();
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem74 = new org.jfree.data.xy.XYIntervalDataItem((double) (-1.0f), (double) 10L, (double) 10L, (double) (byte) 0, (double) (byte) 10, 310.0d);
        double double75 = xYIntervalDataItem74.getXHighValue();
        boolean boolean76 = xYIntervalSeries63.equals((java.lang.Object) double75);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection77 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number78 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection77);
        java.lang.Number number79 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection77);
        org.jfree.data.general.DatasetGroup datasetGroup81 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str82 = datasetGroup81.getID();
        xYIntervalSeriesCollection77.setGroup(datasetGroup81);
        xYIntervalSeries56.firePropertyChange("", (java.lang.Object) boolean76, (java.lang.Object) datasetGroup81);
        categoryDataset39.setGroup(datasetGroup81);
        org.jfree.data.Range range87 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10L);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2147483647 + "'", int67 == 2147483647);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10.0d + "'", double75 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(number78);
        org.junit.Assert.assertNull(number79);
        org.junit.Assert.assertEquals("'" + str82 + "' != '" + "hi!" + "'", str82, "hi!");
        org.junit.Assert.assertNotNull(range87);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.xy.XYInterval xYInterval5 = new org.jfree.data.xy.XYInterval((double) 1, (double) (short) -1, (double) 2, 0.0d, 0.0d);
        double double6 = xYInterval5.getXHigh();
        double double7 = xYInterval5.getXLow();
        org.jfree.data.general.DatasetGroup datasetGroup9 = new org.jfree.data.general.DatasetGroup("hi!1");
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10.0f, (short) 1, 2147483647 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,100.0]", "", numberArray16);
        java.lang.Comparable comparable19 = categoryDataset17.getColumnKey((int) (short) 1);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset17);
        org.jfree.data.Range range23 = org.jfree.data.Range.expand(range20, (double) 2, (double) (short) 1);
        boolean boolean24 = datasetGroup9.equals((java.lang.Object) 2);
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray44 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray50 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray56 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray62 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray63 = new double[][] { doubleArray32, doubleArray38, doubleArray44, doubleArray50, doubleArray56, doubleArray62 };
        org.jfree.data.category.CategoryDataset categoryDataset64 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray63);
        org.jfree.data.Range range66 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset64, false);
        int int67 = categoryDataset64.getRowCount();
        boolean boolean68 = datasetGroup9.equals((java.lang.Object) categoryDataset64);
        boolean boolean69 = xYInterval5.equals((java.lang.Object) categoryDataset64);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertEquals("'" + comparable19 + "' != '" + "2" + "'", comparable19, "2");
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray44), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray50), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray56), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray62), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(categoryDataset64);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str5 = datasetGroup4.getID();
        xYIntervalSeriesCollection0.setGroup(datasetGroup4);
        int int7 = xYIntervalSeriesCollection0.getSeriesCount();
        java.lang.Object obj8 = xYIntervalSeriesCollection0.clone();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = null;
        xYIntervalSeriesCollection0.seriesChanged(seriesChangeEvent9);
        double[] doubleArray18 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray24 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray30 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray36 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray42 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray48 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray49 = new double[][] { doubleArray18, doubleArray24, doubleArray30, doubleArray36, doubleArray42, doubleArray48 };
        org.jfree.data.category.CategoryDataset categoryDataset50 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray49);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset50, false);
        int int54 = categoryDataset50.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range55 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset50);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo56 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) range55, seriesChangeInfo56);
        xYIntervalSeriesCollection0.seriesChanged(seriesChangeEvent57);
        org.jfree.data.DomainOrder domainOrder59 = xYIntervalSeriesCollection0.getDomainOrder();
        try {
            int int61 = xYIntervalSeriesCollection0.getItemCount(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "hi!" + "'", str5, "hi!");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray18), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray24), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray30), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray36), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray42), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray48), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(categoryDataset50);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertNotNull(domainOrder59);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int4 = xYIntervalSeries3.getItemCount();
        int int5 = xYIntervalSeries3.getItemCount();
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries10 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int11 = xYIntervalSeries10.getItemCount();
        boolean boolean12 = xYIntervalSeries10.isEmpty();
        xYIntervalSeries10.clear();
        int int14 = xYIntervalSeries10.getMaximumItemCount();
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem21 = new org.jfree.data.xy.XYIntervalDataItem((double) (-1.0f), (double) 10L, (double) 10L, (double) (byte) 0, (double) (byte) 10, 310.0d);
        double double22 = xYIntervalDataItem21.getXHighValue();
        boolean boolean23 = xYIntervalSeries10.equals((java.lang.Object) double22);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection24 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection24);
        org.jfree.data.general.DatasetGroup datasetGroup28 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str29 = datasetGroup28.getID();
        xYIntervalSeriesCollection24.setGroup(datasetGroup28);
        xYIntervalSeries3.firePropertyChange("", (java.lang.Object) boolean23, (java.lang.Object) datasetGroup28);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection32 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException36 = new org.jfree.data.general.SeriesException("hi!");
        seriesException34.addSuppressed((java.lang.Throwable) seriesException36);
        boolean boolean38 = xYIntervalSeriesCollection32.equals((java.lang.Object) seriesException34);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection39 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean40 = xYIntervalSeriesCollection32.hasListener((java.util.EventListener) xYIntervalSeriesCollection39);
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection32);
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries45 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
        xYIntervalSeries45.removeChangeListener(seriesChangeListener46);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo49 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0, seriesChangeInfo49);
        xYIntervalSeries45.notifyListeners(seriesChangeEvent50);
        java.lang.Comparable comparable52 = xYIntervalSeries45.getKey();
        xYIntervalSeriesCollection32.removeSeries(xYIntervalSeries45);
        try {
            xYIntervalSeries3.addChangeListener((org.jfree.data.event.SeriesChangeListener) xYIntervalSeriesCollection32);
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "hi!" + "'", str29, "hi!");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(number41);
        org.junit.Assert.assertEquals("'" + comparable52 + "' != '" + 1.0d + "'", comparable52, 1.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries3 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int4 = xYIntervalSeries3.getItemCount();
        int int5 = xYIntervalSeries3.getItemCount();
        org.jfree.data.xy.XYIntervalSeries xYIntervalSeries10 = new org.jfree.data.xy.XYIntervalSeries((java.lang.Comparable) 1.0d, false, false);
        int int11 = xYIntervalSeries10.getItemCount();
        boolean boolean12 = xYIntervalSeries10.isEmpty();
        xYIntervalSeries10.clear();
        int int14 = xYIntervalSeries10.getMaximumItemCount();
        org.jfree.data.xy.XYIntervalDataItem xYIntervalDataItem21 = new org.jfree.data.xy.XYIntervalDataItem((double) (-1.0f), (double) 10L, (double) 10L, (double) (byte) 0, (double) (byte) 10, 310.0d);
        double double22 = xYIntervalDataItem21.getXHighValue();
        boolean boolean23 = xYIntervalSeries10.equals((java.lang.Object) double22);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection24 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection24);
        java.lang.Number number26 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection24);
        org.jfree.data.general.DatasetGroup datasetGroup28 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str29 = datasetGroup28.getID();
        xYIntervalSeriesCollection24.setGroup(datasetGroup28);
        xYIntervalSeries3.firePropertyChange("", (java.lang.Object) boolean23, (java.lang.Object) datasetGroup28);
        boolean boolean32 = xYIntervalSeries3.isEmpty();
        xYIntervalSeries3.add((double) (short) 100, 0.0d, (double) (byte) 1, 101.0d, (double) 1.0f, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "hi!" + "'", str29, "hi!");
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.ComparableObjectSeries comparableObjectSeries1 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        comparableObjectSeries1.addChangeListener(seriesChangeListener2);
        int int5 = comparableObjectSeries1.indexOf((java.lang.Comparable) 100);
        org.jfree.data.ComparableObjectSeries comparableObjectSeries8 = new org.jfree.data.ComparableObjectSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        comparableObjectSeries8.addChangeListener(seriesChangeListener9);
        int int11 = comparableObjectSeries8.getMaximumItemCount();
        comparableObjectSeries8.fireSeriesChanged();
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray44 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray50 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray51 = new double[][] { doubleArray20, doubleArray26, doubleArray32, doubleArray38, doubleArray44, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray51);
        org.jfree.data.Range range54 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset52, false);
        org.jfree.data.general.DatasetGroup datasetGroup56 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset52.setGroup(datasetGroup56);
        org.jfree.data.Range range58 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset52);
        comparableObjectSeries1.firePropertyChange("", (java.lang.Object) comparableObjectSeries8, (java.lang.Object) categoryDataset52);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) '4');
        comparableObjectSeries8.notifyListeners(seriesChangeEvent61);
        comparableObjectSeries8.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray44), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray50), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(range58);
    }

    @Test
    public void test501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test501");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection2 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection2);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection2);
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str7 = datasetGroup6.getID();
        xYIntervalSeriesCollection2.setGroup(datasetGroup6);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState9 = null;
        xYIntervalSeriesCollection2.setSelectionState(xYDatasetSelectionState9);
        boolean boolean11 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection2);
        try {
            java.lang.Number number14 = xYIntervalSeriesCollection2.getX(0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertEquals("'" + str7 + "' != '" + "hi!" + "'", str7, "hi!");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

}
