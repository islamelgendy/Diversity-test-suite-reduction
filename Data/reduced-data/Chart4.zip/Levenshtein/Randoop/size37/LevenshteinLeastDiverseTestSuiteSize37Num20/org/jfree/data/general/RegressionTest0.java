package org.jfree.data.general;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Class<?> wildcardClass42 = categoryDataset39.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Class<?> wildcardClass42 = range41.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        try {
            java.lang.Number number46 = categoryDataset39.getValue(10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        try {
            org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        double double45 = range44.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        boolean boolean44 = range41.intersects((double) (-1), 0.0d);
        try {
            org.jfree.data.Range range46 = org.jfree.data.Range.scale(range41, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.shift(range41, (double) 100.0f, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        boolean boolean47 = range44.intersects((double) 'a', (double) 6);
        double double48 = range44.getLength();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        double double46 = range45.getLowerBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 100.0d + "'", double46 == 100.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + number40 + "' != '" + 0.0d + "'", number40, 0.0d);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        org.jfree.data.pie.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        int int46 = categoryDataset39.getColumnCount();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 5 + "'", int46 == 5);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, true);
        java.util.List list44 = categoryDataset39.getColumnKeys();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertEquals("'" + number45 + "' != '" + 600.0d + "'", number45, 600.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        boolean boolean47 = range44.intersects((double) (-1.0f), (double) '4');
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.general.DatasetGroup datasetGroup43 = categoryDataset39.getGroup();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(datasetGroup43);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        java.util.List list43 = categoryDataset39.getColumnKeys();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + number42 + "' != '" + 0.0d + "'", number42, 0.0d);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        try {
            java.lang.Comparable comparable45 = categoryDataset39.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, true);
        double double44 = range43.getUpperBound();
        java.lang.String str45 = range43.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "Range[0.0,100.0]" + "'", str45, "Range[0.0,100.0]");
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        java.lang.Object obj45 = datasetGroup43.clone();
        java.lang.Object obj46 = datasetGroup43.clone();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        try {
            org.jfree.data.Range range44 = org.jfree.data.Range.scale(range41, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int42 = categoryDataset39.getRowCount();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.jfree.data.Range range47 = org.jfree.data.Range.scale(range45, (double) 100.0f);
        org.jfree.data.Range range49 = org.jfree.data.Range.scale(range45, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(range49);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        double double47 = range45.constrain((double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.0d + "'", double47 == 100.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int42 = categoryDataset39.getRowCount();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Object obj45 = null;
        boolean boolean46 = range44.equals(obj45);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        int int45 = pieDataset43.getIndex((java.lang.Comparable) (byte) 0);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener46 = null;
        pieDataset43.removeChangeListener(datasetChangeListener46);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.addChangeListener(datasetChangeListener42);
        java.lang.Number number44 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + number44 + "' != '" + 600.0d + "'", number44, 600.0d);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        double double44 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 6.0d + "'", double44 == 6.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.String str42 = range41.toString();
        org.jfree.data.Range range44 = org.jfree.data.Range.expandToInclude(range41, (double) (-1.0f));
        org.jfree.data.Range range47 = org.jfree.data.Range.expand(range44, 310.0d, 50.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "Range[0.0,100.0]" + "'", str42, "Range[0.0,100.0]");
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        boolean boolean44 = range41.equals((java.lang.Object) "org.jfree.data.event.DatasetChangeEvent[source=-1.0]");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "org.jfree.data.event.DatasetChangeEvent[source=-1.0]");
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        double double46 = range45.getCentralValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 300.0d + "'", double46 == 300.0d);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

}
