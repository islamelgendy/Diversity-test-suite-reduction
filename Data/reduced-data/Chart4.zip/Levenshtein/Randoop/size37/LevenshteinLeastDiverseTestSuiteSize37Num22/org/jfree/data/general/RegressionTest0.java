package org.jfree.data.general;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.util.List list40 = null;
        try {
            org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, list40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        try {
            org.jfree.data.pie.PieDataset pieDataset41 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        boolean boolean44 = range41.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Class<?> wildcardClass42 = categoryDataset39.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Class<?> wildcardClass42 = range41.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        try {
            org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        try {
            java.lang.Number number44 = categoryDataset39.getValue((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        double double45 = range44.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Comparable comparable41 = categoryDataset39.getColumnKey(0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + comparable41 + "' != '" + "hi!1" + "'", comparable41, "hi!1");
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { 100.0f, "Range[0.0,100.0]", ' ', 10.0f, (byte) 100 };
        double[] doubleArray7 = new double[] {};
        double[] doubleArray8 = new double[] {};
        double[] doubleArray9 = new double[] {};
        double[] doubleArray10 = new double[] {};
        double[] doubleArray11 = new double[] {};
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray8, doubleArray9, doubleArray10, doubleArray11 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray6, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[]");
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray8), "[]");
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[]");
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray10), "[]");
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray11), "[]");
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.shift(range41, (double) 100.0f, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertEquals("'" + number41 + "' != '" + 100.0d + "'", number41, 100.0d);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertEquals("'" + number41 + "' != '" + 100.0d + "'", number41, 100.0d);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + number40 + "' != '" + 0.0d + "'", number40, 0.0d);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        org.jfree.data.pie.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        int int46 = categoryDataset39.getColumnCount();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 5 + "'", int46 == 5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        java.util.List list43 = categoryDataset39.getRowKeys();
        int int44 = categoryDataset39.getRowCount();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        boolean boolean47 = range44.intersects((double) (-1.0f), (double) '4');
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        boolean boolean44 = range41.intersects((double) (-1), 0.0d);
        double double45 = range41.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.general.DatasetGroup datasetGroup43 = categoryDataset39.getGroup();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(datasetGroup43);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection4 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection4);
        org.jfree.data.DomainOrder domainOrder7 = xYIntervalSeriesCollection4.getDomainOrder();
        java.lang.Object obj8 = xYIntervalSeriesCollection4.clone();
        boolean boolean9 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection4);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(domainOrder7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!1");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10.0f, (short) 1, 2147483647 };
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,100.0]", "", numberArray8);
        java.lang.Comparable comparable11 = categoryDataset9.getColumnKey((int) (short) 1);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset9);
        org.jfree.data.Range range15 = org.jfree.data.Range.expand(range12, (double) 2, (double) (short) 1);
        boolean boolean16 = datasetGroup1.equals((java.lang.Object) 2);
        java.lang.Class<?> wildcardClass17 = datasetGroup1.getClass();
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertEquals("'" + comparable11 + "' != '" + "2" + "'", comparable11, "2");
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int42 = categoryDataset39.getRowCount();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.KeyToGroupMap keyToGroupMap41 = null;
        try {
            org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, keyToGroupMap41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10.0f, (short) 1, 2147483647 };
        java.lang.Number[][] numberArray6 = new java.lang.Number[][] { numberArray5 };
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Range[0.0,100.0]", "", numberArray6);
        java.lang.Comparable comparable9 = categoryDataset7.getColumnKey((int) (short) 1);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset7);
        org.jfree.data.Range range13 = org.jfree.data.Range.expand(range10, (double) 2, (double) (short) 1);
        java.lang.String str14 = range13.toString();
        double double15 = range13.getLowerBound();
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertEquals("'" + comparable9 + "' != '" + "2" + "'", comparable9, "2");
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertEquals("'" + str14 + "' != '" + "Range[-4.294967316E9,4.294967316E9]" + "'", str14, "Range[-4.294967316E9,4.294967316E9]");
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-4.294967316E9d) + "'", double15 == (-4.294967316E9d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str5 = datasetGroup4.getID();
        xYIntervalSeriesCollection0.setGroup(datasetGroup4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener9 = null;
        xYIntervalSeriesCollection0.addChangeListener(datasetChangeListener9);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "hi!" + "'", str5, "hi!");
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str5 = datasetGroup4.getID();
        xYIntervalSeriesCollection0.setGroup(datasetGroup4);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) xYIntervalSeriesCollection0);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "hi!" + "'", str5, "hi!");
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.general.DatasetGroup datasetGroup4 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str5 = datasetGroup4.getID();
        xYIntervalSeriesCollection0.setGroup(datasetGroup4);
        int int7 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "hi!" + "'", str5, "hi!");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        double double44 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 6.0d + "'", double44 == 6.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        double double46 = range45.getCentralValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 300.0d + "'", double46 == 300.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        java.util.List list41 = null;
        try {
            org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, list41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + number40 + "' != '" + 0.0d + "'", number40, 0.0d);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

}
