package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0072");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator4 = jDOMNodePointer2.namespaceIterator();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        java.lang.Object obj8 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler11 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer12 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer7, qName9, (java.lang.Object) 1.0d, dynamicPropertyHandler11);
        org.apache.commons.jxpath.ri.QName qName13 = dynamicPointer12.getName();
        boolean boolean14 = dynamicPointer12.isLeaf();
        org.apache.commons.jxpath.ri.QName qName15 = dynamicPointer12.getName();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory16 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale18);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = jDOMNodePointer19.getImmediateParentPointer();
        java.lang.Object obj21 = jDOMNodePointer19.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver22 = jDOMNodePointer19.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext23 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer19);
        org.apache.commons.jxpath.ri.parser.Token token24 = null;
        int[] intArray26 = new int[] { 10 };
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[][] intArray31 = new int[][] { intArray26, intArray28, intArray30 };
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException37 = new org.apache.commons.jxpath.ri.parser.ParseException(token24, intArray31, strArray36);
        org.apache.commons.jxpath.JXPathContext jXPathContext38 = jXPathContextFactory16.newContext(jXPathContext23, (java.lang.Object) token24);
        java.lang.Object obj39 = jXPathContext38.getContextBean();
        java.lang.Object obj40 = jXPathContext38.getContextBean();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer41 = dynamicPointer12.createPath(jXPathContext38);
        org.apache.commons.jxpath.ri.QName qName43 = new org.apache.commons.jxpath.ri.QName("");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = jDOMNodePointer2.createChild(jXPathContext38, qName43, 2, (java.lang.Object) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: ");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNotNull(nodeIterator4);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(qName13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(qName15);
        org.junit.Assert.assertNotNull(jXPathContextFactory16);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(namespaceResolver22);
        org.junit.Assert.assertNotNull(jXPathContext23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[10]");
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jXPathContext38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNotNull(nodePointer41);
    }

    @Test
    public void test0101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0101");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = null;
        org.apache.commons.jxpath.Container container2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer4 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container2, locale3);
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container2, locale5, "hi!");
        org.apache.commons.jxpath.ri.QName qName9 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator10 = jDOMNodePointer7.attributeIterator(qName9);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference11 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName9);
        boolean boolean12 = variableReference11.computeContextDependent();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = jXPathContextFactory0.newContext(jXPathContext1, (java.lang.Object) variableReference11);
        org.apache.commons.jxpath.ri.EvalContext evalContext14 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest15 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext18 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext14, nodeTest15, false, false);
        childContext18.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest20 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext21 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext18, nodeTest20);
        org.apache.commons.jxpath.ri.QName qName22 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest24 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName22, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext25 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest24);
        org.apache.commons.jxpath.NodeSet nodeSet26 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext27 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, nodeSet26);
        org.apache.commons.jxpath.ri.QName qName28 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest30 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName28, "");
        org.apache.commons.jxpath.ri.QName qName31 = nodeNameTest30.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext32 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest30);
        java.util.Locale locale34 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer35 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale34);
        boolean boolean37 = jDOMNodePointer35.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName39 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = jDOMNodePointer35.attributeIterator(qName39);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest42 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "hi!");
        java.lang.String str43 = nodeNameTest42.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext46 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest42, false, false);
        try {
            java.lang.Object obj47 = variableReference11.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNotNull(nodeIterator10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNull(qName31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeIterator40);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "hi!" + "'", str43, "hi!");
    }

    @Test
    public void test0124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0124");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        collectionPointer7.setIndex(22);
        java.io.Reader reader10 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream11 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader10);
        java.io.Reader reader12 = null;
        simpleCharStream11.ReInit(reader12, (int) (short) -1, 30, 56);
        simpleCharStream11.bufpos = 24;
        java.io.Reader reader19 = null;
        simpleCharStream11.ReInit(reader19);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer7, (java.lang.Object) simpleCharStream11);
        java.lang.Object obj22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj22, locale23);
        java.lang.String str25 = collectionPointer24.asPath();
        int int26 = collectionPointer24.getLength();
        int int27 = collectionPointer24.getLength();
        java.util.Locale locale29 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale29);
        boolean boolean32 = jDOMNodePointer30.equals((java.lang.Object) (byte) 0);
        java.lang.String str33 = jDOMNodePointer30.asPath();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer35 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer30, "");
        java.lang.Object obj36 = namespacePointer35.getNode();
        int int37 = jDOMNodePointer21.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer35);
        org.apache.commons.jxpath.JXPathContext jXPathContext38 = null;
        org.apache.commons.jxpath.Container container39 = null;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer41 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container39, locale40);
        java.util.Locale locale42 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer44 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container39, locale42, "hi!");
        org.apache.commons.jxpath.ri.QName qName46 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator47 = jDOMNodePointer44.attributeIterator(qName46);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference48 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName46);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer49 = jDOMNodePointer21.createAttribute(jXPathContext38, qName46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path /.[23]/@, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "/" + "'", str25, "/");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(nodeIterator47);
    }

    @Test
    public void test0148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0148");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        org.w3c.dom.Node node8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer11 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale9, "");
        java.util.Locale locale12 = dOMNodePointer11.locale;
        java.lang.Object obj13 = dOMNodePointer11.getRootNode();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        int int20 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer11, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory21 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        java.lang.Object obj26 = jDOMNodePointer24.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver27 = jDOMNodePointer24.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer24);
        org.apache.commons.jxpath.ri.parser.Token token29 = null;
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[][] intArray36 = new int[][] { intArray31, intArray33, intArray35 };
        java.lang.String[] strArray41 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException42 = new org.apache.commons.jxpath.ri.parser.ParseException(token29, intArray36, strArray41);
        org.apache.commons.jxpath.JXPathContext jXPathContext43 = jXPathContextFactory21.newContext(jXPathContext28, (java.lang.Object) token29);
        try {
            org.apache.commons.jxpath.Pointer pointer45 = dOMNodePointer11.getPointerByID(jXPathContext28, "$null");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertNull(locale12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(jXPathContextFactory21);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(namespaceResolver27);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jXPathContext43);
    }

    @Test
    public void test0238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0238");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.QName qName50 = nullPointer2.getName();
        try {
            nullPointer2.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot remove an object that is not some other object's property or a collection element");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNull(qName50);
    }

    @Test
    public void test0251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0251");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.Pointer pointer44 = attributeContext30.getSingleNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.computeContextDependent();
        boolean boolean11 = variableReference9.isContextDependent();
        org.apache.commons.jxpath.ri.EvalContext evalContext12 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest13 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext16 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext12, nodeTest13, false, false);
        childContext16.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest18 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext19 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext16, nodeTest18);
        org.apache.commons.jxpath.ri.QName qName20 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest22 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName20, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest22);
        org.apache.commons.jxpath.NodeSet nodeSet24 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext25 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, nodeSet24);
        org.apache.commons.jxpath.ri.QName qName26 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "");
        org.apache.commons.jxpath.ri.QName qName29 = nodeNameTest28.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext30 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        java.util.Locale locale32 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer33 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale32);
        boolean boolean35 = jDOMNodePointer33.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName37 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator38 = jDOMNodePointer33.attributeIterator(qName37);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest40 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName37, "hi!");
        java.lang.String str41 = nodeNameTest40.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext44 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest40, false, false);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator45 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) selfContext30);
        selfContext30.reset();
        try {
            java.lang.Object obj47 = variableReference9.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(qName29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(nodeIterator38);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "hi!" + "'", str41, "hi!");
    }

    @Test
    public void test0328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0328");
        org.apache.commons.jxpath.ri.parser.Token token1 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.kind = 0;
        org.apache.commons.jxpath.ri.parser.Token token5 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.specialToken = token5;
        org.apache.commons.jxpath.ri.parser.Token token8 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token8.endLine = 67;
        token8.endColumn = 44;
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.ri.parser.Token token27 = null;
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[][] intArray34 = new int[][] { intArray29, intArray31, intArray33 };
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException40 = new org.apache.commons.jxpath.ri.parser.ParseException(token27, intArray34, strArray39);
        org.apache.commons.jxpath.ri.parser.Token token41 = parseException40.currentToken;
        org.apache.commons.jxpath.JXPathContextFactoryConfigurationError jXPathContextFactoryConfigurationError43 = new org.apache.commons.jxpath.JXPathContextFactoryConfigurationError((java.lang.Exception) parseException40, "");
        org.apache.commons.jxpath.ri.parser.Token token44 = null;
        int[] intArray46 = new int[] { 10 };
        int[] intArray48 = new int[] { 10 };
        int[] intArray50 = new int[] { 10 };
        int[][] intArray51 = new int[][] { intArray46, intArray48, intArray50 };
        java.lang.String[] strArray56 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException57 = new org.apache.commons.jxpath.ri.parser.ParseException(token44, intArray51, strArray56);
        org.apache.commons.jxpath.ri.parser.Token token58 = parseException57.currentToken;
        java.lang.String[] strArray59 = parseException57.tokenImage;
        parseException40.tokenImage = strArray59;
        org.apache.commons.jxpath.ri.parser.ParseException parseException61 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray20, strArray59);
        java.lang.String str62 = token8.toString();
        token1.next = token8;
        org.apache.commons.jxpath.ri.parser.Token token64 = token1.next;
        int int65 = token1.beginLine;
        org.junit.Assert.assertNotNull(token1);
        org.junit.Assert.assertNotNull(token5);
        org.junit.Assert.assertNotNull(token8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNull(token41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray46), "[10]");
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray48), "[10]");
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray50), "[10]");
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNull(token58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(token64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test0398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0398");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        java.lang.Object obj8 = collectionPointer7.getBaseValue();
        boolean boolean9 = collectionPointer7.isContainer();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory10 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = jDOMNodePointer13.getImmediateParentPointer();
        java.lang.Object obj15 = jDOMNodePointer13.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver16 = jDOMNodePointer13.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext17 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer13);
        org.apache.commons.jxpath.ri.parser.Token token18 = null;
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[] intArray24 = new int[] { 10 };
        int[][] intArray25 = new int[][] { intArray20, intArray22, intArray24 };
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException31 = new org.apache.commons.jxpath.ri.parser.ParseException(token18, intArray25, strArray30);
        org.apache.commons.jxpath.JXPathContext jXPathContext32 = jXPathContextFactory10.newContext(jXPathContext17, (java.lang.Object) token18);
        org.apache.commons.jxpath.Variables variables33 = jXPathContext17.getVariables();
        org.apache.commons.jxpath.Functions functions34 = jXPathContext17.getFunctions();
        java.util.Iterator iterator36 = jXPathContext17.iteratePointers("UNKNOWN");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer38 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer37);
        java.lang.Object obj39 = nullPropertyPointer38.getBaseValue();
        nullPropertyPointer38.setPropertyIndex(55);
        boolean boolean42 = nullPropertyPointer38.isLeaf();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = collectionPointer7.createPath(jXPathContext17, (java.lang.Object) boolean42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertEquals("'" + obj8 + "' != '" + (-2147483648) + "'", obj8, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jXPathContextFactory10);
        org.junit.Assert.assertNull(nodePointer14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(namespaceResolver16);
        org.junit.Assert.assertNotNull(jXPathContext17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jXPathContext32);
        org.junit.Assert.assertNotNull(variables33);
        org.junit.Assert.assertNotNull(functions34);
        org.junit.Assert.assertNotNull(iterator36);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        java.lang.Object obj4 = jDOMNodePointer2.getRootNode();
        org.apache.commons.jxpath.Container container5 = null;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer7 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container5, locale6);
        org.apache.commons.jxpath.ri.QName qName8 = containerPointer7.getName();
        boolean boolean9 = containerPointer7.isContainer();
        org.apache.commons.jxpath.ri.QName qName10 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest12 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName10, "");
        org.apache.commons.jxpath.ri.QName qName13 = nodeNameTest12.getNodeName();
        boolean boolean14 = containerPointer7.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = containerPointer7.getImmediateValuePointer();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory16 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale18);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = jDOMNodePointer19.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer19.getNamespaceResolver();
        int int22 = jDOMNodePointer19.index;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int22, locale23);
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = containerPointerFactory16.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24, qName32, (java.lang.Object) "");
        java.lang.Object obj37 = collectionPointer24.getBaseValue();
        boolean boolean38 = collectionPointer24.isContainer();
        try {
            int int39 = jDOMNodePointer2.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) containerPointer7, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: JXPath internal error: compareChildNodes called for a");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertEquals("'" + obj4 + "' != '" + 'a' + "'", obj4, 'a');
        org.junit.Assert.assertNull(qName8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(qName13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodePointer15);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2147483648) + "'", int22 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertNull(nodePointer36);
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + (-2147483648) + "'", obj37, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test0455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0455");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        java.lang.Object obj4 = treeCompiler0.literal("<<unknown namespace>>");
        java.lang.Object obj6 = treeCompiler0.processingInstructionTest("id(preceding)");
        java.lang.Object obj8 = treeCompiler0.literal("hi!");
        java.lang.Object obj11 = treeCompiler0.qname("$", "UNKNOWN");
        java.lang.Object obj12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer14 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj12, locale13);
        org.apache.commons.jxpath.Container container15 = null;
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer17 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container15, locale16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = containerPointer17.namespacePointer("preceding");
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer22 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale21);
        boolean boolean24 = jDOMNodePointer22.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName26 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator27 = jDOMNodePointer22.attributeIterator(qName26);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest29 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "hi!");
        boolean boolean30 = containerPointer17.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer32 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer32);
        org.apache.commons.jxpath.ri.QName qName34 = nullPropertyPointer33.getName();
        nullPropertyPointer33.setPropertyName("id(preceding)");
        nullPropertyPointer33.setPropertyName("");
        boolean boolean39 = nullPropertyPointer33.isActual();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = collectionPointer14.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest29, false, (org.apache.commons.jxpath.ri.model.NodePointer) nullPropertyPointer33);
        try {
            java.lang.Object obj41 = treeCompiler0.nodeNameTest((java.lang.Object) nullPropertyPointer33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer cannot be cast to org.apache.commons.jxpath.ri.QName");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals(obj4.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals(obj6.toString(), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj6), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj6), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals(obj8.toString(), "'hi!'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj8), "'hi!'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj8), "'hi!'");
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "$:UNKNOWN");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "$:UNKNOWN");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "$:UNKNOWN");
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(nodeIterator27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(qName34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator40);
    }

    @Test
    public void test0460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0460");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale3);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = jDOMNodePointer4.getImmediateParentPointer();
        java.lang.String str6 = jDOMNodePointer4.asPath();
        java.util.Locale locale7 = jDOMNodePointer4.locale;
        java.lang.String str8 = jDOMNodePointer4.asPath();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer4.namespacePointer("id(preceding)");
        org.apache.commons.jxpath.CompiledExpression compiledExpression12 = org.apache.commons.jxpath.JXPathContext.compile("UNKNOWN");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory13 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext20 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer16);
        org.apache.commons.jxpath.ri.parser.Token token21 = null;
        int[] intArray23 = new int[] { 10 };
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[][] intArray28 = new int[][] { intArray23, intArray25, intArray27 };
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException34 = new org.apache.commons.jxpath.ri.parser.ParseException(token21, intArray28, strArray33);
        org.apache.commons.jxpath.JXPathContext jXPathContext35 = jXPathContextFactory13.newContext(jXPathContext20, (java.lang.Object) token21);
        jXPathContext20.setLenient(true);
        java.util.Iterator iterator38 = compiledExpression12.iteratePointers(jXPathContext20);
        org.apache.commons.jxpath.Pointer pointer39 = null;
        jXPathContext20.setNamespaceContextPointer(pointer39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer41 = nodePointer10.createPath(jXPathContext20);
        java.util.Locale locale42 = null;
        jXPathContext20.setLocale(locale42);
        org.apache.commons.jxpath.ri.QName qName45 = new org.apache.commons.jxpath.ri.QName("org.apache.commons.jxpath.JXPathContextFactory");
        java.lang.String str46 = qName45.toString();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer48 = nullPropertyPointer1.createChild(jXPathContext20, qName45, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNotNull(nodePointer10);
        org.junit.Assert.assertNotNull(compiledExpression12);
        org.junit.Assert.assertNotNull(jXPathContextFactory13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertNotNull(jXPathContext20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jXPathContext35);
        org.junit.Assert.assertNotNull(iterator38);
        org.junit.Assert.assertNotNull(nodePointer41);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "org.apache.commons.jxpath.JXPathContextFactory" + "'", str46, "org.apache.commons.jxpath.JXPathContextFactory");
    }

    @Test
    public void test0471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0471");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = attributeContext30.getCurrentNodePointer();
        try {
            boolean boolean45 = attributeContext30.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(nodePointer44);
    }

    @Test
    public void test0508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0508");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory1 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale3);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = jDOMNodePointer4.getImmediateParentPointer();
        java.lang.Object obj6 = jDOMNodePointer4.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver7 = jDOMNodePointer4.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext8 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer4);
        org.apache.commons.jxpath.ri.parser.Token token9 = null;
        int[] intArray11 = new int[] { 10 };
        int[] intArray13 = new int[] { 10 };
        int[] intArray15 = new int[] { 10 };
        int[][] intArray16 = new int[][] { intArray11, intArray13, intArray15 };
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException22 = new org.apache.commons.jxpath.ri.parser.ParseException(token9, intArray16, strArray21);
        org.apache.commons.jxpath.JXPathContext jXPathContext23 = jXPathContextFactory1.newContext(jXPathContext8, (java.lang.Object) token9);
        java.util.Locale locale24 = jXPathContext23.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer26 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale24, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer27 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale24);
        java.lang.String str28 = dOMNodePointer27.getDefaultNamespaceURI();
        org.apache.commons.jxpath.Container container29 = null;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer31 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container29, locale30);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = containerPointer31.namespacePointer("|");
        java.lang.Object obj34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer36 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj34, locale35);
        java.util.Locale locale38 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer39 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale38);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = jDOMNodePointer39.getImmediateParentPointer();
        java.lang.Object obj41 = jDOMNodePointer39.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver42 = jDOMNodePointer39.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext43 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = collectionPointer36.createPath(jXPathContext43);
        try {
            int int45 = dOMNodePointer27.compareChildNodePointers(nodePointer33, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory1);
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(namespaceResolver7);
        org.junit.Assert.assertNotNull(jXPathContext8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray11), "[10]");
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray13), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jXPathContext23);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertEquals(locale24.toString(), "en_GB");
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(nodePointer33);
        org.junit.Assert.assertNull(nodePointer40);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(namespaceResolver42);
        org.junit.Assert.assertNotNull(jXPathContext43);
        org.junit.Assert.assertNotNull(nodePointer44);
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer19 = beanPointer17.getPropertyPointer();
        boolean boolean21 = beanPointer17.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container22, locale23);
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container22, locale25, "hi!");
        org.apache.commons.jxpath.ri.QName qName29 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator30 = jDOMNodePointer27.attributeIterator(qName29);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference31 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName29);
        boolean boolean32 = variableReference31.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray33 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion34 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray33);
        java.lang.String str35 = coreOperationUnion34.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest36 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference31, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion34);
        boolean boolean37 = nameAttributeTest36.computeContextDependent();
        boolean boolean38 = beanPointer17.equals((java.lang.Object) boolean37);
        boolean boolean39 = beanPointer17.isCollection();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = beanPointer17.getParent();
        java.beans.PropertyDescriptor propertyDescriptor41 = null;
        try {
            java.lang.Object obj43 = org.apache.commons.jxpath.util.ValueUtils.getValue((java.lang.Object) nodePointer40, propertyDescriptor41, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(propertyPointer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeIterator30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(expressionArray33);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "|" + "'", str35, "|");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodePointer40);
    }

    @Test
    public void test0557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0557");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.QName qName50 = nullPointer2.getName();
        java.lang.String str51 = nullPointer2.asPath();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNull(qName50);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "id($null)" + "'", str51, "id($null)");
    }

    @Test
    public void test0585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0585");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.Pointer pointer44 = selfContext43.getSingleNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0603");
        org.apache.commons.jxpath.ri.parser.Token token1 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.kind = 0;
        org.apache.commons.jxpath.ri.parser.Token token5 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.specialToken = token5;
        org.apache.commons.jxpath.ri.parser.Token token8 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token8.endLine = 67;
        token8.endColumn = 44;
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.ri.parser.Token token27 = null;
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[][] intArray34 = new int[][] { intArray29, intArray31, intArray33 };
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException40 = new org.apache.commons.jxpath.ri.parser.ParseException(token27, intArray34, strArray39);
        org.apache.commons.jxpath.ri.parser.Token token41 = parseException40.currentToken;
        org.apache.commons.jxpath.JXPathContextFactoryConfigurationError jXPathContextFactoryConfigurationError43 = new org.apache.commons.jxpath.JXPathContextFactoryConfigurationError((java.lang.Exception) parseException40, "");
        org.apache.commons.jxpath.ri.parser.Token token44 = null;
        int[] intArray46 = new int[] { 10 };
        int[] intArray48 = new int[] { 10 };
        int[] intArray50 = new int[] { 10 };
        int[][] intArray51 = new int[][] { intArray46, intArray48, intArray50 };
        java.lang.String[] strArray56 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException57 = new org.apache.commons.jxpath.ri.parser.ParseException(token44, intArray51, strArray56);
        org.apache.commons.jxpath.ri.parser.Token token58 = parseException57.currentToken;
        java.lang.String[] strArray59 = parseException57.tokenImage;
        parseException40.tokenImage = strArray59;
        org.apache.commons.jxpath.ri.parser.ParseException parseException61 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray20, strArray59);
        java.lang.String str62 = token8.toString();
        token1.next = token8;
        org.apache.commons.jxpath.ri.parser.Token token64 = token1.next;
        org.apache.commons.jxpath.ri.parser.Token token65 = token1.next;
        token1.beginLine = 47;
        org.junit.Assert.assertNotNull(token1);
        org.junit.Assert.assertNotNull(token5);
        org.junit.Assert.assertNotNull(token8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNull(token41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray46), "[10]");
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray48), "[10]");
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray50), "[10]");
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNull(token58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(token64);
        org.junit.Assert.assertNotNull(token65);
    }

    @Test
    public void test0604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0604");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer50 = beanPointer49.getPropertyPointer();
        try {
            boolean boolean51 = propertyPointer50.isCollection();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(propertyPointer50);
    }

    @Test
    public void test0610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0610");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        org.apache.commons.jxpath.ri.QName qName2 = nullPropertyPointer1.getName();
        nullPropertyPointer1.setPropertyName("id(preceding)");
        java.lang.String str5 = nullPropertyPointer1.getPropertyName();
        org.apache.commons.jxpath.CompiledExpression compiledExpression7 = org.apache.commons.jxpath.JXPathContext.compile("UNKNOWN");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory8 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale10);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = jDOMNodePointer11.getImmediateParentPointer();
        java.lang.Object obj13 = jDOMNodePointer11.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver14 = jDOMNodePointer11.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext15 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer11);
        org.apache.commons.jxpath.ri.parser.Token token16 = null;
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[][] intArray23 = new int[][] { intArray18, intArray20, intArray22 };
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException29 = new org.apache.commons.jxpath.ri.parser.ParseException(token16, intArray23, strArray28);
        org.apache.commons.jxpath.JXPathContext jXPathContext30 = jXPathContextFactory8.newContext(jXPathContext15, (java.lang.Object) token16);
        jXPathContext15.setLenient(true);
        java.util.Iterator iterator33 = compiledExpression7.iteratePointers(jXPathContext15);
        org.apache.commons.jxpath.Functions functions34 = jXPathContext15.getFunctions();
        org.apache.commons.jxpath.PackageFunctions packageFunctions37 = new org.apache.commons.jxpath.PackageFunctions("=", "org.apache.commons.jxpath.JXPathContextFactory");
        jXPathContext15.setFunctions((org.apache.commons.jxpath.Functions) packageFunctions37);
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer41 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale40);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer42 = jDOMNodePointer41.getImmediateParentPointer();
        java.lang.String str43 = jDOMNodePointer41.asPath();
        java.util.Locale locale44 = jDOMNodePointer41.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = jDOMNodePointer41.namespacePointer("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = nullPropertyPointer1.createPath(jXPathContext15, (java.lang.Object) jDOMNodePointer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(qName2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id(preceding)" + "'", str5, "id(preceding)");
        org.junit.Assert.assertNotNull(compiledExpression7);
        org.junit.Assert.assertNotNull(jXPathContextFactory8);
        org.junit.Assert.assertNull(nodePointer12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(namespaceResolver14);
        org.junit.Assert.assertNotNull(jXPathContext15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jXPathContext30);
        org.junit.Assert.assertNotNull(iterator33);
        org.junit.Assert.assertNotNull(functions34);
        org.junit.Assert.assertNull(nodePointer42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "" + "'", str43, "");
        org.junit.Assert.assertNull(locale44);
        org.junit.Assert.assertNotNull(nodePointer46);
    }

    @Test
    public void test0641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0641");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName16);
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer22 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer23 = variablePointer21.getImmediateValuePointer();
        org.apache.commons.jxpath.ri.EvalContext evalContext24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest25 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext28 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext24, nodeTest25, false, false);
        childContext28.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext31 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext28, nodeTest30);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext precedingOrFollowingContext34 = new org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext((org.apache.commons.jxpath.ri.EvalContext) selfContext31, nodeTest32, false);
        precedingOrFollowingContext34.reset();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator36 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        int int37 = precedingOrFollowingContext34.getDocumentOrder();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer38 = precedingOrFollowingContext34.getCurrentNodePointer();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator39 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        try {
            int int40 = variablePointer21.compareTo((java.lang.Object) valueIterator39);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.compiler.Expression$ValueIterator cannot be cast to org.apache.commons.jxpath.ri.model.NodePointer");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNotNull(nodePointer23);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(nodePointer38);
    }

    @Test
    public void test0729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0729");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        java.lang.Object obj4 = dOMNodePointer3.getNodeValue();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.getParent();
        java.lang.Object obj6 = dOMNodePointer3.getBaseValue();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = null;
        org.apache.commons.jxpath.Container container8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer10 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container8, locale9);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container8, locale11, "hi!");
        org.apache.commons.jxpath.ri.QName qName15 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer13.attributeIterator(qName15);
        org.w3c.dom.Node node17 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        java.util.Locale locale41 = jXPathContext40.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer42 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node17, locale41);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer44 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale41, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer45 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName15, locale41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest46 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName15);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = dOMNodePointer3.createAttribute(jXPathContext7, qName15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path id('')/@, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertEquals(locale41.toString(), "en_GB");
    }

    @Test
    public void test0764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0764");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer19 = beanPointer17.getPropertyPointer();
        boolean boolean21 = beanPointer17.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container22, locale23);
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container22, locale25, "hi!");
        org.apache.commons.jxpath.ri.QName qName29 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator30 = jDOMNodePointer27.attributeIterator(qName29);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference31 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName29);
        boolean boolean32 = variableReference31.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray33 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion34 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray33);
        java.lang.String str35 = coreOperationUnion34.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest36 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference31, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion34);
        boolean boolean37 = nameAttributeTest36.computeContextDependent();
        boolean boolean38 = beanPointer17.equals((java.lang.Object) boolean37);
        boolean boolean39 = beanPointer17.isCollection();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = beanPointer17.getParent();
        org.apache.commons.jxpath.ri.QName qName41 = beanPointer17.getName();
        int int42 = beanPointer17.index;
        boolean boolean43 = beanPointer17.isLeaf();
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(propertyPointer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeIterator30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(expressionArray33);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "|" + "'", str35, "|");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodePointer40);
        org.junit.Assert.assertNotNull(qName41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-2147483648) + "'", int42 == (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test0842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0842");
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray0 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion1 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray0);
        java.lang.String str2 = coreOperationUnion1.getSymbol();
        org.apache.commons.jxpath.ri.EvalContext evalContext3 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest4 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext7 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext3, nodeTest4, false, false);
        childContext7.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest9 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext10 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext7, nodeTest9);
        org.apache.commons.jxpath.ri.QName qName11 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest13 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName11, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext14 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest13);
        org.apache.commons.jxpath.NodeSet nodeSet15 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext16 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, nodeSet15);
        org.apache.commons.jxpath.ri.QName qName17 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest19 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName17, "");
        org.apache.commons.jxpath.ri.QName qName20 = nodeNameTest19.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext21 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest19);
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        boolean boolean26 = jDOMNodePointer24.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName28 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator29 = jDOMNodePointer24.attributeIterator(qName28);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName28, "hi!");
        java.lang.String str32 = nodeNameTest31.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, false, false);
        int int36 = selfContext21.getDocumentOrder();
        org.apache.commons.jxpath.ri.EvalContext[] evalContextArray37 = new org.apache.commons.jxpath.ri.EvalContext[] {};
        org.apache.commons.jxpath.ri.axes.UnionContext unionContext38 = new org.apache.commons.jxpath.ri.axes.UnionContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, evalContextArray37);
        int int39 = unionContext38.getDocumentOrder();
        int int40 = unionContext38.getDocumentOrder();
        int int41 = unionContext38.getDocumentOrder();
        try {
            java.util.Iterator iterator42 = coreOperationUnion1.iteratePointers((org.apache.commons.jxpath.ri.EvalContext) unionContext38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(expressionArray0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "|" + "'", str2, "|");
        org.junit.Assert.assertNull(qName20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeIterator29);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "hi!" + "'", str32, "hi!");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(evalContextArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test0878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0878");
        org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory beanPointerFactory0 = new org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory();
        org.w3c.dom.Node node1 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer4 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node1, locale2, "");
        java.lang.Object obj5 = dOMNodePointer4.getNodeValue();
        boolean boolean6 = dOMNodePointer4.isCollection();
        org.apache.commons.jxpath.Container container7 = null;
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer9 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container7, locale8);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container7, locale10, "hi!");
        org.apache.commons.jxpath.ri.QName qName14 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator15 = jDOMNodePointer12.attributeIterator(qName14);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference16 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName14);
        org.w3c.dom.Node node17 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        java.util.Locale locale41 = jXPathContext40.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer43 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale41, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer44 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node17, locale41);
        java.lang.String str45 = dOMNodePointer44.getDefaultNamespaceURI();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = beanPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer4, qName14, (java.lang.Object) str45);
        boolean boolean47 = dOMNodePointer4.isCollection();
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterator15);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertEquals(locale41.toString(), "en_GB");
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(nodePointer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test0883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0883");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            boolean boolean44 = attributeContext30.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0981");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        java.lang.String str4 = dOMNodePointer3.asPath();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory5 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = jDOMNodePointer8.getImmediateParentPointer();
        java.lang.Object obj10 = jDOMNodePointer8.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver11 = jDOMNodePointer8.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext12 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer8);
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = jXPathContextFactory5.newContext(jXPathContext12, (java.lang.Object) token13);
        java.lang.Object obj28 = jXPathContext27.getContextBean();
        org.w3c.dom.Node node29 = null;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer32 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node29, locale30, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer34 = dOMNodePointer32.namespacePointer("preceding");
        java.lang.Object obj35 = dOMNodePointer32.clone();
        jXPathContext27.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) dOMNodePointer32);
        org.w3c.dom.Node node37 = null;
        java.util.Locale locale38 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer40 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node37, locale38, "");
        java.util.Locale locale41 = dOMNodePointer40.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = dOMNodePointer40.namespacePointer("");
        int int44 = nodePointer43.getIndex();
        jXPathContext27.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) nodePointer43);
        org.apache.commons.jxpath.ri.QName qName46 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer49 = dOMNodePointer3.createChild(jXPathContext27, qName46, 76, (java.lang.Object) 70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: id('')");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "id('')" + "'", str4, "id('')");
        org.junit.Assert.assertNotNull(jXPathContextFactory5);
        org.junit.Assert.assertNull(nodePointer9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(namespaceResolver11);
        org.junit.Assert.assertNotNull(jXPathContext12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNotNull(nodePointer34);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertEquals(obj35.toString(), "id('')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj35), "id('')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj35), "id('')");
        org.junit.Assert.assertNull(locale41);
        org.junit.Assert.assertNotNull(nodePointer43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-2147483648) + "'", int44 == (-2147483648));
    }

    @Test
    public void test0982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0982");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest10 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName8, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext11 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest10);
        org.apache.commons.jxpath.NodeSet nodeSet12 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext13 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, nodeSet12);
        org.apache.commons.jxpath.ri.QName qName14 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest16 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName14, "");
        org.apache.commons.jxpath.ri.QName qName17 = nodeNameTest16.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext18 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest16);
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        boolean boolean23 = jDOMNodePointer21.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName25 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator26 = jDOMNodePointer21.attributeIterator(qName25);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName25, "hi!");
        java.lang.String str29 = nodeNameTest28.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext32 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext18, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28, false, false);
        org.apache.commons.jxpath.ri.EvalContext evalContext34 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest35 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext38 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext34, nodeTest35, false, false);
        childContext38.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest40 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext41 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext38, nodeTest40);
        org.apache.commons.jxpath.ri.QName qName42 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName42, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext41, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.QName qName46 = nodeNameTest44.getNodeName();
        org.apache.commons.jxpath.ri.QName qName47 = nodeNameTest44.getNodeName();
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext48 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) childContext32, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        try {
            java.lang.String str49 = nodeNameTest44.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(qName17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(nodeIterator26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "hi!" + "'", str29, "hi!");
        org.junit.Assert.assertNull(qName46);
        org.junit.Assert.assertNull(qName47);
    }

    @Test
    public void test0991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0991");
        org.apache.commons.jxpath.CompiledExpression compiledExpression1 = org.apache.commons.jxpath.JXPathContext.compile("$null");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory2 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale4 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale4);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer6 = jDOMNodePointer5.getImmediateParentPointer();
        java.lang.Object obj7 = jDOMNodePointer5.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver8 = jDOMNodePointer5.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext9 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer5);
        org.apache.commons.jxpath.ri.parser.Token token10 = null;
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[][] intArray17 = new int[][] { intArray12, intArray14, intArray16 };
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException23 = new org.apache.commons.jxpath.ri.parser.ParseException(token10, intArray17, strArray22);
        org.apache.commons.jxpath.JXPathContext jXPathContext24 = jXPathContextFactory2.newContext(jXPathContext9, (java.lang.Object) token10);
        java.lang.Object obj25 = jXPathContext24.getContextBean();
        org.w3c.dom.Node node26 = null;
        java.util.Locale locale27 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer29 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node26, locale27, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer31 = dOMNodePointer29.namespacePointer("preceding");
        java.lang.Object obj32 = dOMNodePointer29.clone();
        jXPathContext24.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) dOMNodePointer29);
        org.w3c.dom.Node node34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer37 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node34, locale35, "");
        java.util.Locale locale38 = dOMNodePointer37.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = dOMNodePointer37.namespacePointer("");
        int int41 = nodePointer40.getIndex();
        jXPathContext24.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) nodePointer40);
        java.text.DecimalFormatSymbols decimalFormatSymbols44 = jXPathContext24.getDecimalFormatSymbols("$null");
        org.apache.commons.jxpath.KeyManager keyManager45 = null;
        jXPathContext24.setKeyManager(keyManager45);
        try {
            org.apache.commons.jxpath.Pointer pointer47 = compiledExpression1.createPath(jXPathContext24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: $null");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(compiledExpression1);
        org.junit.Assert.assertNotNull(jXPathContextFactory2);
        org.junit.Assert.assertNull(nodePointer6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(namespaceResolver8);
        org.junit.Assert.assertNotNull(jXPathContext9);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jXPathContext24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNotNull(nodePointer31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertEquals(obj32.toString(), "id('')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj32), "id('')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj32), "id('')");
        org.junit.Assert.assertNull(locale38);
        org.junit.Assert.assertNotNull(nodePointer40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-2147483648) + "'", int41 == (-2147483648));
        org.junit.Assert.assertNull(decimalFormatSymbols44);
    }

    @Test
    public void test0995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0995");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        org.apache.commons.jxpath.ri.QName qName1 = null;
        org.apache.commons.jxpath.ri.parser.TokenMgrError tokenMgrError9 = new org.apache.commons.jxpath.ri.parser.TokenMgrError(false, 8, 10, 42, "", ' ', 12);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = containerPointerFactory0.createNodePointer(qName1, (java.lang.Object) 12, locale10);
        int int12 = containerPointerFactory0.getOrder();
        int int13 = containerPointerFactory0.getOrder();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.String str18 = jDOMNodePointer16.asPath();
        java.util.Locale locale19 = jDOMNodePointer16.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer21 = jDOMNodePointer16.namespacePointer("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"");
        int int22 = jDOMNodePointer16.getIndex();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory23 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale25);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = jDOMNodePointer26.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer26.getNamespaceResolver();
        int int29 = jDOMNodePointer26.index;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer31 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int29, locale30);
        org.apache.commons.jxpath.Container container32 = null;
        java.util.Locale locale33 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer34 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container32, locale33);
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container32, locale35, "hi!");
        org.apache.commons.jxpath.ri.QName qName39 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = jDOMNodePointer37.attributeIterator(qName39);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference41 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = containerPointerFactory23.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer31, qName39, (java.lang.Object) "");
        java.lang.String str44 = qName39.getName();
        java.lang.Object obj45 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16, qName39, obj45);
        int int47 = containerPointerFactory0.getOrder();
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 200 + "'", int12 == 200);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNull(locale19);
        org.junit.Assert.assertNotNull(nodePointer21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2147483648) + "'", int22 == (-2147483648));
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2147483648) + "'", int29 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator40);
        org.junit.Assert.assertNull(nodePointer43);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertNull(nodePointer46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 200 + "'", int47 == 200);
    }

    @Test
    public void test1177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1177");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.isContextDependent();
        boolean boolean11 = variableReference9.computeContextDependent();
        java.lang.String str12 = variableReference9.toString();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray13 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion14 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray13);
        java.lang.String str15 = coreOperationUnion14.getSymbol();
        java.lang.String str16 = coreOperationUnion14.getSymbol();
        boolean boolean17 = coreOperationUnion14.computeContextDependent();
        boolean boolean18 = coreOperationUnion14.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest19 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference9, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion14);
        java.lang.String str20 = nameAttributeTest19.toString();
        org.apache.commons.jxpath.ri.EvalContext evalContext21 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext25 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext21, nodeTest22, false, false);
        childContext25.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest27 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext28 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext25, nodeTest27);
        org.apache.commons.jxpath.ri.QName qName29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName29, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext32 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext28, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31);
        org.apache.commons.jxpath.ri.QName qName33 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest35 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName33, "");
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext36 = new org.apache.commons.jxpath.ri.axes.NamespaceContext((org.apache.commons.jxpath.ri.EvalContext) selfContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest35);
        namespaceContext36.reset();
        int int38 = namespaceContext36.getPosition();
        boolean boolean40 = namespaceContext36.setPosition((int) (byte) -1);
        try {
            java.lang.Object obj41 = nameAttributeTest19.computeValue((org.apache.commons.jxpath.ri.EvalContext) namespaceContext36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "$" + "'", str12, "$");
        org.junit.Assert.assertNotNull(expressionArray13);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "|" + "'", str15, "|");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "|" + "'", str16, "|");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "$ = " + "'", str20, "$ = ");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test1215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1215");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        java.lang.String str4 = jDOMNodePointer2.asPath();
        boolean boolean5 = jDOMNodePointer2.isCollection();
        java.lang.Object obj6 = jDOMNodePointer2.getValue();
        org.apache.commons.jxpath.Container container7 = null;
        org.apache.commons.jxpath.ri.QName qName9 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean10 = null;
        org.w3c.dom.Node node11 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory12 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        java.lang.Object obj17 = jDOMNodePointer15.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver18 = jDOMNodePointer15.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext19 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer15);
        org.apache.commons.jxpath.ri.parser.Token token20 = null;
        int[] intArray22 = new int[] { 10 };
        int[] intArray24 = new int[] { 10 };
        int[] intArray26 = new int[] { 10 };
        int[][] intArray27 = new int[][] { intArray22, intArray24, intArray26 };
        java.lang.String[] strArray32 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException33 = new org.apache.commons.jxpath.ri.parser.ParseException(token20, intArray27, strArray32);
        org.apache.commons.jxpath.JXPathContext jXPathContext34 = jXPathContextFactory12.newContext(jXPathContext19, (java.lang.Object) token20);
        java.util.Locale locale35 = jXPathContext34.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale35, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer38 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node11, locale35);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer39 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName9, dynaBean10, locale35);
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer40 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container7, locale35);
        boolean boolean41 = containerPointer40.isActual();
        boolean boolean42 = containerPointer40.isContainer();
        boolean boolean43 = jDOMNodePointer2.equals((java.lang.Object) containerPointer40);
        java.lang.String str44 = containerPointer40.asPath();
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertEquals("'" + str4 + "' != '" + "" + "'", str4, "");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(jXPathContextFactory12);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNull(namespaceResolver18);
        org.junit.Assert.assertNotNull(jXPathContext19);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[10]");
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertNotNull(jXPathContext34);
        org.junit.Assert.assertNotNull(locale35);
        org.junit.Assert.assertEquals(locale35.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "/" + "'", str44, "/");
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext44 = attributeContext30.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

}
