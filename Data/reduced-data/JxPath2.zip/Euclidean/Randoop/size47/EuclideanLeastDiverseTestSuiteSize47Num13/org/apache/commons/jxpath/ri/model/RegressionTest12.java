package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0068");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        java.lang.Object obj3 = jDOMNodePointer2.getValue();
        org.apache.commons.jxpath.ri.QName qName4 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler6 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer7 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer2, qName4, (java.lang.Object) 1.0d, dynamicPropertyHandler6);
        org.apache.commons.jxpath.ri.QName qName8 = dynamicPointer7.getName();
        boolean boolean9 = dynamicPointer7.isLeaf();
        org.apache.commons.jxpath.Container container10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer12 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container10, locale11);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container10, locale13, "hi!");
        org.apache.commons.jxpath.ri.QName qName17 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator18 = jDOMNodePointer15.attributeIterator(qName17);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference19 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName17);
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = dynamicPointer7.attributeIterator(qName17);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory21 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        java.lang.Object obj26 = jDOMNodePointer24.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver27 = jDOMNodePointer24.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer24);
        org.apache.commons.jxpath.ri.parser.Token token29 = null;
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[][] intArray36 = new int[][] { intArray31, intArray33, intArray35 };
        java.lang.String[] strArray41 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException42 = new org.apache.commons.jxpath.ri.parser.ParseException(token29, intArray36, strArray41);
        org.apache.commons.jxpath.JXPathContext jXPathContext43 = jXPathContextFactory21.newContext(jXPathContext28, (java.lang.Object) token29);
        org.apache.commons.jxpath.Variables variables44 = jXPathContext28.getVariables();
        org.apache.commons.jxpath.ri.QName qName45 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = dynamicPointer7.createAttribute(jXPathContext28, qName45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path /null/@null, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(qName8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(nodeIterator18);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory21);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(namespaceResolver27);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jXPathContext43);
        org.junit.Assert.assertNotNull(variables44);
    }

    @Test
    public void test0072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0072");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator4 = jDOMNodePointer2.namespaceIterator();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        java.lang.Object obj8 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler11 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer12 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer7, qName9, (java.lang.Object) 1.0d, dynamicPropertyHandler11);
        org.apache.commons.jxpath.ri.QName qName13 = dynamicPointer12.getName();
        boolean boolean14 = dynamicPointer12.isLeaf();
        org.apache.commons.jxpath.ri.QName qName15 = dynamicPointer12.getName();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory16 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale18);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = jDOMNodePointer19.getImmediateParentPointer();
        java.lang.Object obj21 = jDOMNodePointer19.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver22 = jDOMNodePointer19.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext23 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer19);
        org.apache.commons.jxpath.ri.parser.Token token24 = null;
        int[] intArray26 = new int[] { 10 };
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[][] intArray31 = new int[][] { intArray26, intArray28, intArray30 };
        java.lang.String[] strArray36 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException37 = new org.apache.commons.jxpath.ri.parser.ParseException(token24, intArray31, strArray36);
        org.apache.commons.jxpath.JXPathContext jXPathContext38 = jXPathContextFactory16.newContext(jXPathContext23, (java.lang.Object) token24);
        java.lang.Object obj39 = jXPathContext38.getContextBean();
        java.lang.Object obj40 = jXPathContext38.getContextBean();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer41 = dynamicPointer12.createPath(jXPathContext38);
        org.apache.commons.jxpath.ri.QName qName43 = new org.apache.commons.jxpath.ri.QName("");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = jDOMNodePointer2.createChild(jXPathContext38, qName43, 2, (java.lang.Object) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: ");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNotNull(nodeIterator4);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(qName13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(qName15);
        org.junit.Assert.assertNotNull(jXPathContextFactory16);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(namespaceResolver22);
        org.junit.Assert.assertNotNull(jXPathContext23);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[10]");
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jXPathContext38);
        org.junit.Assert.assertNull(obj39);
        org.junit.Assert.assertNull(obj40);
        org.junit.Assert.assertNotNull(nodePointer41);
    }

    @Test
    public void test0101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0101");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = null;
        org.apache.commons.jxpath.Container container2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer4 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container2, locale3);
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container2, locale5, "hi!");
        org.apache.commons.jxpath.ri.QName qName9 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator10 = jDOMNodePointer7.attributeIterator(qName9);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference11 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName9);
        boolean boolean12 = variableReference11.computeContextDependent();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = jXPathContextFactory0.newContext(jXPathContext1, (java.lang.Object) variableReference11);
        org.apache.commons.jxpath.ri.EvalContext evalContext14 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest15 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext18 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext14, nodeTest15, false, false);
        childContext18.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest20 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext21 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext18, nodeTest20);
        org.apache.commons.jxpath.ri.QName qName22 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest24 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName22, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext25 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest24);
        org.apache.commons.jxpath.NodeSet nodeSet26 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext27 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, nodeSet26);
        org.apache.commons.jxpath.ri.QName qName28 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest30 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName28, "");
        org.apache.commons.jxpath.ri.QName qName31 = nodeNameTest30.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext32 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest30);
        java.util.Locale locale34 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer35 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale34);
        boolean boolean37 = jDOMNodePointer35.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName39 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = jDOMNodePointer35.attributeIterator(qName39);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest42 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "hi!");
        java.lang.String str43 = nodeNameTest42.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext46 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest42, false, false);
        try {
            java.lang.Object obj47 = variableReference11.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNotNull(nodeIterator10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNull(qName31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(nodeIterator40);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "hi!" + "'", str43, "hi!");
    }

    @Test
    public void test0124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0124");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        collectionPointer7.setIndex(22);
        java.io.Reader reader10 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream11 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader10);
        java.io.Reader reader12 = null;
        simpleCharStream11.ReInit(reader12, (int) (short) -1, 30, 56);
        simpleCharStream11.bufpos = 24;
        java.io.Reader reader19 = null;
        simpleCharStream11.ReInit(reader19);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer7, (java.lang.Object) simpleCharStream11);
        java.lang.Object obj22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj22, locale23);
        java.lang.String str25 = collectionPointer24.asPath();
        int int26 = collectionPointer24.getLength();
        int int27 = collectionPointer24.getLength();
        java.util.Locale locale29 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale29);
        boolean boolean32 = jDOMNodePointer30.equals((java.lang.Object) (byte) 0);
        java.lang.String str33 = jDOMNodePointer30.asPath();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer35 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer30, "");
        java.lang.Object obj36 = namespacePointer35.getNode();
        int int37 = jDOMNodePointer21.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer35);
        org.apache.commons.jxpath.JXPathContext jXPathContext38 = null;
        org.apache.commons.jxpath.Container container39 = null;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer41 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container39, locale40);
        java.util.Locale locale42 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer44 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container39, locale42, "hi!");
        org.apache.commons.jxpath.ri.QName qName46 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator47 = jDOMNodePointer44.attributeIterator(qName46);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference48 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName46);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer49 = jDOMNodePointer21.createAttribute(jXPathContext38, qName46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path /.[23]/@, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "/" + "'", str25, "/");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals("'" + str33 + "' != '" + "" + "'", str33, "");
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(nodeIterator47);
    }

    @Test
    public void test0148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0148");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        org.w3c.dom.Node node8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer11 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale9, "");
        java.util.Locale locale12 = dOMNodePointer11.locale;
        java.lang.Object obj13 = dOMNodePointer11.getRootNode();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        int int20 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer11, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory21 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        java.lang.Object obj26 = jDOMNodePointer24.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver27 = jDOMNodePointer24.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer24);
        org.apache.commons.jxpath.ri.parser.Token token29 = null;
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[][] intArray36 = new int[][] { intArray31, intArray33, intArray35 };
        java.lang.String[] strArray41 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException42 = new org.apache.commons.jxpath.ri.parser.ParseException(token29, intArray36, strArray41);
        org.apache.commons.jxpath.JXPathContext jXPathContext43 = jXPathContextFactory21.newContext(jXPathContext28, (java.lang.Object) token29);
        try {
            org.apache.commons.jxpath.Pointer pointer45 = dOMNodePointer11.getPointerByID(jXPathContext28, "$null");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertNull(locale12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(jXPathContextFactory21);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(namespaceResolver27);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jXPathContext43);
    }

    @Test
    public void test0151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0151");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object[] objArray1 = null;
        java.lang.Object obj2 = treeCompiler0.union(objArray1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer5 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale3, "$null");
        boolean boolean6 = nullPointer5.isCollection();
        boolean boolean7 = nullPointer5.isLeaf();
        java.lang.String str8 = nullPointer5.asPath();
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale10);
        boolean boolean13 = jDOMNodePointer11.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName15 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer11.attributeIterator(qName15);
        java.lang.String str17 = qName15.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        org.apache.commons.jxpath.BasicVariables basicVariables41 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext40.setVariables((org.apache.commons.jxpath.Variables) basicVariables41);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException45 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables41.declareVariable("|", (java.lang.Object) "");
        basicVariables41.undeclareVariable("");
        basicVariables41.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo51 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer52 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer5, qName15, (java.lang.Object) basicVariables41, jXPathBeanInfo51);
        try {
            java.lang.Object obj53 = treeCompiler0.minus((java.lang.Object) qName15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.QName cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "id($null)" + "'", str8, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
    }

    @Test
    public void test0238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0238");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.QName qName50 = nullPointer2.getName();
        try {
            nullPointer2.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot remove an object that is not some other object's property or a collection element");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNull(qName50);
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        collectionPointer7.setIndex(42);
        int int10 = collectionPointer7.getLength();
        org.apache.commons.jxpath.Container container11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer13 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container11, locale12);
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container11, locale14, "hi!");
        org.apache.commons.jxpath.ri.QName qName18 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator19 = jDOMNodePointer16.attributeIterator(qName18);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference20 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName18);
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName18);
        java.lang.Object obj22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj22, locale23);
        java.lang.String str25 = collectionPointer24.asPath();
        int int26 = collectionPointer24.getLength();
        int int27 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24);
        boolean boolean29 = variablePointer21.equals((java.lang.Object) 68);
        variablePointer21.setIndex(12);
        variablePointer21.setIndex((-2147483648));
        org.apache.commons.jxpath.ri.EvalContext evalContext34 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest35 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext38 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext34, nodeTest35, false, false);
        childContext38.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest40 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext41 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext38, nodeTest40);
        org.apache.commons.jxpath.ri.QName qName42 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName42, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext41, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.QName qName46 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest48 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName46, "");
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext49 = new org.apache.commons.jxpath.ri.axes.NamespaceContext((org.apache.commons.jxpath.ri.EvalContext) selfContext45, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer51 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator52 = variablePointer21.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48, false, nodePointer51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(nodeIterator19);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "/" + "'", str25, "/");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0251");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.Pointer pointer44 = attributeContext30.getSingleNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.computeContextDependent();
        boolean boolean11 = variableReference9.isContextDependent();
        org.apache.commons.jxpath.ri.EvalContext evalContext12 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest13 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext16 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext12, nodeTest13, false, false);
        childContext16.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest18 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext19 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext16, nodeTest18);
        org.apache.commons.jxpath.ri.QName qName20 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest22 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName20, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest22);
        org.apache.commons.jxpath.NodeSet nodeSet24 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext25 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, nodeSet24);
        org.apache.commons.jxpath.ri.QName qName26 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "");
        org.apache.commons.jxpath.ri.QName qName29 = nodeNameTest28.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext30 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext19, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        java.util.Locale locale32 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer33 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale32);
        boolean boolean35 = jDOMNodePointer33.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName37 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator38 = jDOMNodePointer33.attributeIterator(qName37);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest40 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName37, "hi!");
        java.lang.String str41 = nodeNameTest40.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext44 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest40, false, false);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator45 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) selfContext30);
        selfContext30.reset();
        try {
            java.lang.Object obj47 = variableReference9.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(qName29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(nodeIterator38);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "hi!" + "'", str41, "hi!");
    }

    @Test
    public void test0305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0305");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory3 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer6 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale5);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer7 = jDOMNodePointer6.getImmediateParentPointer();
        java.lang.Object obj8 = jDOMNodePointer6.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver9 = jDOMNodePointer6.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext10 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer6);
        org.apache.commons.jxpath.ri.parser.Token token11 = null;
        int[] intArray13 = new int[] { 10 };
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[][] intArray18 = new int[][] { intArray13, intArray15, intArray17 };
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException24 = new org.apache.commons.jxpath.ri.parser.ParseException(token11, intArray18, strArray23);
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = jXPathContextFactory3.newContext(jXPathContext10, (java.lang.Object) token11);
        java.lang.Object obj26 = jXPathContext25.getContextBean();
        org.apache.commons.jxpath.Variables variables27 = jXPathContext25.getVariables();
        org.w3c.dom.Node node28 = null;
        java.util.Locale locale29 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node28, locale29, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = dOMNodePointer31.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer36 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container34, locale35);
        java.util.Locale locale37 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer39 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container34, locale37, "hi!");
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer39.attributeIterator(qName41);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo44 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer45 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer33, qName41, (java.lang.Object) "id('')", jXPathBeanInfo44);
        boolean boolean46 = beanPointer45.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer47 = beanPointer45.getPropertyPointer();
        try {
            java.lang.Object obj48 = treeCompiler0.multiply((java.lang.Object) jXPathContext25, (java.lang.Object) propertyPointer47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.JXPathContextReferenceImpl cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(jXPathContextFactory3);
        org.junit.Assert.assertNull(nodePointer7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(namespaceResolver9);
        org.junit.Assert.assertNotNull(jXPathContext10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray13), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(variables27);
        org.junit.Assert.assertNotNull(nodePointer33);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(propertyPointer47);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.Variables variables23 = jXPathContext7.getVariables();
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        boolean boolean35 = variableReference34.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray36 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion37 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray36);
        java.lang.String str38 = coreOperationUnion37.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest39 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference34, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion37);
        boolean boolean40 = coreOperationUnion37.computeContextDependent();
        try {
            jXPathContext7.setValue("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"", (java.lang.Object) coreOperationUnion37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidSyntaxException; message: Invalid XPath: 'org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \\\" \\\" (32), after : \\\"\\\"'. Syntax error after: 'org.apache.commons.jxpath.ri.parser.TokenMgrError: L'");
        } catch (org.apache.commons.jxpath.JXPathInvalidSyntaxException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(variables23);
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(expressionArray36);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "|" + "'", str38, "|");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test0437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0437");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        org.apache.commons.jxpath.ri.QName qName2 = nullPropertyPointer1.getName();
        nullPropertyPointer1.setPropertyName("http://www.w3.org/2000/xmlns/");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = nullPropertyPointer1.getImmediateValuePointer();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer6 = nullPropertyPointer1.getValuePointer();
        int int7 = nullPropertyPointer1.getLength();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        java.lang.Object obj11 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.QName qName12 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler14 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer15 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer10, qName12, (java.lang.Object) 1.0d, dynamicPropertyHandler14);
        org.apache.commons.jxpath.ri.QName qName16 = dynamicPointer15.getName();
        boolean boolean17 = dynamicPointer15.isLeaf();
        org.apache.commons.jxpath.ri.QName qName18 = dynamicPointer15.getName();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory19 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer22 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale21);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer23 = jDOMNodePointer22.getImmediateParentPointer();
        java.lang.Object obj24 = jDOMNodePointer22.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver25 = jDOMNodePointer22.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer22);
        org.apache.commons.jxpath.ri.parser.Token token27 = null;
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[][] intArray34 = new int[][] { intArray29, intArray31, intArray33 };
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException40 = new org.apache.commons.jxpath.ri.parser.ParseException(token27, intArray34, strArray39);
        org.apache.commons.jxpath.JXPathContext jXPathContext41 = jXPathContextFactory19.newContext(jXPathContext26, (java.lang.Object) token27);
        java.lang.Object obj42 = jXPathContext41.getContextBean();
        java.lang.Object obj43 = jXPathContext41.getContextBean();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = dynamicPointer15.createPath(jXPathContext41);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = nullPropertyPointer1.createPath(jXPathContext41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(qName2);
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodePointer6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(qName16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(qName18);
        org.junit.Assert.assertNotNull(jXPathContextFactory19);
        org.junit.Assert.assertNull(nodePointer23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(namespaceResolver25);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jXPathContext41);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNull(obj43);
        org.junit.Assert.assertNotNull(nodePointer44);
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        java.lang.Object obj4 = jDOMNodePointer2.getRootNode();
        org.apache.commons.jxpath.Container container5 = null;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer7 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container5, locale6);
        org.apache.commons.jxpath.ri.QName qName8 = containerPointer7.getName();
        boolean boolean9 = containerPointer7.isContainer();
        org.apache.commons.jxpath.ri.QName qName10 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest12 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName10, "");
        org.apache.commons.jxpath.ri.QName qName13 = nodeNameTest12.getNodeName();
        boolean boolean14 = containerPointer7.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = containerPointer7.getImmediateValuePointer();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory16 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale18);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = jDOMNodePointer19.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer19.getNamespaceResolver();
        int int22 = jDOMNodePointer19.index;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int22, locale23);
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = containerPointerFactory16.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24, qName32, (java.lang.Object) "");
        java.lang.Object obj37 = collectionPointer24.getBaseValue();
        boolean boolean38 = collectionPointer24.isContainer();
        try {
            int int39 = jDOMNodePointer2.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) containerPointer7, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: JXPath internal error: compareChildNodes called for a");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertEquals("'" + obj4 + "' != '" + 'a' + "'", obj4, 'a');
        org.junit.Assert.assertNull(qName8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(qName13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodePointer15);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2147483648) + "'", int22 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertNull(nodePointer36);
        org.junit.Assert.assertEquals("'" + obj37 + "' != '" + (-2147483648) + "'", obj37, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test0455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0455");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        java.lang.Object obj4 = treeCompiler0.literal("<<unknown namespace>>");
        java.lang.Object obj6 = treeCompiler0.processingInstructionTest("id(preceding)");
        java.lang.Object obj8 = treeCompiler0.literal("hi!");
        java.lang.Object obj11 = treeCompiler0.qname("$", "UNKNOWN");
        java.lang.Object obj12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer14 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj12, locale13);
        org.apache.commons.jxpath.Container container15 = null;
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer17 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container15, locale16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = containerPointer17.namespacePointer("preceding");
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer22 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale21);
        boolean boolean24 = jDOMNodePointer22.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName26 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator27 = jDOMNodePointer22.attributeIterator(qName26);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest29 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "hi!");
        boolean boolean30 = containerPointer17.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer32 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer32);
        org.apache.commons.jxpath.ri.QName qName34 = nullPropertyPointer33.getName();
        nullPropertyPointer33.setPropertyName("id(preceding)");
        nullPropertyPointer33.setPropertyName("");
        boolean boolean39 = nullPropertyPointer33.isActual();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = collectionPointer14.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest29, false, (org.apache.commons.jxpath.ri.model.NodePointer) nullPropertyPointer33);
        try {
            java.lang.Object obj41 = treeCompiler0.nodeNameTest((java.lang.Object) nullPropertyPointer33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer cannot be cast to org.apache.commons.jxpath.ri.QName");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals(obj4.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals(obj6.toString(), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj6), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj6), "processing-instruction('id(preceding)')");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals(obj8.toString(), "'hi!'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj8), "'hi!'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj8), "'hi!'");
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "$:UNKNOWN");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "$:UNKNOWN");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "$:UNKNOWN");
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(nodeIterator27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(qName34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator40);
    }

    @Test
    public void test0460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0460");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale3);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = jDOMNodePointer4.getImmediateParentPointer();
        java.lang.String str6 = jDOMNodePointer4.asPath();
        java.util.Locale locale7 = jDOMNodePointer4.locale;
        java.lang.String str8 = jDOMNodePointer4.asPath();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer4.namespacePointer("id(preceding)");
        org.apache.commons.jxpath.CompiledExpression compiledExpression12 = org.apache.commons.jxpath.JXPathContext.compile("UNKNOWN");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory13 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext20 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer16);
        org.apache.commons.jxpath.ri.parser.Token token21 = null;
        int[] intArray23 = new int[] { 10 };
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[][] intArray28 = new int[][] { intArray23, intArray25, intArray27 };
        java.lang.String[] strArray33 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException34 = new org.apache.commons.jxpath.ri.parser.ParseException(token21, intArray28, strArray33);
        org.apache.commons.jxpath.JXPathContext jXPathContext35 = jXPathContextFactory13.newContext(jXPathContext20, (java.lang.Object) token21);
        jXPathContext20.setLenient(true);
        java.util.Iterator iterator38 = compiledExpression12.iteratePointers(jXPathContext20);
        org.apache.commons.jxpath.Pointer pointer39 = null;
        jXPathContext20.setNamespaceContextPointer(pointer39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer41 = nodePointer10.createPath(jXPathContext20);
        java.util.Locale locale42 = null;
        jXPathContext20.setLocale(locale42);
        org.apache.commons.jxpath.ri.QName qName45 = new org.apache.commons.jxpath.ri.QName("org.apache.commons.jxpath.JXPathContextFactory");
        java.lang.String str46 = qName45.toString();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer48 = nullPropertyPointer1.createChild(jXPathContext20, qName45, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertEquals("'" + str6 + "' != '" + "" + "'", str6, "");
        org.junit.Assert.assertNull(locale7);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "" + "'", str8, "");
        org.junit.Assert.assertNotNull(nodePointer10);
        org.junit.Assert.assertNotNull(compiledExpression12);
        org.junit.Assert.assertNotNull(jXPathContextFactory13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertNotNull(jXPathContext20);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jXPathContext35);
        org.junit.Assert.assertNotNull(iterator38);
        org.junit.Assert.assertNotNull(nodePointer41);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "org.apache.commons.jxpath.JXPathContextFactory" + "'", str46, "org.apache.commons.jxpath.JXPathContextFactory");
    }

    @Test
    public void test0471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0471");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = attributeContext30.getCurrentNodePointer();
        try {
            boolean boolean45 = attributeContext30.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(nodePointer44);
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler1 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj3 = treeCompiler1.literal("/");
        java.lang.Object obj5 = treeCompiler1.literal("<<unknown namespace>>");
        java.lang.Object obj7 = treeCompiler1.literal("$");
        java.lang.Object obj8 = org.apache.commons.jxpath.ri.Parser.parseExpression("/*", (org.apache.commons.jxpath.ri.Compiler) treeCompiler1);
        org.w3c.dom.Node node9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer12 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale10, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = dOMNodePointer12.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container15 = null;
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer17 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container15, locale16);
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer20 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container15, locale18, "hi!");
        org.apache.commons.jxpath.ri.QName qName22 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator23 = jDOMNodePointer20.attributeIterator(qName22);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo25 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer26 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer14, qName22, (java.lang.Object) "id('')", jXPathBeanInfo25);
        boolean boolean27 = beanPointer26.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer28 = beanPointer26.getPropertyPointer();
        boolean boolean30 = beanPointer26.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.ri.parser.Token token31 = null;
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[] intArray37 = new int[] { 10 };
        int[][] intArray38 = new int[][] { intArray33, intArray35, intArray37 };
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException44 = new org.apache.commons.jxpath.ri.parser.ParseException(token31, intArray38, strArray43);
        org.apache.commons.jxpath.ri.parser.Token token45 = parseException44.currentToken;
        java.lang.String[] strArray46 = parseException44.tokenImage;
        try {
            java.lang.Object obj47 = treeCompiler1.notEqual((java.lang.Object) 10.0f, (java.lang.Object) strArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj3), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj3), "'/'");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertEquals(obj5.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertEquals(obj7.toString(), "'$'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj7), "'$'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj7), "'$'");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals(obj8.toString(), "/*");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj8), "/*");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj8), "/*");
        org.junit.Assert.assertNotNull(nodePointer14);
        org.junit.Assert.assertNotNull(nodeIterator23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(propertyPointer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray37), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNull(token45);
        org.junit.Assert.assertNotNull(strArray46);
    }

    @Test
    public void test0508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0508");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory1 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale3);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = jDOMNodePointer4.getImmediateParentPointer();
        java.lang.Object obj6 = jDOMNodePointer4.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver7 = jDOMNodePointer4.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext8 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer4);
        org.apache.commons.jxpath.ri.parser.Token token9 = null;
        int[] intArray11 = new int[] { 10 };
        int[] intArray13 = new int[] { 10 };
        int[] intArray15 = new int[] { 10 };
        int[][] intArray16 = new int[][] { intArray11, intArray13, intArray15 };
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException22 = new org.apache.commons.jxpath.ri.parser.ParseException(token9, intArray16, strArray21);
        org.apache.commons.jxpath.JXPathContext jXPathContext23 = jXPathContextFactory1.newContext(jXPathContext8, (java.lang.Object) token9);
        java.util.Locale locale24 = jXPathContext23.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer26 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale24, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer27 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale24);
        java.lang.String str28 = dOMNodePointer27.getDefaultNamespaceURI();
        org.apache.commons.jxpath.Container container29 = null;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer31 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container29, locale30);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = containerPointer31.namespacePointer("|");
        java.lang.Object obj34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer36 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj34, locale35);
        java.util.Locale locale38 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer39 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale38);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = jDOMNodePointer39.getImmediateParentPointer();
        java.lang.Object obj41 = jDOMNodePointer39.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver42 = jDOMNodePointer39.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext43 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = collectionPointer36.createPath(jXPathContext43);
        try {
            int int45 = dOMNodePointer27.compareChildNodePointers(nodePointer33, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory1);
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(namespaceResolver7);
        org.junit.Assert.assertNotNull(jXPathContext8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray11), "[10]");
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray13), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jXPathContext23);
        org.junit.Assert.assertNotNull(locale24);
        org.junit.Assert.assertEquals(locale24.toString(), "en_GB");
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(nodePointer33);
        org.junit.Assert.assertNull(nodePointer40);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNull(namespaceResolver42);
        org.junit.Assert.assertNotNull(jXPathContext43);
        org.junit.Assert.assertNotNull(nodePointer44);
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer19 = beanPointer17.getPropertyPointer();
        boolean boolean21 = beanPointer17.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container22, locale23);
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container22, locale25, "hi!");
        org.apache.commons.jxpath.ri.QName qName29 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator30 = jDOMNodePointer27.attributeIterator(qName29);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference31 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName29);
        boolean boolean32 = variableReference31.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray33 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion34 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray33);
        java.lang.String str35 = coreOperationUnion34.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest36 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference31, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion34);
        boolean boolean37 = nameAttributeTest36.computeContextDependent();
        boolean boolean38 = beanPointer17.equals((java.lang.Object) boolean37);
        boolean boolean39 = beanPointer17.isCollection();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = beanPointer17.getParent();
        java.beans.PropertyDescriptor propertyDescriptor41 = null;
        try {
            java.lang.Object obj43 = org.apache.commons.jxpath.util.ValueUtils.getValue((java.lang.Object) nodePointer40, propertyDescriptor41, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(propertyPointer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeIterator30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(expressionArray33);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "|" + "'", str35, "|");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodePointer40);
    }

    @Test
    public void test0557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0557");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.QName qName50 = nullPointer2.getName();
        java.lang.String str51 = nullPointer2.asPath();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNull(qName50);
        org.junit.Assert.assertEquals("'" + str51 + "' != '" + "id($null)" + "'", str51, "id($null)");
    }

    @Test
    public void test0585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0585");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.Pointer pointer44 = selfContext43.getSingleNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0603");
        org.apache.commons.jxpath.ri.parser.Token token1 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.kind = 0;
        org.apache.commons.jxpath.ri.parser.Token token5 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token1.specialToken = token5;
        org.apache.commons.jxpath.ri.parser.Token token8 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token8.endLine = 67;
        token8.endColumn = 44;
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.ri.parser.Token token27 = null;
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[][] intArray34 = new int[][] { intArray29, intArray31, intArray33 };
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException40 = new org.apache.commons.jxpath.ri.parser.ParseException(token27, intArray34, strArray39);
        org.apache.commons.jxpath.ri.parser.Token token41 = parseException40.currentToken;
        org.apache.commons.jxpath.JXPathContextFactoryConfigurationError jXPathContextFactoryConfigurationError43 = new org.apache.commons.jxpath.JXPathContextFactoryConfigurationError((java.lang.Exception) parseException40, "");
        org.apache.commons.jxpath.ri.parser.Token token44 = null;
        int[] intArray46 = new int[] { 10 };
        int[] intArray48 = new int[] { 10 };
        int[] intArray50 = new int[] { 10 };
        int[][] intArray51 = new int[][] { intArray46, intArray48, intArray50 };
        java.lang.String[] strArray56 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException57 = new org.apache.commons.jxpath.ri.parser.ParseException(token44, intArray51, strArray56);
        org.apache.commons.jxpath.ri.parser.Token token58 = parseException57.currentToken;
        java.lang.String[] strArray59 = parseException57.tokenImage;
        parseException40.tokenImage = strArray59;
        org.apache.commons.jxpath.ri.parser.ParseException parseException61 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray20, strArray59);
        java.lang.String str62 = token8.toString();
        token1.next = token8;
        org.apache.commons.jxpath.ri.parser.Token token64 = token1.next;
        org.apache.commons.jxpath.ri.parser.Token token65 = token1.next;
        token1.beginLine = 47;
        org.junit.Assert.assertNotNull(token1);
        org.junit.Assert.assertNotNull(token5);
        org.junit.Assert.assertNotNull(token8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNull(token41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray46), "[10]");
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray48), "[10]");
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray50), "[10]");
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNull(token58);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(token64);
        org.junit.Assert.assertNotNull(token65);
    }

    @Test
    public void test0604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0604");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer50 = beanPointer49.getPropertyPointer();
        try {
            boolean boolean51 = propertyPointer50.isCollection();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(propertyPointer50);
    }

    @Test
    public void test0610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0610");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        org.apache.commons.jxpath.ri.QName qName2 = nullPropertyPointer1.getName();
        nullPropertyPointer1.setPropertyName("id(preceding)");
        java.lang.String str5 = nullPropertyPointer1.getPropertyName();
        org.apache.commons.jxpath.CompiledExpression compiledExpression7 = org.apache.commons.jxpath.JXPathContext.compile("UNKNOWN");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory8 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale10);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = jDOMNodePointer11.getImmediateParentPointer();
        java.lang.Object obj13 = jDOMNodePointer11.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver14 = jDOMNodePointer11.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext15 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer11);
        org.apache.commons.jxpath.ri.parser.Token token16 = null;
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[][] intArray23 = new int[][] { intArray18, intArray20, intArray22 };
        java.lang.String[] strArray28 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException29 = new org.apache.commons.jxpath.ri.parser.ParseException(token16, intArray23, strArray28);
        org.apache.commons.jxpath.JXPathContext jXPathContext30 = jXPathContextFactory8.newContext(jXPathContext15, (java.lang.Object) token16);
        jXPathContext15.setLenient(true);
        java.util.Iterator iterator33 = compiledExpression7.iteratePointers(jXPathContext15);
        org.apache.commons.jxpath.Functions functions34 = jXPathContext15.getFunctions();
        org.apache.commons.jxpath.PackageFunctions packageFunctions37 = new org.apache.commons.jxpath.PackageFunctions("=", "org.apache.commons.jxpath.JXPathContextFactory");
        jXPathContext15.setFunctions((org.apache.commons.jxpath.Functions) packageFunctions37);
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer41 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale40);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer42 = jDOMNodePointer41.getImmediateParentPointer();
        java.lang.String str43 = jDOMNodePointer41.asPath();
        java.util.Locale locale44 = jDOMNodePointer41.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = jDOMNodePointer41.namespacePointer("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = nullPropertyPointer1.createPath(jXPathContext15, (java.lang.Object) jDOMNodePointer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(qName2);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id(preceding)" + "'", str5, "id(preceding)");
        org.junit.Assert.assertNotNull(compiledExpression7);
        org.junit.Assert.assertNotNull(jXPathContextFactory8);
        org.junit.Assert.assertNull(nodePointer12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(namespaceResolver14);
        org.junit.Assert.assertNotNull(jXPathContext15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jXPathContext30);
        org.junit.Assert.assertNotNull(iterator33);
        org.junit.Assert.assertNotNull(functions34);
        org.junit.Assert.assertNull(nodePointer42);
        org.junit.Assert.assertEquals("'" + str43 + "' != '" + "" + "'", str43, "");
        org.junit.Assert.assertNull(locale44);
        org.junit.Assert.assertNotNull(nodePointer46);
    }

    @Test
    public void test0631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0631");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        boolean boolean4 = jDOMNodePointer2.equals((java.lang.Object) (byte) 0);
        java.lang.String str5 = jDOMNodePointer2.asPath();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer7 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer2, "");
        boolean boolean8 = namespacePointer7.isLeaf();
        java.lang.Object obj9 = namespacePointer7.getImmediateNode();
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        boolean boolean14 = jDOMNodePointer12.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer12.attributeIterator(qName16);
        java.lang.String str18 = qName16.getPrefix();
        org.apache.commons.beanutils.DynaBean dynaBean19 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer20 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer7, qName16, dynaBean19);
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        java.lang.Object obj24 = jDOMNodePointer23.getValue();
        org.apache.commons.jxpath.ri.QName qName25 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler27 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer28 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer23, qName25, (java.lang.Object) 1.0d, dynamicPropertyHandler27);
        org.apache.commons.jxpath.Container container29 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer30 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPointer28, container29);
        org.apache.commons.jxpath.ri.QName qName31 = dynamicPointer28.getName();
        org.apache.commons.jxpath.Container container32 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer33 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPointer28, container32);
        boolean boolean34 = dynamicPointer28.isDynamicPropertyDeclarationSupported();
        org.apache.commons.jxpath.ri.QName qName35 = dynamicPointer28.getName();
        boolean boolean36 = dynamicPointer28.isLeaf();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer38 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer37);
        org.apache.commons.jxpath.ri.QName qName39 = nullPropertyPointer38.getName();
        boolean boolean40 = nullPropertyPointer38.isLeaf();
        java.lang.String str41 = nullPropertyPointer38.asPath();
        int int42 = nullPropertyPointer38.getPropertyCount();
        int int43 = namespacePointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPointer28, (org.apache.commons.jxpath.ri.model.NodePointer) nullPropertyPointer38);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "" + "'", str5, "");
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(qName31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(qName35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(qName39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertEquals("'" + str41 + "' != '" + "/*" + "'", str41, "/*");
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test0641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0641");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName16);
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer22 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer23 = variablePointer21.getImmediateValuePointer();
        org.apache.commons.jxpath.ri.EvalContext evalContext24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest25 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext28 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext24, nodeTest25, false, false);
        childContext28.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext31 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext28, nodeTest30);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext precedingOrFollowingContext34 = new org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext((org.apache.commons.jxpath.ri.EvalContext) selfContext31, nodeTest32, false);
        precedingOrFollowingContext34.reset();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator36 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        int int37 = precedingOrFollowingContext34.getDocumentOrder();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer38 = precedingOrFollowingContext34.getCurrentNodePointer();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator39 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        try {
            int int40 = variablePointer21.compareTo((java.lang.Object) valueIterator39);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.compiler.Expression$ValueIterator cannot be cast to org.apache.commons.jxpath.ri.model.NodePointer");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNotNull(nodePointer23);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(nodePointer38);
    }

    @Test
    public void test0650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0650");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName16);
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer22 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21);
        org.apache.commons.jxpath.ri.QName qName23 = nullPropertyPointer22.getName();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = nullPropertyPointer22.getValuePointer();
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        boolean boolean35 = variableReference34.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray36 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion37 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray36);
        java.lang.String str38 = coreOperationUnion37.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest39 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference34, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion37);
        try {
            nodePointer24.setValue((java.lang.Object) coreOperationUnion37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidAccessException; message: Cannot set property $, the target object is null");
        } catch (org.apache.commons.jxpath.JXPathInvalidAccessException e) {
        }
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNotNull(qName23);
        org.junit.Assert.assertNotNull(nodePointer24);
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(expressionArray36);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "|" + "'", str38, "|");
    }

    @Test
    public void test0717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0717");
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray0 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion1 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray0);
        org.apache.commons.jxpath.ri.EvalContext evalContext2 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest3 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext6 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext2, nodeTest3, false, false);
        childContext6.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest8 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext9 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext6, nodeTest8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext11 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext6, nodeSet10);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale13);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = jDOMNodePointer14.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer14.namespaceIterator();
        java.lang.Object obj17 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext18 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest19 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext22 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext18, nodeTest19, false, false);
        childContext22.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest24 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext25 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext22, nodeTest24);
        org.apache.commons.jxpath.ri.QName qName26 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext29 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext25, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.QName qName30 = nodeNameTest28.getNodeName();
        boolean boolean31 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer14, obj17, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext32 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext11, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.EvalContext evalContext33 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest34 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext37 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext33, nodeTest34, false, false);
        childContext37.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest39 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext40 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext37, nodeTest39);
        org.apache.commons.jxpath.ri.QName qName41 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest43 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext44 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext40, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest43);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest43);
        try {
            java.lang.Object obj46 = coreOperationUnion1.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(expressionArray0);
        org.junit.Assert.assertNull(nodePointer15);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNull(qName30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test0729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0729");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        java.lang.Object obj4 = dOMNodePointer3.getNodeValue();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.getParent();
        java.lang.Object obj6 = dOMNodePointer3.getBaseValue();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = null;
        org.apache.commons.jxpath.Container container8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer10 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container8, locale9);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container8, locale11, "hi!");
        org.apache.commons.jxpath.ri.QName qName15 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer13.attributeIterator(qName15);
        org.w3c.dom.Node node17 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        java.util.Locale locale41 = jXPathContext40.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer42 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node17, locale41);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer44 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale41, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer45 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName15, locale41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest46 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName15);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = dOMNodePointer3.createAttribute(jXPathContext7, qName15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path id('')/@, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(nodePointer5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertEquals(locale41.toString(), "en_GB");
    }

    @Test
    public void test0751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0751");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        java.util.Locale locale23 = jXPathContext22.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer25 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "preceding");
        java.lang.String str26 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.getLocalName((java.lang.Object) locale23);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer28 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "http://www.w3.org/2000/xmlns/");
        boolean boolean29 = nullPointer28.isCollection();
        java.util.Locale locale31 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale31);
        boolean boolean34 = jDOMNodePointer32.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName36 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator37 = jDOMNodePointer32.attributeIterator(qName36);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest39 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName36, "hi!");
        java.util.Locale locale42 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer43 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale42);
        boolean boolean45 = jDOMNodePointer43.equals((java.lang.Object) (byte) 0);
        java.lang.String str46 = jDOMNodePointer43.asPath();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer48 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer43, "");
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator49 = nullPointer28.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest39, true, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: PropertyIerator startWith parameter is not a child of the supplied parent");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertEquals(locale23.toString(), "en_GB");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(nodeIterator37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
    }

    @Test
    public void test0764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0764");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer19 = beanPointer17.getPropertyPointer();
        boolean boolean21 = beanPointer17.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container22, locale23);
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container22, locale25, "hi!");
        org.apache.commons.jxpath.ri.QName qName29 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator30 = jDOMNodePointer27.attributeIterator(qName29);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference31 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName29);
        boolean boolean32 = variableReference31.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray33 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion34 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray33);
        java.lang.String str35 = coreOperationUnion34.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest36 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference31, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion34);
        boolean boolean37 = nameAttributeTest36.computeContextDependent();
        boolean boolean38 = beanPointer17.equals((java.lang.Object) boolean37);
        boolean boolean39 = beanPointer17.isCollection();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = beanPointer17.getParent();
        org.apache.commons.jxpath.ri.QName qName41 = beanPointer17.getName();
        int int42 = beanPointer17.index;
        boolean boolean43 = beanPointer17.isLeaf();
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(propertyPointer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeIterator30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(expressionArray33);
        org.junit.Assert.assertEquals("'" + str35 + "' != '" + "|" + "'", str35, "|");
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodePointer40);
        org.junit.Assert.assertNotNull(qName41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-2147483648) + "'", int42 == (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer50 = beanPointer49.getPropertyPointer();
        org.apache.commons.jxpath.ri.QName qName51 = beanPointer49.getName();
        try {
            beanPointer49.setValue((java.lang.Object) "descendant-or-self");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot setValue of an object that is not some other object's property");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(propertyPointer50);
        org.junit.Assert.assertNotNull(qName51);
    }

    @Test
    public void test0806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0806");
        org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory beanPointerFactory0 = new org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory();
        org.w3c.dom.Node node1 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer4 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node1, locale2, "");
        java.lang.Object obj5 = dOMNodePointer4.getNodeValue();
        boolean boolean6 = dOMNodePointer4.isCollection();
        org.apache.commons.jxpath.Container container7 = null;
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer9 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container7, locale8);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container7, locale10, "hi!");
        org.apache.commons.jxpath.ri.QName qName14 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator15 = jDOMNodePointer12.attributeIterator(qName14);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference16 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName14);
        org.w3c.dom.Node node17 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        java.util.Locale locale41 = jXPathContext40.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer43 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale41, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer44 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node17, locale41);
        java.lang.String str45 = dOMNodePointer44.getDefaultNamespaceURI();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = beanPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer4, qName14, (java.lang.Object) str45);
        java.lang.Object obj47 = nodePointer46.getBaseValue();
        nodePointer46.setIndex(5);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer50 = nodePointer46.getValuePointer();
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterator15);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertEquals(locale41.toString(), "en_GB");
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(nodePointer46);
        org.junit.Assert.assertNull(obj47);
        org.junit.Assert.assertNotNull(nodePointer50);
    }

    @Test
    public void test0818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0818");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        org.w3c.dom.Node node8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer11 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale9, "");
        java.util.Locale locale12 = dOMNodePointer11.locale;
        java.lang.Object obj13 = dOMNodePointer11.getRootNode();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        int int20 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer11, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16);
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = jDOMNodePointer23.getImmediateParentPointer();
        java.lang.Object obj25 = jDOMNodePointer23.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver26 = jDOMNodePointer23.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer23);
        java.lang.String str29 = jXPathContext27.getPrefix("http://www.w3.org/2000/xmlns/");
        java.util.Locale locale30 = jXPathContext27.getLocale();
        org.apache.commons.jxpath.Functions functions31 = jXPathContext27.getFunctions();
        boolean boolean32 = jXPathContext27.isLenient();
        java.util.Locale locale34 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer35 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale34);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = jDOMNodePointer35.getImmediateParentPointer();
        java.lang.String str37 = jDOMNodePointer35.asPath();
        java.util.Locale locale38 = jDOMNodePointer35.locale;
        java.lang.String str39 = jDOMNodePointer35.asPath();
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer40 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer35);
        org.apache.commons.jxpath.ri.QName qName41 = jDOMNodePointer35.getName();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = collectionPointer7.createChild(jXPathContext27, qName41, 55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn java.lang.Integer into a collection of size 56");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertNull(locale12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(nodePointer24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(namespaceResolver26);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_GB");
        org.junit.Assert.assertNotNull(functions31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(nodePointer36);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertNull(locale38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertNotNull(qName41);
    }

    @Test
    public void test0842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0842");
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray0 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion1 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray0);
        java.lang.String str2 = coreOperationUnion1.getSymbol();
        org.apache.commons.jxpath.ri.EvalContext evalContext3 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest4 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext7 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext3, nodeTest4, false, false);
        childContext7.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest9 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext10 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext7, nodeTest9);
        org.apache.commons.jxpath.ri.QName qName11 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest13 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName11, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext14 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest13);
        org.apache.commons.jxpath.NodeSet nodeSet15 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext16 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, nodeSet15);
        org.apache.commons.jxpath.ri.QName qName17 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest19 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName17, "");
        org.apache.commons.jxpath.ri.QName qName20 = nodeNameTest19.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext21 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext10, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest19);
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        boolean boolean26 = jDOMNodePointer24.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName28 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator29 = jDOMNodePointer24.attributeIterator(qName28);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName28, "hi!");
        java.lang.String str32 = nodeNameTest31.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, false, false);
        int int36 = selfContext21.getDocumentOrder();
        org.apache.commons.jxpath.ri.EvalContext[] evalContextArray37 = new org.apache.commons.jxpath.ri.EvalContext[] {};
        org.apache.commons.jxpath.ri.axes.UnionContext unionContext38 = new org.apache.commons.jxpath.ri.axes.UnionContext((org.apache.commons.jxpath.ri.EvalContext) selfContext21, evalContextArray37);
        int int39 = unionContext38.getDocumentOrder();
        int int40 = unionContext38.getDocumentOrder();
        int int41 = unionContext38.getDocumentOrder();
        try {
            java.util.Iterator iterator42 = coreOperationUnion1.iteratePointers((org.apache.commons.jxpath.ri.EvalContext) unionContext38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(expressionArray0);
        org.junit.Assert.assertEquals("'" + str2 + "' != '" + "|" + "'", str2, "|");
        org.junit.Assert.assertNull(qName20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(nodeIterator29);
        org.junit.Assert.assertEquals("'" + str32 + "' != '" + "hi!" + "'", str32, "hi!");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(evalContextArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test0878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0878");
        org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory beanPointerFactory0 = new org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory();
        org.w3c.dom.Node node1 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer4 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node1, locale2, "");
        java.lang.Object obj5 = dOMNodePointer4.getNodeValue();
        boolean boolean6 = dOMNodePointer4.isCollection();
        org.apache.commons.jxpath.Container container7 = null;
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer9 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container7, locale8);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container7, locale10, "hi!");
        org.apache.commons.jxpath.ri.QName qName14 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator15 = jDOMNodePointer12.attributeIterator(qName14);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference16 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName14);
        org.w3c.dom.Node node17 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        java.util.Locale locale41 = jXPathContext40.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer43 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale41, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer44 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node17, locale41);
        java.lang.String str45 = dOMNodePointer44.getDefaultNamespaceURI();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = beanPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer4, qName14, (java.lang.Object) str45);
        boolean boolean47 = dOMNodePointer4.isCollection();
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(nodeIterator15);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
        org.junit.Assert.assertNotNull(locale41);
        org.junit.Assert.assertEquals(locale41.toString(), "en_GB");
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(nodePointer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test0961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0961");
        org.apache.commons.jxpath.Variables variables0 = null;
        org.apache.commons.jxpath.ri.QName qName1 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer2 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables0, qName1);
        boolean boolean3 = variablePointer2.isRoot();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer6 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer2, "hi!", "");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory7 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        java.lang.Object obj12 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver13 = jDOMNodePointer10.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext14 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer10);
        org.apache.commons.jxpath.ri.parser.Token token15 = null;
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[][] intArray22 = new int[][] { intArray17, intArray19, intArray21 };
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException28 = new org.apache.commons.jxpath.ri.parser.ParseException(token15, intArray22, strArray27);
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = jXPathContextFactory7.newContext(jXPathContext14, (java.lang.Object) token15);
        java.lang.Object obj30 = jXPathContext29.getContextBean();
        org.w3c.dom.Node node31 = null;
        java.util.Locale locale32 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer34 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node31, locale32, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = dOMNodePointer34.namespacePointer("preceding");
        java.lang.Object obj37 = dOMNodePointer34.clone();
        jXPathContext29.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) dOMNodePointer34);
        org.w3c.dom.Node node39 = null;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer42 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node39, locale40, "");
        java.util.Locale locale43 = dOMNodePointer42.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = dOMNodePointer42.namespacePointer("");
        int int46 = nodePointer45.getIndex();
        jXPathContext29.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) nodePointer45);
        org.apache.commons.jxpath.Pointer pointer48 = jXPathContext29.getNamespaceContextPointer();
        org.apache.commons.jxpath.AbstractFactory abstractFactory49 = null;
        jXPathContext29.setFactory(abstractFactory49);
        try {
            variablePointer2.findVariables(jXPathContext29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(jXPathContextFactory7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(namespaceResolver13);
        org.junit.Assert.assertNotNull(jXPathContext14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(nodePointer36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertEquals(obj37.toString(), "id('')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj37), "id('')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj37), "id('')");
        org.junit.Assert.assertNull(locale43);
        org.junit.Assert.assertNotNull(nodePointer45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-2147483648) + "'", int46 == (-2147483648));
        org.junit.Assert.assertNotNull(pointer48);
    }

    @Test
    public void test0982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0982");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest10 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName8, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext11 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest10);
        org.apache.commons.jxpath.NodeSet nodeSet12 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext13 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, nodeSet12);
        org.apache.commons.jxpath.ri.QName qName14 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest16 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName14, "");
        org.apache.commons.jxpath.ri.QName qName17 = nodeNameTest16.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext18 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest16);
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        boolean boolean23 = jDOMNodePointer21.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName25 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator26 = jDOMNodePointer21.attributeIterator(qName25);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName25, "hi!");
        java.lang.String str29 = nodeNameTest28.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext32 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext18, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28, false, false);
        org.apache.commons.jxpath.ri.EvalContext evalContext34 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest35 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext38 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext34, nodeTest35, false, false);
        childContext38.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest40 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext41 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext38, nodeTest40);
        org.apache.commons.jxpath.ri.QName qName42 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName42, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext41, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.QName qName46 = nodeNameTest44.getNodeName();
        org.apache.commons.jxpath.ri.QName qName47 = nodeNameTest44.getNodeName();
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext48 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) childContext32, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        try {
            java.lang.String str49 = nodeNameTest44.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(qName17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(nodeIterator26);
        org.junit.Assert.assertEquals("'" + str29 + "' != '" + "hi!" + "'", str29, "hi!");
        org.junit.Assert.assertNull(qName46);
        org.junit.Assert.assertNull(qName47);
    }

    @Test
    public void test0989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0989");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        java.lang.Object obj21 = collectionPointer8.getBaseValue();
        boolean boolean22 = collectionPointer8.isContainer();
        java.lang.Object obj23 = collectionPointer8.getNode();
        org.apache.commons.jxpath.ri.EvalContext evalContext24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest25 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext28 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext24, nodeTest25, false, false);
        childContext28.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext31 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext28, nodeTest30);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext precedingOrFollowingContext34 = new org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext((org.apache.commons.jxpath.ri.EvalContext) selfContext31, nodeTest32, false);
        precedingOrFollowingContext34.reset();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator36 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        int int37 = precedingOrFollowingContext34.getDocumentOrder();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer38 = precedingOrFollowingContext34.getCurrentNodePointer();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer39 = precedingOrFollowingContext34.getCurrentNodePointer();
        precedingOrFollowingContext34.reset();
        java.lang.Object obj41 = org.apache.commons.jxpath.util.ValueUtils.getValue((java.lang.Object) precedingOrFollowingContext34);
        boolean boolean42 = collectionPointer8.equals(obj41);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + (-2147483648) + "'", obj21, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + (-2147483648) + "'", obj23, (-2147483648));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(nodePointer38);
        org.junit.Assert.assertNull(nodePointer39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertEquals(obj41.toString(), "Empty expression context");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj41), "Empty expression context");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj41), "Empty expression context");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test0995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0995");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        org.apache.commons.jxpath.ri.QName qName1 = null;
        org.apache.commons.jxpath.ri.parser.TokenMgrError tokenMgrError9 = new org.apache.commons.jxpath.ri.parser.TokenMgrError(false, 8, 10, 42, "", ' ', 12);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = containerPointerFactory0.createNodePointer(qName1, (java.lang.Object) 12, locale10);
        int int12 = containerPointerFactory0.getOrder();
        int int13 = containerPointerFactory0.getOrder();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.String str18 = jDOMNodePointer16.asPath();
        java.util.Locale locale19 = jDOMNodePointer16.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer21 = jDOMNodePointer16.namespacePointer("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"");
        int int22 = jDOMNodePointer16.getIndex();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory23 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale25);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = jDOMNodePointer26.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer26.getNamespaceResolver();
        int int29 = jDOMNodePointer26.index;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer31 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int29, locale30);
        org.apache.commons.jxpath.Container container32 = null;
        java.util.Locale locale33 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer34 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container32, locale33);
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container32, locale35, "hi!");
        org.apache.commons.jxpath.ri.QName qName39 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = jDOMNodePointer37.attributeIterator(qName39);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference41 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName39);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = containerPointerFactory23.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer31, qName39, (java.lang.Object) "");
        java.lang.String str44 = qName39.getName();
        java.lang.Object obj45 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer46 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16, qName39, obj45);
        int int47 = containerPointerFactory0.getOrder();
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 200 + "'", int12 == 200);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 200 + "'", int13 == 200);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertEquals("'" + str18 + "' != '" + "" + "'", str18, "");
        org.junit.Assert.assertNull(locale19);
        org.junit.Assert.assertNotNull(nodePointer21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2147483648) + "'", int22 == (-2147483648));
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2147483648) + "'", int29 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator40);
        org.junit.Assert.assertNull(nodePointer43);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "" + "'", str44, "");
        org.junit.Assert.assertNull(nodePointer46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 200 + "'", int47 == 200);
    }

    @Test
    public void test1177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1177");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.isContextDependent();
        boolean boolean11 = variableReference9.computeContextDependent();
        java.lang.String str12 = variableReference9.toString();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray13 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion14 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray13);
        java.lang.String str15 = coreOperationUnion14.getSymbol();
        java.lang.String str16 = coreOperationUnion14.getSymbol();
        boolean boolean17 = coreOperationUnion14.computeContextDependent();
        boolean boolean18 = coreOperationUnion14.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest19 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference9, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion14);
        java.lang.String str20 = nameAttributeTest19.toString();
        org.apache.commons.jxpath.ri.EvalContext evalContext21 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext25 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext21, nodeTest22, false, false);
        childContext25.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest27 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext28 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext25, nodeTest27);
        org.apache.commons.jxpath.ri.QName qName29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName29, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext32 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext28, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31);
        org.apache.commons.jxpath.ri.QName qName33 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest35 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName33, "");
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext36 = new org.apache.commons.jxpath.ri.axes.NamespaceContext((org.apache.commons.jxpath.ri.EvalContext) selfContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest35);
        namespaceContext36.reset();
        int int38 = namespaceContext36.getPosition();
        boolean boolean40 = namespaceContext36.setPosition((int) (byte) -1);
        try {
            java.lang.Object obj41 = nameAttributeTest19.computeValue((org.apache.commons.jxpath.ri.EvalContext) namespaceContext36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "$" + "'", str12, "$");
        org.junit.Assert.assertNotNull(expressionArray13);
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "|" + "'", str15, "|");
        org.junit.Assert.assertEquals("'" + str16 + "' != '" + "|" + "'", str16, "|");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals("'" + str20 + "' != '" + "$ = " + "'", str20, "$ = ");
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test1267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1267");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = attributeContext30.getCurrentNodePointer();
        org.apache.commons.jxpath.Pointer pointer45 = attributeContext30.getContextNodePointer();
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext46 = attributeContext30.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(nodePointer44);
        org.junit.Assert.assertNull(pointer45);
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest10 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName8, "");
        org.apache.commons.jxpath.ri.QName qName11 = nodeNameTest10.getNodeName();
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext12 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest10);
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer15.getNamespaceResolver();
        int int18 = jDOMNodePointer15.index;
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer20 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int18, locale19);
        org.w3c.dom.Node node21 = null;
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer24 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale22, "");
        java.util.Locale locale25 = dOMNodePointer24.locale;
        java.lang.Object obj26 = dOMNodePointer24.getRootNode();
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer29 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale28);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer30 = jDOMNodePointer29.getImmediateParentPointer();
        java.lang.Object obj31 = jDOMNodePointer29.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver32 = jDOMNodePointer29.getNamespaceResolver();
        int int33 = collectionPointer20.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer24, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer34 = collectionPointer20.getValuePointer();
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale36);
        boolean boolean39 = jDOMNodePointer37.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer37.attributeIterator(qName41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "hi!");
        java.lang.String str45 = nodeNameTest44.getNamespaceURI();
        boolean boolean46 = collectionPointer20.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext47 = new org.apache.commons.jxpath.ri.axes.ParentContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext12, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        attributeContext12.reset();
        org.junit.Assert.assertNull(qName11);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2147483648) + "'", int18 == (-2147483648));
        org.junit.Assert.assertNull(locale25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(nodePointer30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNull(namespaceResolver32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodePointer34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test1406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1406");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        boolean boolean4 = jDOMNodePointer2.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName6 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator7 = jDOMNodePointer2.attributeIterator(qName6);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer10.getNamespaceResolver();
        int int13 = jDOMNodePointer10.index;
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer15 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int13, locale14);
        org.w3c.dom.Node node16 = null;
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer19 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node16, locale17, "");
        java.util.Locale locale20 = dOMNodePointer19.locale;
        java.lang.Object obj21 = dOMNodePointer19.getRootNode();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        java.lang.Object obj26 = jDOMNodePointer24.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver27 = jDOMNodePointer24.getNamespaceResolver();
        int int28 = collectionPointer15.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer19, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer24);
        org.apache.commons.jxpath.ri.QName qName29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName29, "");
        org.apache.commons.jxpath.ri.QName qName32 = nodeNameTest31.getNodeName();
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer36 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale35);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = jDOMNodePointer36.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver38 = jDOMNodePointer36.getNamespaceResolver();
        int int39 = jDOMNodePointer36.index;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer41 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int39, locale40);
        java.lang.Object obj42 = collectionPointer41.getBaseValue();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator43 = collectionPointer15.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, true, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = null;
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator46 = jDOMNodePointer2.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, true, nodePointer45);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer48 = jDOMNodePointer2.namespacePointer("Expression context [0] id(\\'\\'):id(\\'\\')");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeIterator7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2147483648) + "'", int13 == (-2147483648));
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(namespaceResolver27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(qName32);
        org.junit.Assert.assertNull(nodePointer37);
        org.junit.Assert.assertNull(namespaceResolver38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-2147483648) + "'", int39 == (-2147483648));
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + (-2147483648) + "'", obj42, (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator43);
        org.junit.Assert.assertNotNull(nodeIterator46);
        org.junit.Assert.assertNotNull(nodePointer48);
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler1 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj3 = treeCompiler1.literal("/");
        java.lang.Object obj5 = treeCompiler1.literal("<<unknown namespace>>");
        java.lang.Object obj7 = treeCompiler1.literal("$");
        java.lang.Object obj10 = treeCompiler1.qname("/http://www.w3.org/2000/xmlns/", "/http://www.w3.org/2000/xmlns/");
        java.lang.Object obj11 = org.apache.commons.jxpath.ri.Parser.parseExpression("/.[43]", (org.apache.commons.jxpath.ri.Compiler) treeCompiler1);
        java.lang.Object obj14 = treeCompiler1.qname("namespace", "org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer18 = jDOMNodePointer17.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer17.getNamespaceResolver();
        int int20 = jDOMNodePointer17.index;
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer22 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int20, locale21);
        collectionPointer22.setIndex(42);
        int int25 = collectionPointer22.getLength();
        org.apache.commons.jxpath.ri.QName qName26 = collectionPointer22.getName();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = collectionPointer22.parent;
        boolean boolean28 = collectionPointer22.isCollection();
        org.apache.commons.jxpath.ri.QName qName29 = collectionPointer22.getName();
        java.lang.Object obj30 = null;
        java.util.Locale locale31 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer32 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj30, locale31);
        java.lang.Object obj33 = collectionPointer32.getRootNode();
        try {
            java.lang.Object obj34 = treeCompiler1.lessThanOrEqual((java.lang.Object) collectionPointer22, obj33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.model.beans.CollectionPointer cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj3), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj3), "'/'");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertEquals(obj5.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertEquals(obj7.toString(), "'$'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj7), "'$'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj7), "'$'");
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertEquals(obj10.toString(), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj10), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj10), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "/.[43]");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "/.[43]");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "/.[43]");
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertEquals(obj14.toString(), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj14), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj14), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertNull(nodePointer18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-2147483648) + "'", int20 == (-2147483648));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(qName26);
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(qName29);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext44 = attributeContext30.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

}
