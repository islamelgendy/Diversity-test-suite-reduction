package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0025");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory23 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale25);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = jDOMNodePointer26.getImmediateParentPointer();
        java.lang.Object obj28 = jDOMNodePointer26.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver29 = jDOMNodePointer26.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext30 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer26);
        org.apache.commons.jxpath.ri.parser.Token token31 = null;
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[] intArray37 = new int[] { 10 };
        int[][] intArray38 = new int[][] { intArray33, intArray35, intArray37 };
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException44 = new org.apache.commons.jxpath.ri.parser.ParseException(token31, intArray38, strArray43);
        org.apache.commons.jxpath.JXPathContext jXPathContext45 = jXPathContextFactory23.newContext(jXPathContext30, (java.lang.Object) token31);
        org.apache.commons.jxpath.Variables variables46 = jXPathContext30.getVariables();
        org.apache.commons.jxpath.JXPathContext jXPathContext48 = jXPathContextFactory0.newContext(jXPathContext30, (java.lang.Object) (short) 10);
        try {
            org.apache.commons.jxpath.Pointer pointer50 = jXPathContext48.createPath("");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidSyntaxException; message: Invalid XPath: ''. Syntax error at the beginning of the expression");
        } catch (org.apache.commons.jxpath.JXPathInvalidSyntaxException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(jXPathContextFactory23);
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(namespaceResolver29);
        org.junit.Assert.assertNotNull(jXPathContext30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray37), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jXPathContext45);
        org.junit.Assert.assertNotNull(variables46);
        org.junit.Assert.assertNotNull(jXPathContext48);
    }

    @Test
    public void test0033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0033");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory23 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale25);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = jDOMNodePointer26.getImmediateParentPointer();
        java.lang.Object obj28 = jDOMNodePointer26.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver29 = jDOMNodePointer26.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext30 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer26);
        org.apache.commons.jxpath.ri.parser.Token token31 = null;
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[] intArray37 = new int[] { 10 };
        int[][] intArray38 = new int[][] { intArray33, intArray35, intArray37 };
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException44 = new org.apache.commons.jxpath.ri.parser.ParseException(token31, intArray38, strArray43);
        org.apache.commons.jxpath.JXPathContext jXPathContext45 = jXPathContextFactory23.newContext(jXPathContext30, (java.lang.Object) token31);
        org.apache.commons.jxpath.Variables variables46 = jXPathContext30.getVariables();
        org.apache.commons.jxpath.JXPathContext jXPathContext48 = jXPathContextFactory0.newContext(jXPathContext30, (java.lang.Object) (short) 10);
        try {
            org.apache.commons.jxpath.Pointer pointer51 = jXPathContext30.getPointerByKey("http://www.w3.org/XML/1998/namespace", "");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot find an element by key - no KeyManager has been specified");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(jXPathContextFactory23);
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(namespaceResolver29);
        org.junit.Assert.assertNotNull(jXPathContext30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray37), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jXPathContext45);
        org.junit.Assert.assertNotNull(variables46);
        org.junit.Assert.assertNotNull(jXPathContext48);
    }

    @Test
    public void test0086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0086");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray11 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion12 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray11);
        java.lang.String str13 = coreOperationUnion12.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest14 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference9, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion12);
        org.apache.commons.jxpath.ri.EvalContext evalContext15 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest16 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext19 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext15, nodeTest16, false, false);
        childContext19.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest21 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext22 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext19, nodeTest21);
        org.apache.commons.jxpath.ri.QName qName23 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest25 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName23, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext26 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext22, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest25);
        org.apache.commons.jxpath.NodeSet nodeSet27 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext28 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext22, nodeSet27);
        org.apache.commons.jxpath.ri.QName qName29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName29, "");
        org.apache.commons.jxpath.ri.QName qName32 = nodeNameTest31.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext33 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext22, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31);
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer36 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale35);
        boolean boolean38 = jDOMNodePointer36.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName40 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator41 = jDOMNodePointer36.attributeIterator(qName40);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest43 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName40, "hi!");
        java.lang.String str44 = nodeNameTest43.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext47 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext33, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest43, false, false);
        try {
            java.lang.Object obj48 = coreOperationUnion12.compute((org.apache.commons.jxpath.ri.EvalContext) childContext47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(expressionArray11);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "|" + "'", str13, "|");
        org.junit.Assert.assertNull(qName32);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(nodeIterator41);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "hi!" + "'", str44, "hi!");
    }

    @Test
    public void test0088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0088");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory23 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale25);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = jDOMNodePointer26.getImmediateParentPointer();
        java.lang.Object obj28 = jDOMNodePointer26.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver29 = jDOMNodePointer26.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext30 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer26);
        org.apache.commons.jxpath.ri.parser.Token token31 = null;
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[] intArray37 = new int[] { 10 };
        int[][] intArray38 = new int[][] { intArray33, intArray35, intArray37 };
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException44 = new org.apache.commons.jxpath.ri.parser.ParseException(token31, intArray38, strArray43);
        org.apache.commons.jxpath.JXPathContext jXPathContext45 = jXPathContextFactory23.newContext(jXPathContext30, (java.lang.Object) token31);
        org.apache.commons.jxpath.Variables variables46 = jXPathContext30.getVariables();
        org.apache.commons.jxpath.JXPathContext jXPathContext48 = jXPathContextFactory0.newContext(jXPathContext30, (java.lang.Object) (short) 10);
        try {
            org.apache.commons.jxpath.Pointer pointer50 = jXPathContext30.getPointerByID("/null");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot find an element by ID - no IdentityManager has been specified");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(jXPathContextFactory23);
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertNull(obj28);
        org.junit.Assert.assertNull(namespaceResolver29);
        org.junit.Assert.assertNotNull(jXPathContext30);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray37), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNotNull(jXPathContext45);
        org.junit.Assert.assertNotNull(variables46);
        org.junit.Assert.assertNotNull(jXPathContext48);
    }

    @Test
    public void test0151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0151");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object[] objArray1 = null;
        java.lang.Object obj2 = treeCompiler0.union(objArray1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer5 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale3, "$null");
        boolean boolean6 = nullPointer5.isCollection();
        boolean boolean7 = nullPointer5.isLeaf();
        java.lang.String str8 = nullPointer5.asPath();
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale10);
        boolean boolean13 = jDOMNodePointer11.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName15 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer11.attributeIterator(qName15);
        java.lang.String str17 = qName15.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory18 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale20);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer22 = jDOMNodePointer21.getImmediateParentPointer();
        java.lang.Object obj23 = jDOMNodePointer21.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver24 = jDOMNodePointer21.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer21);
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContext jXPathContext40 = jXPathContextFactory18.newContext(jXPathContext25, (java.lang.Object) token26);
        org.apache.commons.jxpath.BasicVariables basicVariables41 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext40.setVariables((org.apache.commons.jxpath.Variables) basicVariables41);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException45 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables41.declareVariable("|", (java.lang.Object) "");
        basicVariables41.undeclareVariable("");
        basicVariables41.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo51 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer52 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer5, qName15, (java.lang.Object) basicVariables41, jXPathBeanInfo51);
        try {
            java.lang.Object obj53 = treeCompiler0.minus((java.lang.Object) qName15);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.QName cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "id($null)" + "'", str8, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(jXPathContextFactory18);
        org.junit.Assert.assertNull(nodePointer22);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertNull(namespaceResolver24);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jXPathContext40);
    }

    @Test
    public void test0173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0173");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        java.lang.Object obj4 = treeCompiler0.literal("<<unknown namespace>>");
        org.apache.commons.jxpath.ri.parser.Token token6 = org.apache.commons.jxpath.ri.parser.Token.newToken(67);
        token6.endLine = 67;
        token6.endColumn = 44;
        org.apache.commons.jxpath.ri.parser.Token token11 = null;
        int[] intArray13 = new int[] { 10 };
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[][] intArray18 = new int[][] { intArray13, intArray15, intArray17 };
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException24 = new org.apache.commons.jxpath.ri.parser.ParseException(token11, intArray18, strArray23);
        org.apache.commons.jxpath.ri.parser.Token token25 = null;
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[][] intArray32 = new int[][] { intArray27, intArray29, intArray31 };
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException38 = new org.apache.commons.jxpath.ri.parser.ParseException(token25, intArray32, strArray37);
        org.apache.commons.jxpath.ri.parser.Token token39 = parseException38.currentToken;
        org.apache.commons.jxpath.JXPathContextFactoryConfigurationError jXPathContextFactoryConfigurationError41 = new org.apache.commons.jxpath.JXPathContextFactoryConfigurationError((java.lang.Exception) parseException38, "");
        org.apache.commons.jxpath.ri.parser.Token token42 = null;
        int[] intArray44 = new int[] { 10 };
        int[] intArray46 = new int[] { 10 };
        int[] intArray48 = new int[] { 10 };
        int[][] intArray49 = new int[][] { intArray44, intArray46, intArray48 };
        java.lang.String[] strArray54 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException55 = new org.apache.commons.jxpath.ri.parser.ParseException(token42, intArray49, strArray54);
        org.apache.commons.jxpath.ri.parser.Token token56 = parseException55.currentToken;
        java.lang.String[] strArray57 = parseException55.tokenImage;
        parseException38.tokenImage = strArray57;
        org.apache.commons.jxpath.ri.parser.ParseException parseException59 = new org.apache.commons.jxpath.ri.parser.ParseException(token6, intArray18, strArray57);
        try {
            java.lang.Object obj60 = treeCompiler0.or((java.lang.Object[]) strArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals(obj4.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(token6);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray13), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNull(token39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray44), "[10]");
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray46), "[10]");
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray48), "[10]");
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(strArray54);
        org.junit.Assert.assertNull(token56);
        org.junit.Assert.assertNotNull(strArray57);
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        org.apache.commons.jxpath.ri.parser.Token token3 = null;
        int[] intArray5 = new int[] { 10 };
        int[] intArray7 = new int[] { 10 };
        int[] intArray9 = new int[] { 10 };
        int[][] intArray10 = new int[][] { intArray5, intArray7, intArray9 };
        java.lang.String[] strArray15 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException16 = new org.apache.commons.jxpath.ri.parser.ParseException(token3, intArray10, strArray15);
        java.lang.Throwable[] throwableArray17 = parseException16.getSuppressed();
        java.lang.Object obj18 = treeCompiler0.union((java.lang.Object[]) throwableArray17);
        java.lang.Object obj20 = treeCompiler0.literal("|");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        org.apache.commons.jxpath.BasicVariables basicVariables45 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext44.setVariables((org.apache.commons.jxpath.Variables) basicVariables45);
        basicVariables45.undeclareVariable("");
        try {
            java.lang.Object obj49 = treeCompiler0.greaterThan((java.lang.Object) 70, (java.lang.Object) basicVariables45);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[10]");
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray7), "[10]");
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray9), "[10]");
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertEquals(obj18.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj18), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj18), "");
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertEquals(obj20.toString(), "'|'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj20), "'|'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj20), "'|'");
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
    }

    @Test
    public void test0241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0241");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        java.util.Locale locale4 = dOMNodePointer3.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer6 = dOMNodePointer3.namespacePointer("");
        java.lang.Object obj7 = dOMNodePointer3.getNodeValue();
        org.apache.commons.jxpath.ri.EvalContext evalContext8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest9 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext12 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext8, nodeTest9, false, false);
        childContext12.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest14 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext15 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext12, nodeTest14);
        org.apache.commons.jxpath.NodeSet nodeSet16 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext17 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext12, nodeSet16);
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer20 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale19);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer21 = jDOMNodePointer20.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator22 = jDOMNodePointer20.namespaceIterator();
        java.lang.Object obj23 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest25 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext28 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext24, nodeTest25, false, false);
        childContext28.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext31 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext28, nodeTest30);
        org.apache.commons.jxpath.ri.QName qName32 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest34 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName32, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext35 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext31, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest34);
        org.apache.commons.jxpath.ri.QName qName36 = nodeNameTest34.getNodeName();
        boolean boolean37 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer20, obj23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest34);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext38 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext17, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest34);
        org.apache.commons.jxpath.ri.EvalContext evalContext39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest40 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext43 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext39, nodeTest40, false, false);
        childContext43.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest45 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext46 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext43, nodeTest45);
        org.apache.commons.jxpath.ri.QName qName47 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest49 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName47, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext50 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext46, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest49);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext51 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest49);
        try {
            boolean boolean52 = dOMNodePointer3.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(locale4);
        org.junit.Assert.assertNotNull(nodePointer6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(nodePointer21);
        org.junit.Assert.assertNotNull(nodeIterator22);
        org.junit.Assert.assertNull(qName36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        collectionPointer7.setIndex(42);
        int int10 = collectionPointer7.getLength();
        org.apache.commons.jxpath.Container container11 = null;
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer13 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container11, locale12);
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container11, locale14, "hi!");
        org.apache.commons.jxpath.ri.QName qName18 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator19 = jDOMNodePointer16.attributeIterator(qName18);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference20 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName18);
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName18);
        java.lang.Object obj22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer24 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj22, locale23);
        java.lang.String str25 = collectionPointer24.asPath();
        int int26 = collectionPointer24.getLength();
        int int27 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer24);
        boolean boolean29 = variablePointer21.equals((java.lang.Object) 68);
        variablePointer21.setIndex(12);
        variablePointer21.setIndex((-2147483648));
        org.apache.commons.jxpath.ri.EvalContext evalContext34 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest35 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext38 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext34, nodeTest35, false, false);
        childContext38.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest40 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext41 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext38, nodeTest40);
        org.apache.commons.jxpath.ri.QName qName42 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName42, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext41, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.QName qName46 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest48 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName46, "");
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext49 = new org.apache.commons.jxpath.ri.axes.NamespaceContext((org.apache.commons.jxpath.ri.EvalContext) selfContext45, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer51 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator52 = variablePointer21.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48, false, nodePointer51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(nodeIterator19);
        org.junit.Assert.assertEquals("'" + str25 + "' != '" + "/" + "'", str25, "/");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0305");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory3 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer6 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale5);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer7 = jDOMNodePointer6.getImmediateParentPointer();
        java.lang.Object obj8 = jDOMNodePointer6.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver9 = jDOMNodePointer6.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext10 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer6);
        org.apache.commons.jxpath.ri.parser.Token token11 = null;
        int[] intArray13 = new int[] { 10 };
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[][] intArray18 = new int[][] { intArray13, intArray15, intArray17 };
        java.lang.String[] strArray23 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException24 = new org.apache.commons.jxpath.ri.parser.ParseException(token11, intArray18, strArray23);
        org.apache.commons.jxpath.JXPathContext jXPathContext25 = jXPathContextFactory3.newContext(jXPathContext10, (java.lang.Object) token11);
        java.lang.Object obj26 = jXPathContext25.getContextBean();
        org.apache.commons.jxpath.Variables variables27 = jXPathContext25.getVariables();
        org.w3c.dom.Node node28 = null;
        java.util.Locale locale29 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node28, locale29, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = dOMNodePointer31.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer36 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container34, locale35);
        java.util.Locale locale37 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer39 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container34, locale37, "hi!");
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer39.attributeIterator(qName41);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo44 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer45 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer33, qName41, (java.lang.Object) "id('')", jXPathBeanInfo44);
        boolean boolean46 = beanPointer45.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer47 = beanPointer45.getPropertyPointer();
        try {
            java.lang.Object obj48 = treeCompiler0.multiply((java.lang.Object) jXPathContext25, (java.lang.Object) propertyPointer47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.JXPathContextReferenceImpl cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(jXPathContextFactory3);
        org.junit.Assert.assertNull(nodePointer7);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNull(namespaceResolver9);
        org.junit.Assert.assertNotNull(jXPathContext10);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray13), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jXPathContext25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(variables27);
        org.junit.Assert.assertNotNull(nodePointer33);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(propertyPointer47);
    }

    @Test
    public void test0327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0327");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.isContextDependent();
        boolean boolean11 = variableReference9.computeContextDependent();
        java.lang.String str12 = variableReference9.toString();
        org.apache.commons.jxpath.ri.EvalContext evalContext13 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest14 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext17 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext13, nodeTest14, false, false);
        childContext17.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest19 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext20 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext17, nodeTest19);
        org.apache.commons.jxpath.NodeSet nodeSet21 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext22 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext17, nodeSet21);
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator27 = jDOMNodePointer25.namespaceIterator();
        java.lang.Object obj28 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext33 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext29, nodeTest30, false, false);
        childContext33.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest35 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext36 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext33, nodeTest35);
        org.apache.commons.jxpath.ri.QName qName37 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest39 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName37, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext40 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext36, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest39);
        org.apache.commons.jxpath.ri.QName qName41 = nodeNameTest39.getNodeName();
        boolean boolean42 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer25, obj28, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest39);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext43 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext22, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest39);
        boolean boolean44 = nodeSetContext22.nextSet();
        org.apache.commons.jxpath.NodeSet nodeSet45 = nodeSetContext22.getNodeSet();
        org.apache.commons.jxpath.Pointer pointer46 = nodeSetContext22.getSingleNodePointer();
        boolean boolean47 = nodeSetContext22.nextSet();
        try {
            java.util.Iterator iterator48 = variableReference9.iterate((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertEquals("'" + str12 + "' != '" + "$" + "'", str12, "$");
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNotNull(nodeIterator27);
        org.junit.Assert.assertNull(qName41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(nodeSet45);
        org.junit.Assert.assertNull(pointer46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.Variables variables23 = jXPathContext7.getVariables();
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        boolean boolean35 = variableReference34.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray36 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion37 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray36);
        java.lang.String str38 = coreOperationUnion37.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest39 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference34, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion37);
        boolean boolean40 = coreOperationUnion37.computeContextDependent();
        try {
            jXPathContext7.setValue("org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \" \" (32), after : \"\"", (java.lang.Object) coreOperationUnion37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidSyntaxException; message: Invalid XPath: 'org.apache.commons.jxpath.ri.parser.TokenMgrError: Lexical error at line 10, column 42.  Encountered: \\\" \\\" (32), after : \\\"\\\"'. Syntax error after: 'org.apache.commons.jxpath.ri.parser.TokenMgrError: L'");
        } catch (org.apache.commons.jxpath.JXPathInvalidSyntaxException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(variables23);
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(expressionArray36);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "|" + "'", str38, "|");
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test0344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0344");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        org.apache.commons.jxpath.Variables variables23 = jXPathContext7.getVariables();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale26);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer28 = jDOMNodePointer27.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver29 = jDOMNodePointer27.getNamespaceResolver();
        int int30 = jDOMNodePointer27.index;
        java.util.Locale locale31 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer32 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int30, locale31);
        org.apache.commons.jxpath.Container container33 = null;
        java.util.Locale locale34 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer35 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container33, locale34);
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer38 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container33, locale36, "hi!");
        org.apache.commons.jxpath.ri.QName qName40 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator41 = jDOMNodePointer38.attributeIterator(qName40);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference42 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName40);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = containerPointerFactory24.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer32, qName40, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer45 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName40);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference46 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName40);
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer47 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables23, qName40);
        try {
            boolean boolean48 = variablePointer47.isLeaf();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No such variable: ''");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(variables23);
        org.junit.Assert.assertNull(nodePointer28);
        org.junit.Assert.assertNull(namespaceResolver29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-2147483648) + "'", int30 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator41);
        org.junit.Assert.assertNull(nodePointer44);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        java.lang.Object obj3 = jDOMNodePointer2.getValue();
        org.apache.commons.jxpath.ri.QName qName4 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler6 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer7 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer2, qName4, (java.lang.Object) 1.0d, dynamicPropertyHandler6);
        org.apache.commons.jxpath.ri.QName qName8 = dynamicPointer7.getName();
        boolean boolean9 = dynamicPointer7.isLeaf();
        org.apache.commons.jxpath.Container container10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer12 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container10, locale11);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container10, locale13, "hi!");
        org.apache.commons.jxpath.ri.QName qName17 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator18 = jDOMNodePointer15.attributeIterator(qName17);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference19 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName17);
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = dynamicPointer7.attributeIterator(qName17);
        dynamicPointer7.setIndex(41);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer23 = dynamicPointer7.getPropertyPointer();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory24 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale26);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer28 = jDOMNodePointer27.getImmediateParentPointer();
        java.lang.Object obj29 = jDOMNodePointer27.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver30 = jDOMNodePointer27.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext31 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer27);
        org.apache.commons.jxpath.ri.parser.Token token32 = null;
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[] intArray38 = new int[] { 10 };
        int[][] intArray39 = new int[][] { intArray34, intArray36, intArray38 };
        java.lang.String[] strArray44 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException45 = new org.apache.commons.jxpath.ri.parser.ParseException(token32, intArray39, strArray44);
        org.apache.commons.jxpath.JXPathContext jXPathContext46 = jXPathContextFactory24.newContext(jXPathContext31, (java.lang.Object) token32);
        org.apache.commons.jxpath.Variables variables47 = jXPathContext31.getVariables();
        org.apache.commons.jxpath.Functions functions48 = jXPathContext31.getFunctions();
        java.util.Iterator iterator50 = jXPathContext31.iteratePointers("UNKNOWN");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer51 = propertyPointer23.createPath(jXPathContext31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(qName8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(nodeIterator18);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(propertyPointer23);
        org.junit.Assert.assertNotNull(jXPathContextFactory24);
        org.junit.Assert.assertNull(nodePointer28);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNull(namespaceResolver30);
        org.junit.Assert.assertNotNull(jXPathContext31);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray38), "[10]");
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jXPathContext46);
        org.junit.Assert.assertNotNull(variables47);
        org.junit.Assert.assertNotNull(functions48);
        org.junit.Assert.assertNotNull(iterator50);
    }

    @Test
    public void test0366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0366");
        org.apache.commons.jxpath.Variables variables0 = null;
        org.apache.commons.jxpath.ri.QName qName1 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer2 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables0, qName1);
        boolean boolean3 = variablePointer2.isRoot();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer6 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer2, "hi!", "");
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer14 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer9, "preceding");
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale16);
        boolean boolean19 = jDOMNodePointer17.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName21 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator22 = jDOMNodePointer17.attributeIterator(qName21);
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer23 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName21);
        int int24 = variablePointer2.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer14, (org.apache.commons.jxpath.ri.model.NodePointer) variablePointer23);
        org.apache.commons.jxpath.ri.QName qName25 = null;
        org.apache.commons.jxpath.ri.parser.Token token26 = null;
        int[] intArray28 = new int[] { 10 };
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[][] intArray33 = new int[][] { intArray28, intArray30, intArray32 };
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException39 = new org.apache.commons.jxpath.ri.parser.ParseException(token26, intArray33, strArray38);
        org.apache.commons.jxpath.JXPathContextFactoryConfigurationError jXPathContextFactoryConfigurationError41 = new org.apache.commons.jxpath.JXPathContextFactoryConfigurationError((java.lang.Exception) parseException39, "hi!");
        java.lang.Exception exception42 = jXPathContextFactoryConfigurationError41.getException();
        java.lang.Exception exception43 = jXPathContextFactoryConfigurationError41.getException();
        java.util.Locale locale44 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = org.apache.commons.jxpath.ri.model.NodePointer.newNodePointer(qName25, (java.lang.Object) exception43, locale44);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer48 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer45, "http://www.w3.org/2000/xmlns/", "/null");
        java.lang.Object obj49 = nodePointer45.getNode();
        org.apache.commons.jxpath.ri.QName qName51 = new org.apache.commons.jxpath.ri.QName("/");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator52 = nodePointer45.attributeIterator(qName51);
        try {
            variablePointer2.setValue((java.lang.Object) nodeIterator52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(nodeIterator22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(exception42);
        org.junit.Assert.assertNotNull(exception43);
        org.junit.Assert.assertNotNull(nodePointer45);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertNotNull(nodeIterator52);
    }

    @Test
    public void test0416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0416");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.literal("/");
        java.lang.Object obj4 = treeCompiler0.literal("<<unknown namespace>>");
        java.lang.Object obj6 = treeCompiler0.literal("$");
        org.apache.commons.jxpath.ri.EvalContext evalContext7 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest8 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext11 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext7, nodeTest8, false, false);
        childContext11.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest13 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext14 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext11, nodeTest13);
        org.apache.commons.jxpath.ri.QName qName15 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest17 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName15, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext18 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext14, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest17);
        org.apache.commons.jxpath.ri.QName qName19 = nodeNameTest17.getNodeName();
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory20 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = jDOMNodePointer23.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver25 = jDOMNodePointer23.getNamespaceResolver();
        int int26 = jDOMNodePointer23.index;
        java.util.Locale locale27 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer28 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int26, locale27);
        org.apache.commons.jxpath.Container container29 = null;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer31 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container29, locale30);
        java.util.Locale locale32 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer34 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container29, locale32, "hi!");
        org.apache.commons.jxpath.ri.QName qName36 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator37 = jDOMNodePointer34.attributeIterator(qName36);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference38 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName36);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer40 = containerPointerFactory20.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer28, qName36, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer41 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName36);
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer42 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer41);
        try {
            java.lang.Object obj43 = treeCompiler0.greaterThan((java.lang.Object) qName19, (java.lang.Object) variablePointer41);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.model.VariablePointer cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertEquals(obj2.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj2), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj2), "'/'");
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertEquals(obj4.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj4), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals(obj6.toString(), "'$'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj6), "'$'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj6), "'$'");
        org.junit.Assert.assertNull(qName19);
        org.junit.Assert.assertNull(nodePointer24);
        org.junit.Assert.assertNull(namespaceResolver25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-2147483648) + "'", int26 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator37);
        org.junit.Assert.assertNull(nodePointer40);
    }

    @Test
    public void test0429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0429");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory beanPointerFactory1 = new org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory();
        org.w3c.dom.Node node2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer5 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node2, locale3, "");
        java.lang.Object obj6 = dOMNodePointer5.getNodeValue();
        boolean boolean7 = dOMNodePointer5.isCollection();
        org.apache.commons.jxpath.Container container8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer10 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container8, locale9);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container8, locale11, "hi!");
        org.apache.commons.jxpath.ri.QName qName15 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer13.attributeIterator(qName15);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference17 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName15);
        org.w3c.dom.Node node18 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory19 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer22 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale21);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer23 = jDOMNodePointer22.getImmediateParentPointer();
        java.lang.Object obj24 = jDOMNodePointer22.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver25 = jDOMNodePointer22.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer22);
        org.apache.commons.jxpath.ri.parser.Token token27 = null;
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[] intArray33 = new int[] { 10 };
        int[][] intArray34 = new int[][] { intArray29, intArray31, intArray33 };
        java.lang.String[] strArray39 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException40 = new org.apache.commons.jxpath.ri.parser.ParseException(token27, intArray34, strArray39);
        org.apache.commons.jxpath.JXPathContext jXPathContext41 = jXPathContextFactory19.newContext(jXPathContext26, (java.lang.Object) token27);
        java.util.Locale locale42 = jXPathContext41.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer44 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale42, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer45 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node18, locale42);
        java.lang.String str46 = dOMNodePointer45.getDefaultNamespaceURI();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = beanPointerFactory1.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer5, qName15, (java.lang.Object) str46);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest48 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName15);
        try {
            boolean boolean49 = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.testNode(node0, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNotNull(jXPathContextFactory19);
        org.junit.Assert.assertNull(nodePointer23);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertNull(namespaceResolver25);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jXPathContext41);
        org.junit.Assert.assertNotNull(locale42);
        org.junit.Assert.assertEquals(locale42.toString(), "en_GB");
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(nodePointer47);
    }

    @Test
    public void test0436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0436");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        java.lang.Object obj2 = nullPropertyPointer1.getBaseValue();
        nullPropertyPointer1.setPropertyIndex(55);
        boolean boolean5 = nullPropertyPointer1.isContainer();
        org.apache.commons.jxpath.ri.EvalContext evalContext6 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest7 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext10 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext6, nodeTest7, false, false);
        childContext10.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest12 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext13 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext10, nodeTest12);
        org.apache.commons.jxpath.NodeSet nodeSet14 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext15 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext10, nodeSet14);
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer18.namespaceIterator();
        java.lang.Object obj21 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext22 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest23 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext26 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext22, nodeTest23, false, false);
        childContext26.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest28 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext29 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext26, nodeTest28);
        org.apache.commons.jxpath.ri.QName qName30 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest32 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName30, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext33 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext29, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest32);
        org.apache.commons.jxpath.ri.QName qName34 = nodeNameTest32.getNodeName();
        boolean boolean35 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer18, obj21, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest32);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext36 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest32);
        org.apache.commons.jxpath.ri.EvalContext evalContext37 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest38 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext41 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext37, nodeTest38, false, false);
        childContext41.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest43 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext44 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext41, nodeTest43);
        org.apache.commons.jxpath.ri.QName qName45 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest47 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName45, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext48 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext44, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest47);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext49 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext36, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest47);
        boolean boolean50 = nullPropertyPointer1.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest47);
        int int51 = nullPropertyPointer1.getPropertyCount();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNull(qName34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test0473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0473");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean53 = ancestorContext51.setPosition(68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler1 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj3 = treeCompiler1.literal("/");
        java.lang.Object obj5 = treeCompiler1.literal("<<unknown namespace>>");
        java.lang.Object obj7 = treeCompiler1.literal("$");
        java.lang.Object obj8 = org.apache.commons.jxpath.ri.Parser.parseExpression("/*", (org.apache.commons.jxpath.ri.Compiler) treeCompiler1);
        org.w3c.dom.Node node9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer12 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale10, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = dOMNodePointer12.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container15 = null;
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer17 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container15, locale16);
        java.util.Locale locale18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer20 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container15, locale18, "hi!");
        org.apache.commons.jxpath.ri.QName qName22 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator23 = jDOMNodePointer20.attributeIterator(qName22);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo25 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer26 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer14, qName22, (java.lang.Object) "id('')", jXPathBeanInfo25);
        boolean boolean27 = beanPointer26.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer28 = beanPointer26.getPropertyPointer();
        boolean boolean30 = beanPointer26.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.ri.parser.Token token31 = null;
        int[] intArray33 = new int[] { 10 };
        int[] intArray35 = new int[] { 10 };
        int[] intArray37 = new int[] { 10 };
        int[][] intArray38 = new int[][] { intArray33, intArray35, intArray37 };
        java.lang.String[] strArray43 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException44 = new org.apache.commons.jxpath.ri.parser.ParseException(token31, intArray38, strArray43);
        org.apache.commons.jxpath.ri.parser.Token token45 = parseException44.currentToken;
        java.lang.String[] strArray46 = parseException44.tokenImage;
        try {
            java.lang.Object obj47 = treeCompiler1.notEqual((java.lang.Object) 10.0f, (java.lang.Object) strArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj3), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj3), "'/'");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertEquals(obj5.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertEquals(obj7.toString(), "'$'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj7), "'$'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj7), "'$'");
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals(obj8.toString(), "/*");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj8), "/*");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj8), "/*");
        org.junit.Assert.assertNotNull(nodePointer14);
        org.junit.Assert.assertNotNull(nodeIterator23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(propertyPointer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray33), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray35), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray37), "[10]");
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(strArray43);
        org.junit.Assert.assertNull(token45);
        org.junit.Assert.assertNotNull(strArray46);
    }

    @Test
    public void test0517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0517");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        collectionPointer7.setIndex(42);
        int int10 = collectionPointer7.getLength();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = collectionPointer7.namespacePointer("/");
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer15.getNamespaceResolver();
        int int18 = jDOMNodePointer15.index;
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer20 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int18, locale19);
        org.w3c.dom.Node node21 = null;
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer24 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale22, "");
        java.util.Locale locale25 = dOMNodePointer24.locale;
        java.lang.Object obj26 = dOMNodePointer24.getRootNode();
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer29 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale28);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer30 = jDOMNodePointer29.getImmediateParentPointer();
        java.lang.Object obj31 = jDOMNodePointer29.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver32 = jDOMNodePointer29.getNamespaceResolver();
        int int33 = collectionPointer20.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer24, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer34 = collectionPointer20.getValuePointer();
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale36);
        boolean boolean39 = jDOMNodePointer37.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer37.attributeIterator(qName41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "hi!");
        java.lang.String str45 = nodeNameTest44.getNamespaceURI();
        boolean boolean46 = collectionPointer20.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        boolean boolean47 = collectionPointer7.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        try {
            boolean boolean49 = collectionPointer7.isLanguage("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(nodePointer12);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2147483648) + "'", int18 == (-2147483648));
        org.junit.Assert.assertNull(locale25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(nodePointer30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNull(namespaceResolver32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodePointer34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test0518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0518");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean52 = ancestorContext51.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0542");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        java.util.Locale locale23 = jXPathContext22.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer25 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "");
        boolean boolean26 = nullPointer25.isLeaf();
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = null;
        org.w3c.dom.Node node28 = null;
        java.util.Locale locale29 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node28, locale29, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = dOMNodePointer31.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container34 = null;
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer36 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container34, locale35);
        java.util.Locale locale37 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer39 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container34, locale37, "hi!");
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer39.attributeIterator(qName41);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo44 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer45 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer33, qName41, (java.lang.Object) "id('')", jXPathBeanInfo44);
        org.apache.commons.jxpath.JXPathContext jXPathContext46 = org.apache.commons.jxpath.JXPathContext.newContext(jXPathContext27, (java.lang.Object) "id('')");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer47 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer47);
        org.apache.commons.jxpath.ri.QName qName49 = nullPropertyPointer48.getName();
        nullPropertyPointer48.setPropertyName("http://www.w3.org/2000/xmlns/");
        org.apache.commons.jxpath.ri.QName qName52 = nullPropertyPointer48.getName();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer54 = nullPointer25.createChild(jXPathContext46, qName52, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot create the root object: id()");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertEquals(locale23.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(nodePointer33);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertNotNull(jXPathContext46);
        org.junit.Assert.assertNotNull(qName49);
        org.junit.Assert.assertNotNull(qName52);
    }

    @Test
    public void test0598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0598");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean53 = nodeSetContext9.setPosition((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0650");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer21 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName16);
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer22 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer21);
        org.apache.commons.jxpath.ri.QName qName23 = nullPropertyPointer22.getName();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = nullPropertyPointer22.getValuePointer();
        org.apache.commons.jxpath.Container container25 = null;
        java.util.Locale locale26 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer27 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container25, locale26);
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer30 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container25, locale28, "hi!");
        org.apache.commons.jxpath.ri.QName qName32 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator33 = jDOMNodePointer30.attributeIterator(qName32);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference34 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName32);
        boolean boolean35 = variableReference34.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray36 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion37 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray36);
        java.lang.String str38 = coreOperationUnion37.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest39 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference34, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion37);
        try {
            nodePointer24.setValue((java.lang.Object) coreOperationUnion37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidAccessException; message: Cannot set property $, the target object is null");
        } catch (org.apache.commons.jxpath.JXPathInvalidAccessException e) {
        }
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertNotNull(qName23);
        org.junit.Assert.assertNotNull(nodePointer24);
        org.junit.Assert.assertNotNull(nodeIterator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(expressionArray36);
        org.junit.Assert.assertEquals("'" + str38 + "' != '" + "|" + "'", str38, "|");
    }

    @Test
    public void test0660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0660");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer7 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer3, container6);
        java.lang.String str8 = dOMNodePointer3.asPath();
        java.lang.String str9 = dOMNodePointer3.getDefaultNamespaceURI();
        org.w3c.dom.Node node10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer13 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node10, locale11, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = dOMNodePointer13.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container16 = null;
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer18 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container16, locale17);
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer21 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container16, locale19, "hi!");
        org.apache.commons.jxpath.ri.QName qName23 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator24 = jDOMNodePointer21.attributeIterator(qName23);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo26 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer27 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer15, qName23, (java.lang.Object) "id('')", jXPathBeanInfo26);
        boolean boolean28 = beanPointer27.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer29 = beanPointer27.getPropertyPointer();
        boolean boolean31 = beanPointer27.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container32 = null;
        java.util.Locale locale33 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer34 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container32, locale33);
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container32, locale35, "hi!");
        org.apache.commons.jxpath.ri.QName qName39 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator40 = jDOMNodePointer37.attributeIterator(qName39);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference41 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName39);
        boolean boolean42 = variableReference41.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray43 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion44 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray43);
        java.lang.String str45 = coreOperationUnion44.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest46 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference41, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion44);
        boolean boolean47 = nameAttributeTest46.computeContextDependent();
        boolean boolean48 = beanPointer27.equals((java.lang.Object) boolean47);
        try {
            dOMNodePointer3.setValue((java.lang.Object) beanPointer27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertEquals("'" + str8 + "' != '" + "id('')" + "'", str8, "id('')");
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(nodePointer15);
        org.junit.Assert.assertNotNull(nodeIterator24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(propertyPointer29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(nodeIterator40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(expressionArray43);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "|" + "'", str45, "|");
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0681");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        java.lang.Object obj52 = nodeSetContext9.getValue();
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
        org.junit.Assert.assertNull(obj52);
    }

    @Test
    public void test0710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0710");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference9 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName7);
        boolean boolean10 = variableReference9.computeContextDependent();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray11 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion12 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray11);
        java.lang.String str13 = coreOperationUnion12.getSymbol();
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest14 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) variableReference9, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationUnion12);
        java.lang.String str15 = coreOperationUnion12.getSymbol();
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.NodeSet nodeSet28 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext29 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, nodeSet28);
        org.apache.commons.jxpath.ri.QName qName30 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest32 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName30, "");
        org.apache.commons.jxpath.ri.QName qName33 = nodeNameTest32.getNodeName();
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext34 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest32);
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale36);
        boolean boolean39 = jDOMNodePointer37.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer37.attributeIterator(qName41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "hi!");
        java.lang.String str45 = nodeNameTest44.getNamespaceURI();
        org.apache.commons.jxpath.ri.axes.ChildContext childContext48 = new org.apache.commons.jxpath.ri.axes.ChildContext((org.apache.commons.jxpath.ri.EvalContext) selfContext34, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44, false, false);
        try {
            java.lang.Object obj49 = coreOperationUnion12.compute((org.apache.commons.jxpath.ri.EvalContext) childContext48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(expressionArray11);
        org.junit.Assert.assertEquals("'" + str13 + "' != '" + "|" + "'", str13, "|");
        org.junit.Assert.assertEquals("'" + str15 + "' != '" + "|" + "'", str15, "|");
        org.junit.Assert.assertNull(qName33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
    }

    @Test
    public void test0715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0715");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext52 = nodeSetContext9.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0717");
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray0 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion1 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray0);
        org.apache.commons.jxpath.ri.EvalContext evalContext2 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest3 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext6 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext2, nodeTest3, false, false);
        childContext6.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest8 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext9 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext6, nodeTest8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext11 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext6, nodeSet10);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale13);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = jDOMNodePointer14.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator16 = jDOMNodePointer14.namespaceIterator();
        java.lang.Object obj17 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext18 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest19 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext22 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext18, nodeTest19, false, false);
        childContext22.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest24 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext25 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext22, nodeTest24);
        org.apache.commons.jxpath.ri.QName qName26 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest28 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName26, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext29 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext25, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.QName qName30 = nodeNameTest28.getNodeName();
        boolean boolean31 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer14, obj17, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext32 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext11, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest28);
        org.apache.commons.jxpath.ri.EvalContext evalContext33 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest34 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext37 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext33, nodeTest34, false, false);
        childContext37.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest39 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext40 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext37, nodeTest39);
        org.apache.commons.jxpath.ri.QName qName41 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest43 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext44 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext40, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest43);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext45 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext32, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest43);
        try {
            java.lang.Object obj46 = coreOperationUnion1.compute((org.apache.commons.jxpath.ri.EvalContext) selfContext45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(expressionArray0);
        org.junit.Assert.assertNull(nodePointer15);
        org.junit.Assert.assertNotNull(nodeIterator16);
        org.junit.Assert.assertNull(qName30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test0732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0732");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest10 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName8, "");
        org.apache.commons.jxpath.ri.QName qName11 = nodeNameTest10.getNodeName();
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext12 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest10);
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer15.getNamespaceResolver();
        int int18 = jDOMNodePointer15.index;
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer20 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int18, locale19);
        org.w3c.dom.Node node21 = null;
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer24 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale22, "");
        java.util.Locale locale25 = dOMNodePointer24.locale;
        java.lang.Object obj26 = dOMNodePointer24.getRootNode();
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer29 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale28);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer30 = jDOMNodePointer29.getImmediateParentPointer();
        java.lang.Object obj31 = jDOMNodePointer29.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver32 = jDOMNodePointer29.getNamespaceResolver();
        int int33 = collectionPointer20.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer24, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer34 = collectionPointer20.getValuePointer();
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale36);
        boolean boolean39 = jDOMNodePointer37.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer37.attributeIterator(qName41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "hi!");
        java.lang.String str45 = nodeNameTest44.getNamespaceURI();
        boolean boolean46 = collectionPointer20.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext47 = new org.apache.commons.jxpath.ri.axes.ParentContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext12, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        try {
            boolean boolean48 = parentContext47.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(qName11);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2147483648) + "'", int18 == (-2147483648));
        org.junit.Assert.assertNull(locale25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(nodePointer30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNull(namespaceResolver32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodePointer34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test0737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0737");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean52 = ancestorContext51.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0743");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean52 = ancestorContext51.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test0751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0751");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        java.util.Locale locale23 = jXPathContext22.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer25 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "preceding");
        java.lang.String str26 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.getLocalName((java.lang.Object) locale23);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer28 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "http://www.w3.org/2000/xmlns/");
        boolean boolean29 = nullPointer28.isCollection();
        java.util.Locale locale31 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale31);
        boolean boolean34 = jDOMNodePointer32.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName36 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator37 = jDOMNodePointer32.attributeIterator(qName36);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest39 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName36, "hi!");
        java.util.Locale locale42 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer43 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale42);
        boolean boolean45 = jDOMNodePointer43.equals((java.lang.Object) (byte) 0);
        java.lang.String str46 = jDOMNodePointer43.asPath();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer48 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer43, "");
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator49 = nullPointer28.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest39, true, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: PropertyIerator startWith parameter is not a child of the supplied parent");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertEquals(locale23.toString(), "en_GB");
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(nodeIterator37);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "" + "'", str46, "");
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer50 = beanPointer49.getPropertyPointer();
        org.apache.commons.jxpath.ri.QName qName51 = beanPointer49.getName();
        try {
            beanPointer49.setValue((java.lang.Object) "descendant-or-self");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot setValue of an object that is not some other object's property");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(propertyPointer50);
        org.junit.Assert.assertNotNull(qName51);
    }

    @Test
    public void test0818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0818");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver4 = jDOMNodePointer2.getNamespaceResolver();
        int int5 = jDOMNodePointer2.index;
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int5, locale6);
        org.w3c.dom.Node node8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer11 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale9, "");
        java.util.Locale locale12 = dOMNodePointer11.locale;
        java.lang.Object obj13 = dOMNodePointer11.getRootNode();
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer16 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = jDOMNodePointer16.getImmediateParentPointer();
        java.lang.Object obj18 = jDOMNodePointer16.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer16.getNamespaceResolver();
        int int20 = collectionPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer11, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer16);
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = jDOMNodePointer23.getImmediateParentPointer();
        java.lang.Object obj25 = jDOMNodePointer23.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver26 = jDOMNodePointer23.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer23);
        java.lang.String str29 = jXPathContext27.getPrefix("http://www.w3.org/2000/xmlns/");
        java.util.Locale locale30 = jXPathContext27.getLocale();
        org.apache.commons.jxpath.Functions functions31 = jXPathContext27.getFunctions();
        boolean boolean32 = jXPathContext27.isLenient();
        java.util.Locale locale34 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer35 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale34);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = jDOMNodePointer35.getImmediateParentPointer();
        java.lang.String str37 = jDOMNodePointer35.asPath();
        java.util.Locale locale38 = jDOMNodePointer35.locale;
        java.lang.String str39 = jDOMNodePointer35.asPath();
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer40 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer35);
        org.apache.commons.jxpath.ri.QName qName41 = jDOMNodePointer35.getName();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer43 = collectionPointer7.createChild(jXPathContext27, qName41, 55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn java.lang.Integer into a collection of size 56");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNull(namespaceResolver4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-2147483648) + "'", int5 == (-2147483648));
        org.junit.Assert.assertNull(locale12);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(nodePointer17);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(nodePointer24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(namespaceResolver26);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_GB");
        org.junit.Assert.assertNotNull(functions31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(nodePointer36);
        org.junit.Assert.assertEquals("'" + str37 + "' != '" + "" + "'", str37, "");
        org.junit.Assert.assertNull(locale38);
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
        org.junit.Assert.assertNotNull(qName41);
    }

    @Test
    public void test0961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0961");
        org.apache.commons.jxpath.Variables variables0 = null;
        org.apache.commons.jxpath.ri.QName qName1 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer2 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables0, qName1);
        boolean boolean3 = variablePointer2.isRoot();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer6 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer2, "hi!", "");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory7 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        java.lang.Object obj12 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver13 = jDOMNodePointer10.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext14 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer10);
        org.apache.commons.jxpath.ri.parser.Token token15 = null;
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[][] intArray22 = new int[][] { intArray17, intArray19, intArray21 };
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException28 = new org.apache.commons.jxpath.ri.parser.ParseException(token15, intArray22, strArray27);
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = jXPathContextFactory7.newContext(jXPathContext14, (java.lang.Object) token15);
        java.lang.Object obj30 = jXPathContext29.getContextBean();
        org.w3c.dom.Node node31 = null;
        java.util.Locale locale32 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer34 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node31, locale32, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = dOMNodePointer34.namespacePointer("preceding");
        java.lang.Object obj37 = dOMNodePointer34.clone();
        jXPathContext29.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) dOMNodePointer34);
        org.w3c.dom.Node node39 = null;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer42 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node39, locale40, "");
        java.util.Locale locale43 = dOMNodePointer42.locale;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = dOMNodePointer42.namespacePointer("");
        int int46 = nodePointer45.getIndex();
        jXPathContext29.setNamespaceContextPointer((org.apache.commons.jxpath.Pointer) nodePointer45);
        org.apache.commons.jxpath.Pointer pointer48 = jXPathContext29.getNamespaceContextPointer();
        org.apache.commons.jxpath.AbstractFactory abstractFactory49 = null;
        jXPathContext29.setFactory(abstractFactory49);
        try {
            variablePointer2.findVariables(jXPathContext29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(jXPathContextFactory7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(namespaceResolver13);
        org.junit.Assert.assertNotNull(jXPathContext14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(nodePointer36);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertEquals(obj37.toString(), "id('')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj37), "id('')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj37), "id('')");
        org.junit.Assert.assertNull(locale43);
        org.junit.Assert.assertNotNull(nodePointer45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-2147483648) + "'", int46 == (-2147483648));
        org.junit.Assert.assertNotNull(pointer48);
    }

    @Test
    public void test0989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0989");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver5 = jDOMNodePointer3.getNamespaceResolver();
        int int6 = jDOMNodePointer3.index;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int6, locale7);
        org.apache.commons.jxpath.Container container9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer11 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container9, locale10);
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container9, locale12, "hi!");
        org.apache.commons.jxpath.ri.QName qName16 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator17 = jDOMNodePointer14.attributeIterator(qName16);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference18 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer20 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, qName16, (java.lang.Object) "");
        java.lang.Object obj21 = collectionPointer8.getBaseValue();
        boolean boolean22 = collectionPointer8.isContainer();
        java.lang.Object obj23 = collectionPointer8.getNode();
        org.apache.commons.jxpath.ri.EvalContext evalContext24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest25 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext28 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext24, nodeTest25, false, false);
        childContext28.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext31 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext28, nodeTest30);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext precedingOrFollowingContext34 = new org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext((org.apache.commons.jxpath.ri.EvalContext) selfContext31, nodeTest32, false);
        precedingOrFollowingContext34.reset();
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator36 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) precedingOrFollowingContext34);
        int int37 = precedingOrFollowingContext34.getDocumentOrder();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer38 = precedingOrFollowingContext34.getCurrentNodePointer();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer39 = precedingOrFollowingContext34.getCurrentNodePointer();
        precedingOrFollowingContext34.reset();
        java.lang.Object obj41 = org.apache.commons.jxpath.util.ValueUtils.getValue((java.lang.Object) precedingOrFollowingContext34);
        boolean boolean42 = collectionPointer8.equals(obj41);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(namespaceResolver5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-2147483648) + "'", int6 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator17);
        org.junit.Assert.assertNull(nodePointer20);
        org.junit.Assert.assertEquals("'" + obj21 + "' != '" + (-2147483648) + "'", obj21, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertEquals("'" + obj23 + "' != '" + (-2147483648) + "'", obj23, (-2147483648));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNull(nodePointer38);
        org.junit.Assert.assertNull(nodePointer39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertEquals(obj41.toString(), "Empty expression context");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj41), "Empty expression context");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj41), "Empty expression context");
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean53 = nodeSetContext9.setPosition(900);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test1076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1076");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        org.apache.commons.jxpath.NodeSet nodeSet10 = nodeSetContext9.getNodeSet();
        org.apache.commons.jxpath.Container container12 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer14 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container12, locale13);
        java.util.Locale locale15 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container12, locale15, "hi!");
        org.apache.commons.jxpath.ri.QName qName19 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator20 = jDOMNodePointer17.attributeIterator(qName19);
        org.w3c.dom.Node node21 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory22 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer25 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale24);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer26 = jDOMNodePointer25.getImmediateParentPointer();
        java.lang.Object obj27 = jDOMNodePointer25.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver28 = jDOMNodePointer25.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer25);
        org.apache.commons.jxpath.ri.parser.Token token30 = null;
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[] intArray36 = new int[] { 10 };
        int[][] intArray37 = new int[][] { intArray32, intArray34, intArray36 };
        java.lang.String[] strArray42 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException43 = new org.apache.commons.jxpath.ri.parser.ParseException(token30, intArray37, strArray42);
        org.apache.commons.jxpath.JXPathContext jXPathContext44 = jXPathContextFactory22.newContext(jXPathContext29, (java.lang.Object) token30);
        java.util.Locale locale45 = jXPathContext44.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer46 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale45);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer48 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale45, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer49 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName19, locale45);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest50 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName19);
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext51 = new org.apache.commons.jxpath.ri.axes.AncestorContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, false, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest50);
        try {
            boolean boolean53 = nodeSetContext9.setPosition(52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodeSet10);
        org.junit.Assert.assertNotNull(nodeIterator20);
        org.junit.Assert.assertNotNull(jXPathContextFactory22);
        org.junit.Assert.assertNull(nodePointer26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNull(namespaceResolver28);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[10]");
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jXPathContext44);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertEquals(locale45.toString(), "en_GB");
    }

    @Test
    public void test1201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1201");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        java.lang.Object obj6 = dOMNodePointer3.clone();
        boolean boolean7 = dOMNodePointer3.isCollection();
        java.lang.String str9 = dOMNodePointer3.getNamespaceURI("http://www.w3.org/XML/1998/namespace");
        org.apache.commons.jxpath.Container container10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer12 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container10, locale11);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container10, locale13, "hi!");
        org.apache.commons.jxpath.ri.QName qName17 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator18 = jDOMNodePointer15.attributeIterator(qName17);
        org.w3c.dom.Node node19 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory20 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = jDOMNodePointer23.getImmediateParentPointer();
        java.lang.Object obj25 = jDOMNodePointer23.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver26 = jDOMNodePointer23.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer23);
        org.apache.commons.jxpath.ri.parser.Token token28 = null;
        int[] intArray30 = new int[] { 10 };
        int[] intArray32 = new int[] { 10 };
        int[] intArray34 = new int[] { 10 };
        int[][] intArray35 = new int[][] { intArray30, intArray32, intArray34 };
        java.lang.String[] strArray40 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException41 = new org.apache.commons.jxpath.ri.parser.ParseException(token28, intArray35, strArray40);
        org.apache.commons.jxpath.JXPathContext jXPathContext42 = jXPathContextFactory20.newContext(jXPathContext27, (java.lang.Object) token28);
        java.util.Locale locale43 = jXPathContext42.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer44 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node19, locale43);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer46 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale43, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer47 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName17, locale43);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest48 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer50 = null;
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator51 = dOMNodePointer3.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest48, false, nodePointer50);
        java.util.Locale locale52 = dOMNodePointer3.locale;
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertEquals(obj6.toString(), "id('')");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj6), "id('')");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj6), "id('')");
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(nodeIterator18);
        org.junit.Assert.assertNotNull(jXPathContextFactory20);
        org.junit.Assert.assertNull(nodePointer24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(namespaceResolver26);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[10]");
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray34), "[10]");
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jXPathContext42);
        org.junit.Assert.assertNotNull(locale43);
        org.junit.Assert.assertEquals(locale43.toString(), "en_GB");
        org.junit.Assert.assertNotNull(nodeIterator51);
        org.junit.Assert.assertNull(locale52);
    }

    @Test
    public void test1267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1267");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.NodeSet nodeSet8 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext9 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeSet8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer12.namespaceIterator();
        java.lang.Object obj15 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext16 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest17 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext20 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext16, nodeTest17, false, false);
        childContext20.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest22 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext23 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext20, nodeTest22);
        org.apache.commons.jxpath.ri.QName qName24 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest26 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName24, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext27 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext23, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.QName qName28 = nodeNameTest26.getNodeName();
        boolean boolean29 = org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer.testNode((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer12, obj15, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext30 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) nodeSetContext9, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest26);
        org.apache.commons.jxpath.ri.EvalContext evalContext31 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest32 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext35 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext31, nodeTest32, false, false);
        childContext35.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest37 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext38 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext35, nodeTest37);
        org.apache.commons.jxpath.ri.QName qName39 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest41 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName39, "");
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext42 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) selfContext38, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext43 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext30, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer44 = attributeContext30.getCurrentNodePointer();
        org.apache.commons.jxpath.Pointer pointer45 = attributeContext30.getContextNodePointer();
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext46 = attributeContext30.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertNull(qName28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(nodePointer44);
        org.junit.Assert.assertNull(pointer45);
    }

    @Test
    public void test1293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1293");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        java.lang.Object obj3 = jDOMNodePointer2.getValue();
        org.apache.commons.jxpath.ri.QName qName4 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler6 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer7 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer2, qName4, (java.lang.Object) 1.0d, dynamicPropertyHandler6);
        org.apache.commons.jxpath.ri.QName qName8 = dynamicPointer7.getName();
        boolean boolean9 = dynamicPointer7.isLeaf();
        boolean boolean10 = dynamicPointer7.isLeaf();
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = dynamicPointer7.attributeIterator(qName12);
        boolean boolean14 = dynamicPointer7.isLeaf();
        java.util.Locale locale15 = null;
        dynamicPointer7.locale = locale15;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory17 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer20 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale19);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer21 = jDOMNodePointer20.getImmediateParentPointer();
        java.lang.Object obj22 = jDOMNodePointer20.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver23 = jDOMNodePointer20.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext24 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer20);
        org.apache.commons.jxpath.ri.parser.Token token25 = null;
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[] intArray31 = new int[] { 10 };
        int[][] intArray32 = new int[][] { intArray27, intArray29, intArray31 };
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException38 = new org.apache.commons.jxpath.ri.parser.ParseException(token25, intArray32, strArray37);
        org.apache.commons.jxpath.JXPathContext jXPathContext39 = jXPathContextFactory17.newContext(jXPathContext24, (java.lang.Object) token25);
        org.apache.commons.jxpath.Variables variables40 = jXPathContext24.getVariables();
        org.apache.commons.jxpath.Functions functions41 = jXPathContext24.getFunctions();
        java.util.Iterator iterator43 = jXPathContext24.iteratePointers("UNKNOWN");
        java.lang.Object obj44 = jXPathContext24.getContextBean();
        java.lang.Object obj45 = jXPathContext24.getContextBean();
        try {
            org.apache.commons.jxpath.Pointer pointer48 = dynamicPointer7.getPointerByKey(jXPathContext24, "", "$ = ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot find an element by key - no KeyManager has been specified");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(qName8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jXPathContextFactory17);
        org.junit.Assert.assertNull(nodePointer21);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertNull(namespaceResolver23);
        org.junit.Assert.assertNotNull(jXPathContext24);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[10]");
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jXPathContext39);
        org.junit.Assert.assertNotNull(variables40);
        org.junit.Assert.assertNotNull(functions41);
        org.junit.Assert.assertNotNull(iterator43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertEquals(obj44.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj44), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj44), "");
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertEquals(obj45.toString(), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj45), "");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj45), "");
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        childContext4.reset();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.SelfContext selfContext7 = new org.apache.commons.jxpath.ri.axes.SelfContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, nodeTest6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest10 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName8, "");
        org.apache.commons.jxpath.ri.QName qName11 = nodeNameTest10.getNodeName();
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext12 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) selfContext7, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest10);
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer15.getNamespaceResolver();
        int int18 = jDOMNodePointer15.index;
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer20 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int18, locale19);
        org.w3c.dom.Node node21 = null;
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer24 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node21, locale22, "");
        java.util.Locale locale25 = dOMNodePointer24.locale;
        java.lang.Object obj26 = dOMNodePointer24.getRootNode();
        java.util.Locale locale28 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer29 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale28);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer30 = jDOMNodePointer29.getImmediateParentPointer();
        java.lang.Object obj31 = jDOMNodePointer29.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver32 = jDOMNodePointer29.getNamespaceResolver();
        int int33 = collectionPointer20.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer24, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer29);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer34 = collectionPointer20.getValuePointer();
        java.util.Locale locale36 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer37 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale36);
        boolean boolean39 = jDOMNodePointer37.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName41 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator42 = jDOMNodePointer37.attributeIterator(qName41);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest44 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName41, "hi!");
        java.lang.String str45 = nodeNameTest44.getNamespaceURI();
        boolean boolean46 = collectionPointer20.testNode((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext47 = new org.apache.commons.jxpath.ri.axes.ParentContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext12, (org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest44);
        attributeContext12.reset();
        org.junit.Assert.assertNull(qName11);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2147483648) + "'", int18 == (-2147483648));
        org.junit.Assert.assertNull(locale25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(nodePointer30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNull(namespaceResolver32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodePointer34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(nodeIterator42);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "hi!" + "'", str45, "hi!");
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test1406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1406");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        boolean boolean4 = jDOMNodePointer2.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName6 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator7 = jDOMNodePointer2.attributeIterator(qName6);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer10.getNamespaceResolver();
        int int13 = jDOMNodePointer10.index;
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer15 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int13, locale14);
        org.w3c.dom.Node node16 = null;
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer19 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node16, locale17, "");
        java.util.Locale locale20 = dOMNodePointer19.locale;
        java.lang.Object obj21 = dOMNodePointer19.getRootNode();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        java.lang.Object obj26 = jDOMNodePointer24.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver27 = jDOMNodePointer24.getNamespaceResolver();
        int int28 = collectionPointer15.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer19, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer24);
        org.apache.commons.jxpath.ri.QName qName29 = null;
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest31 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName29, "");
        org.apache.commons.jxpath.ri.QName qName32 = nodeNameTest31.getNodeName();
        java.util.Locale locale35 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer36 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale35);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = jDOMNodePointer36.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver38 = jDOMNodePointer36.getNamespaceResolver();
        int int39 = jDOMNodePointer36.index;
        java.util.Locale locale40 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer41 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int39, locale40);
        java.lang.Object obj42 = collectionPointer41.getBaseValue();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator43 = collectionPointer15.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, true, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer41);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer45 = null;
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator46 = jDOMNodePointer2.childIterator((org.apache.commons.jxpath.ri.compiler.NodeTest) nodeNameTest31, true, nodePointer45);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer48 = jDOMNodePointer2.namespacePointer("Expression context [0] id(\\'\\'):id(\\'\\')");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeIterator7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-2147483648) + "'", int13 == (-2147483648));
        org.junit.Assert.assertNull(locale20);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(namespaceResolver27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(qName32);
        org.junit.Assert.assertNull(nodePointer37);
        org.junit.Assert.assertNull(namespaceResolver38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-2147483648) + "'", int39 == (-2147483648));
        org.junit.Assert.assertEquals("'" + obj42 + "' != '" + (-2147483648) + "'", obj42, (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator43);
        org.junit.Assert.assertNotNull(nodeIterator46);
        org.junit.Assert.assertNotNull(nodePointer48);
    }

    @Test
    public void test1417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1417");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        boolean boolean3 = nullPointer2.isCollection();
        boolean boolean4 = nullPointer2.isLeaf();
        java.lang.String str5 = nullPointer2.asPath();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        boolean boolean10 = jDOMNodePointer8.equals((java.lang.Object) (byte) 0);
        org.apache.commons.jxpath.ri.QName qName12 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator13 = jDOMNodePointer8.attributeIterator(qName12);
        java.lang.String str14 = qName12.getPrefix();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        org.apache.commons.jxpath.BasicVariables basicVariables38 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContext37.setVariables((org.apache.commons.jxpath.Variables) basicVariables38);
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException42 = new org.apache.commons.jxpath.JXPathInvalidAccessException("");
        basicVariables38.declareVariable("|", (java.lang.Object) "");
        basicVariables38.undeclareVariable("");
        basicVariables38.undeclareVariable("UNKNOWN");
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo48 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer49 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, qName12, (java.lang.Object) basicVariables38, jXPathBeanInfo48);
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer50 = beanPointer49.getPropertyPointer();
        java.lang.Object obj51 = beanPointer49.getBaseValue();
        java.lang.Object obj52 = beanPointer49.getBaseValue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertEquals("'" + str5 + "' != '" + "id($null)" + "'", str5, "id($null)");
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterator13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(propertyPointer50);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertEquals(obj51.toString(), "{|=}");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj51), "{|=}");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj51), "{|=}");
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertEquals(obj52.toString(), "{|=}");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj52), "{|=}");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj52), "{|=}");
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler1 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj3 = treeCompiler1.literal("/");
        java.lang.Object obj5 = treeCompiler1.literal("<<unknown namespace>>");
        java.lang.Object obj7 = treeCompiler1.literal("$");
        java.lang.Object obj10 = treeCompiler1.qname("/http://www.w3.org/2000/xmlns/", "/http://www.w3.org/2000/xmlns/");
        java.lang.Object obj11 = org.apache.commons.jxpath.ri.Parser.parseExpression("/.[43]", (org.apache.commons.jxpath.ri.Compiler) treeCompiler1);
        java.lang.Object obj14 = treeCompiler1.qname("namespace", "org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        java.util.Locale locale16 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer17 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer18 = jDOMNodePointer17.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver19 = jDOMNodePointer17.getNamespaceResolver();
        int int20 = jDOMNodePointer17.index;
        java.util.Locale locale21 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer22 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int20, locale21);
        collectionPointer22.setIndex(42);
        int int25 = collectionPointer22.getLength();
        org.apache.commons.jxpath.ri.QName qName26 = collectionPointer22.getName();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer27 = collectionPointer22.parent;
        boolean boolean28 = collectionPointer22.isCollection();
        org.apache.commons.jxpath.ri.QName qName29 = collectionPointer22.getName();
        java.lang.Object obj30 = null;
        java.util.Locale locale31 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer32 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj30, locale31);
        java.lang.Object obj33 = collectionPointer32.getRootNode();
        try {
            java.lang.Object obj34 = treeCompiler1.lessThanOrEqual((java.lang.Object) collectionPointer22, obj33);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.model.beans.CollectionPointer cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals(obj3.toString(), "'/'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj3), "'/'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj3), "'/'");
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertEquals(obj5.toString(), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj5), "'<<unknown namespace>>'");
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertEquals(obj7.toString(), "'$'");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj7), "'$'");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj7), "'$'");
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertEquals(obj10.toString(), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj10), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj10), "/http://www.w3.org/2000/xmlns/:/http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertEquals(obj11.toString(), "/.[43]");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj11), "/.[43]");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj11), "/.[43]");
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertEquals(obj14.toString(), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(obj14), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertEquals(java.util.Objects.toString(obj14), "namespace:org.apache.commons.jxpath.JXPathInvalidSyntaxException: http://www.w3.org/2000/xmlns/");
        org.junit.Assert.assertNull(nodePointer18);
        org.junit.Assert.assertNull(namespaceResolver19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-2147483648) + "'", int20 == (-2147483648));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(qName26);
        org.junit.Assert.assertNull(nodePointer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(qName29);
        org.junit.Assert.assertNull(obj33);
    }

}
