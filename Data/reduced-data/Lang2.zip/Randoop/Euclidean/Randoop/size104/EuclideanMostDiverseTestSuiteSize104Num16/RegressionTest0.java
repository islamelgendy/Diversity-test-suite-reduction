import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0245");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 32, (int) (short) 1);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 10 -1 100 10 100" + "'", str16.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test0248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0248");
        int[] intArray1 = new int[] { ' ' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 0, (int) (byte) 0);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 6, 121);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[32]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32" + "'", str8.equals("32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
    }

    @Test
    public void test0307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0307");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "0 97 10 32");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0 97 10 32");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
    }

    @Test
    public void test0311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0311");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 1, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ', (int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[1, 0, 1, -1]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
    }

    @Test
    public void test0331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0331");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 10, (int) (byte) -1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 100, 121);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test0351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0351");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 0, 0);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 95, 32);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test0354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0354");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "                                               a# ##                                                ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                a# ##                                                ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 10 -1 100 10 100" + "'", str16.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
    }

    @Test
    public void test0449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0449");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 0, (int) (byte) -1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "0404049740");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0404049740");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test0496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0496");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "97.0 35.0 100.0aaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 97.0 35.0 100.0aaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test0503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0503");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 1, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, ' ');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[1, 0, 1, -1]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1 0 1 -1" + "'", str11.equals("1 0 1 -1"));
    }

    @Test
    public void test0533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0533");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 1, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, 'a', 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[1, 0, 1, -1]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
    }

    @Test
    public void test0539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0539");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (int) (short) 10, (int) (short) 1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 79, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test0569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0569");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 32, (int) (short) 1);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 32, (-1));
        byte byte26 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 10 -1 100 10 100" + "'", str16.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + byte26 + "' != '" + (byte) 100 + "'", byte26 == (byte) 100);
    }

    @Test
    public void test0573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0573");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 960, (int) '4');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        java.lang.Class<?> wildcardClass15 = longArray4.getClass();
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#10#97#100" + "'", str9.equals("-1#10#97#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test0597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0597");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0444444444444444444444444444444444444444497.0410.04100.04-1.044444444444444444444444444444444444444440 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A1000 10 -1 100 10 100-1A10A97A100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test0599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0599");
        double[] doubleArray4 = new double[] { 0.0f, 0.0f, 10, 0.0f };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) '#', (int) (short) -1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 79, (int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray4), "[0.0, 0.0, 10.0, 0.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test0603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0603");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 0, (int) (byte) -1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (byte) 100, (int) (byte) 10);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 79, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 79");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test0604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0604");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 10097.00 10 -1 100 10 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test0620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0620");
        float[] floatArray6 = new float[] { (short) 10, (byte) -1, 0L, 10L, 100L, 3 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray6), "[10.0, -1.0, 0.0, 10.0, 100.0, 3.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0#-1.0#0.0#10.0#100.0#3.0" + "'", str8.equals("10.0#-1.0#0.0#10.0#100.0#3.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a-1.0a0.0a10.0a100.0a3.0" + "'", str10.equals("10.0a-1.0a0.0a10.0a100.0a3.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + (-1.0f) + "'", float11 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + (-1.0f) + "'", float13 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 100.0f + "'", float14 == 100.0f);
    }

    @Test
    public void test0635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0635");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test0638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0638");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                1004-14-1432410#################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                1004-14-1432410#################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test0639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0639");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test0643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0643");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.097.0a10.0a100.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test0668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0668");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0497410432" + "'", str10.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0497410432" + "'", str12.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0 97 10 32" + "'", str14.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0#97#10#32" + "'", str16.equals("0#97#10#32"));
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 5, 0);
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) -1, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 10 -1 100 10 100" + "'", str15.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test0692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0692");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 15, 497410432);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
    }

    @Test
    public void test0721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0721");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 21, (int) (byte) -1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test0727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0727");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 1, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[1, 0, 1, -1]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
    }

    @Test
    public void test0743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0743");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "0.00.0hi!97.097.0435.04100.0   ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0.00.0hi!97.097.0435.04100.0   ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test0766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0766");
        float[] floatArray4 = new float[] { 0L, (short) -1, (byte) 1, 1L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 0, 38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, -1.0, 1.0, 1.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.04-1.041.041.0" + "'", str7.equals("0.04-1.041.041.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 -1.0 1.0 1.0" + "'", str10.equals("0.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test0773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0773");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 21, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test0783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0783");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 0, (int) (byte) -1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (byte) 100, (int) (byte) 10);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "97.0435.04100.10097.0435.04100.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 97.0435.04100.10097.0435.04100.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test0796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0796");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 960, (int) '4');
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#10#97#100" + "'", str9.equals("-1#10#97#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test0797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0797");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 0, 0);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test0810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0810");
        short[] shortArray5 = new short[] { (short) -1, (byte) -1, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 1, (int) (short) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (int) '4', 2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 199, 52);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[-1, -1, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1 -1 1 0 10" + "'", str16.equals("-1 -1 1 0 10"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test0864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0864");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 97, 217);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test0865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0865");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#', 5, 0);
        byte byte20 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "52.0#1.0#100.010.0a-1.0a0.0a10.0a100.0a3.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 52.0#1.0#100.010.0a-1.0a0.0a10.0a100.0a3.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 10 -1 100 10 100" + "'", str15.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + byte20 + "' != '" + (byte) -1 + "'", byte20 == (byte) -1);
    }

    @Test
    public void test0887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0887");
        float[] floatArray4 = new float[] { (short) 0, 10.0f, 0, 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 0, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, 10.0, 0.0, 10.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
    }

    @Test
    public void test0901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0901");
        int[] intArray1 = new int[] { ' ' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 0, (int) (byte) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 95, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', (int) (short) 10, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[32]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32" + "'", str11.equals("32"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
    }

    @Test
    public void test0910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0910");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 32, (int) (short) 1);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 32, (-1));
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str31 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "00.010.0a-1.0a0.0a10.0a100.0a3.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 00.010.0a-1.0a0.0a10.0a100.0a3.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 10 -1 100 10 100" + "'", str16.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0#10#-1#100#10#100" + "'", str27.equals("0#10#-1#100#10#100"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0a10a-1a100a10a100" + "'", str29.equals("0a10a-1a100a10a100"));
    }

    @Test
    public void test0914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0914");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...97.0#10...\r\n-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0hi-1.041.0410.040.041.0!-1.041.0410.040.041.0h-1.041.0410.040.041.0...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test0928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0928");
        short[] shortArray5 = new short[] { (short) -1, (byte) -1, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 1, (int) (short) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (int) '4', 2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', 199, 52);
        short short21 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[-1, -1, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1 -1 1 0 10" + "'", str16.equals("-1 -1 1 0 10"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 10 + "'", short21 == (short) 10);
    }

    @Test
    public void test0936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0936");
        double[] doubleArray5 = new double[] { (-1.0f), 1.0d, (short) 10, 0L, 1.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 2, 3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a');
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray5), "[-1.0, 1.0, 10.0, 0.0, 1.0]");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.041.0410.040.041.0" + "'", str8.equals("-1.041.0410.040.041.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1.0a1.0a10.0a0.0a1.0" + "'", str14.equals("-1.0a1.0a10.0a0.0a1.0"));
    }

    @Test
    public void test0946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0946");
        double[] doubleArray1 = new double[] { 0.0d };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) '#', (int) (short) 1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 138, (-1));
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0" + "'", str3.equals("0.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0.0" + "'", str16.equals("0.0"));
    }

    @Test
    public void test0974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0974");
        float[] floatArray4 = new float[] { (short) 0, 10.0f, 0, 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 31, (-1));
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, 10.0, 0.0, 10.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0410.040.0410.0" + "'", str14.equals("0.0410.040.0410.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test0983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0983");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 6, (int) (short) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0497410432" + "'", str7.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0497410432" + "'", str13.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ');
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a10a97a100" + "'", str10.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 10 97 100" + "'", str12.equals("-1 10 97 100"));
    }

    @Test
    public void test0988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0988");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n\r...01#0.79...0.140.040.0140.140.1-h0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-!0.140.040.0140.140.1-ih0.140.040.0140.140.1-\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test0996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0996");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("44444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.0404444444444444444444444440.04-1.041.041.04-1.041.04");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        float[] floatArray4 = new float[] { (short) 0, 10.0f, 0, 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 31, (-1));
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, 10.0, 0.0, 10.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 10.0f + "'", float12 == 10.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0.0410.040.0410.0" + "'", str14.equals("0.0410.040.0410.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 10.0f + "'", float15 == 10.0f);
    }

    @Test
    public void test1010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1010");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) 'a', 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 21, 2);
        try {
            byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test1011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1011");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 6, (int) (short) -1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (int) '#', 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0497410432" + "'", str7.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0497410432" + "'", str13.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test1034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1034");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("i ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiii");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1042");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[0, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0 -1" + "'", str6.equals("0 -1"));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test1044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1044");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a-1.0a.a0a#a1a.a0a#a52a.a0                      7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        7.#97.#27.10.0a-1.0a0.0a10.0a100.0a3.0                        ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test1053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1053");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "                                                                                         ################################");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                          ################################");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
    }

    @Test
    public void test1065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1065");
        short[] shortArray5 = new short[] { (short) -1, (byte) -1, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 1, (int) (short) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4', 100, 27);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 96, (int) '4');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 0, 138);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[-1, -1, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-14-14140410" + "'", str20.equals("-14-14140410"));
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 95, (int) (byte) 1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A##########################10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A##########################10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A10.0A-1.0A0.0A10.0A100.0A1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test1082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1082");
        short[] shortArray5 = new short[] { (short) 0, (byte) 0, (short) 0, (byte) 10, (short) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', 5, 0);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.Class<?> wildcardClass13 = shortArray5.getClass();
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[0, 0, 0, 10, -1]");
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) -1 + "'", short12 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test1097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1097");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100100a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1137");
        double[] doubleArray4 = new double[] { (short) -1, 32, 10.0d, (short) 0 };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray4, 'a', 4, 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray4), "[-1.0, 32.0, 10.0, 0.0]");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 32.0 10.0 0.0" + "'", str7.equals("-1.0 32.0 10.0 0.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (short) 0, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 42, 1124);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 42");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test1187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1187");
        short[] shortArray5 = new short[] { (short) -1, (byte) -1, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 1, (int) (short) -1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (int) '4', 2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ');
        short short21 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[-1, -1, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 10 + "'", short10 == (short) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-1 -1 1 0 10" + "'", str16.equals("-1 -1 1 0 10"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1#-1#1#0#10" + "'", str18.equals("-1#-1#1#0#10"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "-1 -1 1 0 10" + "'", str20.equals("-1 -1 1 0 10"));
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) -1 + "'", short21 == (short) -1);
    }

    @Test
    public void test1193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1193");
        float[] floatArray4 = new float[] { (short) 0, 10.0f, 0, 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 237, (int) (byte) 100);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 25, 6);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, 10.0, 0.0, 10.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0.0#10.0#0.0#10.0" + "'", str9.equals("0.0#10.0#0.0#10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test1221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1221");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "52.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 52.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#10010052.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test1236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1236");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1238");
        int[] intArray1 = new int[] { ' ' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 0, (int) (byte) 0);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 79, 1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[32]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "32" + "'", str8.equals("32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test1261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1261");
        long[] longArray4 = new long[] { (-1L), (short) 10, 'a', (short) 100 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray4, ' ', 960, (int) '4');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 31, 56);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[-1, 10, 97, 100]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a10a97a100" + "'", str6.equals("-1a10a97a100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1#10#97#100" + "'", str9.equals("-1#10#97#100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
    }

    @Test
    public void test1267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1267");
        byte[] byteArray2 = new byte[] { (byte) 0, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "0 97 10 320 97 10 320 97 10 3200a-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0 97 10 320 97 10 320 97 10 3200a-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[0, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "04-1" + "'", str6.equals("04-1"));
    }

    @Test
    public void test1279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1279");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) 'a', 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 21, 2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 52, 0);
        try {
            byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test1287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1287");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("01A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 044444444444444444444444444444444444444440.1-40.00140.0140.7944444444444444444444444444444444444444440");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 0001A79A01A1-001 01 001 1- 01 044444444444444444444444444444444444444440.1-40.00140.0140.7944444444444444444444444444444444444444440\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1305");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100...####################...2a577a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1310");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ', (int) '#', 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
    }

    @Test
    public void test1324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1324");
        double[] doubleArray3 = new double[] { 100, (byte) 1, '4' };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', 4, 81);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray3), "[100.0, 1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0#1.0#52.0" + "'", str6.equals("100.0#1.0#52.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0#1.0#52.0" + "'", str8.equals("100.0#1.0#52.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0a1.0a52.0" + "'", str10.equals("100.0a1.0a52.0"));
    }

    @Test
    public void test1328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1328");
        int[] intArray1 = new int[] { ' ' };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 0, (int) (byte) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 121, 100);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 35, 20);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 138, (int) (short) 10);
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 5, 105);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[32]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "32" + "'", str7.equals("32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test1342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1342");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 0, 0);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
    }

    @Test
    public void test1344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1344");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', (int) (short) 32, (int) (short) 1);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 32, (-1));
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join(byteArray6, '#');
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a');
        try {
            java.lang.String str31 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "100.0 1.0 52");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0 1.0 52");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 10 -1 100 10 100" + "'", str16.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) 100 + "'", byte17 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0#10#-1#100#10#100" + "'", str27.equals("0#10#-1#100#10#100"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0a10a-1a100a10a100" + "'", str29.equals("0a10a-1a100a10a100"));
    }

    @Test
    public void test1352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1352");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("             Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!                          Iiihi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1353");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("00.0#0.0#32.0#1.0#3.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0#0.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1362");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ', 95, (int) (byte) 10);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
    }

    @Test
    public void test1363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1363");
        double[] doubleArray4 = new double[] { 'a', 10.0f, (short) 100, (-1L) };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '#');
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray4), "[97.0, 10.0, 100.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97.0#10.0#100.0#-1.0" + "'", str6.equals("97.0#10.0#100.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test1364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1364");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                      044444444444444444444444444444444444444449797.0435.04100.00-1A10A97A1000 10 -1 100 10 100-1A10A97A10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1366");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!hi!h...#########################################100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!hi!h...#########################################100aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test1370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1370");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 0, (int) (byte) 1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', (int) (short) -1, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100" + "'", str7.equals("100"));
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test1371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1371");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a97a10a32" + "'", str11.equals("0a97a10a32"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0a97a10a32" + "'", str13.equals("0a97a10a32"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 97 10 32" + "'", str15.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0 97 10 32" + "'", str19.equals("0 97 10 32"));
    }

    @Test
    public void test1382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1382");
        float[] floatArray4 = new float[] { 0L, (short) -1, (byte) 1, 1L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) (short) -1, 138);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, -1.0, 1.0, 1.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.04-1.041.041.0" + "'", str7.equals("0.04-1.041.041.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0.0 -1.0 1.0 1.0" + "'", str10.equals("0.0 -1.0 1.0 1.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test1385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1385");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("i ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiiii ii -i iii ii iii-iaiia97aiii");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test1392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1392");
        float[] floatArray4 = new float[] { (short) 0, 10.0f, 0, 10 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', 35, (int) '#');
        float float14 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float16 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 138, (int) '#');
        try {
            java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 20, 155);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[0.0, 10.0, 0.0, 10.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5 == 10.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 10.0f + "'", float6 == 10.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 10.0f + "'", float9 == 10.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 10.0f + "'", float16 == 10.0f);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test1408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1408");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#10010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#100-1#10#97#10010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0a10.0a100.0a3.010.0a-1.0a0.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test1425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1425");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
    }

    @Test
    public void test1429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1429");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test1431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1431");
        long[] longArray1 = new long[] { 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray1, '4');
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (short) 0, 0);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, ' ');
        long long17 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long18 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10" + "'", str8.equals("10"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
    }

    @Test
    public void test1435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1435");
        float[] floatArray6 = new float[] { (short) 10, (byte) -1, 0L, 10L, 100L, 3 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 237, 1341);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 237");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray6), "[10.0, -1.0, 0.0, 10.0, 100.0, 3.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0#-1.0#0.0#10.0#100.0#3.0" + "'", str8.equals("10.0#-1.0#0.0#10.0#100.0#3.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a-1.0a0.0a10.0a100.0a3.0" + "'", str10.equals("10.0a-1.0a0.0a10.0a100.0a3.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0a-1.0a0.0a10.0a100.0a3.0" + "'", str12.equals("10.0a-1.0a0.0a10.0a100.0a3.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0 -1.0 0.0 10.0 100.0 3.0" + "'", str14.equals("10.0 -1.0 0.0 10.0 100.0 3.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 10, (byte) -1, (byte) 100, (byte) 10, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray6, 'a', 3, 6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray6, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "I!HI!H...\nHI97.0 35.0 100.0AAAAAAAAAAAAAAAAAAAA1.040.0410.041.04-1.00.0 35.0 97.0 ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: I!HI!H...?HI97.0 35.0 100.0AAAAAAAAAAAAAAAAAAAA1.040.0410.041.04-1.00.0 35.0 97.0 ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 10, -1, 100, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 -1 100 10 100" + "'", str9.equals("0 10 -1 100 10 100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a100" + "'", str13.equals("100a10a100"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 10 -1 100 10 100" + "'", str15.equals("0 10 -1 100 10 100"));
    }

    @Test
    public void test1446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1446");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 100, 0);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int24 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int25 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass26 = intArray4.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0497410432" + "'", str10.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0#97#10#32" + "'", str17.equals("0#97#10#32"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0 97 10 32" + "'", str23.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test1455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1455");
        byte[] byteArray2 = new byte[] { (byte) 100, (byte) -1 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 21, (int) (byte) -1);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.097.0 35.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.0-1.041.0410.040.041.0hi-1.041.097.0 35.0 100.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[100, -1]");
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) -1 + "'", byte4 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#-1" + "'", str12.equals("100#-1"));
    }

    @Test
    public void test1472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1472");
        double[] doubleArray4 = new double[] { 0.0f, 0.0f, 10, 0.0f };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', (int) '#', (int) (short) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray4, ' ', 0, 1);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray4, '4', (int) ' ', (int) (short) 40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray4), "[0.0, 0.0, 10.0, 0.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test1477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1477");
        double[] doubleArray5 = new double[] { (-1.0f), 1.0d, (short) 10, 0L, 1.0d };
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray5, '#', 2, 3);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray5, 'a', 95, 16);
        double double17 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray5), "[-1.0, 1.0, 10.0, 0.0, 1.0]");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.041.0410.040.041.0" + "'", str8.equals("-1.041.0410.040.041.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0" + "'", str12.equals("10.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test1478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1478");
        float[] floatArray6 = new float[] { (short) 10, (byte) -1, 0L, 10L, 100L, 3 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4', 960, 100);
        float float19 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray6), "[10.0, -1.0, 0.0, 10.0, 100.0, 3.0]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0#-1.0#0.0#10.0#100.0#3.0" + "'", str8.equals("10.0#-1.0#0.0#10.0#100.0#3.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a-1.0a0.0a10.0a100.0a3.0" + "'", str10.equals("10.0a-1.0a0.0a10.0a100.0a3.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.0a-1.0a0.0a10.0a100.0a3.0" + "'", str12.equals("10.0a-1.0a0.0a10.0a100.0a3.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0 -1.0 0.0 10.0 100.0 3.0" + "'", str14.equals("10.0 -1.0 0.0 10.0 100.0 3.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 100.0f + "'", float19 == 100.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
    }

    @Test
    public void test1481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1481");
        double[] doubleArray1 = new double[] { 0.0d };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) '#', (int) (short) 1);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 29, 199);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0" + "'", str3.equals("0.0"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
    }

    @Test
    public void test1484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1484");
        short[] shortArray4 = new short[] { (short) 1, (short) 0, (byte) 1, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray4, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray4, '4');
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[1, 0, 1, -1]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 1 + "'", short6 == (short) 1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1#0#1#-1" + "'", str11.equals("1#0#1#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "140414-1" + "'", str13.equals("140414-1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "140414-1" + "'", str15.equals("140414-1"));
    }

    @Test
    public void test1487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1487");
        int[] intArray4 = new int[] { (byte) 0, 'a', (byte) 10, ' ' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 0, 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int18 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[0, 97, 10, 32]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0 97 10 32" + "'", str8.equals("0 97 10 32"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0497410432" + "'", str10.equals("0497410432"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0#97#10#32" + "'", str17.equals("0#97#10#32"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
    }

    @Test
    public void test1497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1497");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\nhi!hi!h...#########################################100", (double) 21.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.0d + "'", double2 == 21.0d);
    }

}
