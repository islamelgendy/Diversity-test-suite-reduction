import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0027");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test0055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0055");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0 35.0 97.0", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test0068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0068");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) 2, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test0081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0081");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.00.00.00.00.00.00.00.00.00.0100.0 35.0 97.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test0085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0085");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 10, (float) 1L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test0097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0097");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) 3, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test0187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0187");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 1, (double) 1, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test0192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0192");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.00.00.00.00.00.00.00.00.00.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), (double) 21, (double) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test0205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0205");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97.0#10.0#100.0#-1.00 10 -1 100 10 100", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test0212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0212");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.00.00.00.00.00.00.00.00.00.", (double) 121);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 121.0d + "'", double2 == 121.0d);
    }

    @Test
    public void test0235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0235");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3.0f, (double) (-1), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test0263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0263");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("101.040.0410.041.04-1.00.0 35.0 97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test0308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0308");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.4444443E23f + "'", float1 == 4.4444443E23f);
    }

    @Test
    public void test0326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0326");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 32, (float) 5, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test0403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0403");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test0410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0410");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0444444444444444444444444       04104-14100410410", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test0412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0412");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 32, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.041.0410.040.041.0HI-1.041.00.0#10.0#0.0#10.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test0440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0440");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.00.0hi!97.097.0435.04100.0", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test0445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0445");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) (byte) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test0459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0459");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.04iIIHI!.041.041.0", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test0514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0514");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".040.041.0h-1.041.0410.040.041.0...", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 32, (double) (short) 32, 25.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.0d + "'", double3 == 25.0d);
    }

    @Test
    public void test0612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0612");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 15, (float) (short) -1, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 15.0f + "'", float3 == 15.0f);
    }

    @Test
    public void test0615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0615");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...h...h...h...h...h...h...h...h...h...h");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test0628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0628");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0.00.0hi!97.097.0435.04100.0###", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test0640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0640");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test0655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0655");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("52.0#1.0#100.052.0#1.0#10052.0#1.0#100.052.0#1.0#100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test0666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0666");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 96.0f, (double) (short) 32, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test0701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0701");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 15.0f, (double) 26, (double) 79);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 79.0d + "'", double3 == 79.0d);
    }

    @Test
    public void test0718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0718");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("\n-1.041.0410.040.041.0HI-1.041.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test0733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0733");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("111111111111111");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 111111111111111L + "'", long1.equals(111111111111111L));
    }

    @Test
    public void test0749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0749");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 49, (double) (short) -1, (double) 121);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 121.0d + "'", double3 == 121.0d);
    }

    @Test
    public void test0768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0768");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.040.0410.041.04-1.00.0 35.0 97.0 ", 96.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.0f + "'", float2 == 96.0f);
    }

    @Test
    public void test0793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0793");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.040.0410.041.04-1.00.0 35.0 97.0 ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test0868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0868");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\nhi97.0 35.0 100.0aaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test0874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0874");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("I100 10 0100 10 0100 10 0100 10 0100 10 0100 10 0100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test0889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0889");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 7, (double) 217L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test0899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0899");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444aa a#44444444444444", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test0922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0922");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 0, (double) 11L, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test0923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0923");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test0927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0927");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...10.040.041.0hi-1.041.0410....", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test0930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0930");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi97.0 35.0 100.0aaaaaaaaaaaaaaaaaaaa", (long) 133);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 133L + "'", long2 == 133L);
    }

    @Test
    public void test0932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0932");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(111111111111111L, (long) 21, (long) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 111111111111111L + "'", long3 == 111111111111111L);
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test0950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0950");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97.0#10...", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test0966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0966");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97.0A10.0A100.0A-1.0", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test1015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1015");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("##a### #...h...h...h...h...h...h...h...h...h...h");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test1025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1025");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 27L, (float) 111111111111111L, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 27.0f + "'", float3 == 27.0f);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test1058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1058");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, (float) (byte) -1, 27.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test1063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1063");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".a0a#a1a.a0a#a52a.a0", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test1067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1067");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) 121L, (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 121.0d + "'", double3 == 121.0d);
    }

    @Test
    public void test1076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1076");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 40, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test1087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1087");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97.0 35.0 100.0aaaaaaaaaaaaaaaaaaaa", (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test1124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1124");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) (short) 40, 237.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 237.0d + "'", double3 == 237.0d);
    }

    @Test
    public void test1132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1132");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0.00.0hi!97.097.0435.04100.0###");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test1139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1139");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0.0f, (double) 100L, (double) 42.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test1185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1185");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0 97 10 320 97 10 320 97 10 3200a-1", (long) 927);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 927L + "'", long2 == 927L);
    }

    @Test
    public void test1245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1245");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test1252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1252");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0#0.0#32.0#1.0#3.01.040.0410.041.04-1.00.0 35.0 97...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test1254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1254");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 497410432L, (float) 3, 4.97410432E8f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.97410432E8f + "'", float3 == 4.97410432E8f);
    }

    @Test
    public void test1270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1270");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97L, (float) 497410432, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.97410432E8f + "'", float3 == 4.97410432E8f);
    }

    @Test
    public void test1286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1286");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) 40);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test1343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1343");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 32, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test1367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1367");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test1406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1406");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), (long) 497410432, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 497410432L + "'", long3 == 497410432L);
    }

    @Test
    public void test1424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1424");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(21.0f, (float) 30L, (float) 111111111111111L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.11111114E14f + "'", float3 == 1.11111114E14f);
    }

    @Test
    public void test1449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1449");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaa", (float) 21L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test1470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1470");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4444444444");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 4444444444L + "'", number1.equals(4444444444L));
    }

}
