import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0041");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        org.joda.time.Partial partial18 = new org.joda.time.Partial();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        boolean boolean20 = partial18.isMatch((org.joda.time.ReadablePartial) partial19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.DateTime dateTime22 = partial19.toDateTime(readableInstant21);
        int[] intArray27 = new int[] { ' ', '4', (byte) 0 };
        try {
            int[] intArray29 = offsetDateTimeField13.addWrapField((org.joda.time.ReadablePartial) partial19, (-28800000), intArray27, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[32, 52, 0]");
    }

    @Test
    public void test0067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0067");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.millisOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology2.eras();
        org.joda.time.Chronology chronology12 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology2.yearOfCentury();
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        long long18 = gregorianChronology2.set((org.joda.time.ReadablePartial) partial14, (-3155674021990L));
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = partial14.getFieldTypes();
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType21 = partial14.getFieldType((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3155674021990L) + "'", long18 == (-3155674021990L));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
    }

    @Test
    public void test0201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0201");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.millisOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology2.eras();
        org.joda.time.Chronology chronology12 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology2.yearOfCentury();
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        long long18 = gregorianChronology2.set((org.joda.time.ReadablePartial) partial14, (-3155674021990L));
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray19 = partial14.getFieldTypes();
        int[] intArray26 = new int[] { 'a', (byte) 1, 576001, 57600132, (short) 1, 36 };
        try {
            org.joda.time.Partial partial27 = new org.joda.time.Partial(dateTimeFieldTypeArray19, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Values array must be the same length as the types array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3155674021990L) + "'", long18 == (-3155674021990L));
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[97, 1, 576001, 57600132, 1, 36]");
    }

    @Test
    public void test0266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0266");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText(0L, locale23);
        boolean boolean25 = offsetDateTimeField13.isLenient();
        long long28 = offsetDateTimeField13.getDifferenceAsLong((-3900000L), (long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57600035" + "'", str24.equals("57600035"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3899999L) + "'", long28 == (-3899999L));
    }

    @Test
    public void test0279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0279");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        int int33 = unsupportedDateTimeField30.getDifference(28800101L, 28800065L);
        try {
            long long35 = unsupportedDateTimeField30.roundHalfEven(1604822400073L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test0288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0288");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.Partial partial18 = new org.joda.time.Partial();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        boolean boolean20 = partial18.isMatch((org.joda.time.ReadablePartial) partial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        org.joda.time.Partial partial22 = partial19.without(dateTimeFieldType21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.Partial partial24 = partial22.plus(readablePeriod23);
        int[] intArray28 = new int[] { 'a', 35 };
        java.util.Locale locale30 = null;
        try {
            int[] intArray31 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) partial24, (-28800100), intArray28, "57600045", locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28800100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(partial22);
        org.junit.Assert.assertNotNull(partial24);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray28), "[97, 35]");
    }

    @Test
    public void test0314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0314");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        boolean boolean24 = offsetDateTimeField13.isLeap((-57600000L));
        boolean boolean26 = offsetDateTimeField13.isLeap((-28799900L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0335");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        try {
            long long33 = unsupportedDateTimeField30.roundCeiling((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test0338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0338");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (int) (short) -1);
        int int25 = offsetDateTimeField13.getMaximumValue((long) 'a');
        long long28 = offsetDateTimeField13.add((long) 1, 10);
        long long31 = offsetDateTimeField13.add(1L, (int) (byte) 100);
        long long33 = offsetDateTimeField13.roundHalfCeiling(1604908553036L);
        int int34 = offsetDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 86400034 + "'", int25 == 86400034);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 11L + "'", long28 == 11L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 101L + "'", long31 == 101L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1604908553036L + "'", long33 == 1604908553036L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 35 + "'", int34 == 35);
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        long long19 = offsetDateTimeField13.roundHalfEven((-1L));
        long long21 = offsetDateTimeField13.roundCeiling((long) (short) 100);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsText(11L, locale23);
        org.joda.time.DurationField durationField25 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57600046" + "'", str24.equals("57600046"));
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.DurationField durationField24 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test0389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0389");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        try {
            int int33 = unsupportedDateTimeField30.getMaximumValue((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (long) (short) 10);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 11L + "'", long23 == 11L);
    }

    @Test
    public void test0450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0450");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (int) (short) -1);
        int int25 = offsetDateTimeField13.getMaximumValue((long) 'a');
        int int27 = offsetDateTimeField13.getLeapAmount((-210866803168010L));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField13.getAsShortText(35L, locale29);
        long long32 = offsetDateTimeField13.roundHalfCeiling((-2488325831845999L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 86400034 + "'", int25 == 86400034);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "57600070" + "'", str30.equals("57600070"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-2488325831845999L) + "'", long32 == (-2488325831845999L));
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        int int24 = offsetDateTimeField13.get(35L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField13.getAsText(0, locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField13.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField28, durationFieldType29, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57600070 + "'", int24 == 57600070);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test0508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0508");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.millisOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology2.eras();
        org.joda.time.Chronology chronology12 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology2.yearOfCentury();
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        long long18 = gregorianChronology2.set((org.joda.time.ReadablePartial) partial14, (-3155674021990L));
        java.lang.String str19 = gregorianChronology2.toString();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone21);
        long long28 = zonedChronology22.getDateTimeMillis((-210866731622001L), 0, 0, (int) ' ', (int) (short) 0);
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology22.year();
        try {
            long long35 = zonedChronology22.getDateTimeMillis(2440587L, 0, 36, 28800114, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800114 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3155674021990L) + "'", long18 == (-3155674021990L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str19.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-210866803168010L) + "'", long28 == (-210866803168010L));
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test0550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0550");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray31 = new int[] { 57600132, 36, ' ', 14822035, 57600135, 36 };
        try {
            int[] intArray33 = offsetDateTimeField13.addWrapField(readablePartial23, (int) (byte) 0, intArray31, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray31), "[57600132, 36, 32, 14822035, 57600135, 36]");
    }

    @Test
    public void test0568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0568");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        long long25 = offsetDateTimeField13.remainder(0L);
        java.util.Locale locale28 = null;
        try {
            long long29 = offsetDateTimeField13.set((long) (-57600035), "-28800100", locale28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800100 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test0569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0569");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        long long25 = offsetDateTimeField13.remainder(0L);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField13.getMaximumShortTextLength(locale26);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
    }

    @Test
    public void test0622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0622");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int18 = offsetDateTimeField13.getDifference((-28800000L), (long) 100);
        long long20 = offsetDateTimeField13.roundHalfCeiling((long) 99);
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        boolean boolean23 = partial21.isMatch((org.joda.time.ReadablePartial) partial22);
        int[] intArray24 = partial21.getValues();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial21.minus(readablePeriod25);
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        org.joda.time.Partial partial28 = new org.joda.time.Partial();
        boolean boolean29 = partial27.isMatch((org.joda.time.ReadablePartial) partial28);
        int int30 = partial26.compareTo((org.joda.time.ReadablePartial) partial28);
        int[] intArray32 = new int[] { (short) -1 };
        int int33 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial26, intArray32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        try {
            int int35 = partial26.compareTo(readablePartial34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800100) + "'", int18 == (-28800100));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 99L + "'", long20 == 99L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[]");
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[-1]");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
    }

    @Test
    public void test0649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0649");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField13.getAsShortText((long) (byte) 1, locale20);
        int int24 = offsetDateTimeField13.getDifference((long) (short) 100, (long) 0);
        long long26 = offsetDateTimeField13.roundHalfCeiling((long) 57600070);
        long long29 = offsetDateTimeField13.add(1604822400065L, (-57599999L));
        int int31 = offsetDateTimeField13.get((-65L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "36" + "'", str21.equals("36"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 57600070L + "'", long26 == 57600070L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1604764800066L + "'", long29 == 1604764800066L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86399970 + "'", int31 == 86399970);
    }

    @Test
    public void test0661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0661");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getRangeDurationField();
        long long24 = offsetDateTimeField13.remainder(82800034L);
        java.lang.String str25 = offsetDateTimeField13.toString();
        long long28 = offsetDateTimeField13.add(4L, 7380336744181990L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[millisOfDay]" + "'", str25.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 7380336744181994L + "'", long28 == 7380336744181994L);
    }

    @Test
    public void test0683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0683");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        boolean boolean26 = partial22.isBefore((org.joda.time.ReadablePartial) partial23);
        int int27 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) partial22);
        long long30 = offsetDateTimeField13.addWrapField(57600065L, 99);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86400034 + "'", int27 == 86400034);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 57600164L + "'", long30 == 57600164L);
    }

    @Test
    public void test0727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0727");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField12 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType11);
        java.lang.Object obj13 = null;
        boolean boolean14 = unsupportedDurationField12.equals(obj13);
        boolean boolean15 = unsupportedDurationField12.isSupported();
        org.joda.time.DurationFieldType durationFieldType16 = unsupportedDurationField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str20 = illegalFieldValueException19.getIllegalValueAsString();
        boolean boolean21 = unsupportedDurationField12.equals((java.lang.Object) str20);
        boolean boolean23 = unsupportedDurationField12.equals((java.lang.Object) 1604908553036L);
        boolean boolean24 = unsupportedDurationField12.isPrecise();
        long long25 = unsupportedDurationField12.getUnitMillis();
        boolean boolean26 = gregorianChronology2.equals((java.lang.Object) unsupportedDurationField12);
        try {
            long long29 = unsupportedDurationField12.getDifferenceAsLong(86400034L, (-210866774368000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(unsupportedDurationField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0736");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField13.getType();
        java.lang.String str23 = offsetDateTimeField13.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[millisOfDay]" + "'", str23.equals("DateTimeField[millisOfDay]"));
    }

    @Test
    public void test0784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0784");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField13.getWrappedField();
        long long23 = offsetDateTimeField13.roundHalfEven((long) (-28800000));
        long long25 = offsetDateTimeField13.roundHalfEven((long) (short) 100);
        try {
            long long28 = offsetDateTimeField13.set((long) 86399970, (-63540079));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63540079 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test0789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0789");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (byte) -1);
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getRangeDurationField();
        int int24 = offsetDateTimeField13.getLeapAmount((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test0811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0811");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField13.getAsShortText((long) (byte) 1, locale20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsText((long) 10, locale23);
        boolean boolean25 = offsetDateTimeField13.isLenient();
        long long27 = offsetDateTimeField13.roundHalfFloor(0L);
        long long29 = offsetDateTimeField13.roundHalfCeiling(288001L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "36" + "'", str21.equals("36"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "45" + "'", str24.equals("45"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 288001L + "'", long29 == 288001L);
    }

    @Test
    public void test0813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0813");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText(0L, locale23);
        boolean boolean25 = offsetDateTimeField13.isLenient();
        long long28 = offsetDateTimeField13.getDifferenceAsLong((-3900000L), (long) (byte) -1);
        long long31 = offsetDateTimeField13.add((-7591203504181990L), (long) 100);
        long long34 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 100, (long) 57600043);
        java.lang.String str36 = offsetDateTimeField13.getAsShortText(1L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "35" + "'", str24.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3899999L) + "'", long28 == (-3899999L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-7591203504181890L) + "'", long31 == (-7591203504181890L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57599943L) + "'", long34 == (-57599943L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "36" + "'", str36.equals("36"));
    }

    @Test
    public void test0817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0817");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        try {
            long long33 = unsupportedDateTimeField30.add((long) (short) -1, 57600079L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 5760007900");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
    }

    @Test
    public void test0927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0927");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        int int20 = offsetDateTimeField13.getMinimumValue(0L);
        long long22 = offsetDateTimeField13.roundHalfCeiling(0L);
        java.lang.String str24 = offsetDateTimeField13.getAsText(7380336744181994L);
        long long26 = offsetDateTimeField13.roundHalfEven((long) 97);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int[] intArray29 = null;
        try {
            int[] intArray31 = offsetDateTimeField13.add(readablePartial27, 43200035, intArray29, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
    }

    @Test
    public void test0931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0931");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        long long34 = durationField31.subtract(0L, 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-31556908800000L) + "'", long34 == (-31556908800000L));
    }

    @Test
    public void test0975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0975");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.getName();
        try {
            long long33 = unsupportedDateTimeField30.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfDay" + "'", str31.equals("millisOfDay"));
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        int int22 = offsetDateTimeField13.getOffset();
        long long24 = offsetDateTimeField13.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        long long24 = offsetDateTimeField13.roundHalfCeiling((long) (byte) 100);
        int int25 = offsetDateTimeField13.getOffset();
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField13.getAsText(25006, locale27);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "25006" + "'", str28.equals("25006"));
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField13.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType22, 135);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test1246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1246");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        try {
            long long32 = unsupportedDateTimeField30.roundHalfFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
    }

    @Test
    public void test1251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1251");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField12 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType11);
        java.lang.Object obj13 = null;
        boolean boolean14 = unsupportedDurationField12.equals(obj13);
        boolean boolean15 = unsupportedDurationField12.isSupported();
        org.joda.time.DurationFieldType durationFieldType16 = unsupportedDurationField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str20 = illegalFieldValueException19.getIllegalValueAsString();
        boolean boolean21 = unsupportedDurationField12.equals((java.lang.Object) str20);
        boolean boolean23 = unsupportedDurationField12.equals((java.lang.Object) 1604908553036L);
        boolean boolean24 = unsupportedDurationField12.isPrecise();
        long long25 = unsupportedDurationField12.getUnitMillis();
        boolean boolean26 = gregorianChronology2.equals((java.lang.Object) unsupportedDurationField12);
        boolean boolean27 = unsupportedDurationField12.isSupported();
        try {
            long long29 = unsupportedDurationField12.getMillis(288001L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(unsupportedDurationField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test1278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1278");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int17 = offsetDateTimeField13.getLeapAmount((long) 100);
        int int19 = offsetDateTimeField13.getLeapAmount((long) 99);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int[] intArray23 = partial20.getValues();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial20.getFieldTypes();
        int int25 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial20);
        try {
            org.joda.time.DateTimeField dateTimeField27 = partial20.getField(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[]");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
    }

    @Test
    public void test1371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1371");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField22.getAsShortText(9972000000L, locale24);
        long long27 = offsetDateTimeField22.roundHalfFloor(88800034L);
        org.joda.time.ReadablePartial readablePartial28 = null;
        java.util.Locale locale29 = null;
        try {
            java.lang.String str30 = offsetDateTimeField22.getAsShortText(readablePartial28, locale29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 88800034L + "'", long27 == 88800034L);
    }

    @Test
    public void test1401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1401");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        long long23 = offsetDateTimeField13.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test1422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1422");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        int int20 = offsetDateTimeField13.getMinimumValue(0L);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int17 = offsetDateTimeField13.getLeapAmount((long) 100);
        int int19 = offsetDateTimeField13.getLeapAmount((long) 99);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int[] intArray23 = partial20.getValues();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial20.getFieldTypes();
        int int25 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial20);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) 1);
        java.util.Locale locale28 = null;
        int int29 = offsetDateTimeField27.getMaximumShortTextLength(locale28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[]");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (int) (short) -1);
        org.joda.time.DurationField durationField24 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test1483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1483");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField12 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType11);
        java.lang.Object obj13 = null;
        boolean boolean14 = unsupportedDurationField12.equals(obj13);
        boolean boolean15 = unsupportedDurationField12.isSupported();
        org.joda.time.DurationFieldType durationFieldType16 = unsupportedDurationField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str20 = illegalFieldValueException19.getIllegalValueAsString();
        boolean boolean21 = unsupportedDurationField12.equals((java.lang.Object) str20);
        boolean boolean23 = unsupportedDurationField12.equals((java.lang.Object) 1604908553036L);
        boolean boolean24 = unsupportedDurationField12.isPrecise();
        long long25 = unsupportedDurationField12.getUnitMillis();
        boolean boolean26 = gregorianChronology2.equals((java.lang.Object) unsupportedDurationField12);
        boolean boolean27 = unsupportedDurationField12.isSupported();
        try {
            long long30 = unsupportedDurationField12.add((-2699195400000000L), (-57599999L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(unsupportedDurationField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

}
