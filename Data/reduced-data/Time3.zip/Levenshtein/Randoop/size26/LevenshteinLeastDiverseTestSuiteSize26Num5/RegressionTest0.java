import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0056");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField13.getAsText((int) (short) 10, locale20);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
    }

    @Test
    public void test0095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0095");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText(0L, locale23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57600035" + "'", str24.equals("57600035"));
    }

    @Test
    public void test0112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0112");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        long long24 = offsetDateTimeField13.roundHalfCeiling((long) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 100L + "'", long24 == 100L);
    }

    @Test
    public void test0229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0229");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        boolean boolean18 = offsetDateTimeField13.isLenient();
        long long20 = offsetDateTimeField13.roundHalfFloor((long) (byte) 1);
        long long23 = offsetDateTimeField13.add((-3155674021990L), (long) 57600132);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-3155616421858L) + "'", long23 == (-3155616421858L));
    }

    @Test
    public void test0266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0266");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText(0L, locale23);
        boolean boolean25 = offsetDateTimeField13.isLenient();
        long long28 = offsetDateTimeField13.getDifferenceAsLong((-3900000L), (long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57600035" + "'", str24.equals("57600035"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3899999L) + "'", long28 == (-3899999L));
    }

    @Test
    public void test0314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0314");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        boolean boolean24 = offsetDateTimeField13.isLeap((-57600000L));
        boolean boolean26 = offsetDateTimeField13.isLeap((-28799900L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        long long19 = offsetDateTimeField13.roundHalfEven((-1L));
        long long21 = offsetDateTimeField13.roundCeiling((long) (short) 100);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsText(11L, locale23);
        org.joda.time.DurationField durationField25 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 100L + "'", long21 == 100L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "57600046" + "'", str24.equals("57600046"));
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test0358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0358");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField22.getMaximumTextLength(locale23);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
    }

    @Test
    public void test0364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0364");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.DurationField durationField24 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertNull(durationField24);
    }

    @Test
    public void test0413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0413");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (long) (short) 10);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 11L + "'", long23 == 11L);
    }

    @Test
    public void test0568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0568");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        long long25 = offsetDateTimeField13.remainder(0L);
        java.util.Locale locale28 = null;
        try {
            long long29 = offsetDateTimeField13.set((long) (-57600035), "-28800100", locale28);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800100 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test0569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0569");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        long long25 = offsetDateTimeField13.remainder(0L);
        java.util.Locale locale26 = null;
        int int27 = offsetDateTimeField13.getMaximumShortTextLength(locale26);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
    }

    @Test
    public void test0679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0679");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        try {
            long long21 = offsetDateTimeField13.set(1604822400065L, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test0736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0736");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = offsetDateTimeField13.getType();
        java.lang.String str23 = offsetDateTimeField13.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[millisOfDay]" + "'", str23.equals("DateTimeField[millisOfDay]"));
    }

    @Test
    public void test0784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0784");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField13.getWrappedField();
        long long23 = offsetDateTimeField13.roundHalfEven((long) (-28800000));
        long long25 = offsetDateTimeField13.roundHalfEven((long) (short) 100);
        try {
            long long28 = offsetDateTimeField13.set((long) 86399970, (-63540079));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63540079 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test0789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0789");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (byte) -1);
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getRangeDurationField();
        int int24 = offsetDateTimeField13.getLeapAmount((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        int int22 = offsetDateTimeField13.getOffset();
        long long24 = offsetDateTimeField13.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 35 + "'", int22 == 35);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
    }

    @Test
    public void test0999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0999");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        boolean boolean18 = offsetDateTimeField13.isLenient();
        int int20 = offsetDateTimeField13.get(8L);
        long long23 = offsetDateTimeField13.add(0L, (long) (-28800100));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800100L) + "'", long23 == (-28800100L));
    }

    @Test
    public void test1033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1033");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField13.getWrappedField();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField24 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType22, 135);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test1171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1171");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        int int18 = offsetDateTimeField13.getMinimumValue();
        int int19 = offsetDateTimeField13.getMinimumValue();
        int int20 = offsetDateTimeField13.getMinimumValue();
        int int21 = offsetDateTimeField13.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 35 + "'", int18 == 35);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 35 + "'", int21 == 35);
    }

    @Test
    public void test1311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1311");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getRangeDurationField();
        long long25 = durationField22.subtract((long) 57600043, 14822035);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test1333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1333");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        long long19 = offsetDateTimeField13.roundFloor((long) (byte) 0);
        int int20 = offsetDateTimeField13.getOffset();
        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField13.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test1401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1401");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        long long23 = offsetDateTimeField13.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test1422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1422");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        int int20 = offsetDateTimeField13.getMinimumValue(0L);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getDurationField();
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test1438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1438");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        java.util.Locale locale19 = null;
        int int20 = offsetDateTimeField13.getMaximumTextLength(locale19);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 8 + "'", int20 == 8);
    }

    @Test
    public void test1462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1462");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        long long23 = offsetDateTimeField13.add((long) 1, (int) (short) -1);
        org.joda.time.DurationField durationField24 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(durationField24);
    }

}
