import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.weekOfWeekyear();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.Chronology chronology18 = gregorianChronology12.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology12.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology12.millisOfDay();
        org.joda.time.DurationField durationField21 = gregorianChronology12.eras();
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField24 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, durationField21, dateTimeFieldType22, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test0292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0292");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekOfWeekyear();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology6.millisOfDay();
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) gregorianChronology6);
        org.joda.time.Partial partial16 = new org.joda.time.Partial();
        org.joda.time.Partial partial17 = new org.joda.time.Partial();
        boolean boolean18 = partial16.isMatch((org.joda.time.ReadablePartial) partial17);
        int[] intArray19 = partial16.getValues();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = partial16.getFormatter();
        boolean boolean21 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter20);
        java.lang.String str22 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[]");
        org.junit.Assert.assertNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]\")" + "'", str22.equals("(\"org.joda.time.JodaTimePermission\" \"ZonedChronology[GregorianChronology[UTC], America/Los_Angeles]\")"));
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        long long22 = offsetDateTimeField13.roundFloor(35L);
        int int24 = offsetDateTimeField13.get(35L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField13.getAsText(0, locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField13.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType29 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField28, durationFieldType29, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 57600070 + "'", int24 == 57600070);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test0491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0491");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.getName(0L);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfDay();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology6);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.ReadableInstant readableInstant13 = null;
        int int14 = dateTimeZone10.getOffset(readableInstant13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone10.getName((long) (-1), locale16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance(chronology8, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone20 = zonedChronology18.getZone();
        org.joda.time.DateTimeZone dateTimeZone21 = zonedChronology18.getZone();
        boolean boolean22 = iSOChronology5.equals((java.lang.Object) zonedChronology18);
        org.joda.time.DateTimeZone dateTimeZone23 = iSOChronology5.getZone();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology5.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        try {
            int[] intArray27 = iSOChronology5.get(readablePeriod25, (long) 99);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-08:00" + "'", str4.equals("-08:00"));
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-08:00" + "'", str17.equals("-08:00"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test0683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0683");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        boolean boolean26 = partial22.isBefore((org.joda.time.ReadablePartial) partial23);
        int int27 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) partial22);
        long long30 = offsetDateTimeField13.addWrapField(57600065L, 99);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86400034 + "'", int27 == 86400034);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 57600164L + "'", long30 == 57600164L);
    }

    @Test
    public void test0718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0718");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str9 = illegalFieldValueException8.getIllegalValueAsString();
        boolean boolean10 = unsupportedDurationField1.equals((java.lang.Object) str9);
        boolean boolean12 = unsupportedDurationField1.equals((java.lang.Object) 1604908553036L);
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField1.getType();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.centuries();
        int int19 = unsupportedDurationField1.compareTo(durationField18);
        boolean boolean20 = unsupportedDurationField1.isPrecise();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        boolean boolean23 = unsupportedDurationField22.isSupported();
        int int24 = unsupportedDurationField1.compareTo((org.joda.time.DurationField) unsupportedDurationField22);
        try {
            long long27 = unsupportedDurationField22.getValueAsLong((long) (byte) -1, 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test0744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0744");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField5 = gregorianChronology2.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.year();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.minuteOfDay();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.weekOfWeekyear();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology18.centuryOfEra();
        org.joda.time.Chronology chronology20 = zonedChronology18.withUTC();
        boolean boolean21 = gregorianChronology2.equals((java.lang.Object) zonedChronology18);
        try {
            long long27 = zonedChronology18.getDateTimeMillis(1604908552981L, (int) '4', 57600135, 0, 28800114);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test0746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0746");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        boolean boolean2 = partial0.isMatch((org.joda.time.ReadablePartial) partial1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial1.without(dateTimeFieldType3);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial4.getFieldTypes();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DurationField durationField10 = iSOChronology9.centuries();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.yearOfCentury();
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
        org.joda.time.Chronology chronology15 = iSOChronology9.withZone(dateTimeZone13);
        org.joda.time.Partial partial16 = partial4.withChronologyRetainFields(chronology15);
        org.joda.time.Partial partial17 = new org.joda.time.Partial();
        org.joda.time.Partial partial18 = new org.joda.time.Partial();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        boolean boolean21 = partial19.isMatch((org.joda.time.ReadablePartial) partial20);
        boolean boolean22 = partial18.isBefore((org.joda.time.ReadablePartial) partial19);
        boolean boolean23 = partial17.isAfter((org.joda.time.ReadablePartial) partial19);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        boolean boolean25 = partial17.isSupported(dateTimeFieldType24);
        boolean boolean26 = partial4.isMatch((org.joda.time.ReadablePartial) partial17);
        java.lang.String str27 = partial4.toStringList();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(partial16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[]" + "'", str27.equals("[]"));
    }

    @Test
    public void test0748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0748");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = iSOChronology3.centuries();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology3.yearOfCentury();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        java.lang.String str10 = dateTimeZone7.getName(0L);
        long long14 = dateTimeZone7.convertLocalToUTC((-210866760000000L), true, (long) (short) 10);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, dateTimeZone7);
        long long19 = zonedChronology15.add(101L, (-1L), (-28800000));
        boolean boolean21 = zonedChronology15.equals((java.lang.Object) 1.0d);
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology15.minuteOfHour();
        java.util.TimeZone timeZone23 = null;
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone23);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeUtils.getZone(dateTimeZone24);
        java.lang.String str27 = dateTimeZone24.getName(0L);
        long long31 = dateTimeZone24.convertLocalToUTC((-210866760000000L), true, (long) (short) 10);
        int int33 = dateTimeZone24.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.Chronology chronology34 = zonedChronology15.withZone(dateTimeZone24);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -28800000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00" + "'", str10.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210866760000000L) + "'", long14 == (-210866760000000L));
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800101L + "'", long19 == 28800101L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-210866760000000L) + "'", long31 == (-210866760000000L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(chronology34);
    }

    @Test
    public void test0806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0806");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.hourOfDay();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        org.joda.time.Partial partial13 = new org.joda.time.Partial();
        boolean boolean14 = partial12.isMatch((org.joda.time.ReadablePartial) partial13);
        boolean boolean15 = partial11.isBefore((org.joda.time.ReadablePartial) partial12);
        long long17 = iSOChronology9.set((org.joda.time.ReadablePartial) partial11, (long) (-28800000));
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial11.minus(readablePeriod18);
        int[] intArray21 = gregorianChronology2.get((org.joda.time.ReadablePartial) partial11, (long) (byte) 0);
        org.joda.time.DurationField durationField22 = gregorianChronology2.weekyears();
        org.joda.time.DurationField durationField23 = gregorianChronology2.months();
        try {
            long long28 = gregorianChronology2.getDateTimeMillis((-65), 28800114, 1, (-65));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -65 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTC" + "'", str7.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800000L) + "'", long17 == (-28800000L));
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[]");
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test0813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0813");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling(0L);
        long long20 = offsetDateTimeField13.addWrapField((-210866731622000L), (int) (byte) -1);
        org.joda.time.DurationField durationField21 = offsetDateTimeField13.getLeapDurationField();
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField13.getAsShortText(0L, locale23);
        boolean boolean25 = offsetDateTimeField13.isLenient();
        long long28 = offsetDateTimeField13.getDifferenceAsLong((-3900000L), (long) (byte) -1);
        long long31 = offsetDateTimeField13.add((-7591203504181990L), (long) 100);
        long long34 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 100, (long) 57600043);
        java.lang.String str36 = offsetDateTimeField13.getAsShortText(1L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210866731622001L) + "'", long20 == (-210866731622001L));
        org.junit.Assert.assertNull(durationField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "35" + "'", str24.equals("35"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3899999L) + "'", long28 == (-3899999L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-7591203504181890L) + "'", long31 == (-7591203504181890L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57599943L) + "'", long34 == (-57599943L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "36" + "'", str36.equals("36"));
    }

    @Test
    public void test0815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0815");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str9 = illegalFieldValueException8.getIllegalValueAsString();
        boolean boolean10 = unsupportedDurationField1.equals((java.lang.Object) str9);
        boolean boolean12 = unsupportedDurationField1.equals((java.lang.Object) 1604908553036L);
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField1.getType();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.centuries();
        int int19 = unsupportedDurationField1.compareTo(durationField18);
        boolean boolean20 = unsupportedDurationField1.isPrecise();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        boolean boolean23 = unsupportedDurationField22.isSupported();
        int int24 = unsupportedDurationField1.compareTo((org.joda.time.DurationField) unsupportedDurationField22);
        try {
            long long27 = unsupportedDurationField1.add((-57600035L), 34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test0933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0933");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "14822035", (-28800000), (int) (short) 100);
        long long12 = fixedDateTimeZone10.nextTransition((long) (byte) -1);
        java.lang.String str14 = fixedDateTimeZone10.getNameKey(101L);
        int int16 = fixedDateTimeZone10.getOffset((long) (byte) 0);
        java.util.TimeZone timeZone17 = fixedDateTimeZone10.toTimeZone();
        boolean boolean18 = unsupportedDurationField1.equals((java.lang.Object) timeZone17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.weekOfWeekyear();
        java.lang.String str24 = gregorianChronology21.toString();
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial25);
        long long28 = gregorianChronology21.set((org.joda.time.ReadablePartial) partial25, 1604908552980L);
        boolean boolean29 = unsupportedDurationField1.equals((java.lang.Object) partial25);
        try {
            long long32 = unsupportedDurationField1.getMillis(135, 9972000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14822035" + "'", str14.equals("14822035"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertEquals(timeZone17.getDisplayName(), "GMT-08:00");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1604908552980L + "'", long28 == 1604908552980L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test0939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0939");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        java.util.TimeZone timeZone9 = dateTimeZone6.toTimeZone();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.weekOfWeekyear();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology18.getZone();
        java.util.Locale locale21 = null;
        java.lang.String str22 = dateTimeZone19.getShortName((long) 4, locale21);
        long long24 = dateTimeZone6.getMillisKeepLocal(dateTimeZone19, (-7591203446400000L));
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        long long28 = dateTimeZone6.adjustOffset(43200087L, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-7591203446400000L) + "'", long24 == (-7591203446400000L));
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43200087L + "'", long28 == 43200087L);
    }

    @Test
    public void test0957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0957");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Partial partial1 = new org.joda.time.Partial();
        boolean boolean2 = partial0.isMatch((org.joda.time.ReadablePartial) partial1);
        int[] intArray3 = partial0.getValues();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Partial partial5 = partial0.minus(readablePeriod4);
        org.joda.time.Partial partial6 = new org.joda.time.Partial();
        org.joda.time.Partial partial7 = new org.joda.time.Partial();
        boolean boolean8 = partial6.isMatch((org.joda.time.ReadablePartial) partial7);
        int int9 = partial5.compareTo((org.joda.time.ReadablePartial) partial7);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = partial5.getFieldTypes();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.hourOfDay();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology11);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology11.monthOfYear();
        org.joda.time.DurationField durationField15 = iSOChronology11.halfdays();
        org.joda.time.Partial partial16 = new org.joda.time.Partial();
        org.joda.time.Partial partial17 = new org.joda.time.Partial();
        boolean boolean18 = partial16.isMatch((org.joda.time.ReadablePartial) partial17);
        int[] intArray19 = partial16.getValues();
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.Partial partial21 = partial16.minus(readablePeriod20);
        int[] intArray23 = iSOChronology11.get((org.joda.time.ReadablePartial) partial16, (long) '4');
        org.joda.time.Partial partial24 = new org.joda.time.Partial(dateTimeFieldTypeArray10, intArray23);
        org.joda.time.DurationFieldType durationFieldType25 = null;
        try {
            org.joda.time.Partial partial27 = partial24.withFieldAdded(durationFieldType25, 57600132);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray3), "[]");
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[]");
        org.junit.Assert.assertNotNull(partial21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[]");
    }

    @Test
    public void test1029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1029");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str9 = illegalFieldValueException8.getIllegalValueAsString();
        boolean boolean10 = unsupportedDurationField1.equals((java.lang.Object) str9);
        boolean boolean12 = unsupportedDurationField1.equals((java.lang.Object) 1604908553036L);
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField1.getType();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.centuries();
        int int19 = unsupportedDurationField1.compareTo(durationField18);
        boolean boolean20 = unsupportedDurationField1.isPrecise();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        boolean boolean23 = unsupportedDurationField22.isSupported();
        int int24 = unsupportedDurationField1.compareTo((org.joda.time.DurationField) unsupportedDurationField22);
        try {
            java.lang.String str25 = unsupportedDurationField1.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test1035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1035");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException8 = new org.joda.time.IllegalFieldValueException("-08:00", "");
        java.lang.String str9 = illegalFieldValueException8.getIllegalValueAsString();
        boolean boolean10 = unsupportedDurationField1.equals((java.lang.Object) str9);
        boolean boolean12 = unsupportedDurationField1.equals((java.lang.Object) 1604908553036L);
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField1.getType();
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DurationField durationField18 = gregorianChronology16.centuries();
        int int19 = unsupportedDurationField1.compareTo(durationField18);
        boolean boolean20 = unsupportedDurationField1.isPrecise();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        boolean boolean23 = unsupportedDurationField22.isSupported();
        int int24 = unsupportedDurationField1.compareTo((org.joda.time.DurationField) unsupportedDurationField22);
        try {
            long long27 = unsupportedDurationField22.getMillis(1604674330065L, 43622069L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(durationFieldType13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test1045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1045");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.lang.String str5 = gregorianChronology2.toString();
        org.joda.time.Partial partial6 = new org.joda.time.Partial();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial6);
        long long9 = gregorianChronology2.set((org.joda.time.ReadablePartial) partial6, 1604908552980L);
        org.joda.time.DurationField durationField10 = gregorianChronology2.seconds();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.hourOfDay();
        org.joda.time.Partial partial13 = new org.joda.time.Partial();
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        boolean boolean17 = partial13.isBefore((org.joda.time.ReadablePartial) partial14);
        long long19 = iSOChronology11.set((org.joda.time.ReadablePartial) partial13, (long) (-28800000));
        org.joda.time.Partial partial20 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial13);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        boolean boolean22 = partial20.isSupported(dateTimeFieldType21);
        org.joda.time.Chronology chronology23 = partial20.getChronology();
        int[] intArray25 = gregorianChronology2.get((org.joda.time.ReadablePartial) partial20, (long) (-28800100));
        try {
            long long30 = gregorianChronology2.getDateTimeMillis(57600043, (-234674912), (int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -234674912 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1604908552980L + "'", long9 == 1604908552980L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-28800000L) + "'", long19 == (-28800000L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[]");
    }

    @Test
    public void test1048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1048");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "14822035", (-28800000), (int) (short) 100);
        long long12 = fixedDateTimeZone10.nextTransition((long) (byte) -1);
        java.lang.String str14 = fixedDateTimeZone10.getNameKey(101L);
        int int16 = fixedDateTimeZone10.getOffset((long) (byte) 0);
        java.util.TimeZone timeZone17 = fixedDateTimeZone10.toTimeZone();
        boolean boolean18 = unsupportedDurationField1.equals((java.lang.Object) timeZone17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.weekOfWeekyear();
        java.lang.String str24 = gregorianChronology21.toString();
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial25);
        long long28 = gregorianChronology21.set((org.joda.time.ReadablePartial) partial25, 1604908552980L);
        boolean boolean29 = unsupportedDurationField1.equals((java.lang.Object) partial25);
        try {
            long long32 = unsupportedDurationField1.add(36L, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14822035" + "'", str14.equals("14822035"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertEquals(timeZone17.getDisplayName(), "GMT-08:00");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1604908552980L + "'", long28 == 1604908552980L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
        java.lang.Object obj2 = null;
        boolean boolean3 = unsupportedDurationField1.equals(obj2);
        boolean boolean4 = unsupportedDurationField1.isSupported();
        org.joda.time.DurationFieldType durationFieldType5 = unsupportedDurationField1.getType();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "14822035", (-28800000), (int) (short) 100);
        long long12 = fixedDateTimeZone10.nextTransition((long) (byte) -1);
        java.lang.String str14 = fixedDateTimeZone10.getNameKey(101L);
        int int16 = fixedDateTimeZone10.getOffset((long) (byte) 0);
        java.util.TimeZone timeZone17 = fixedDateTimeZone10.toTimeZone();
        boolean boolean18 = unsupportedDurationField1.equals((java.lang.Object) timeZone17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.weekOfWeekyear();
        java.lang.String str24 = gregorianChronology21.toString();
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        org.joda.time.Partial partial26 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial25);
        long long28 = gregorianChronology21.set((org.joda.time.ReadablePartial) partial25, 1604908552980L);
        boolean boolean29 = unsupportedDurationField1.equals((java.lang.Object) partial25);
        try {
            int int32 = unsupportedDurationField1.getDifference(3455971200065L, 29400065L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(unsupportedDurationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "14822035" + "'", str14.equals("14822035"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertEquals(timeZone17.getDisplayName(), "GMT-08:00");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1604908552980L + "'", long28 == 1604908552980L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1276");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.lang.String str5 = gregorianChronology2.toString();
        org.joda.time.Partial partial6 = new org.joda.time.Partial();
        org.joda.time.Partial partial7 = new org.joda.time.Partial((org.joda.time.ReadablePartial) partial6);
        long long9 = gregorianChronology2.set((org.joda.time.ReadablePartial) partial6, 1604908552980L);
        org.joda.time.DurationField durationField10 = gregorianChronology2.minutes();
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekOfWeekyear();
        java.lang.String str15 = gregorianChronology13.toString();
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone17);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        org.joda.time.DurationField durationField20 = iSOChronology19.centuries();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology19.hourOfDay();
        boolean boolean23 = gregorianChronology13.equals((java.lang.Object) dateTimeField22);
        boolean boolean24 = gregorianChronology2.equals((java.lang.Object) boolean23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1604908552980L + "'", long9 == 1604908552980L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test1278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1278");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int17 = offsetDateTimeField13.getLeapAmount((long) 100);
        int int19 = offsetDateTimeField13.getLeapAmount((long) 99);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int[] intArray23 = partial20.getValues();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial20.getFieldTypes();
        int int25 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial20);
        try {
            org.joda.time.DateTimeField dateTimeField27 = partial20.getField(8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[]");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
    }

    @Test
    public void test1444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1444");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int17 = offsetDateTimeField13.getLeapAmount((long) 100);
        int int19 = offsetDateTimeField13.getLeapAmount((long) 99);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int[] intArray23 = partial20.getValues();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray24 = partial20.getFieldTypes();
        int int25 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial20);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) 1);
        java.util.Locale locale28 = null;
        int int29 = offsetDateTimeField27.getMaximumShortTextLength(locale28);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[]");
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 35 + "'", int25 == 35);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.hourOfDay();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        org.joda.time.Partial partial13 = new org.joda.time.Partial();
        boolean boolean14 = partial12.isMatch((org.joda.time.ReadablePartial) partial13);
        boolean boolean15 = partial11.isBefore((org.joda.time.ReadablePartial) partial12);
        long long17 = iSOChronology9.set((org.joda.time.ReadablePartial) partial11, (long) (-28800000));
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial11.minus(readablePeriod18);
        int[] intArray21 = gregorianChronology2.get((org.joda.time.ReadablePartial) partial11, (long) (byte) 0);
        org.joda.time.DurationField durationField22 = gregorianChronology2.weekyears();
        org.joda.time.DurationField durationField23 = gregorianChronology2.months();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology2.weekOfWeekyear();
        java.lang.String str25 = gregorianChronology2.toString();
        org.joda.time.DurationField durationField26 = gregorianChronology2.months();
        org.joda.time.DurationField durationField27 = gregorianChronology2.seconds();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800000L) + "'", long17 == (-28800000L));
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[]");
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.millisOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "14822035", (-28800000), (int) (short) 100);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        long long12 = fixedDateTimeZone9.previousTransition(82800034L);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.weekOfWeekyear();
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology16.withZone(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology16.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology16.millisOfDay();
        org.joda.time.DurationField durationField25 = gregorianChronology16.eras();
        org.joda.time.Chronology chronology26 = gregorianChronology16.withUTC();
        boolean boolean27 = fixedDateTimeZone9.equals((java.lang.Object) chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 82800034L + "'", long12 == 82800034L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test1478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1478");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField5 = gregorianChronology2.days();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology2.halfdays();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology2.year();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.minuteOfDay();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.weekOfWeekyear();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology18.centuryOfEra();
        org.joda.time.Chronology chronology20 = zonedChronology18.withUTC();
        boolean boolean21 = gregorianChronology2.equals((java.lang.Object) zonedChronology18);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(chronology23);
    }

}
