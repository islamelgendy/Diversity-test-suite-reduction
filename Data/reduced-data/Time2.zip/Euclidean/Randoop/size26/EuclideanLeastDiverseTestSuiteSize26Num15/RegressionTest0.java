import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0047");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        try {
            long long33 = offsetDateTimeField13.set((long) (short) 100, "[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
    }

    @Test
    public void test0069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0069");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        try {
            long long33 = offsetDateTimeField13.set(0L, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
    }

    @Test
    public void test0074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0074");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getName((long) 'a');
        java.util.TimeZone timeZone29 = dateTimeZone25.toTimeZone();
        boolean boolean30 = partial21.equals((java.lang.Object) dateTimeZone25);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) partial21, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-08:00" + "'", str28.equals("-08:00"));
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertEquals(timeZone29.getDisplayName(), "Pacific Standard Time");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test0273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0273");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        try {
            int int33 = unsupportedDateTimeField30.getMinimumValue((-3155674021990L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test0279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0279");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        int int33 = unsupportedDateTimeField30.getDifference(28800101L, 28800065L);
        try {
            long long35 = unsupportedDateTimeField30.roundHalfEven(1604822400073L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test0348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0348");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial23.getValues();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial23.minus(readablePeriod27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        boolean boolean31 = partial29.isMatch((org.joda.time.ReadablePartial) partial30);
        int int32 = partial28.compareTo((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray33 = partial28.getFieldTypes();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) partial28, (int) (byte) 10, locale35);
        try {
            long long38 = offsetDateTimeField22.roundHalfEven((-9223372036854775808L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[]");
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        try {
            int int34 = unsupportedDateTimeField30.getMinimumValue((long) 576001);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test0389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0389");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        try {
            int int33 = unsupportedDateTimeField30.getMaximumValue((long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test0406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0406");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        try {
            int int33 = unsupportedDateTimeField30.get((long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test0447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0447");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField30.getDurationField();
        try {
            long long34 = unsupportedDateTimeField30.roundFloor((long) 480);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test0591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0591");
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray0 = new org.joda.time.DateTimeFieldType[] {};
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.hourOfDay();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.dayOfYear();
        org.joda.time.Partial partial4 = new org.joda.time.Partial();
        org.joda.time.Partial partial5 = new org.joda.time.Partial();
        boolean boolean6 = partial4.isMatch((org.joda.time.ReadablePartial) partial5);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        org.joda.time.Partial partial8 = partial5.without(dateTimeFieldType7);
        int[] intArray10 = iSOChronology1.get((org.joda.time.ReadablePartial) partial5, (long) (byte) -1);
        java.util.TimeZone timeZone11 = null;
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.weekOfWeekyear();
        java.util.TimeZone timeZone16 = null;
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forTimeZone(timeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone17);
        org.joda.time.Chronology chronology19 = gregorianChronology13.withZone(dateTimeZone17);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology13.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology13.millisOfDay();
        org.joda.time.DurationField durationField22 = gregorianChronology13.eras();
        org.joda.time.Chronology chronology23 = gregorianChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology13.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology13.clockhourOfDay();
        org.joda.time.Partial partial26 = new org.joda.time.Partial(dateTimeFieldTypeArray0, intArray10, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = partial26.getFormatter();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.Partial partial30 = partial26.withPeriodAdded(readablePeriod28, 1);
        try {
            org.joda.time.DateTimeField dateTimeField32 = partial26.getField(86400034);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 86400034");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[]");
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(partial30);
    }

    @Test
    public void test0621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0621");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField30.getDurationField();
        try {
            long long34 = unsupportedDateTimeField30.roundHalfCeiling((long) 57600132);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test0622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0622");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int18 = offsetDateTimeField13.getDifference((-28800000L), (long) 100);
        long long20 = offsetDateTimeField13.roundHalfCeiling((long) 99);
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        boolean boolean23 = partial21.isMatch((org.joda.time.ReadablePartial) partial22);
        int[] intArray24 = partial21.getValues();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial21.minus(readablePeriod25);
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        org.joda.time.Partial partial28 = new org.joda.time.Partial();
        boolean boolean29 = partial27.isMatch((org.joda.time.ReadablePartial) partial28);
        int int30 = partial26.compareTo((org.joda.time.ReadablePartial) partial28);
        int[] intArray32 = new int[] { (short) -1 };
        int int33 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial26, intArray32);
        org.joda.time.ReadablePartial readablePartial34 = null;
        try {
            int int35 = partial26.compareTo(readablePartial34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800100) + "'", int18 == (-28800100));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 99L + "'", long20 == 99L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[]");
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[-1]");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
    }

    @Test
    public void test0658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0658");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekOfWeekyear();
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology3.withZone(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology3.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology3.era();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology3.getZone();
        org.joda.time.DurationField durationField14 = gregorianChronology3.weekyears();
        java.util.TimeZone timeZone15 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forTimeZone(timeZone15);
        java.lang.String str17 = dateTimeZone16.getID();
        org.joda.time.Chronology chronology18 = gregorianChronology3.withZone(dateTimeZone16);
        org.joda.time.DurationField durationField19 = gregorianChronology3.months();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
        java.lang.String str25 = gregorianChronology22.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.DurationField durationField27 = gregorianChronology22.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField28 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField19, durationField27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "UTC" + "'", str17.equals("UTC"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "GregorianChronology[UTC]" + "'", str25.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test0688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0688");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test0716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0716");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        boolean boolean26 = partial22.isBefore((org.joda.time.ReadablePartial) partial23);
        int int27 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) partial22);
        boolean boolean28 = offsetDateTimeField13.isLenient();
        java.lang.String str29 = offsetDateTimeField13.toString();
        long long31 = offsetDateTimeField13.roundHalfCeiling(28800065L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType32, 864000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86400034 + "'", int27 == 86400034);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[millisOfDay]" + "'", str29.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800065L + "'", long31 == 28800065L);
    }

    @Test
    public void test0722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0722");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfMinute();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.weekOfWeekyear();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        java.lang.String str12 = dateTimeZone11.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, dateTimeZone11);
        java.lang.String str14 = zonedChronology13.toString();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        org.joda.time.Partial partial16 = new org.joda.time.Partial();
        boolean boolean17 = partial15.isMatch((org.joda.time.ReadablePartial) partial16);
        java.util.TimeZone timeZone18 = null;
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forTimeZone(timeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField22 = iSOChronology21.centuries();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology21.centuryOfEra();
        org.joda.time.Partial partial26 = partial16.withChronologyRetainFields((org.joda.time.Chronology) iSOChronology21);
        boolean boolean27 = zonedChronology13.equals((java.lang.Object) partial26);
        boolean boolean28 = iSOChronology0.equals((java.lang.Object) partial26);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTC" + "'", str12.equals("UTC"));
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test0801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0801");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        long long15 = offsetDateTimeField13.roundCeiling((long) (short) -1);
        int int18 = offsetDateTimeField13.getDifference((-28800000L), (long) 100);
        long long20 = offsetDateTimeField13.roundHalfCeiling((long) 99);
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        boolean boolean23 = partial21.isMatch((org.joda.time.ReadablePartial) partial22);
        int[] intArray24 = partial21.getValues();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.Partial partial26 = partial21.minus(readablePeriod25);
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        org.joda.time.Partial partial28 = new org.joda.time.Partial();
        boolean boolean29 = partial27.isMatch((org.joda.time.ReadablePartial) partial28);
        int int30 = partial26.compareTo((org.joda.time.ReadablePartial) partial28);
        int[] intArray32 = new int[] { (short) -1 };
        int int33 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial26, intArray32);
        long long35 = offsetDateTimeField13.roundHalfCeiling((long) (byte) 10);
        java.lang.String str37 = offsetDateTimeField13.getAsShortText(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800100) + "'", int18 == (-28800100));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 99L + "'", long20 == 99L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[]");
        org.junit.Assert.assertNotNull(partial26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray32), "[-1]");
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "35" + "'", str37.equals("35"));
    }

    @Test
    public void test0960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0960");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        java.lang.String str7 = dateTimeZone6.getID();
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = zonedChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.era();
        org.joda.time.Partial partial11 = new org.joda.time.Partial();
        org.joda.time.Partial partial12 = new org.joda.time.Partial();
        boolean boolean13 = partial11.isMatch((org.joda.time.ReadablePartial) partial12);
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        boolean boolean20 = partial11.isEqual((org.joda.time.ReadablePartial) partial19);
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.dayOfYear();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        org.joda.time.Partial partial25 = new org.joda.time.Partial();
        boolean boolean26 = partial24.isMatch((org.joda.time.ReadablePartial) partial25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        org.joda.time.Partial partial28 = partial25.without(dateTimeFieldType27);
        int[] intArray30 = iSOChronology21.get((org.joda.time.ReadablePartial) partial25, (long) (byte) -1);
        zonedChronology8.validate((org.joda.time.ReadablePartial) partial19, intArray30);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType33 = partial19.getFieldType((-65));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -65");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray30), "[]");
    }

    @Test
    public void test0975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0975");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.getName();
        try {
            long long33 = unsupportedDateTimeField30.roundFloor(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "millisOfDay" + "'", str31.equals("millisOfDay"));
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        try {
            int int33 = unsupportedDateTimeField30.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long33 = offsetDateTimeField13.add(10L, 0);
        org.joda.time.DurationField durationField34 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test1151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1151");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.lang.String str5 = gregorianChronology2.toString();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology2.add(readablePeriod7, (long) 10, (-1));
        org.joda.time.DurationField durationField11 = gregorianChronology2.years();
        java.util.TimeZone timeZone12 = null;
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.weekOfWeekyear();
        java.util.TimeZone timeZone17 = null;
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forTimeZone(timeZone17);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology20 = gregorianChronology14.withZone(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology14.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology14.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology14.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) '#');
        int int27 = offsetDateTimeField25.getLeapAmount((long) 10);
        int int29 = offsetDateTimeField25.getLeapAmount((long) (byte) 100);
        int int30 = offsetDateTimeField25.getMinimumValue();
        int int31 = offsetDateTimeField25.getMinimumValue();
        long long33 = offsetDateTimeField25.roundFloor(57600065L);
        boolean boolean34 = gregorianChronology2.equals((java.lang.Object) long33);
        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 57600065L + "'", long33 == 57600065L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone35);
    }

    @Test
    public void test1355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekOfWeekyear();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone16);
        org.joda.time.DurationField durationField18 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.weekOfWeekyear();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
        java.lang.String str25 = gregorianChronology22.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        long long30 = gregorianChronology22.add(readablePeriod27, (long) 10, (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology22.getZone();
        org.joda.time.Chronology chronology32 = iSOChronology0.withZone(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        java.lang.String str33 = unsupportedDateTimeField30.toString();
        try {
            int int34 = unsupportedDateTimeField30.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UnsupportedDateTimeField" + "'", str33.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test1492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1492");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial23.getValues();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial23.minus(readablePeriod27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        boolean boolean31 = partial29.isMatch((org.joda.time.ReadablePartial) partial30);
        int int32 = partial28.compareTo((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray33 = partial28.getFieldTypes();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) partial28, (int) (byte) 10, locale35);
        long long38 = offsetDateTimeField22.roundHalfFloor((-210866774368000L));
        long long41 = offsetDateTimeField22.add((-3900000L), (-1550735873650L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[]");
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-210866774368000L) + "'", long38 == (-210866774368000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1550739773650L) + "'", long41 == (-1550739773650L));
    }

}
