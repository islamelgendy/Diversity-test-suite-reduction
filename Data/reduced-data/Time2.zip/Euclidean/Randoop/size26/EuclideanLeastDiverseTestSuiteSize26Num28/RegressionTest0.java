import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0047");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        try {
            long long33 = offsetDateTimeField13.set((long) (short) 100, "[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
    }

    @Test
    public void test0057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0057");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.Partial partial18 = new org.joda.time.Partial();
        org.joda.time.Partial partial19 = new org.joda.time.Partial();
        boolean boolean20 = partial18.isMatch((org.joda.time.ReadablePartial) partial19);
        int[] intArray21 = partial18.getValues();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.Partial partial23 = partial18.minus(readablePeriod22);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.Partial partial25 = partial23.minus(readablePeriod24);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.hourOfDay();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology27.dayOfYear();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        org.joda.time.Partial partial31 = new org.joda.time.Partial();
        boolean boolean32 = partial30.isMatch((org.joda.time.ReadablePartial) partial31);
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = null;
        org.joda.time.Partial partial34 = partial31.without(dateTimeFieldType33);
        int[] intArray36 = iSOChronology27.get((org.joda.time.ReadablePartial) partial31, (long) (byte) -1);
        try {
            int[] intArray38 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) partial25, 10, intArray36, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[]");
        org.junit.Assert.assertNotNull(partial23);
        org.junit.Assert.assertNotNull(partial25);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(partial34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray36), "[]");
    }

    @Test
    public void test0069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0069");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        try {
            long long33 = offsetDateTimeField13.set(0L, 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for millisOfDay must be in the range [35,86400034]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
    }

    @Test
    public void test0074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0074");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeUtils.getZone(dateTimeZone25);
        java.lang.String str28 = dateTimeZone25.getName((long) 'a');
        java.util.TimeZone timeZone29 = dateTimeZone25.toTimeZone();
        boolean boolean30 = partial21.equals((java.lang.Object) dateTimeZone25);
        java.util.Locale locale31 = null;
        try {
            java.lang.String str32 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) partial21, locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-08:00" + "'", str28.equals("-08:00"));
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertEquals(timeZone29.getDisplayName(), "Pacific Standard Time");
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test0117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0117");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField13.getMaximumTextLength(locale33);
        try {
            long long37 = offsetDateTimeField13.set(10L, "[]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"[]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
    }

    @Test
    public void test0209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0209");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField13.getMaximumTextLength(locale33);
        long long36 = offsetDateTimeField13.roundHalfCeiling((long) '#');
        long long38 = offsetDateTimeField13.roundHalfEven((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
    }

    @Test
    public void test0226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0226");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField13.getMaximumTextLength(locale33);
        long long36 = offsetDateTimeField13.roundHalfCeiling((long) '#');
        java.util.Locale locale37 = null;
        int int38 = offsetDateTimeField13.getMaximumShortTextLength(locale37);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
    }

    @Test
    public void test0273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0273");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        try {
            int int33 = unsupportedDateTimeField30.getMinimumValue((-3155674021990L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test0348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0348");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial23.getValues();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial23.minus(readablePeriod27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        boolean boolean31 = partial29.isMatch((org.joda.time.ReadablePartial) partial30);
        int int32 = partial28.compareTo((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray33 = partial28.getFieldTypes();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) partial28, (int) (byte) 10, locale35);
        try {
            long long38 = offsetDateTimeField22.roundHalfEven((-9223372036854775808L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[]");
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        try {
            int int34 = unsupportedDateTimeField30.getMinimumValue((long) 576001);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test0406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0406");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        try {
            int int33 = unsupportedDateTimeField30.get((long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test0447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0447");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField30.getDurationField();
        try {
            long long34 = unsupportedDateTimeField30.roundFloor((long) 480);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155674021990L) + "'", long29 == (-3155674021990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test0490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0490");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField13.getMaximumTextLength(locale33);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField13.getMaximumTextLength(locale35);
        long long38 = offsetDateTimeField13.roundHalfCeiling((long) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 8 + "'", int36 == 8);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
    }

    @Test
    public void test0532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0532");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        java.util.Locale locale33 = null;
        int int34 = offsetDateTimeField13.getMaximumTextLength(locale33);
        try {
            long long37 = offsetDateTimeField13.set(2440587L, "+00:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
    }

    @Test
    public void test0621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0621");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        org.joda.time.DurationField durationField31 = unsupportedDateTimeField30.getDurationField();
        org.joda.time.DurationField durationField32 = unsupportedDateTimeField30.getDurationField();
        try {
            long long34 = unsupportedDateTimeField30.roundHalfCeiling((long) 57600132);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-3155673599990L) + "'", long29 == (-3155673599990L));
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertNotNull(durationField31);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test0688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0688");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long32 = offsetDateTimeField13.roundHalfFloor(0L);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test0716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0716");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        boolean boolean18 = offsetDateTimeField13.isLenient();
        org.joda.time.DurationField durationField19 = offsetDateTimeField13.getDurationField();
        int int21 = offsetDateTimeField13.getLeapAmount((long) (byte) 100);
        org.joda.time.Partial partial22 = new org.joda.time.Partial();
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        boolean boolean26 = partial22.isBefore((org.joda.time.ReadablePartial) partial23);
        int int27 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) partial22);
        boolean boolean28 = offsetDateTimeField13.isLenient();
        java.lang.String str29 = offsetDateTimeField13.toString();
        long long31 = offsetDateTimeField13.roundHalfCeiling(28800065L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField34 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType32, 864000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 86400034 + "'", int27 == 86400034);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[millisOfDay]" + "'", str29.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 28800065L + "'", long31 == 28800065L);
    }

    @Test
    public void test0771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0771");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfDay();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.ReadableInstant readableInstant7 = null;
        int int8 = dateTimeZone4.getOffset(readableInstant7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = dateTimeZone4.getName((long) (-1), locale10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology12.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology12, dateTimeZone17);
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone(dateTimeZone20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.ReadableInstant readableInstant23 = null;
        int int24 = dateTimeZone20.getOffset(readableInstant23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = dateTimeZone20.getName((long) (-1), locale26);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        long long30 = cachedDateTimeZone28.nextTransition((long) (short) -1);
        int int32 = cachedDateTimeZone28.getOffset(86400044L);
        java.lang.String str34 = cachedDateTimeZone28.getName(57600043L);
        org.joda.time.DateTimeZone dateTimeZone35 = cachedDateTimeZone28.getUncachedZone();
        boolean boolean36 = zonedChronology12.equals((java.lang.Object) dateTimeZone35);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00" + "'", str11.equals("+00:00"));
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00" + "'", str27.equals("+00:00"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-1L) + "'", long30 == (-1L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+00:00" + "'", str34.equals("+00:00"));
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test0983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0983");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        long long19 = offsetDateTimeField13.roundFloor((long) (byte) 0);
        int int20 = offsetDateTimeField13.getOffset();
        long long22 = offsetDateTimeField13.roundCeiling((-210866803168010L));
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial23.getValues();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial23.minus(readablePeriod27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        boolean boolean31 = partial29.isMatch((org.joda.time.ReadablePartial) partial30);
        int int32 = partial28.compareTo((org.joda.time.ReadablePartial) partial30);
        int int33 = partial28.size();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) partial28, (int) ' ', locale35);
        long long38 = offsetDateTimeField13.roundFloor((-52595047L));
        int int39 = offsetDateTimeField13.getOffset();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-210866803168010L) + "'", long22 == (-210866803168010L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[]");
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "32" + "'", str36.equals("32"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-52595047L) + "'", long38 == (-52595047L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 35 + "'", int39 == 35);
    }

    @Test
    public void test1066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1066");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        try {
            int int33 = unsupportedDateTimeField30.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        org.joda.time.Partial partial14 = new org.joda.time.Partial();
        org.joda.time.Partial partial15 = new org.joda.time.Partial();
        boolean boolean16 = partial14.isMatch((org.joda.time.ReadablePartial) partial15);
        int[] intArray17 = partial14.getValues();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.Partial partial19 = partial14.minus(readablePeriod18);
        org.joda.time.Partial partial20 = new org.joda.time.Partial();
        org.joda.time.Partial partial21 = new org.joda.time.Partial();
        boolean boolean22 = partial20.isMatch((org.joda.time.ReadablePartial) partial21);
        int int23 = partial19.compareTo((org.joda.time.ReadablePartial) partial21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = null;
        java.lang.String str25 = partial19.toString(dateTimeFormatter24);
        org.joda.time.Partial partial26 = new org.joda.time.Partial();
        org.joda.time.Partial partial27 = new org.joda.time.Partial();
        boolean boolean28 = partial26.isMatch((org.joda.time.ReadablePartial) partial27);
        int[] intArray29 = partial26.getValues();
        int int30 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) partial19, intArray29);
        long long33 = offsetDateTimeField13.add(10L, 0);
        org.joda.time.DurationField durationField34 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[]");
        org.junit.Assert.assertNotNull(partial19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "[]" + "'", str25.equals("[]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 35 + "'", int30 == 35);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test1117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1117");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        long long17 = offsetDateTimeField13.roundHalfCeiling((-1L));
        long long19 = offsetDateTimeField13.roundFloor((long) (byte) 0);
        int int20 = offsetDateTimeField13.getOffset();
        long long22 = offsetDateTimeField13.roundCeiling((-210866803168010L));
        java.lang.String str23 = offsetDateTimeField13.toString();
        java.util.TimeZone timeZone24 = null;
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forTimeZone(timeZone24);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.halfdayOfDay();
        org.joda.time.DurationField durationField28 = gregorianChronology26.weekyears();
        org.joda.time.DurationField durationField29 = gregorianChronology26.halfdays();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology26.era();
        org.joda.time.Partial partial31 = new org.joda.time.Partial((org.joda.time.Chronology) gregorianChronology26);
        org.joda.time.Chronology chronology32 = partial31.getChronology();
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = offsetDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) partial31, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 35 + "'", int20 == 35);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-210866803168010L) + "'", long22 == (-210866803168010L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[millisOfDay]" + "'", str23.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test1355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField2 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.weekOfWeekyear();
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology12 = gregorianChronology6.withZone(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology6.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology6.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology6.getZone();
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone16);
        org.joda.time.DurationField durationField18 = iSOChronology0.months();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology0.weekOfWeekyear();
        java.util.TimeZone timeZone20 = null;
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forTimeZone(timeZone20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology22.weekOfWeekyear();
        java.lang.String str25 = gregorianChronology22.toString();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.weekyearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        long long30 = gregorianChronology22.add(readablePeriod27, (long) 10, (-1));
        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology22.getZone();
        org.joda.time.Chronology chronology32 = iSOChronology0.withZone(dateTimeZone31);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test1414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1414");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology2.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "14822035", (-28800000), (int) (short) 100);
        long long17 = fixedDateTimeZone15.nextTransition((long) (byte) -1);
        java.lang.String str19 = fixedDateTimeZone15.getNameKey(101L);
        int int21 = fixedDateTimeZone15.getOffset((long) (byte) 0);
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology24);
        boolean boolean26 = fixedDateTimeZone15.equals((java.lang.Object) gregorianChronology24);
        java.util.Locale locale28 = null;
        java.lang.String str29 = fixedDateTimeZone15.getName(0L, locale28);
        java.util.TimeZone timeZone30 = fixedDateTimeZone15.toTimeZone();
        int int32 = fixedDateTimeZone15.getStandardOffset((long) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeZone) fixedDateTimeZone15);
        int int35 = fixedDateTimeZone15.getStandardOffset(1604221199999L);
        java.util.TimeZone timeZone36 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.lang.String str38 = fixedDateTimeZone15.getID();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "14822035" + "'", str19.equals("14822035"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-08:00" + "'", str29.equals("-08:00"));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertEquals(timeZone30.getDisplayName(), "GMT-08:00");
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertEquals(timeZone36.getDisplayName(), "GMT-08:00");
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField13.getWrappedField();
        int int20 = offsetDateTimeField13.getLeapAmount(35L);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = offsetDateTimeField13.getType();
        java.util.TimeZone timeZone22 = null;
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone23);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DurationField durationField26 = iSOChronology25.centuries();
        long long29 = durationField26.subtract(10L, (long) (short) 1);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType21, durationField26);
        java.lang.String str31 = unsupportedDateTimeField30.toString();
        boolean boolean32 = unsupportedDateTimeField30.isLenient();
        java.lang.String str33 = unsupportedDateTimeField30.toString();
        try {
            int int34 = unsupportedDateTimeField30.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "UnsupportedDateTimeField" + "'", str31.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "UnsupportedDateTimeField" + "'", str33.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test1492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1492");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.weekOfWeekyear();
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = gregorianChronology2.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology2.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology2.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '#');
        int int15 = offsetDateTimeField13.getLeapAmount((long) 10);
        int int17 = offsetDateTimeField13.getLeapAmount((-28800000L));
        long long20 = offsetDateTimeField13.add((long) 4, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (int) (short) -1);
        org.joda.time.Partial partial23 = new org.joda.time.Partial();
        org.joda.time.Partial partial24 = new org.joda.time.Partial();
        boolean boolean25 = partial23.isMatch((org.joda.time.ReadablePartial) partial24);
        int[] intArray26 = partial23.getValues();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.Partial partial28 = partial23.minus(readablePeriod27);
        org.joda.time.Partial partial29 = new org.joda.time.Partial();
        org.joda.time.Partial partial30 = new org.joda.time.Partial();
        boolean boolean31 = partial29.isMatch((org.joda.time.ReadablePartial) partial30);
        int int32 = partial28.compareTo((org.joda.time.ReadablePartial) partial30);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray33 = partial28.getFieldTypes();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField22.getAsShortText((org.joda.time.ReadablePartial) partial28, (int) (byte) 10, locale35);
        long long38 = offsetDateTimeField22.roundHalfFloor((-210866774368000L));
        long long41 = offsetDateTimeField22.add((-3900000L), (-1550735873650L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 39L + "'", long20 == 39L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray26), "[]");
        org.junit.Assert.assertNotNull(partial28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-210866774368000L) + "'", long38 == (-210866774368000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-1550739773650L) + "'", long41 == (-1550739773650L));
    }

}
