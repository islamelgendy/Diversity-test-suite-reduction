package org.jfree.data.general;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.util.List list40 = null;
        try {
            org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, list40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        try {
            org.jfree.data.pie.PieDataset pieDataset41 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        boolean boolean44 = range41.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Class<?> wildcardClass42 = categoryDataset39.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        java.util.List list42 = null;
        try {
            org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, list42, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        try {
            java.lang.Number number46 = categoryDataset39.getValue(10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        try {
            org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (java.lang.Comparable) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        try {
            org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (java.lang.Comparable) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        try {
            java.lang.Number number44 = categoryDataset39.getValue((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        double double45 = range44.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener46 = null;
        categoryDataset39.addChangeListener(datasetChangeListener46);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        boolean boolean44 = range41.intersects((double) (-1), 0.0d);
        try {
            org.jfree.data.Range range46 = org.jfree.data.Range.scale(range41, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.shift(range41, (double) 100.0f, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        double double43 = range42.getLength();
        double double44 = range42.getCentralValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 600.0d + "'", double43 == 600.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 310.0d + "'", double44 == 310.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        try {
            java.lang.Comparable comparable45 = pieDataset43.getKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        try {
            java.lang.Comparable comparable44 = categoryDataset39.getColumnKey((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 5");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        boolean boolean47 = range44.intersects((double) 'a', (double) 6);
        double double48 = range44.getLength();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertEquals("'" + number41 + "' != '" + 100.0d + "'", number41, 100.0d);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertEquals("'" + number41 + "' != '" + 100.0d + "'", number41, 100.0d);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        double double46 = range45.getLowerBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 100.0d + "'", double46 == 100.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + number40 + "' != '" + 0.0d + "'", number40, 0.0d);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        org.jfree.data.pie.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertNotNull(pieDataset45);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.String str42 = range41.toString();
        org.jfree.data.Range range45 = org.jfree.data.Range.expand(range41, (double) (-1), (double) 1L);
        double double47 = range41.constrain((-1.0d));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "Range[0.0,100.0]" + "'", str42, "Range[0.0,100.0]");
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 100L);
        int int46 = categoryDataset39.getColumnCount();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 5 + "'", int46 == 5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        java.util.List list43 = categoryDataset39.getRowKeys();
        int int44 = categoryDataset39.getRowCount();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, true);
        java.util.List list44 = categoryDataset39.getColumnKeys();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertEquals("'" + number45 + "' != '" + 600.0d + "'", number45, 600.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int43 = categoryDataset39.getRowIndex((java.lang.Comparable) (-1.0d));
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.addChangeListener(datasetChangeListener42);
        try {
            org.jfree.data.pie.PieDataset pieDataset45 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset39, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        boolean boolean47 = range44.intersects((double) (-1.0f), (double) '4');
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        boolean boolean44 = range41.intersects((double) (-1), 0.0d);
        double double45 = range41.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        java.lang.String str45 = range44.toString();
        java.lang.String str46 = range44.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "Range[100.0,100.0]" + "'", str45, "Range[100.0,100.0]");
        org.junit.Assert.assertEquals("'" + str46 + "' != '" + "Range[100.0,100.0]" + "'", str46, "Range[100.0,100.0]");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 10);
        org.jfree.data.general.DatasetGroup datasetGroup43 = categoryDataset39.getGroup();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(datasetGroup43);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        java.util.List list43 = categoryDataset39.getColumnKeys();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + number42 + "' != '" + 0.0d + "'", number42, 0.0d);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        try {
            java.lang.Comparable comparable45 = categoryDataset39.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, true);
        double double44 = range43.getUpperBound();
        java.lang.String str45 = range43.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertEquals("'" + str45 + "' != '" + "Range[0.0,100.0]" + "'", str45, "Range[0.0,100.0]");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        int int14 = xYIntervalSeriesCollection0.getSeriesCount();
        int int15 = xYIntervalSeriesCollection0.getSeriesCount();
        try {
            double double18 = xYIntervalSeriesCollection0.getYValue((int) (short) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range44 = org.jfree.data.Range.expand(range41, (double) (-1L), (double) (short) 0);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        java.lang.Object obj45 = datasetGroup43.clone();
        java.lang.Object obj46 = datasetGroup43.clone();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(obj46);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        double double43 = range41.getLength();
        java.lang.String str44 = range41.toString();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 100.0d + "'", double43 == 100.0d);
        org.junit.Assert.assertEquals("'" + str44 + "' != '" + "Range[0.0,100.0]" + "'", str44, "Range[0.0,100.0]");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray8 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray14 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray20 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray26 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray32 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray38 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray39 = new double[][] { doubleArray8, doubleArray14, doubleArray20, doubleArray26, doubleArray32, doubleArray38 };
        org.jfree.data.category.CategoryDataset categoryDataset40 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset40, false);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo43 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent44 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) (-1.0d), (org.jfree.data.general.Dataset) categoryDataset40, datasetChangeInfo43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset40);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray8), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray14), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray20), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray26), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray32), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray38), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(categoryDataset40);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        int int14 = xYIntervalSeriesCollection0.getSeriesCount();
        int int15 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.DomainOrder domainOrder17 = xYIntervalSeriesCollection0.getDomainOrder();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(domainOrder17);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        try {
            java.lang.Number number46 = categoryDataset39.getValue(5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        double double42 = range41.getLength();
        try {
            org.jfree.data.Range range44 = org.jfree.data.Range.scale(range41, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'factor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        int int14 = xYIntervalSeriesCollection0.getSeriesCount();
        int int15 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        try {
            double double19 = xYIntervalSeriesCollection0.getEndXValue((int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        try {
            java.lang.Number number17 = xYIntervalSeriesCollection0.getY((int) '4', 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int42 = categoryDataset39.getRowCount();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range44, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset39);
        java.lang.Number number42 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset39);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertEquals("'" + number41 + "' != '" + 100.0d + "'", number41, 100.0d);
        org.junit.Assert.assertEquals("'" + number42 + "' != '" + 600.0d + "'", number42, 600.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.KeyToGroupMap keyToGroupMap41 = null;
        try {
            org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, keyToGroupMap41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, false);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener42 = null;
        categoryDataset39.removeChangeListener(datasetChangeListener42);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        double double47 = range45.constrain((double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.0d + "'", double47 == 100.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        int int42 = categoryDataset39.getRowCount();
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.Object obj45 = null;
        boolean boolean46 = range44.equals(obj45);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        try {
            java.lang.Number number17 = xYIntervalSeriesCollection0.getX((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(number14);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        int int45 = pieDataset43.getIndex((java.lang.Comparable) (byte) 0);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener46 = null;
        pieDataset43.removeChangeListener(datasetChangeListener46);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.pie.PieDataset pieDataset43 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset39, (int) (byte) 0);
        double double44 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset43);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(pieDataset43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 6.0d + "'", double44 == 6.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        java.lang.String str42 = range41.toString();
        org.jfree.data.Range range44 = org.jfree.data.Range.expandToInclude(range41, (double) (-1.0f));
        org.jfree.data.Range range47 = org.jfree.data.Range.expand(range44, 310.0d, 50.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertEquals("'" + str42 + "' != '" + "Range[0.0,100.0]" + "'", str42, "Range[0.0,100.0]");
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(range47);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray9 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray15 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray21 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray27 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray33 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray39 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray40 = new double[][] { doubleArray9, doubleArray15, doubleArray21, doubleArray27, doubleArray33, doubleArray39 };
        org.jfree.data.category.CategoryDataset categoryDataset41 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray40);
        org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!2", "hi!", doubleArray40);
        org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset42);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) categoryDataset42);
        int int45 = categoryDataset42.getColumnCount();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray9), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray15), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray21), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray27), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray33), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray39), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(categoryDataset41);
        org.junit.Assert.assertNotNull(categoryDataset42);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 5 + "'", int45 == 5);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39, false);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range45 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39);
        double double46 = range45.getCentralValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 300.0d + "'", double46 == 300.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        java.lang.Number number40 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset39);
        java.util.List list41 = null;
        try {
            org.jfree.data.Range range43 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset39, list41, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'visibleSeriesKeys' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertEquals("'" + number40 + "' != '" + 0.0d + "'", number40, 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection0 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        org.jfree.data.general.SeriesException seriesException2 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Range[0.0,100.0]");
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        seriesException2.addSuppressed((java.lang.Throwable) seriesException4);
        boolean boolean6 = xYIntervalSeriesCollection0.equals((java.lang.Object) seriesException2);
        org.jfree.data.xy.XYIntervalSeriesCollection xYIntervalSeriesCollection7 = new org.jfree.data.xy.XYIntervalSeriesCollection();
        boolean boolean8 = xYIntervalSeriesCollection0.hasListener((java.util.EventListener) xYIntervalSeriesCollection7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo11 = new org.jfree.chart.event.DatasetChangeInfo();
        xYIntervalSeriesCollection0.fireDatasetChanged(datasetChangeInfo11);
        int int13 = xYIntervalSeriesCollection0.getSeriesCount();
        int int14 = xYIntervalSeriesCollection0.getSeriesCount();
        int int15 = xYIntervalSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYIntervalSeriesCollection0);
        try {
            double double19 = xYIntervalSeriesCollection0.getYValue((int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test504");
        double[] doubleArray7 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray13 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray19 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray25 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray31 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[] doubleArray37 = new double[] { 1.0d, (short) 1, (short) 100, (byte) 1, 0 };
        double[][] doubleArray38 = new double[][] { doubleArray7, doubleArray13, doubleArray19, doubleArray25, doubleArray31, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "hi!", doubleArray38);
        int int40 = categoryDataset39.getRowCount();
        org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset39);
        org.jfree.data.general.DatasetGroup datasetGroup43 = new org.jfree.data.general.DatasetGroup("hi!");
        categoryDataset39.setGroup(datasetGroup43);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset39, false);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray7), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray13), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray19), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray25), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray31), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray37), "[1.0, 1.0, 100.0, 1.0, 0.0]");
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(range46);
    }

}
