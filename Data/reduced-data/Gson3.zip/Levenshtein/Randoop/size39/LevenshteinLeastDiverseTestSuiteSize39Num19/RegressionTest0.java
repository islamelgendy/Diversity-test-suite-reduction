import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0076");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        try {
            jsonTreeReader29.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected END_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0087");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        com.google.gson.JsonPrimitive jsonPrimitive33 = jsonObject12.getAsJsonPrimitive("1");
        com.google.gson.JsonPrimitive jsonPrimitive35 = jsonObject12.getAsJsonPrimitive("true");
        try {
            com.google.gson.JsonObject jsonObject36 = jsonPrimitive35.getAsJsonObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonPrimitive33);
        org.junit.Assert.assertNull(jsonPrimitive35);
    }

    @Test
    public void test0115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0115");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        com.google.gson.JsonPrimitive jsonPrimitive33 = jsonObject12.getAsJsonPrimitive("1");
        try {
            com.google.gson.JsonPrimitive jsonPrimitive34 = jsonObject12.getAsJsonPrimitive();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: This is not a JSON Primitive.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonPrimitive33);
    }

    @Test
    public void test0136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0136");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        com.google.gson.JsonPrimitive jsonPrimitive33 = jsonObject12.getAsJsonPrimitive("1");
        com.google.gson.JsonPrimitive jsonPrimitive35 = jsonObject12.getAsJsonPrimitive("true");
        try {
            java.math.BigInteger bigInteger36 = jsonObject12.getAsBigInteger();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonObject");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonPrimitive33);
        org.junit.Assert.assertNull(jsonPrimitive35);
    }

    @Test
    public void test0172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0172");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonObject jsonObject29 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive31 = jsonObject29.getAsJsonPrimitive("hi!");
        java.lang.String str32 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive31);
        java.io.Writer writer33 = null;
        try {
            com.google.gson.stream.JsonWriter jsonWriter34 = gson0.newJsonWriter(writer33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonPrimitive31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "null" + "'", str32.equals("null"));
    }

    @Test
    public void test0254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0254");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        try {
            jsonTreeReader29.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected END_ARRAY but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0268");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginArray();
        try {
            com.google.gson.stream.JsonWriter jsonWriter31 = jsonWriter30.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
    }

    @Test
    public void test0325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0325");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        try {
            double double31 = jsonTreeReader29.nextDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0350");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.name("true");
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter19.value(false);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
    }

    @Test
    public void test0375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0375");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        try {
            com.google.gson.JsonElement jsonElement31 = jsonTreeWriter19.get();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected one JSON element but was [{}]");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
    }

    @Test
    public void test0390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0390");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.nullValue();
        try {
            jsonTreeWriter19.close();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Incomplete document");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter31);
    }

    @Test
    public void test0439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0439");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.name("true");
        try {
            com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter32);
    }

    @Test
    public void test0464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0464");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        jsonTreeWriter19.close();
        jsonTreeWriter19.flush();
        boolean boolean32 = jsonTreeWriter19.isLenient();
        try {
            com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.nullValue();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test0535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0535");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        boolean boolean31 = jsonTreeWriter19.getSerializeNulls();
        try {
            com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test0641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0641");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        boolean boolean31 = jsonTreeWriter19.getSerializeNulls();
        try {
            com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test0683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0683");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter19.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.value((double) 1.0f);
        boolean boolean32 = jsonWriter31.isLenient();
        try {
            com.google.gson.stream.JsonWriter jsonWriter33 = jsonWriter31.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test0785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0785");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        boolean boolean29 = jsonTreeWriter19.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.value(0.0d);
        try {
            com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(jsonWriter31);
    }

    @Test
    public void test0832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0832");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        java.lang.String str31 = jsonTreeReader29.getPath();
        try {
            int int32 = jsonTreeReader29.nextInt();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NUMBER but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "$" + "'", str31.equals("$"));
    }

    @Test
    public void test0837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0837");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        try {
            com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
    }

    @Test
    public void test0873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0873");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.value("");
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter19.value((long) 'c');
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter35);
    }

    @Test
    public void test0904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0904");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        jsonObject12.addProperty("1", "$");
        com.google.gson.JsonElement jsonElement36 = jsonObject12.get("[null,true]");
        com.google.gson.JsonArray jsonArray38 = jsonObject12.getAsJsonArray("com.google.gson.JsonSyntaxException: com.google.gson.JsonSyntaxException: com.google.gson.JsonIOException: JsonTreeReader");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonElement36);
        org.junit.Assert.assertNull(jsonArray38);
    }

    @Test
    public void test0930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0930");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        jsonObject12.addProperty("com.google.gson.JsonParseException: com.google.gson.JsonParseException: a", (java.lang.Boolean) true);
        jsonObject12.addProperty("{\"value\":\"com.google.gson.JsonSyntaxException: hi!\"}", (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
    }

    @Test
    public void test0939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0939");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter19.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.value((double) 1.0f);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.value(0L);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        try {
            jsonTreeReader29.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected END_OBJECT but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test0973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0973");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonWriter30.value(false);
        jsonWriter30.setSerializeNulls(false);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter32);
    }

    @Test
    public void test1069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1069");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        jsonObject12.add("com.google.gson.JsonIOException: com.google.gson.JsonSyntaxException: a", (com.google.gson.JsonElement) jsonPrimitive32);
        java.math.BigDecimal bigDecimal34 = jsonPrimitive32.getAsBigDecimal();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(bigDecimal34);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        boolean boolean29 = jsonTreeWriter19.isHtmlSafe();
        jsonTreeWriter19.close();
        try {
            com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.jsonValue("{\"\":1.0,\"com.google.gson.JsonParseException: com.google.gson.JsonSyntaxException: a\":\"4\"}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1089");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter19.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter19.name("true");
        java.lang.Number number33 = null;
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter19.value(number33);
        try {
            com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter19.endArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter34);
    }

    @Test
    public void test1108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1108");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        java.lang.String str31 = jsonTreeReader29.getPath();
        try {
            java.lang.String str32 = jsonTreeReader29.nextName();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected NAME but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "$" + "'", str31.equals("$"));
    }

    @Test
    public void test1167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1167");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        jsonObject12.add("com.google.gson.JsonIOException: com.google.gson.JsonSyntaxException: a", (com.google.gson.JsonElement) jsonPrimitive32);
        boolean boolean34 = jsonObject12.isJsonNull();
        com.google.gson.JsonPrimitive jsonPrimitive36 = jsonObject12.getAsJsonPrimitive("{\"\":100.0,\"$\":\" \"}");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(jsonPrimitive36);
    }

    @Test
    public void test1198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1198");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        jsonObject12.addProperty("1", "$");
        com.google.gson.JsonElement jsonElement36 = jsonObject12.get("[\"1\"]");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonElement36);
    }

    @Test
    public void test1208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1208");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.value(false);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.value(0.0d);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonWriter33.beginObject();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter34);
    }

    @Test
    public void test1210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1210");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = jsonTreeWriter19.get();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter19.value(false);
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter19.value(0.0d);
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonWriter33.value(false);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter35);
    }

    @Test
    public void test1264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1264");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonArray jsonArray31 = jsonObject12.getAsJsonArray("[{}]");
        jsonObject12.addProperty("1", "$");
        com.google.gson.JsonElement jsonElement36 = jsonObject12.get("[null,true]");
        com.google.gson.JsonObject jsonObject38 = jsonObject12.getAsJsonObject("100");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonArray31);
        org.junit.Assert.assertNull(jsonElement36);
        org.junit.Assert.assertNull(jsonObject38);
    }

    @Test
    public void test1282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1282");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        boolean boolean30 = jsonTreeReader29.hasNext();
        java.lang.String str31 = jsonTreeReader29.getPath();
        try {
            java.lang.String str32 = jsonTreeReader29.nextString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected STRING but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "$" + "'", str31.equals("$"));
    }

    @Test
    public void test1291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1291");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonElement jsonElement31 = jsonObject12.remove("{\"\":null,\"hi!\":false}");
        try {
            com.google.gson.JsonArray jsonArray32 = jsonObject12.getAsJsonArray();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: This is not a JSON Array.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonElement31);
    }

    @Test
    public void test1349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1349");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        jsonObject12.add("com.google.gson.JsonIOException: com.google.gson.JsonSyntaxException: a", (com.google.gson.JsonElement) jsonPrimitive32);
        boolean boolean34 = jsonPrimitive32.isNumber();
        java.lang.Class<?> wildcardClass35 = jsonPrimitive32.getClass();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

    @Test
    public void test1360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1360");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        jsonObject12.add("com.google.gson.JsonIOException: com.google.gson.JsonSyntaxException: a", (com.google.gson.JsonElement) jsonPrimitive32);
        double double34 = jsonPrimitive32.getAsDouble();
        java.lang.Number number35 = jsonPrimitive32.getAsNumber();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 100 + "'", number35.equals(100));
    }

    @Test
    public void test1373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1373");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.JsonPrimitive jsonPrimitive32 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        jsonObject12.add("com.google.gson.JsonIOException: com.google.gson.JsonSyntaxException: a", (com.google.gson.JsonElement) jsonPrimitive32);
        double double34 = jsonPrimitive32.getAsDouble();
        boolean boolean35 = jsonPrimitive32.getAsBoolean();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.0d + "'", double34 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

}
