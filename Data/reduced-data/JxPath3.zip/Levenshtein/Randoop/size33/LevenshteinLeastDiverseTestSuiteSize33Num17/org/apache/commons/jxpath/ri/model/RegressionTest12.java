package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0162");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        java.lang.Object obj32 = dynaBeanPointer31.getBaseValue();
        try {
            dynaBeanPointer31.setValue((java.lang.Object) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test0205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0205");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        java.lang.Object obj2 = nullPropertyPointer1.getBaseValue();
        boolean boolean3 = nullPropertyPointer1.isCollection();
        org.apache.commons.jxpath.JXPathContext jXPathContext4 = null;
        org.apache.commons.jxpath.ri.QName qName6 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean7 = null;
        org.w3c.dom.Node node8 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory9 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer13 = jDOMNodePointer12.getImmediateParentPointer();
        java.lang.Object obj14 = jDOMNodePointer12.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver15 = jDOMNodePointer12.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext16 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer12);
        org.apache.commons.jxpath.ri.parser.Token token17 = null;
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[] intArray23 = new int[] { 10 };
        int[][] intArray24 = new int[][] { intArray19, intArray21, intArray23 };
        java.lang.String[] strArray29 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException30 = new org.apache.commons.jxpath.ri.parser.ParseException(token17, intArray24, strArray29);
        org.apache.commons.jxpath.JXPathContext jXPathContext31 = jXPathContextFactory9.newContext(jXPathContext16, (java.lang.Object) token17);
        java.util.Locale locale32 = jXPathContext31.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale32, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer35 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale32);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer36 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName6, dynaBean7, locale32);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer38 = nullPropertyPointer1.createChild(jXPathContext4, qName6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jXPathContextFactory9);
        org.junit.Assert.assertNull(nodePointer13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(namespaceResolver15);
        org.junit.Assert.assertNotNull(jXPathContext16);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jXPathContext31);
        org.junit.Assert.assertNotNull(locale32);
        org.junit.Assert.assertEquals(locale32.toString(), "en_GB");
    }

    @Test
    public void test0295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0295");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        boolean boolean34 = nullPointer33.isCollection();
        java.beans.PropertyDescriptor propertyDescriptor35 = null;
        try {
            java.lang.Object obj36 = org.apache.commons.jxpath.util.ValueUtils.getValue((java.lang.Object) boolean34, propertyDescriptor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.NodeSet nodeSet33 = childContext4.getNodeSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.w3c.dom.Node node9 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory10 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = jDOMNodePointer13.getImmediateParentPointer();
        java.lang.Object obj15 = jDOMNodePointer13.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver16 = jDOMNodePointer13.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext17 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer13);
        org.apache.commons.jxpath.ri.parser.Token token18 = null;
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[] intArray24 = new int[] { 10 };
        int[][] intArray25 = new int[][] { intArray20, intArray22, intArray24 };
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException31 = new org.apache.commons.jxpath.ri.parser.ParseException(token18, intArray25, strArray30);
        org.apache.commons.jxpath.JXPathContext jXPathContext32 = jXPathContextFactory10.newContext(jXPathContext17, (java.lang.Object) token18);
        java.util.Locale locale33 = jXPathContext32.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer34 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale33);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer36 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale33, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName7, locale33);
        boolean boolean38 = nullPointer37.isCollection();
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertNotNull(jXPathContextFactory10);
        org.junit.Assert.assertNull(nodePointer14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(namespaceResolver16);
        org.junit.Assert.assertNotNull(jXPathContext17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jXPathContext32);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertEquals(locale33.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.String str36 = nodePointer35.asPath();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0513");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext33 = childContext4.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0520");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0629");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0647");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0799");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.w3c.dom.Node node9 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory10 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = jDOMNodePointer13.getImmediateParentPointer();
        java.lang.Object obj15 = jDOMNodePointer13.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver16 = jDOMNodePointer13.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext17 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer13);
        org.apache.commons.jxpath.ri.parser.Token token18 = null;
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[] intArray24 = new int[] { 10 };
        int[][] intArray25 = new int[][] { intArray20, intArray22, intArray24 };
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException31 = new org.apache.commons.jxpath.ri.parser.ParseException(token18, intArray25, strArray30);
        org.apache.commons.jxpath.JXPathContext jXPathContext32 = jXPathContextFactory10.newContext(jXPathContext17, (java.lang.Object) token18);
        java.util.Locale locale33 = jXPathContext32.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer34 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale33);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer36 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale33, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName7, locale33);
        org.apache.commons.jxpath.ri.compiler.NodeNameTest nodeNameTest38 = new org.apache.commons.jxpath.ri.compiler.NodeNameTest(qName7);
        java.lang.String str39 = nodeNameTest38.toString();
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertNotNull(jXPathContextFactory10);
        org.junit.Assert.assertNull(nodePointer14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(namespaceResolver16);
        org.junit.Assert.assertNotNull(jXPathContext17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jXPathContext32);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertEquals(locale33.toString(), "en_GB");
        org.junit.Assert.assertEquals("'" + str39 + "' != '" + "" + "'", str39, "");
    }

    @Test
    public void test0803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0803");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            java.lang.Object obj34 = org.apache.commons.jxpath.util.ValueUtils.expandCollection((java.lang.Object) locale29, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn java.util.Locale into a collection of size 2");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0825");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext1 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext5 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext1, nodeTest2, false, false);
        org.w3c.dom.Node node6 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory7 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        java.lang.Object obj12 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver13 = jDOMNodePointer10.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext14 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer10);
        org.apache.commons.jxpath.ri.parser.Token token15 = null;
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[][] intArray22 = new int[][] { intArray17, intArray19, intArray21 };
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException28 = new org.apache.commons.jxpath.ri.parser.ParseException(token15, intArray22, strArray27);
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = jXPathContextFactory7.newContext(jXPathContext14, (java.lang.Object) token15);
        java.util.Locale locale30 = jXPathContext29.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node6, locale30);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer33 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext5, locale30, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer35 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale30, "$");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer36 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale30);
        try {
            org.apache.commons.jxpath.ri.QName qName37 = dOMNodePointer36.getName();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(namespaceResolver13);
        org.junit.Assert.assertNotNull(jXPathContext14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_GB");
    }

    @Test
    public void test0839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0839");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1006");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        jDOMNodePointer32.printPointerChain();
        java.lang.String str34 = jDOMNodePointer32.getNamespaceURI();
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1179");
        org.apache.commons.jxpath.Container container0 = null;
        org.apache.commons.jxpath.ri.QName qName2 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean3 = null;
        org.w3c.dom.Node node4 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory5 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = jDOMNodePointer8.getImmediateParentPointer();
        java.lang.Object obj10 = jDOMNodePointer8.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver11 = jDOMNodePointer8.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext12 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer8);
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = jXPathContextFactory5.newContext(jXPathContext12, (java.lang.Object) token13);
        java.util.Locale locale28 = jXPathContext27.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer30 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale28, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node4, locale28);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer32 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName2, dynaBean3, locale28);
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer33 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale28);
        int int34 = containerPointer33.getLength();
        boolean boolean35 = containerPointer33.isContainer();
        org.junit.Assert.assertNotNull(jXPathContextFactory5);
        org.junit.Assert.assertNull(nodePointer9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(namespaceResolver11);
        org.junit.Assert.assertNotNull(jXPathContext12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertEquals(locale28.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.Object obj36 = nodePointer35.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            boolean boolean37 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1229");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer1 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer(nodePointer0);
        org.apache.commons.jxpath.ri.QName qName2 = nullPropertyPointer1.getName();
        nullPropertyPointer1.setPropertyName("id(preceding)");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory5 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = jDOMNodePointer8.getImmediateParentPointer();
        java.lang.Object obj10 = jDOMNodePointer8.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver11 = jDOMNodePointer8.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext12 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer8);
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = jXPathContextFactory5.newContext(jXPathContext12, (java.lang.Object) token13);
        java.util.Locale locale28 = jXPathContext27.getLocale();
        org.apache.commons.jxpath.IdentityManager identityManager29 = null;
        jXPathContext27.setIdentityManager(identityManager29);
        java.lang.String str32 = jXPathContext27.getPrefix("{}");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = nullPropertyPointer1.createPath(jXPathContext27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(qName2);
        org.junit.Assert.assertNotNull(jXPathContextFactory5);
        org.junit.Assert.assertNull(nodePointer9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(namespaceResolver11);
        org.junit.Assert.assertNotNull(jXPathContext12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertEquals(locale28.toString(), "en_GB");
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test1247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1247");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1285");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale29, "$");
        java.lang.Object obj35 = nullPointer34.getNode();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = nullPointer34.parent;
        boolean boolean37 = nullPointer34.isLeaf();
        org.apache.commons.jxpath.JXPathContext jXPathContext38 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer39 = nullPointer34.createPath(jXPathContext38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot create the root object: id($)");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(nodePointer36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test1363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1363");
        java.io.Reader reader0 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream1 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader0);
        java.io.Reader reader2 = null;
        simpleCharStream1.ReInit(reader2, 48, 6);
        int int6 = simpleCharStream1.getBeginColumn();
        java.beans.PropertyDescriptor propertyDescriptor7 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext9 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest10 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext13 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext9, nodeTest10, false, false);
        org.w3c.dom.Node node14 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory15 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer18 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale17);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = jDOMNodePointer18.getImmediateParentPointer();
        java.lang.Object obj20 = jDOMNodePointer18.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver21 = jDOMNodePointer18.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer18);
        org.apache.commons.jxpath.ri.parser.Token token23 = null;
        int[] intArray25 = new int[] { 10 };
        int[] intArray27 = new int[] { 10 };
        int[] intArray29 = new int[] { 10 };
        int[][] intArray30 = new int[][] { intArray25, intArray27, intArray29 };
        java.lang.String[] strArray35 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException36 = new org.apache.commons.jxpath.ri.parser.ParseException(token23, intArray30, strArray35);
        org.apache.commons.jxpath.JXPathContext jXPathContext37 = jXPathContextFactory15.newContext(jXPathContext22, (java.lang.Object) token23);
        java.util.Locale locale38 = jXPathContext37.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer39 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node14, locale38);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer41 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext13, locale38, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression42 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext43 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext13, expression42);
        try {
            org.apache.commons.jxpath.util.ValueUtils.setValue((java.lang.Object) simpleCharStream1, propertyDescriptor7, 78, (java.lang.Object) expression42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jXPathContextFactory15);
        org.junit.Assert.assertNull(nodePointer19);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertNull(namespaceResolver21);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray27), "[10]");
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray29), "[10]");
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jXPathContext37);
        org.junit.Assert.assertNotNull(locale38);
        org.junit.Assert.assertEquals(locale38.toString(), "en_GB");
    }

    @Test
    public void test1366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1366");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale29, "http://www.w3.org/XML/1998/namespace");
        boolean boolean36 = nullPointer34.isDefaultNamespace("/null");
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer34);
        java.lang.Object obj38 = nullPointer34.getBaseValue();
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test1397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1397");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale29, "$");
        java.lang.Object obj35 = nullPointer34.getNode();
        org.apache.commons.jxpath.ri.QName qName36 = nullPointer34.getName();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator37 = nullPointer34.namespaceIterator();
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(qName36);
        org.junit.Assert.assertNull(nodeIterator37);
    }

    @Test
    public void test1407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1407");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        java.lang.Object obj36 = nullPointer33.getBaseValue();
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
        org.junit.Assert.assertNull(obj36);
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            boolean boolean39 = predicateContext34.setPosition(18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

}
