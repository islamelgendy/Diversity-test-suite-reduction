package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0049");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.lang.Object obj29 = null;
        java.util.Locale locale30 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer31 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(obj29, locale30);
        java.lang.Object obj32 = collectionPointer31.getRootNode();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = nodePointer5.createPath(jXPathContext28, obj32);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot modify DOM trees");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test0059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0059");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "$null");
        java.util.Locale locale4 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale4);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer6 = jDOMNodePointer5.getImmediateParentPointer();
        java.lang.Object obj7 = jDOMNodePointer5.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver8 = jDOMNodePointer5.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext9 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer5);
        java.lang.String str11 = jXPathContext9.getPrefix("http://www.w3.org/2000/xmlns/");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory12 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale14 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer15 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale14);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMNodePointer15.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer15.getNamespaceResolver();
        int int18 = jDOMNodePointer15.index;
        java.util.Locale locale19 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer20 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) int18, locale19);
        org.apache.commons.jxpath.Container container21 = null;
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer23 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container21, locale22);
        java.util.Locale locale24 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer26 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container21, locale24, "hi!");
        org.apache.commons.jxpath.ri.QName qName28 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator29 = jDOMNodePointer26.attributeIterator(qName28);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference30 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName28);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer32 = containerPointerFactory12.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer20, qName28, (java.lang.Object) "");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer2.createChild(jXPathContext9, qName28, 0, (java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot create the root object: id($null)");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(nodePointer6);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(namespaceResolver8);
        org.junit.Assert.assertNotNull(jXPathContext9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNull(nodePointer16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-2147483648) + "'", int18 == (-2147483648));
        org.junit.Assert.assertNotNull(nodeIterator29);
        org.junit.Assert.assertNull(nodePointer32);
    }

    @Test
    public void test0081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0081");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale1);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = jDOMNodePointer2.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator4 = jDOMNodePointer2.namespaceIterator();
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory5 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = jDOMNodePointer8.getImmediateParentPointer();
        java.lang.Object obj10 = jDOMNodePointer8.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver11 = jDOMNodePointer8.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext12 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer8);
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = jXPathContextFactory5.newContext(jXPathContext12, (java.lang.Object) token13);
        org.apache.commons.jxpath.Variables variables28 = jXPathContext12.getVariables();
        org.apache.commons.jxpath.ri.QName qName29 = null;
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer31 = jDOMNodePointer2.createChild(jXPathContext12, qName29, 63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: ");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNull(nodePointer3);
        org.junit.Assert.assertNotNull(nodeIterator4);
        org.junit.Assert.assertNotNull(jXPathContextFactory5);
        org.junit.Assert.assertNull(nodePointer9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(namespaceResolver11);
        org.junit.Assert.assertNotNull(jXPathContext12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNotNull(variables28);
    }

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0195");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        int int4 = dOMNodePointer3.getLength();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer6 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer3, "");
        java.lang.String str8 = dOMNodePointer3.getNamespaceURI("/null");
        org.w3c.dom.Node node9 = null;
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer12 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale10, "");
        java.util.Locale locale13 = dOMNodePointer12.locale;
        java.lang.Object obj14 = dOMNodePointer12.getRootNode();
        org.apache.commons.jxpath.Variables variables15 = null;
        org.apache.commons.jxpath.ri.QName qName16 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer17 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables15, qName16);
        org.apache.commons.jxpath.Variables variables18 = null;
        org.apache.commons.jxpath.ri.QName qName19 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer20 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables18, qName19);
        boolean boolean21 = variablePointer20.isRoot();
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer24 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer24.getImmediateParentPointer();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver26 = jDOMNodePointer24.getNamespaceResolver();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer28 = jDOMNodePointer24.namespacePointer("http://www.w3.org/2000/xmlns/");
        int int29 = variablePointer17.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) variablePointer20, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer24);
        try {
            int int30 = dOMNodePointer3.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer12, (org.apache.commons.jxpath.ri.model.NodePointer) variablePointer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(nodePointer25);
        org.junit.Assert.assertNull(namespaceResolver26);
        org.junit.Assert.assertNotNull(nodePointer28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.NodeSet nodeSet33 = childContext4.getNodeSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        org.apache.commons.jxpath.Container container0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer2 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale1);
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container0, locale3, "hi!");
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = jDOMNodePointer5.attributeIterator(qName7);
        org.w3c.dom.Node node9 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory10 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale12 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale12);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = jDOMNodePointer13.getImmediateParentPointer();
        java.lang.Object obj15 = jDOMNodePointer13.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver16 = jDOMNodePointer13.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext17 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer13);
        org.apache.commons.jxpath.ri.parser.Token token18 = null;
        int[] intArray20 = new int[] { 10 };
        int[] intArray22 = new int[] { 10 };
        int[] intArray24 = new int[] { 10 };
        int[][] intArray25 = new int[][] { intArray20, intArray22, intArray24 };
        java.lang.String[] strArray30 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException31 = new org.apache.commons.jxpath.ri.parser.ParseException(token18, intArray25, strArray30);
        org.apache.commons.jxpath.JXPathContext jXPathContext32 = jXPathContextFactory10.newContext(jXPathContext17, (java.lang.Object) token18);
        java.util.Locale locale33 = jXPathContext32.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer34 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node9, locale33);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer36 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale33, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName7, locale33);
        boolean boolean38 = nullPointer37.isCollection();
        org.junit.Assert.assertNotNull(nodeIterator8);
        org.junit.Assert.assertNotNull(jXPathContextFactory10);
        org.junit.Assert.assertNull(nodePointer14);
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(namespaceResolver16);
        org.junit.Assert.assertNotNull(jXPathContext17);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray22), "[10]");
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray24), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jXPathContext32);
        org.junit.Assert.assertNotNull(locale33);
        org.junit.Assert.assertEquals(locale33.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.String str36 = nodePointer35.asPath();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0483");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        org.apache.commons.jxpath.ri.model.beans.PropertyPointer propertyPointer19 = beanPointer17.getPropertyPointer();
        boolean boolean21 = beanPointer17.equals((java.lang.Object) 10.0f);
        org.apache.commons.jxpath.Container container22 = null;
        java.util.Locale locale23 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer24 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container22, locale23);
        java.util.Locale locale25 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container22, locale25, "hi!");
        org.apache.commons.jxpath.ri.QName qName29 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator30 = jDOMNodePointer27.attributeIterator(qName29);
        org.apache.commons.jxpath.ri.compiler.VariableReference variableReference31 = new org.apache.commons.jxpath.ri.compiler.VariableReference(qName29);
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer32 = new org.apache.commons.jxpath.ri.model.VariablePointer(qName29);
        boolean boolean33 = beanPointer17.equals((java.lang.Object) qName29);
        boolean boolean34 = beanPointer17.isLeaf();
        boolean boolean35 = beanPointer17.isLeaf();
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(propertyPointer19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(nodeIterator30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        java.util.Locale locale23 = jXPathContext22.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer25 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "preceding");
        org.w3c.dom.Node node26 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer27 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer25, node26);
        java.lang.String str29 = dOMNodePointer27.getNamespaceURI("http://www.w3.org/2000/xmlns/");
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer31 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer27, "/null");
        org.apache.commons.jxpath.JXPathContext jXPathContext32 = null;
        try {
            org.apache.commons.jxpath.Pointer pointer34 = dOMNodePointer27.getPointerByID(jXPathContext32, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertEquals(locale23.toString(), "en_GB");
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test0513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0513");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext33 = childContext4.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0520");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0529");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        int int4 = dOMNodePointer3.getLength();
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer6 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer3, "");
        java.lang.String str8 = dOMNodePointer3.getNamespaceURI("/null");
        org.apache.commons.jxpath.CompiledExpression compiledExpression10 = org.apache.commons.jxpath.JXPathContext.compile("UNKNOWN");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory11 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale13);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = jDOMNodePointer14.getImmediateParentPointer();
        java.lang.Object obj16 = jDOMNodePointer14.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver17 = jDOMNodePointer14.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext18 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer14);
        org.apache.commons.jxpath.ri.parser.Token token19 = null;
        int[] intArray21 = new int[] { 10 };
        int[] intArray23 = new int[] { 10 };
        int[] intArray25 = new int[] { 10 };
        int[][] intArray26 = new int[][] { intArray21, intArray23, intArray25 };
        java.lang.String[] strArray31 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException32 = new org.apache.commons.jxpath.ri.parser.ParseException(token19, intArray26, strArray31);
        org.apache.commons.jxpath.JXPathContext jXPathContext33 = jXPathContextFactory11.newContext(jXPathContext18, (java.lang.Object) token19);
        jXPathContext18.setLenient(true);
        java.util.Iterator iterator36 = compiledExpression10.iteratePointers(jXPathContext18);
        try {
            org.apache.commons.jxpath.Pointer pointer38 = dOMNodePointer3.getPointerByID(jXPathContext18, "http://www.w3.org/XML/1998/namespace");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(compiledExpression10);
        org.junit.Assert.assertNotNull(jXPathContextFactory11);
        org.junit.Assert.assertNull(nodePointer15);
        org.junit.Assert.assertNull(obj16);
        org.junit.Assert.assertNull(namespaceResolver17);
        org.junit.Assert.assertNotNull(jXPathContext18);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray23), "[10]");
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray25), "[10]");
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jXPathContext33);
        org.junit.Assert.assertNotNull(iterator36);
    }

    @Test
    public void test0629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0629");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0647");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0740");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMNodePointer3.getImmediateParentPointer();
        java.lang.Object obj5 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver6 = jDOMNodePointer3.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer3);
        org.apache.commons.jxpath.ri.parser.Token token8 = null;
        int[] intArray10 = new int[] { 10 };
        int[] intArray12 = new int[] { 10 };
        int[] intArray14 = new int[] { 10 };
        int[][] intArray15 = new int[][] { intArray10, intArray12, intArray14 };
        java.lang.String[] strArray20 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException21 = new org.apache.commons.jxpath.ri.parser.ParseException(token8, intArray15, strArray20);
        org.apache.commons.jxpath.JXPathContext jXPathContext22 = jXPathContextFactory0.newContext(jXPathContext7, (java.lang.Object) token8);
        java.util.Locale locale23 = jXPathContext22.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer25 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale23, "preceding");
        org.w3c.dom.Node node26 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer27 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer25, node26);
        java.lang.String str29 = dOMNodePointer27.getNamespaceURI("http://www.w3.org/2000/xmlns/");
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer31 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer27, "/null");
        try {
            java.lang.String str32 = dOMNodePointer27.getNamespaceURI();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
        org.junit.Assert.assertNull(nodePointer4);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(namespaceResolver6);
        org.junit.Assert.assertNotNull(jXPathContext7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray10), "[10]");
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray12), "[10]");
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jXPathContext22);
        org.junit.Assert.assertNotNull(locale23);
        org.junit.Assert.assertEquals(locale23.toString(), "en_GB");
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test0803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0803");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            java.lang.Object obj34 = org.apache.commons.jxpath.util.ValueUtils.expandCollection((java.lang.Object) locale29, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn java.util.Locale into a collection of size 2");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0825");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext1 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext5 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext1, nodeTest2, false, false);
        org.w3c.dom.Node node6 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory7 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        java.lang.Object obj12 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver13 = jDOMNodePointer10.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext14 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer10);
        org.apache.commons.jxpath.ri.parser.Token token15 = null;
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[][] intArray22 = new int[][] { intArray17, intArray19, intArray21 };
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException28 = new org.apache.commons.jxpath.ri.parser.ParseException(token15, intArray22, strArray27);
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = jXPathContextFactory7.newContext(jXPathContext14, (java.lang.Object) token15);
        java.util.Locale locale30 = jXPathContext29.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node6, locale30);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer33 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext5, locale30, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer35 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale30, "$");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer36 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale30);
        try {
            org.apache.commons.jxpath.ri.QName qName37 = dOMNodePointer36.getName();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(namespaceResolver13);
        org.junit.Assert.assertNotNull(jXPathContext14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_GB");
    }

    @Test
    public void test0839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0839");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0946");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer3 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1, "");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = dOMNodePointer3.namespacePointer("preceding");
        org.apache.commons.jxpath.Container container6 = null;
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer8 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container6, locale7);
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) container6, locale9, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = new org.apache.commons.jxpath.ri.QName("");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator14 = jDOMNodePointer11.attributeIterator(qName13);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo16 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer17 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(nodePointer5, qName13, (java.lang.Object) "id('')", jXPathBeanInfo16);
        boolean boolean18 = beanPointer17.isLeaf();
        boolean boolean19 = beanPointer17.isCollection();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver20 = beanPointer17.getNamespaceResolver();
        java.util.Locale locale22 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer23 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale22);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer24 = jDOMNodePointer23.getImmediateParentPointer();
        java.lang.Object obj25 = jDOMNodePointer23.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver26 = jDOMNodePointer23.getNamespaceResolver();
        java.lang.Object obj27 = jDOMNodePointer23.getBaseValue();
        boolean boolean28 = beanPointer17.equals((java.lang.Object) jDOMNodePointer23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer29 = jDOMNodePointer23.getImmediateValuePointer();
        try {
            jDOMNodePointer23.remove();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot remove root JDOM node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        }
        org.junit.Assert.assertNotNull(nodePointer5);
        org.junit.Assert.assertNotNull(nodeIterator14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(namespaceResolver20);
        org.junit.Assert.assertNull(nodePointer24);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertNull(namespaceResolver26);
        org.junit.Assert.assertEquals("'" + obj27 + "' != '" + 'a' + "'", obj27, 'a');
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(nodePointer29);
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1179");
        org.apache.commons.jxpath.Container container0 = null;
        org.apache.commons.jxpath.ri.QName qName2 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean3 = null;
        org.w3c.dom.Node node4 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory5 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale7);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = jDOMNodePointer8.getImmediateParentPointer();
        java.lang.Object obj10 = jDOMNodePointer8.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver11 = jDOMNodePointer8.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext12 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer8);
        org.apache.commons.jxpath.ri.parser.Token token13 = null;
        int[] intArray15 = new int[] { 10 };
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[][] intArray20 = new int[][] { intArray15, intArray17, intArray19 };
        java.lang.String[] strArray25 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException26 = new org.apache.commons.jxpath.ri.parser.ParseException(token13, intArray20, strArray25);
        org.apache.commons.jxpath.JXPathContext jXPathContext27 = jXPathContextFactory5.newContext(jXPathContext12, (java.lang.Object) token13);
        java.util.Locale locale28 = jXPathContext27.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer30 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale28, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node4, locale28);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer32 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName2, dynaBean3, locale28);
        org.apache.commons.jxpath.ri.model.container.ContainerPointer containerPointer33 = new org.apache.commons.jxpath.ri.model.container.ContainerPointer(container0, locale28);
        int int34 = containerPointer33.getLength();
        boolean boolean35 = containerPointer33.isContainer();
        org.junit.Assert.assertNotNull(jXPathContextFactory5);
        org.junit.Assert.assertNull(nodePointer9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(namespaceResolver11);
        org.junit.Assert.assertNotNull(jXPathContext12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray15), "[10]");
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jXPathContext27);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertEquals(locale28.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.Object obj36 = nodePointer35.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test1222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1222");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            boolean boolean37 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1247");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1366");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale29, "http://www.w3.org/XML/1998/namespace");
        boolean boolean36 = nullPointer34.isDefaultNamespace("/null");
        org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer nullPropertyPointer37 = new org.apache.commons.jxpath.ri.model.beans.NullPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer34);
        java.lang.Object obj38 = nullPointer34.getBaseValue();
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(obj38);
    }

    @Test
    public void test1397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1397");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer34 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale29, "$");
        java.lang.Object obj35 = nullPointer34.getNode();
        org.apache.commons.jxpath.ri.QName qName36 = nullPointer34.getName();
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator37 = nullPointer34.namespaceIterator();
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNull(qName36);
        org.junit.Assert.assertNull(nodeIterator37);
    }

    @Test
    public void test1407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1407");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        java.lang.Object obj36 = nullPointer33.getBaseValue();
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
        org.junit.Assert.assertNull(obj36);
    }

}
