package org.apache.commons.jxpath.ri.model;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test0122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0122");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer33 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0162");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        java.lang.Object obj32 = dynaBeanPointer31.getBaseValue();
        try {
            dynaBeanPointer31.setValue((java.lang.Object) 59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test0336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0336");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.NodeSet nodeSet33 = childContext4.getNodeSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0341");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0371");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0382");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean36 = predicateContext34.setPosition(71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.String str36 = nodePointer35.asPath();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test0433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0433");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = childContext4.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0513");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        try {
            org.apache.commons.jxpath.JXPathContext jXPathContext33 = childContext4.getJXPathContext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0520");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0629");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0647");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer36 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0825");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext1 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext5 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext1, nodeTest2, false, false);
        org.w3c.dom.Node node6 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory7 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale9);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = jDOMNodePointer10.getImmediateParentPointer();
        java.lang.Object obj12 = jDOMNodePointer10.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver13 = jDOMNodePointer10.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext14 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer10);
        org.apache.commons.jxpath.ri.parser.Token token15 = null;
        int[] intArray17 = new int[] { 10 };
        int[] intArray19 = new int[] { 10 };
        int[] intArray21 = new int[] { 10 };
        int[][] intArray22 = new int[][] { intArray17, intArray19, intArray21 };
        java.lang.String[] strArray27 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException28 = new org.apache.commons.jxpath.ri.parser.ParseException(token15, intArray22, strArray27);
        org.apache.commons.jxpath.JXPathContext jXPathContext29 = jXPathContextFactory7.newContext(jXPathContext14, (java.lang.Object) token15);
        java.util.Locale locale30 = jXPathContext29.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node6, locale30);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer33 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext5, locale30, "UNKNOWN");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer35 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale30, "$");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer36 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale30);
        try {
            org.apache.commons.jxpath.ri.QName qName37 = dOMNodePointer36.getName();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory7);
        org.junit.Assert.assertNull(nodePointer11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNull(namespaceResolver13);
        org.junit.Assert.assertNotNull(jXPathContext14);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray17), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray19), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray21), "[10]");
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jXPathContext29);
        org.junit.Assert.assertNotNull(locale30);
        org.junit.Assert.assertEquals(locale30.toString(), "en_GB");
    }

    @Test
    public void test0839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0839");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        try {
            boolean boolean36 = predicateContext34.nextNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1079");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        try {
            boolean boolean35 = predicateContext34.nextSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1184");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        try {
            java.lang.Object obj36 = nodePointer35.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
    }

    @Test
    public void test1247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1247");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ChildContext childContext4 = new org.apache.commons.jxpath.ri.axes.ChildContext(evalContext0, nodeTest1, false, false);
        org.w3c.dom.Node node5 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory6 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale8);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = jDOMNodePointer9.getImmediateParentPointer();
        java.lang.Object obj11 = jDOMNodePointer9.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver12 = jDOMNodePointer9.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer9);
        org.apache.commons.jxpath.ri.parser.Token token14 = null;
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[] intArray20 = new int[] { 10 };
        int[][] intArray21 = new int[][] { intArray16, intArray18, intArray20 };
        java.lang.String[] strArray26 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException27 = new org.apache.commons.jxpath.ri.parser.ParseException(token14, intArray21, strArray26);
        org.apache.commons.jxpath.JXPathContext jXPathContext28 = jXPathContextFactory6.newContext(jXPathContext13, (java.lang.Object) token14);
        java.util.Locale locale29 = jXPathContext28.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node5, locale29);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer32 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) childContext4, locale29, "UNKNOWN");
        org.apache.commons.jxpath.ri.compiler.Expression expression33 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext34 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) childContext4, expression33);
        predicateContext34.reset();
        predicateContext34.reset();
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer37 = predicateContext34.getCurrentNodePointer();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jXPathContextFactory6);
        org.junit.Assert.assertNull(nodePointer10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(namespaceResolver12);
        org.junit.Assert.assertNotNull(jXPathContext13);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray20), "[10]");
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jXPathContext28);
        org.junit.Assert.assertNotNull(locale29);
        org.junit.Assert.assertEquals(locale29.toString(), "en_GB");
    }

    @Test
    public void test1407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1407");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("|");
        org.apache.commons.beanutils.DynaBean dynaBean2 = null;
        org.w3c.dom.Node node3 = null;
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory4 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) 'a', locale6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = jDOMNodePointer7.getImmediateParentPointer();
        java.lang.Object obj9 = jDOMNodePointer7.getValue();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver10 = jDOMNodePointer7.getNamespaceResolver();
        org.apache.commons.jxpath.JXPathContext jXPathContext11 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) jDOMNodePointer7);
        org.apache.commons.jxpath.ri.parser.Token token12 = null;
        int[] intArray14 = new int[] { 10 };
        int[] intArray16 = new int[] { 10 };
        int[] intArray18 = new int[] { 10 };
        int[][] intArray19 = new int[][] { intArray14, intArray16, intArray18 };
        java.lang.String[] strArray24 = new java.lang.String[] { "hi!", "", "http://www.w3.org/XML/1998/namespace", "hi!" };
        org.apache.commons.jxpath.ri.parser.ParseException parseException25 = new org.apache.commons.jxpath.ri.parser.ParseException(token12, intArray19, strArray24);
        org.apache.commons.jxpath.JXPathContext jXPathContext26 = jXPathContextFactory4.newContext(jXPathContext11, (java.lang.Object) token12);
        java.util.Locale locale27 = jXPathContext26.getLocale();
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer29 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "preceding");
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer30 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node3, locale27);
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer dynaBeanPointer31 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPointer(qName1, dynaBean2, locale27);
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer33 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale27, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer35 = nullPointer33.namespacePointer("/");
        java.lang.Object obj36 = nullPointer33.getBaseValue();
        org.junit.Assert.assertNotNull(jXPathContextFactory4);
        org.junit.Assert.assertNull(nodePointer8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNull(namespaceResolver10);
        org.junit.Assert.assertNotNull(jXPathContext11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray14), "[10]");
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray16), "[10]");
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray18), "[10]");
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jXPathContext26);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertEquals(locale27.toString(), "en_GB");
        org.junit.Assert.assertNull(nodePointer35);
        org.junit.Assert.assertNull(obj36);
    }

}
