import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0142");
        org.apache.commons.codec.binary.Base64 base64_1 = new org.apache.commons.codec.binary.Base64((int) '#');
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_9 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray8);
        java.math.BigInteger bigInteger10 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray8);
        java.lang.Object obj11 = base64_1.decode((java.lang.Object) byteArray8);
        org.apache.commons.codec.DecoderException decoderException13 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray14 = decoderException13.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException16 = new org.apache.commons.codec.DecoderException("");
        decoderException13.addSuppressed((java.lang.Throwable) decoderException16);
        org.apache.commons.codec.DecoderException decoderException19 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray20 = decoderException19.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException22 = new org.apache.commons.codec.DecoderException("");
        decoderException19.addSuppressed((java.lang.Throwable) decoderException22);
        decoderException16.addSuppressed((java.lang.Throwable) decoderException19);
        try {
            java.lang.Object obj25 = base64_1.encode((java.lang.Object) decoderException19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base64 encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        }
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray8), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        boolean boolean3 = base64InputStream2.markSupported();
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream2, false);
        byte[] byteArray6 = null;
        try {
            int int7 = base64InputStream5.read(byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test0311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0311");
        org.apache.commons.codec.binary.Base64 base64_1 = new org.apache.commons.codec.binary.Base64(100);
        byte[] byteArray4 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_5 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray4);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_13 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray12);
        byte[] byteArray14 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray12);
        byte[] byteArray15 = base64_5.encode(byteArray14);
        byte[] byteArray22 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_23 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray22);
        byte[] byteArray24 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray22);
        byte[] byteArray25 = base64_5.decode(byteArray24);
        boolean boolean26 = base64_5.isUrlSafe();
        byte[] byteArray29 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_30 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray29);
        byte[] byteArray37 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_38 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray37);
        byte[] byteArray39 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray37);
        byte[] byteArray40 = base64_30.encode(byteArray39);
        byte[] byteArray47 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_48 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray47);
        byte[] byteArray49 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray47);
        byte[] byteArray50 = base64_30.decode(byteArray49);
        byte[] byteArray51 = base64_5.decode(byteArray49);
        boolean boolean52 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray51);
        byte[] byteArray54 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray51, false);
        byte[] byteArray55 = base64_1.encode(byteArray51);
        java.io.InputStream inputStream56 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream58 = new org.apache.commons.codec.binary.Base64InputStream(inputStream56, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream59 = new org.apache.commons.codec.binary.Base64InputStream(inputStream56);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream61 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream59, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream63 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream59, false);
        org.apache.commons.codec.binary.Base64 base64_67 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray68 = null;
        byte[] byteArray69 = base64_67.decode(byteArray68);
        byte[] byteArray76 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_77 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray76);
        byte[] byteArray78 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray76);
        byte[] byteArray79 = base64_67.encode(byteArray78);
        byte[] byteArray82 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray83 = base64_67.decode(byteArray82);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream84 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream59, true, (int) (short) 10, byteArray82);
        boolean boolean85 = base64InputStream59.markSupported();
        boolean boolean86 = base64InputStream59.markSupported();
        try {
            java.lang.Object obj87 = base64_1.encode((java.lang.Object) boolean86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base64 encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0]");
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray12), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray24), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray25), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray29), "[0]");
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray39), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray40), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray47), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray49), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray50), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray51), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[65, 65, 69, 66, 65, 102, 56, 61]");
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray55), "[65, 65, 69, 66, 65, 102, 56, 61]");
        org.junit.Assert.assertNull(byteArray69);
        org.junit.Assert.assertNotNull(byteArray76);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray76), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray78);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray78), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray79), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray82), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray83), "[]");
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test0622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0622");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_7 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray6);
        java.io.OutputStream outputStream8 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream9 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream8);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream11 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream9, true);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream13 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream9, true);
        base64OutputStream13.write(0);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream16 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream13);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream17 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream13);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream18 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream17);
        base64OutputStream17.write(0);
        base64OutputStream17.write(0);
        org.apache.commons.codec.binary.Base64 base64_24 = new org.apache.commons.codec.binary.Base64((int) '#');
        byte[] byteArray31 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_32 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray31);
        java.math.BigInteger bigInteger33 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray31);
        java.lang.Object obj34 = base64_24.decode((java.lang.Object) byteArray31);
        byte[] byteArray37 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_38 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray37);
        byte[] byteArray45 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_46 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray45);
        byte[] byteArray47 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray45);
        byte[] byteArray48 = base64_38.encode(byteArray47);
        byte[] byteArray55 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_56 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray55);
        byte[] byteArray57 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray55);
        byte[] byteArray58 = base64_38.decode(byteArray57);
        byte[] byteArray65 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_66 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray65);
        byte[] byteArray67 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray65);
        byte[] byteArray70 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray67, false, true);
        byte[] byteArray71 = base64_38.encode(byteArray70);
        boolean boolean72 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray71);
        java.math.BigInteger bigInteger73 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray71);
        byte[] byteArray74 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger73);
        byte[] byteArray75 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger73);
        byte[] byteArray76 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger73);
        byte[] byteArray77 = base64_24.decode(byteArray76);
        base64OutputStream17.write(byteArray76, 0, (int) (short) 0);
        byte[] byteArray81 = base64_7.encode(byteArray76);
        byte[] byteArray82 = null;
        byte[] byteArray83 = base64_7.decode(byteArray82);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray31), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[0]");
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray45), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray47), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray48), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray55), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray57), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray58), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray65), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray67), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray70), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103]");
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray71), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 61]");
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray74), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 61]");
        org.junit.Assert.assertNotNull(byteArray75);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray75), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 61]");
        org.junit.Assert.assertNotNull(byteArray76);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray76), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 61]");
        org.junit.Assert.assertNotNull(byteArray77);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray77), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103]");
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[86, 86, 90, 87, 82, 49, 74, 115, 82, 110, 74, 83, 98, 84, 70, 81, 85, 107, 82, 67, 84, 49, 69, 121, 89, 122, 48, 61]");
        org.junit.Assert.assertNull(byteArray83);
    }

    @Test
    public void test0944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0944");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream1 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0);
        base64OutputStream1.write(1);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream4 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream1);
        byte[] byteArray13 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_14 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray13);
        java.math.BigInteger bigInteger15 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray13);
        byte[] byteArray16 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger15);
        byte[] byteArray17 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger15);
        byte[] byteArray18 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger15);
        byte[] byteArray21 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray18, false, true);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream22 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream1, false, (int) (byte) 10, byteArray18);
        org.apache.commons.codec.binary.Base64 base64_26 = new org.apache.commons.codec.binary.Base64((int) (short) 1);
        byte[] byteArray30 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_31 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray30);
        byte[] byteArray38 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_39 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray38);
        byte[] byteArray40 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray38);
        byte[] byteArray41 = base64_31.encode(byteArray40);
        byte[] byteArray48 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_49 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray48);
        byte[] byteArray50 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray48);
        byte[] byteArray51 = base64_31.decode(byteArray50);
        boolean boolean52 = base64_31.isUrlSafe();
        byte[] byteArray55 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_56 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray55);
        byte[] byteArray63 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_64 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray63);
        byte[] byteArray65 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray63);
        byte[] byteArray66 = base64_56.encode(byteArray65);
        byte[] byteArray73 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_74 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray73);
        byte[] byteArray75 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray73);
        byte[] byteArray76 = base64_56.decode(byteArray75);
        byte[] byteArray77 = base64_31.decode(byteArray75);
        org.apache.commons.codec.binary.Base64 base64_78 = new org.apache.commons.codec.binary.Base64((int) (byte) 10, byteArray77);
        byte[] byteArray80 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray77, true);
        byte[] byteArray81 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray77);
        byte[] byteArray83 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray77, true);
        byte[] byteArray86 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray77, true, true);
        byte[] byteArray87 = base64_26.decode(byteArray86);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream88 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream1, false, 10, byteArray87);
        java.lang.Class<?> wildcardClass89 = byteArray87.getClass();
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray13), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray16), "[]");
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[]");
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[]");
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[]");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray30), "[0]");
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray38), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray40), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray41), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray48), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray50), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray51);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray51), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray55), "[0]");
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray63), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray65), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray66), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray73);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray73), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray75);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray75), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray76);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray76), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray77);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray77), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray80), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[65, 65, 69, 66, 65, 102, 56, 61]");
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray83), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray86), "[65, 65, 69, 66, 65, 102, 56, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray87);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray87), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(wildcardClass89);
    }

    @Test
    public void test1119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1119");
        byte[] byteArray2 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_3 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray2);
        byte[] byteArray10 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray10);
        byte[] byteArray13 = base64_3.encode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_3.decode(byteArray22);
        byte[] byteArray31 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_32 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray31);
        java.math.BigInteger bigInteger33 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray31);
        byte[] byteArray34 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger33);
        org.apache.commons.codec.binary.Base64 base64_35 = new org.apache.commons.codec.binary.Base64((int) 'a', byteArray34);
        byte[] byteArray37 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray34, true);
        byte[] byteArray38 = base64_3.decode(byteArray34);
        boolean boolean39 = base64_3.isUrlSafe();
        org.apache.commons.codec.binary.Base64 base64_41 = new org.apache.commons.codec.binary.Base64((int) '#');
        byte[] byteArray44 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_45 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray44);
        byte[] byteArray52 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_53 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray52);
        byte[] byteArray54 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray52);
        byte[] byteArray55 = base64_45.encode(byteArray54);
        byte[] byteArray62 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_63 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray62);
        byte[] byteArray64 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray62);
        byte[] byteArray65 = base64_45.decode(byteArray64);
        byte[] byteArray66 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray64);
        byte[] byteArray67 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray64);
        byte[] byteArray68 = base64_41.encode(byteArray67);
        byte[] byteArray71 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_72 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray71);
        byte[] byteArray79 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_80 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray79);
        byte[] byteArray81 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray79);
        byte[] byteArray82 = base64_72.encode(byteArray81);
        byte[] byteArray84 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray81, true);
        java.lang.Object obj85 = base64_41.decode((java.lang.Object) byteArray84);
        boolean boolean86 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray84);
        java.math.BigInteger bigInteger87 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray84);
        byte[] byteArray88 = base64_3.decode(byteArray84);
        java.io.OutputStream outputStream89 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream90 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream89);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream92 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream90, true);
        base64OutputStream92.write((int) (byte) 100);
        try {
            java.lang.Object obj95 = base64_3.encode((java.lang.Object) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base64 encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[0]");
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray12), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray13), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray31), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray34), "[]");
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[]");
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray38), "[]");
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray44), "[0]");
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray52), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray55);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray55), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray62), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray64), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray65), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray66), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray67), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray68), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 57, 80, 81, 48, 75]");
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray71), "[0]");
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray79), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray82), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray84);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray84), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(obj85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(bigInteger87);
        org.junit.Assert.assertNotNull(byteArray88);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray88), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
    }

    @Test
    public void test1150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1150");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream1 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream3 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream1, true);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream4 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream1);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream6 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream4, true);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream8 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream6, true);
        base64OutputStream8.write((int) ' ');
    }

    @Test
    public void test1173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1173");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_13 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray12);
        java.math.BigInteger bigInteger14 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray12);
        byte[] byteArray15 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger14);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream16 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false, 0, byteArray15);
        boolean boolean17 = base64InputStream16.markSupported();
        org.apache.commons.codec.binary.Base64InputStream base64InputStream18 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream16);
        org.apache.commons.codec.binary.Base64 base64_20 = new org.apache.commons.codec.binary.Base64((int) '#');
        boolean boolean21 = base64_20.isUrlSafe();
        byte[] byteArray25 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_26 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray25);
        byte[] byteArray33 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_34 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray33);
        byte[] byteArray35 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray33);
        byte[] byteArray36 = base64_26.encode(byteArray35);
        byte[] byteArray43 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_44 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray43);
        byte[] byteArray45 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray43);
        byte[] byteArray46 = base64_26.decode(byteArray45);
        boolean boolean47 = base64_26.isUrlSafe();
        byte[] byteArray50 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_51 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray50);
        byte[] byteArray58 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_59 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray58);
        byte[] byteArray60 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray58);
        byte[] byteArray61 = base64_51.encode(byteArray60);
        byte[] byteArray68 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_69 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray68);
        byte[] byteArray70 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray68);
        byte[] byteArray71 = base64_51.decode(byteArray70);
        byte[] byteArray72 = base64_26.decode(byteArray70);
        org.apache.commons.codec.binary.Base64 base64_73 = new org.apache.commons.codec.binary.Base64((int) (byte) 10, byteArray72);
        byte[] byteArray74 = base64_20.decode(byteArray72);
        org.apache.commons.codec.binary.Base64 base64_76 = new org.apache.commons.codec.binary.Base64(false);
        byte[] byteArray83 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_84 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray83);
        byte[] byteArray85 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray83);
        byte[] byteArray88 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray85, false, true);
        byte[] byteArray89 = base64_76.encode(byteArray88);
        byte[] byteArray90 = org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(byteArray89);
        byte[] byteArray91 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray90);
        byte[] byteArray92 = base64_20.encode(byteArray90);
        try {
            int int93 = base64InputStream18.read(byteArray92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray12), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[]");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray25), "[0]");
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray35), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray36), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray43), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray45), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray46), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(byteArray50);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray50), "[0]");
        org.junit.Assert.assertNotNull(byteArray58);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray58), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray60);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray60), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray61), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray68);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray68), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray70), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray71), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray72), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray74), "[]");
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray83), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray85);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray85), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray88);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray88), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103]");
        org.junit.Assert.assertNotNull(byteArray89);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray89), "[85, 86, 86, 71, 82, 108, 70, 114, 82, 109, 49, 80, 82, 68, 66, 79, 81, 50, 99, 61]");
        org.junit.Assert.assertNotNull(byteArray90);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray90), "[86, 86, 90, 87, 82, 49, 74, 115, 82, 110, 74, 83, 98, 84, 70, 81, 85, 107, 82, 67, 84, 49, 69, 121, 89, 122, 48]");
        org.junit.Assert.assertNotNull(byteArray91);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray91), "[86, 108, 90, 97, 86, 49, 73, 120, 83, 110, 78, 83, 98, 107, 112, 84, 89, 108, 82, 71, 85, 86, 86, 114, 85, 107, 78, 85, 77, 85, 86, 53, 87, 88, 111, 119, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray92);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray92), "[86, 108, 90, 97, 86, 49, 73, 120, 83, 110, 78, 83, 98, 107, 112, 84, 89, 108, 82, 71, 85, 86, 86, 114, 85, 107, 78, 85, 77, 85, 86, 53, 87, 88, 111, 119]");
    }

    @Test
    public void test1239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1239");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream8 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream9 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream8);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream11 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream8, true);
        org.apache.commons.codec.binary.Base64 base64_13 = new org.apache.commons.codec.binary.Base64((int) (byte) 0);
        java.io.OutputStream outputStream14 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream15 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream14);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream17 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream15, true);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream19 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream15, true);
        base64OutputStream19.write(0);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream22 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream19);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream23 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream19);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream24 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream23);
        base64OutputStream23.write(0);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream28 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream23, true);
        byte[] byteArray37 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_38 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray37);
        java.math.BigInteger bigInteger39 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray37);
        byte[] byteArray40 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger39);
        byte[] byteArray42 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray40, false);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream43 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base64OutputStream23, false, (int) ' ', byteArray40);
        byte[] byteArray44 = org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(byteArray40);
        java.lang.Object obj45 = base64_13.decode((java.lang.Object) byteArray44);
        byte[] byteArray48 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray44, true, false);
        try {
            int int51 = base64InputStream11.read(byteArray48, (int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray40), "[]");
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray42), "[]");
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray44), "[]");
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray48), "[]");
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        org.apache.commons.codec.binary.Base64 base64_2 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray3 = null;
        byte[] byteArray4 = base64_2.decode(byteArray3);
        byte[] byteArray11 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_12 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray11);
        byte[] byteArray13 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray11);
        byte[] byteArray14 = base64_2.encode(byteArray13);
        byte[] byteArray17 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray18 = base64_2.decode(byteArray17);
        org.apache.commons.codec.binary.Base64 base64_19 = new org.apache.commons.codec.binary.Base64(100, byteArray18);
        byte[] byteArray26 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_27 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray26);
        byte[] byteArray28 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray26);
        byte[] byteArray30 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray28, true);
        java.lang.Object obj31 = base64_19.encode((java.lang.Object) byteArray30);
        byte[] byteArray36 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_37 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray36);
        byte[] byteArray44 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_45 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray44);
        byte[] byteArray46 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray44);
        byte[] byteArray47 = base64_37.encode(byteArray46);
        byte[] byteArray54 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_55 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray54);
        byte[] byteArray56 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray54);
        byte[] byteArray57 = base64_37.decode(byteArray56);
        boolean boolean58 = base64_37.isUrlSafe();
        byte[] byteArray61 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_62 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray61);
        byte[] byteArray69 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_70 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray69);
        byte[] byteArray71 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray69);
        byte[] byteArray72 = base64_62.encode(byteArray71);
        byte[] byteArray79 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_80 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray79);
        byte[] byteArray81 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray79);
        byte[] byteArray82 = base64_62.decode(byteArray81);
        byte[] byteArray83 = base64_37.decode(byteArray81);
        org.apache.commons.codec.binary.Base64 base64_84 = new org.apache.commons.codec.binary.Base64((int) (byte) 10, byteArray83);
        byte[] byteArray86 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray83, true);
        byte[] byteArray87 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray83);
        byte[] byteArray88 = org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(byteArray83);
        org.apache.commons.codec.binary.Base64 base64_90 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray83, true);
        byte[] byteArray91 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray83);
        byte[] byteArray94 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray91, true, true);
        boolean boolean95 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray94);
        byte[] byteArray96 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray94);
        byte[] byteArray97 = base64_19.decode(byteArray94);
        byte[] byteArray98 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray97);
        org.junit.Assert.assertNull(byteArray4);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray11), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray13), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray28), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray30), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(byteArray36);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray36), "[0]");
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray44), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray46), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray47), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray56), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray57);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray57), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray61), "[0]");
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray69), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray71), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray72), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray79);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray79), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray82), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray83);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray83), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray86), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray87);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray87), "[65, 65, 69, 66, 65, 102, 56, 61]");
        org.junit.Assert.assertNotNull(byteArray88);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray88), "[65, 65, 69, 66, 65, 102, 56]");
        org.junit.Assert.assertNotNull(byteArray91);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray91), "[]");
        org.junit.Assert.assertNotNull(byteArray94);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray94), "[]");
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(byteArray96);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray96), "[]");
        org.junit.Assert.assertNotNull(byteArray97);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray97), "[]");
        org.junit.Assert.assertNotNull(byteArray98);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray98), "[]");
    }

    @Test
    public void test1439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1439");
        java.io.OutputStream outputStream0 = null;
        byte[] byteArray6 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_7 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray6);
        org.apache.commons.codec.binary.Base64 base64_8 = new org.apache.commons.codec.binary.Base64((int) (byte) -1, byteArray6);
        byte[] byteArray11 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_12 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray11);
        byte[] byteArray19 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_20 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray19);
        byte[] byteArray21 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray19);
        byte[] byteArray22 = base64_12.encode(byteArray21);
        byte[] byteArray29 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_30 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray29);
        byte[] byteArray31 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray29);
        byte[] byteArray32 = base64_12.decode(byteArray31);
        byte[] byteArray33 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray31);
        byte[] byteArray35 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray31, false);
        java.math.BigInteger bigInteger36 = org.apache.commons.codec.binary.Base64.decodeInteger(byteArray31);
        byte[] byteArray37 = org.apache.commons.codec.binary.Base64.encodeInteger(bigInteger36);
        byte[] byteArray38 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray37);
        byte[] byteArray39 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray38);
        byte[] byteArray40 = org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(byteArray38);
        byte[] byteArray41 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray40);
        java.lang.Object obj42 = base64_8.decode((java.lang.Object) byteArray41);
        byte[] byteArray43 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray41);
        try {
            org.apache.commons.codec.binary.Base64OutputStream base64OutputStream44 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false, 0, byteArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: lineSeperator must not contain base64 characters: [VVZaR1JsRnBPVE5RVkRBOURRbw==??]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0]");
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray11), "[0]");
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray19), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray29), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray31);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray31), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray32), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray35), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[65, 81, 69, 66, 47, 119, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray38);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray38), "[81, 86, 70, 70, 81, 105, 57, 51, 80, 84, 48, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray39), "[65, 81, 69, 66, 47, 119, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray40), "[85, 86, 90, 71, 82, 108, 70, 112, 79, 84, 78, 81, 86, 68, 65, 57, 68, 81, 111]");
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray41), "[86, 86, 90, 97, 82, 49, 74, 115, 82, 110, 66, 80, 86, 69, 53, 82, 86, 107, 82, 66, 79, 85, 82, 82, 98, 119, 61, 61, 13, 10]");
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray43), "[86, 108, 90, 97, 89, 86, 73, 120, 83, 110, 78, 83, 98, 107, 74, 81, 86, 107, 85, 49, 85, 108, 90, 114, 85, 107, 74, 80, 86, 86, 74, 83, 89, 110, 99, 57, 80, 81, 48, 75]");
    }

    @Test
    public void test1455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1455");
        byte[] byteArray2 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_3 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray2);
        byte[] byteArray10 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray10);
        byte[] byteArray13 = base64_3.encode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_3.decode(byteArray22);
        byte[] byteArray24 = null;
        byte[] byteArray25 = base64_3.encode(byteArray24);
        org.apache.commons.codec.DecoderException decoderException27 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray28 = decoderException27.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException30 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray31 = decoderException30.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException33 = new org.apache.commons.codec.DecoderException("");
        decoderException30.addSuppressed((java.lang.Throwable) decoderException33);
        org.apache.commons.codec.EncoderException encoderException36 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.DecoderException: ");
        org.apache.commons.codec.EncoderException encoderException38 = new org.apache.commons.codec.EncoderException("org.apache.commons.codec.DecoderException: ");
        encoderException36.addSuppressed((java.lang.Throwable) encoderException38);
        decoderException33.addSuppressed((java.lang.Throwable) encoderException36);
        org.apache.commons.codec.DecoderException decoderException42 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray43 = decoderException42.getSuppressed();
        java.lang.Throwable[] throwableArray44 = decoderException42.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException46 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray47 = decoderException46.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException49 = new org.apache.commons.codec.DecoderException("");
        decoderException46.addSuppressed((java.lang.Throwable) decoderException49);
        org.apache.commons.codec.DecoderException decoderException52 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray53 = decoderException52.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException55 = new org.apache.commons.codec.DecoderException("");
        decoderException52.addSuppressed((java.lang.Throwable) decoderException55);
        org.apache.commons.codec.DecoderException decoderException58 = new org.apache.commons.codec.DecoderException("");
        java.lang.Throwable[] throwableArray59 = decoderException58.getSuppressed();
        org.apache.commons.codec.DecoderException decoderException61 = new org.apache.commons.codec.DecoderException("");
        decoderException58.addSuppressed((java.lang.Throwable) decoderException61);
        decoderException55.addSuppressed((java.lang.Throwable) decoderException58);
        decoderException49.addSuppressed((java.lang.Throwable) decoderException58);
        decoderException42.addSuppressed((java.lang.Throwable) decoderException49);
        decoderException33.addSuppressed((java.lang.Throwable) decoderException42);
        decoderException27.addSuppressed((java.lang.Throwable) decoderException33);
        java.lang.Throwable[] throwableArray68 = decoderException33.getSuppressed();
        try {
            java.lang.Object obj69 = base64_3.encode((java.lang.Object) decoderException33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base64 encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray2), "[0]");
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray12), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray13), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNull(byteArray25);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(throwableArray68);
    }

}
