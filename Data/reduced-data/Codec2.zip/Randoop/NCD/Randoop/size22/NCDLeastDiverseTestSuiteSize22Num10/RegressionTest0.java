import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0033");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream9 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream7, false);
        boolean boolean10 = base64InputStream7.markSupported();
        byte[] byteArray17 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_18 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray17);
        byte[] byteArray19 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray17);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray19, false, true);
        try {
            int int23 = base64InputStream7.read(byteArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray19), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103]");
    }

    @Test
    public void test0038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0038");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream9 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream7, false);
        byte[] byteArray12 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_13 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_13.encode(byteArray22);
        byte[] byteArray30 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_31 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray30);
        byte[] byteArray32 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray30);
        byte[] byteArray33 = base64_13.decode(byteArray32);
        byte[] byteArray34 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray32);
        try {
            int int35 = base64InputStream9.read(byteArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray12), "[0]");
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray30), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray32), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray34), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
    }

    @Test
    public void test0199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0199");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        try {
            base64InputStream28.close();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0347");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        try {
            base64InputStream28.reset();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0396");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            long long31 = base64InputStream28.skip(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0512");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            int int30 = base64InputStream29.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0526");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, true);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream31 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            int int32 = base64InputStream28.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0560");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, true);
        try {
            base64InputStream28.close();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0561");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            base64InputStream29.close();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0572");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        boolean boolean6 = base64InputStream3.markSupported();
        boolean boolean7 = base64InputStream3.markSupported();
        byte[] byteArray10 = new byte[] { (byte) 0 };
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64((int) (short) 100, byteArray10);
        byte[] byteArray18 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_19 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray18);
        byte[] byteArray20 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray18);
        byte[] byteArray21 = base64_11.encode(byteArray20);
        byte[] byteArray24 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray20, true, false);
        try {
            int int25 = base64InputStream3.read(byteArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[0]");
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray24), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61, 13, 10]");
    }

    @Test
    public void test0597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0597");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        byte[] byteArray29 = null;
        try {
            int int32 = base64InputStream28.read(byteArray29, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0675");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            base64InputStream29.mark((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0760");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            long long31 = base64InputStream28.skip((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0843");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream31 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream29, false);
        try {
            int int32 = base64InputStream31.available();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0865");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, false);
        try {
            int int31 = base64InputStream30.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0870");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, true);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream31 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            base64InputStream31.mark((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test0945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0945");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            base64InputStream28.close();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test1027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1027");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream29 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        byte[] byteArray30 = null;
        try {
            int int33 = base64InputStream28.read(byteArray30, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test1045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1045");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, true);
        try {
            long long32 = base64InputStream28.skip(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test1051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1051");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, false);
        try {
            int int31 = base64InputStream28.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

    @Test
    public void test1072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1072");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        boolean boolean29 = base64InputStream28.markSupported();
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28);
        try {
            int int31 = base64InputStream28.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test1220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1220");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base64InputStream base64InputStream2 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream3 = new org.apache.commons.codec.binary.Base64InputStream(inputStream0);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream5 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream7 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, false);
        org.apache.commons.codec.binary.Base64 base64_11 = new org.apache.commons.codec.binary.Base64(1);
        byte[] byteArray12 = null;
        byte[] byteArray13 = base64_11.decode(byteArray12);
        byte[] byteArray20 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) -1 };
        org.apache.commons.codec.binary.Base64 base64_21 = new org.apache.commons.codec.binary.Base64((int) (short) 0, byteArray20);
        byte[] byteArray22 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray20);
        byte[] byteArray23 = base64_11.encode(byteArray22);
        byte[] byteArray26 = new byte[] { (byte) -1, (byte) 1 };
        byte[] byteArray27 = base64_11.decode(byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream28 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream3, true, (int) (short) 10, byteArray26);
        org.apache.commons.codec.binary.Base64InputStream base64InputStream30 = new org.apache.commons.codec.binary.Base64InputStream((java.io.InputStream) base64InputStream28, true);
        try {
            int int31 = base64InputStream30.available();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray20), "[0, 1, 1, 1, -1]");
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[65, 65, 69, 66, 65, 102, 56, 61, 13, 10]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[81, 85, 70, 70, 81, 107, 70, 109, 79, 68, 48, 78, 67, 103, 61, 61]");
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[-1, 1]");
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
    }

}
