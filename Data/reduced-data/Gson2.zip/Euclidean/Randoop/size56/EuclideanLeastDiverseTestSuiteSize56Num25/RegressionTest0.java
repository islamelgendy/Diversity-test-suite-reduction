import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0018");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter30 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date32 = null;
        dateTypeAdapter30.write((com.google.gson.stream.JsonWriter) jsonTreeWriter31, date32);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter31.nullValue();
        gson0.toJson(jsonElement29, (com.google.gson.stream.JsonWriter) jsonTreeWriter31);
        com.google.gson.JsonPrimitive jsonPrimitive37 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean38 = jsonPrimitive37.isJsonNull();
        java.lang.String str39 = jsonPrimitive37.toString();
        boolean boolean40 = jsonPrimitive37.isJsonArray();
        char char41 = jsonPrimitive37.getAsCharacter();
        boolean boolean42 = jsonPrimitive37.isJsonNull();
        java.lang.Appendable appendable43 = null;
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive37, appendable43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "\"a\"" + "'", str39.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + char41 + "' != '" + 'a' + "'", char41 == 'a');
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test0144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0144");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory>(gson0, reflectiveTypeAdapterFactoryTypeAdapter1, reflectiveTypeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        int int5 = jsonArray4.size();
        com.google.gson.JsonArray jsonArray6 = new com.google.gson.JsonArray();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean9 = jsonPrimitive8.isJsonNull();
        java.lang.String str10 = jsonPrimitive8.toString();
        boolean boolean11 = jsonPrimitive8.isJsonArray();
        char char12 = jsonPrimitive8.getAsCharacter();
        boolean boolean13 = jsonPrimitive8.isJsonNull();
        jsonArray6.add((com.google.gson.JsonElement) jsonPrimitive8);
        com.google.gson.JsonElement jsonElement15 = null;
        boolean boolean16 = jsonArray6.remove(jsonElement15);
        boolean boolean17 = jsonArray6.getAsBoolean();
        jsonArray4.addAll(jsonArray6);
        java.lang.String str19 = jsonArray6.getAsString();
        com.google.gson.LongSerializationPolicy longSerializationPolicy20 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement22 = longSerializationPolicy20.serialize((java.lang.Long) (-1L));
        com.google.gson.JsonElement jsonElement24 = longSerializationPolicy20.serialize((java.lang.Long) 100L);
        com.google.gson.JsonElement jsonElement26 = longSerializationPolicy20.serialize((java.lang.Long) 100L);
        jsonArray6.add(jsonElement26);
        com.google.gson.JsonObject jsonObject28 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive30 = jsonObject28.getAsJsonPrimitive("\"a\"");
        jsonObject28.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonPrimitive jsonPrimitive36 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean37 = jsonPrimitive36.isJsonNull();
        java.lang.String str38 = jsonPrimitive36.toString();
        jsonObject28.add("", (com.google.gson.JsonElement) jsonPrimitive36);
        java.lang.Number number40 = jsonPrimitive36.getAsNumber();
        boolean boolean41 = jsonArray6.remove((com.google.gson.JsonElement) jsonPrimitive36);
        try {
            java.lang.Object obj42 = reflectiveTypeAdapterFactoryArrayTypeAdapter3.fromJsonTree((com.google.gson.JsonElement) jsonArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"a\"" + "'", str10.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + char12 + "' != '" + 'a' + "'", char12 == 'a');
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "a" + "'", str19.equals("a"));
        org.junit.Assert.assertNotNull(longSerializationPolicy20);
        org.junit.Assert.assertNotNull(jsonElement22);
        org.junit.Assert.assertNotNull(jsonElement24);
        org.junit.Assert.assertNotNull(jsonElement26);
        org.junit.Assert.assertNull(jsonPrimitive30);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "\"a\"" + "'", str38.equals("\"a\""));
        org.junit.Assert.assertNotNull(number40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test0182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0182");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        java.io.Writer writer45 = null;
        java.util.Date date46 = null;
        try {
            dateTypeAdapter0.toJson(writer45, date46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        try {
            float float46 = jsonObject12.getAsFloat();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonObject");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test0310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0310");
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter1 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter2 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = classTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter4 = classTypeAdapter3.nullSafe();
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        java.lang.String str11 = gson5.toString();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter12 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter13 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date14 = null;
        dateTypeAdapter12.write((com.google.gson.stream.JsonWriter) jsonTreeWriter13, date14);
        com.google.gson.stream.JsonWriter jsonWriter16 = jsonTreeWriter13.nullValue();
        jsonTreeWriter13.setHtmlSafe(false);
        boolean boolean19 = jsonTreeWriter13.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonTreeWriter13.value(0.0d);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter13.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter13.value((-1L));
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter13.beginArray();
        jsonTreeWriter13.setLenient(true);
        java.lang.Number number28 = null;
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter13.value(number28);
        com.google.gson.Gson gson30 = new com.google.gson.Gson();
        java.lang.Object obj31 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter32 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass33 = classTypeAdapter32.getClass();
        com.google.gson.JsonElement jsonElement34 = gson30.toJsonTree(obj31, (java.lang.reflect.Type) wildcardClass33);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken35 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass33);
        com.google.gson.JsonElement jsonElement36 = gson5.toJsonTree((java.lang.Object) number28, (java.lang.reflect.Type) wildcardClass33);
        try {
            java.lang.String str37 = classTypeAdapter3.toJson((java.lang.Class) wildcardClass33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Attempted to serialize java.lang.Class: com.google.gson.internal.bind.TypeAdapters$1. Forgot to register a type adapter?");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter0);
        org.junit.Assert.assertNotNull(classTypeAdapter1);
        org.junit.Assert.assertNotNull(classTypeAdapter2);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(classTypeAdapter4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertNotNull(jsonWriter16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(classTypeAdapter32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(jsonElement34);
        org.junit.Assert.assertNotNull(wildcardTypeToken35);
        org.junit.Assert.assertNotNull(jsonElement36);
    }

    @Test
    public void test0333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0333");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean11 = jsonPrimitive10.isJsonNull();
        java.lang.Number number12 = jsonPrimitive10.getAsNumber();
        char char13 = jsonPrimitive10.getAsCharacter();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter14 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date16 = null;
        dateTypeAdapter14.write((com.google.gson.stream.JsonWriter) jsonTreeWriter15, date16);
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter15.nullValue();
        jsonWriter18.setLenient(true);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonWriter18.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive10, jsonWriter18);
        java.lang.Object obj23 = null;
        java.lang.String str24 = gson0.toJson(obj23);
        com.google.gson.JsonObject jsonObject25 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive27 = jsonObject25.getAsJsonPrimitive("\"a\"");
        jsonObject25.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonPrimitive jsonPrimitive33 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean34 = jsonPrimitive33.isJsonNull();
        java.lang.String str35 = jsonPrimitive33.toString();
        jsonObject25.add("", (com.google.gson.JsonElement) jsonPrimitive33);
        jsonObject25.addProperty("a", "-1.0");
        java.lang.String str40 = gson0.toJson((com.google.gson.JsonElement) jsonObject25);
        com.google.gson.JsonPrimitive jsonPrimitive43 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        java.math.BigDecimal bigDecimal44 = jsonPrimitive43.getAsBigDecimal();
        byte byte45 = jsonPrimitive43.getAsByte();
        java.math.BigDecimal bigDecimal46 = jsonPrimitive43.getAsBigDecimal();
        jsonObject25.addProperty("com.google.gson.JsonParseException: com.google.gson.JsonSyntaxException: a", (java.lang.Number) bigDecimal46);
        try {
            com.google.gson.JsonNull jsonNull48 = jsonObject25.getAsJsonNull();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: This is not a JSON Null.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(number12);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + 'a' + "'", char13 == 'a');
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "null" + "'", str24.equals("null"));
        org.junit.Assert.assertNull(jsonPrimitive27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "\"a\"" + "'", str35.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{\"\":\"a\",\"a\":\"-1.0\"}" + "'", str40.equals("{\"\":\"a\",\"a\":\"-1.0\"}"));
        org.junit.Assert.assertNotNull(bigDecimal44);
        org.junit.Assert.assertTrue("'" + byte45 + "' != '" + (byte) -1 + "'", byte45 == (byte) -1);
        org.junit.Assert.assertNotNull(bigDecimal46);
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.TypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionTypeAdapter31 = null;
        java.lang.Class<com.google.gson.JsonIOException> jsonIOExceptionClass32 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionArrayTypeAdapter33 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException>(gson0, jsonIOExceptionTypeAdapter31, jsonIOExceptionClass32);
        com.google.gson.JsonPrimitive jsonPrimitive35 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        double double36 = jsonPrimitive35.getAsDouble();
        boolean boolean37 = jsonPrimitive35.isBoolean();
        java.lang.Appendable appendable38 = null;
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive35, appendable38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test0388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0388");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter1 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter2 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter3 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter4 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter5 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy11 = gson6.fromJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str14 = gson6.toJson((com.google.gson.JsonElement) jsonPrimitive13);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter15 = null;
        java.lang.Class<java.lang.Exception> exceptionClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson6, exceptionTypeAdapter15, exceptionClass16);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive20 = jsonObject18.getAsJsonPrimitive("\"a\"");
        jsonObject18.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter24 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter25 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date26 = null;
        dateTypeAdapter24.write((com.google.gson.stream.JsonWriter) jsonTreeWriter25, date26);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter25.nullValue();
        jsonTreeWriter25.setHtmlSafe(false);
        boolean boolean31 = jsonTreeWriter25.getSerializeNulls();
        boolean boolean32 = jsonTreeWriter25.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter25.nullValue();
        gson6.toJson((com.google.gson.JsonElement) jsonObject18, (com.google.gson.stream.JsonWriter) jsonTreeWriter25);
        boolean boolean35 = jsonTreeWriter25.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter25.value(0.0d);
        java.sql.Date date38 = null;
        sqlDateTypeAdapter0.write(jsonWriter37, date38);
        java.io.Reader reader40 = null;
        try {
            java.sql.Date date41 = sqlDateTypeAdapter0.fromJson(reader40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(dateTypeAdapter3);
        org.junit.Assert.assertNotNull(dateTypeAdapter4);
        org.junit.Assert.assertNotNull(dateTypeAdapter5);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(fieldNamingStrategy11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\"hi!\"" + "'", str14.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive20);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jsonWriter37);
    }

    @Test
    public void test0400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0400");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.JsonArray jsonArray31 = new com.google.gson.JsonArray();
        int int32 = jsonArray31.size();
        jsonArray31.add((java.lang.Boolean) false);
        java.util.Iterator<com.google.gson.JsonElement> jsonElementItor35 = jsonArray31.iterator();
        char char36 = jsonArray31.getAsCharacter();
        boolean boolean37 = jsonArray31.getAsBoolean();
        java.lang.Appendable appendable38 = null;
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonArray31, appendable38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(jsonElementItor35);
        org.junit.Assert.assertTrue("'" + char36 + "' != '" + 'f' + "'", char36 == 'f');
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        java.lang.Object obj1 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter2 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass3 = classTypeAdapter2.getClass();
        com.google.gson.JsonElement jsonElement4 = gson0.toJsonTree(obj1, (java.lang.reflect.Type) wildcardClass3);
        com.google.gson.JsonSyntaxException jsonSyntaxException7 = new com.google.gson.JsonSyntaxException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException8 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonSyntaxException7);
        com.google.gson.stream.MalformedJsonException malformedJsonException9 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonSyntaxException8);
        com.google.gson.JsonSyntaxException jsonSyntaxException10 = new com.google.gson.JsonSyntaxException("hi!", (java.lang.Throwable) malformedJsonException9);
        com.google.gson.JsonElement jsonElement11 = gson0.toJsonTree((java.lang.Object) malformedJsonException9);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonElement jsonElement16 = jsonObject12.remove("$");
        java.lang.String str17 = gson0.toJson((com.google.gson.JsonElement) jsonObject12);
        com.google.gson.Gson gson18 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive20 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter21 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass22 = classTypeAdapter21.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy23 = gson18.fromJson((com.google.gson.JsonElement) jsonPrimitive20, (java.lang.reflect.Type) wildcardClass22);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter24 = null;
        java.lang.Class<java.lang.Throwable> throwableClass25 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter26 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson18, throwableTypeAdapter24, throwableClass25);
        com.google.gson.TypeAdapter<java.lang.reflect.AnnotatedElement> annotatedElementTypeAdapter27 = null;
        java.lang.Class<java.lang.reflect.AnnotatedElement> annotatedElementClass28 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.AnnotatedElement> annotatedElementArrayTypeAdapter29 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.AnnotatedElement>(gson18, annotatedElementTypeAdapter27, annotatedElementClass28);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter30 = annotatedElementArrayTypeAdapter29.nullSafe();
        java.lang.String str31 = gson0.toJson((java.lang.Object) annotatedElementArrayTypeAdapter29);
        com.google.gson.JsonPrimitive jsonPrimitive33 = new com.google.gson.JsonPrimitive("com.google.gson.JsonIOException: true");
        try {
            java.lang.Object obj34 = annotatedElementArrayTypeAdapter29.fromJsonTree((com.google.gson.JsonElement) jsonPrimitive33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was STRING");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNull(jsonElement16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{}" + "'", str17.equals("{}"));
        org.junit.Assert.assertNotNull(classTypeAdapter21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(fieldNamingStrategy23);
        org.junit.Assert.assertNotNull(objTypeAdapter30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{\"componentTypeAdapter\":{}}" + "'", str31.equals("{\"componentTypeAdapter\":{}}"));
    }

    @Test
    public void test0425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0425");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean11 = jsonPrimitive10.isJsonNull();
        java.lang.Number number12 = jsonPrimitive10.getAsNumber();
        char char13 = jsonPrimitive10.getAsCharacter();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter14 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date16 = null;
        dateTypeAdapter14.write((com.google.gson.stream.JsonWriter) jsonTreeWriter15, date16);
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter15.nullValue();
        jsonWriter18.setLenient(true);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonWriter18.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive10, jsonWriter18);
        java.lang.Object obj23 = null;
        java.lang.String str24 = gson0.toJson(obj23);
        com.google.gson.JsonObject jsonObject25 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive27 = jsonObject25.getAsJsonPrimitive("\"a\"");
        jsonObject25.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonPrimitive jsonPrimitive33 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean34 = jsonPrimitive33.isJsonNull();
        java.lang.String str35 = jsonPrimitive33.toString();
        jsonObject25.add("", (com.google.gson.JsonElement) jsonPrimitive33);
        jsonObject25.addProperty("a", "-1.0");
        java.lang.String str40 = gson0.toJson((com.google.gson.JsonElement) jsonObject25);
        com.google.gson.JsonPrimitive jsonPrimitive43 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        java.math.BigDecimal bigDecimal44 = jsonPrimitive43.getAsBigDecimal();
        byte byte45 = jsonPrimitive43.getAsByte();
        java.math.BigDecimal bigDecimal46 = jsonPrimitive43.getAsBigDecimal();
        jsonObject25.addProperty("com.google.gson.JsonParseException: com.google.gson.JsonSyntaxException: a", (java.lang.Number) bigDecimal46);
        com.google.gson.JsonArray jsonArray49 = jsonObject25.getAsJsonArray("com.google.gson.JsonIOException: true");
        boolean boolean51 = jsonObject25.has("");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(number12);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + 'a' + "'", char13 == 'a');
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "null" + "'", str24.equals("null"));
        org.junit.Assert.assertNull(jsonPrimitive27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "\"a\"" + "'", str35.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{\"\":\"a\",\"a\":\"-1.0\"}" + "'", str40.equals("{\"\":\"a\",\"a\":\"-1.0\"}"));
        org.junit.Assert.assertNotNull(bigDecimal44);
        org.junit.Assert.assertTrue("'" + byte45 + "' != '" + (byte) -1 + "'", byte45 == (byte) -1);
        org.junit.Assert.assertNotNull(bigDecimal46);
        org.junit.Assert.assertNull(jsonArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test0429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0429");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        jsonObject10.addProperty("a", "");
        com.google.gson.JsonObject jsonObject14 = jsonObject10.getAsJsonObject();
        jsonObject10.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader18 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.Gson gson19 = new com.google.gson.Gson();
        java.lang.Object obj20 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter21 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass22 = classTypeAdapter21.getClass();
        com.google.gson.JsonElement jsonElement23 = gson19.toJsonTree(obj20, (java.lang.reflect.Type) wildcardClass22);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken24 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass22);
        java.lang.reflect.AnnotatedElement annotatedElement25 = gson0.fromJson((com.google.gson.stream.JsonReader) jsonTreeReader18, (java.lang.reflect.Type) wildcardClass22);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter26 = null;
        java.lang.Class<java.lang.Exception> exceptionClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter26, exceptionClass27);
        com.google.gson.JsonObject jsonObject29 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive31 = jsonObject29.getAsJsonPrimitive("hi!");
        com.google.gson.JsonElement jsonElement33 = jsonObject29.remove("$");
        boolean boolean35 = jsonObject29.has("$");
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet36 = jsonObject29.entrySet();
        jsonObject29.addProperty("", (java.lang.Character) 'a');
        com.google.gson.JsonPrimitive jsonPrimitive42 = new com.google.gson.JsonPrimitive((java.lang.Character) ' ');
        jsonObject29.add("{\"cause\":{\"detailMessage\":\"com.google.gson.JsonSyntaxException: hi!\",\"cause\":{\"detailMessage\":\"hi!\",\"stackTrace\":[],\"suppressedExceptions\":[]},\"stackTrace\":[],\"suppressedExceptions\":[]},\"stackTrace\":[],\"suppressedExceptions\":[]}", (com.google.gson.JsonElement) jsonPrimitive42);
        java.lang.Appendable appendable44 = null;
        try {
            gson0.toJson((java.lang.Object) jsonObject29, appendable44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonObject14);
        org.junit.Assert.assertNotNull(classTypeAdapter21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNotNull(wildcardTypeToken24);
        org.junit.Assert.assertNull(annotatedElement25);
        org.junit.Assert.assertNull(jsonPrimitive31);
        org.junit.Assert.assertNull(jsonElement33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strEntrySet36);
    }

    @Test
    public void test0435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0435");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isJsonPrimitive();
        char char7 = jsonPrimitive1.getAsCharacter();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        boolean boolean38 = jsonPrimitive1.equals((java.lang.Object) jsonTreeWriter27);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.value("{}");
        try {
            com.google.gson.stream.JsonWriter jsonWriter41 = jsonWriter40.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        try {
            int int49 = jsonArray0.getAsInt();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0551");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value(false);
        try {
            com.google.gson.stream.JsonWriter jsonWriter47 = jsonTreeWriter39.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
    }

    @Test
    public void test0552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0552");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isJsonPrimitive();
        char char7 = jsonPrimitive1.getAsCharacter();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        boolean boolean38 = jsonPrimitive1.equals((java.lang.Object) jsonTreeWriter27);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.value("{}");
        try {
            com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter27.name("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
    }

    @Test
    public void test0556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0556");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time1 = null;
        com.google.gson.JsonElement jsonElement2 = timeTypeAdapter0.toJsonTree(time1);
        java.sql.Time time3 = null;
        com.google.gson.JsonElement jsonElement4 = timeTypeAdapter0.toJsonTree(time3);
        java.sql.Time time5 = null;
        com.google.gson.JsonElement jsonElement6 = timeTypeAdapter0.toJsonTree(time5);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter7 = timeTypeAdapter0.nullSafe();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader37 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject20);
        com.google.gson.JsonArray jsonArray39 = jsonObject20.getAsJsonArray("[{}]");
        jsonObject20.addProperty("1", "$");
        com.google.gson.JsonPrimitive jsonPrimitive44 = jsonObject20.getAsJsonPrimitive("{\"\":100.0,\"$\":\" \"}");
        try {
            java.sql.Time time45 = timeTypeAdapter7.fromJsonTree((com.google.gson.JsonElement) jsonObject20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected STRING but was BEGIN_OBJECT");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(jsonElement6);
        org.junit.Assert.assertNotNull(timeTypeAdapter7);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNull(jsonArray39);
        org.junit.Assert.assertNull(jsonPrimitive44);
    }

    @Test
    public void test0580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0580");
        com.google.gson.internal.LazilyParsedNumber lazilyParsedNumber1 = new com.google.gson.internal.LazilyParsedNumber("com.google.gson.JsonSyntaxException: hi!");
        java.lang.String str2 = lazilyParsedNumber1.toString();
        java.lang.String str3 = lazilyParsedNumber1.toString();
        com.google.gson.Gson gson4 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive6 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter7 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass8 = classTypeAdapter7.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy9 = gson4.fromJson((com.google.gson.JsonElement) jsonPrimitive6, (java.lang.reflect.Type) wildcardClass8);
        com.google.gson.JsonPrimitive jsonPrimitive11 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str12 = gson4.toJson((com.google.gson.JsonElement) jsonPrimitive11);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter13 = null;
        java.lang.Class<java.lang.Exception> exceptionClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson4, exceptionTypeAdapter13, exceptionClass14);
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive18 = jsonObject16.getAsJsonPrimitive("\"a\"");
        jsonObject16.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter22 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter23 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date24 = null;
        dateTypeAdapter22.write((com.google.gson.stream.JsonWriter) jsonTreeWriter23, date24);
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter23.nullValue();
        jsonTreeWriter23.setHtmlSafe(false);
        boolean boolean29 = jsonTreeWriter23.getSerializeNulls();
        boolean boolean30 = jsonTreeWriter23.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter31 = jsonTreeWriter23.nullValue();
        gson4.toJson((com.google.gson.JsonElement) jsonObject16, (com.google.gson.stream.JsonWriter) jsonTreeWriter23);
        com.google.gson.JsonElement jsonElement33 = jsonTreeWriter23.get();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter23.value(false);
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter23.value(false);
        boolean boolean38 = lazilyParsedNumber1.equals((java.lang.Object) jsonWriter37);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonWriter37.value("100");
        try {
            com.google.gson.stream.JsonWriter jsonWriter42 = jsonWriter37.name("\"JsonTreeReader\"");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "com.google.gson.JsonSyntaxException: hi!" + "'", str2.equals("com.google.gson.JsonSyntaxException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.google.gson.JsonSyntaxException: hi!" + "'", str3.equals("com.google.gson.JsonSyntaxException: hi!"));
        org.junit.Assert.assertNotNull(classTypeAdapter7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(fieldNamingStrategy9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "\"hi!\"" + "'", str12.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive18);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jsonWriter31);
        org.junit.Assert.assertNotNull(jsonElement33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
    }

    @Test
    public void test0583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0583");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value((double) 0.0f);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value(false);
        try {
            com.google.gson.stream.JsonWriter jsonWriter49 = jsonTreeWriter39.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
    }

    @Test
    public void test0585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0585");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        java.util.Date date45 = null;
        try {
            java.lang.String str46 = dateTypeAdapter0.toJson(date45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
    }

    @Test
    public void test0591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0591");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isJsonPrimitive();
        char char7 = jsonPrimitive1.getAsCharacter();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        boolean boolean38 = jsonPrimitive1.equals((java.lang.Object) jsonTreeWriter27);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.value("{}");
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter27.value(100L);
        com.google.gson.stream.JsonWriter jsonWriter43 = jsonWriter42.nullValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertNotNull(jsonWriter43);
    }

    @Test
    public void test0642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0642");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter30 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date32 = null;
        dateTypeAdapter30.write((com.google.gson.stream.JsonWriter) jsonTreeWriter31, date32);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter31.nullValue();
        gson0.toJson(jsonElement29, (com.google.gson.stream.JsonWriter) jsonTreeWriter31);
        com.google.gson.TypeAdapter<java.lang.Number> numberTypeAdapter36 = com.google.gson.internal.bind.TypeAdapters.FLOAT;
        java.lang.String str37 = gson0.toJson((java.lang.Object) numberTypeAdapter36);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter38 = null;
        java.lang.Class<java.lang.Exception> exceptionClass39 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter40 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter38, exceptionClass39);
        com.google.gson.stream.JsonReader jsonReader41 = null;
        try {
            java.lang.Object obj42 = exceptionArrayTypeAdapter40.read(jsonReader41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(numberTypeAdapter36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "null" + "'", str37.equals("null"));
    }

    @Test
    public void test0666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0666");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonObject jsonObject29 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive31 = jsonObject29.getAsJsonPrimitive("hi!");
        java.lang.String str32 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive31);
        com.google.gson.LongSerializationPolicy longSerializationPolicy33 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.Gson gson34 = new com.google.gson.Gson();
        java.lang.Object obj35 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter36 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass37 = classTypeAdapter36.getClass();
        com.google.gson.JsonElement jsonElement38 = gson34.toJsonTree(obj35, (java.lang.reflect.Type) wildcardClass37);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken39 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass37);
        com.google.gson.JsonElement jsonElement40 = gson0.toJsonTree((java.lang.Object) longSerializationPolicy33, (java.lang.reflect.Type) wildcardClass37);
        java.lang.String str41 = gson0.toString();
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNull(jsonPrimitive31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "null" + "'", str32.equals("null"));
        org.junit.Assert.assertNotNull(longSerializationPolicy33);
        org.junit.Assert.assertNotNull(classTypeAdapter36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(jsonElement38);
        org.junit.Assert.assertNotNull(wildcardTypeToken39);
        org.junit.Assert.assertNotNull(jsonElement40);
    }

    @Test
    public void test0682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0682");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        boolean boolean46 = jsonObject0.has("[\"a\"]");
        try {
            boolean boolean47 = jsonObject0.getAsBoolean();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonObject");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test0704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0704");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value((double) 0.0f);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value(true);
        jsonTreeWriter39.setHtmlSafe(false);
        jsonTreeWriter39.flush();
        com.google.gson.stream.JsonWriter jsonWriter53 = jsonTreeWriter39.value(false);
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
        org.junit.Assert.assertNotNull(jsonWriter53);
    }

    @Test
    public void test0705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0705");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonElement jsonElement1 = null;
        java.lang.String str2 = gson0.toJson(jsonElement1);
        com.google.gson.TypeAdapterFactory typeAdapterFactory3 = com.google.gson.internal.bind.TypeAdapters.URL_FACTORY;
        com.google.gson.JsonElement jsonElement4 = gson0.toJsonTree((java.lang.Object) typeAdapterFactory3);
        java.lang.String str5 = gson0.toString();
        com.google.gson.TypeAdapter<com.google.gson.LongSerializationPolicy> longSerializationPolicyTypeAdapter6 = null;
        java.lang.Class<com.google.gson.LongSerializationPolicy> longSerializationPolicyClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.LongSerializationPolicy> longSerializationPolicyArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.LongSerializationPolicy>(gson0, longSerializationPolicyTypeAdapter6, longSerializationPolicyClass7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader11 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonPrimitive10);
        java.lang.String str12 = jsonTreeReader11.getPath();
        jsonTreeReader11.setLenient(false);
        jsonTreeReader11.close();
        java.lang.String str16 = jsonTreeReader11.getPath();
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive19 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter20 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass21 = classTypeAdapter20.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy22 = gson17.fromJson((com.google.gson.JsonElement) jsonPrimitive19, (java.lang.reflect.Type) wildcardClass21);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter23 = null;
        java.lang.Class<java.lang.Throwable> throwableClass24 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter25 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson17, throwableTypeAdapter23, throwableClass24);
        com.google.gson.Gson gson27 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive29 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter30 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass31 = classTypeAdapter30.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy32 = gson27.fromJson((com.google.gson.JsonElement) jsonPrimitive29, (java.lang.reflect.Type) wildcardClass31);
        java.lang.String str33 = gson17.toJson((java.lang.Object) 0.0f, (java.lang.reflect.Type) wildcardClass31);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken34 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass31);
        try {
            java.lang.reflect.Type type35 = gson0.fromJson((com.google.gson.stream.JsonReader) jsonTreeReader11, (java.lang.reflect.Type) wildcardClass31);
            org.junit.Assert.fail("Expected exception of type com.google.gson.JsonSyntaxException; message: java.lang.IllegalStateException: JsonReader is closed");
        } catch (com.google.gson.JsonSyntaxException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "null" + "'", str2.equals("null"));
        org.junit.Assert.assertNotNull(typeAdapterFactory3);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "$" + "'", str12.equals("$"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "$" + "'", str16.equals("$"));
        org.junit.Assert.assertNotNull(classTypeAdapter20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(fieldNamingStrategy22);
        org.junit.Assert.assertNotNull(classTypeAdapter30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNull(fieldNamingStrategy32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "null" + "'", str33.equals("null"));
        org.junit.Assert.assertNotNull(wildcardTypeToken34);
    }

    @Test
    public void test0723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0723");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value(false);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value("com.google.gson.JsonIOException: 1");
        jsonTreeWriter39.setIndent("com.google.gson.JsonIOException: \"a\"");
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter13 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass14 = classTypeAdapter13.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy15 = gson10.fromJson((com.google.gson.JsonElement) jsonPrimitive12, (java.lang.reflect.Type) wildcardClass14);
        java.lang.String str16 = gson0.toJson((java.lang.Object) 0.0f, (java.lang.reflect.Type) wildcardClass14);
        com.google.gson.JsonPrimitive jsonPrimitive18 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean19 = jsonPrimitive18.isJsonNull();
        java.lang.Number number20 = jsonPrimitive18.getAsNumber();
        char char21 = jsonPrimitive18.getAsCharacter();
        com.google.gson.internal.Excluder excluder22 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.Excluder excluder24 = excluder22.withVersion((double) (short) 0);
        com.google.gson.internal.Excluder excluder25 = excluder24.disableInnerClassSerialization();
        boolean boolean26 = jsonPrimitive18.equals((java.lang.Object) excluder24);
        com.google.gson.JsonElement jsonElement27 = gson0.toJsonTree((java.lang.Object) jsonPrimitive18);
        java.lang.Object obj28 = null;
        com.google.gson.Gson gson29 = new com.google.gson.Gson();
        java.lang.Object obj30 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter31 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass32 = classTypeAdapter31.getClass();
        com.google.gson.JsonElement jsonElement33 = gson29.toJsonTree(obj30, (java.lang.reflect.Type) wildcardClass32);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken34 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass32);
        java.lang.String str35 = gson0.toJson(obj28, (java.lang.reflect.Type) wildcardClass32);
        java.io.Writer writer36 = null;
        try {
            com.google.gson.stream.JsonWriter jsonWriter37 = gson0.newJsonWriter(writer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNotNull(classTypeAdapter13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(fieldNamingStrategy15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(number20);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + 'a' + "'", char21 == 'a');
        org.junit.Assert.assertNotNull(excluder22);
        org.junit.Assert.assertNotNull(excluder24);
        org.junit.Assert.assertNotNull(excluder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jsonElement27);
        org.junit.Assert.assertNotNull(classTypeAdapter31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(jsonElement33);
        org.junit.Assert.assertNotNull(wildcardTypeToken34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "null" + "'", str35.equals("null"));
    }

    @Test
    public void test0791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0791");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter1 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter2 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter3 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter4 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter5 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy11 = gson6.fromJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str14 = gson6.toJson((com.google.gson.JsonElement) jsonPrimitive13);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter15 = null;
        java.lang.Class<java.lang.Exception> exceptionClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson6, exceptionTypeAdapter15, exceptionClass16);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive20 = jsonObject18.getAsJsonPrimitive("\"a\"");
        jsonObject18.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter24 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter25 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date26 = null;
        dateTypeAdapter24.write((com.google.gson.stream.JsonWriter) jsonTreeWriter25, date26);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter25.nullValue();
        jsonTreeWriter25.setHtmlSafe(false);
        boolean boolean31 = jsonTreeWriter25.getSerializeNulls();
        boolean boolean32 = jsonTreeWriter25.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter25.nullValue();
        gson6.toJson((com.google.gson.JsonElement) jsonObject18, (com.google.gson.stream.JsonWriter) jsonTreeWriter25);
        boolean boolean35 = jsonTreeWriter25.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter25.value(0.0d);
        java.sql.Date date38 = null;
        sqlDateTypeAdapter0.write(jsonWriter37, date38);
        java.sql.Date date40 = null;
        try {
            java.lang.String str41 = sqlDateTypeAdapter0.toJson(date40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: JSON must start with an array or an object.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(dateTypeAdapter3);
        org.junit.Assert.assertNotNull(dateTypeAdapter4);
        org.junit.Assert.assertNotNull(dateTypeAdapter5);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(fieldNamingStrategy11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\"hi!\"" + "'", str14.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive20);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jsonWriter37);
    }

    @Test
    public void test0801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0801");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.JsonObject jsonObject46 = jsonObject0.getAsJsonObject("null");
        try {
            com.google.gson.JsonPrimitive jsonPrimitive48 = jsonObject46.getAsJsonPrimitive("com.google.gson.JsonSyntaxException: [\"a\"]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(jsonObject46);
    }

    @Test
    public void test0807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0807");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        java.util.Date date45 = null;
        com.google.gson.JsonElement jsonElement46 = dateTypeAdapter0.toJsonTree(date45);
        java.io.Writer writer47 = null;
        java.util.Date date48 = null;
        try {
            dateTypeAdapter0.toJson(writer47, date48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonElement46);
    }

    @Test
    public void test0813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0813");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value((double) 0.0f);
        try {
            com.google.gson.stream.JsonWriter jsonWriter47 = jsonWriter46.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
    }

    @Test
    public void test0823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0823");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterTypeAdapter12 = null;
        java.lang.Class<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterClass13 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter> timeTypeAdapterArrayTypeAdapter14 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.TimeTypeAdapter>(gson0, timeTypeAdapterTypeAdapter12, timeTypeAdapterClass13);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.JsonTreeWriter> jsonTreeWriterTypeAdapter15 = null;
        java.lang.Class<com.google.gson.internal.bind.JsonTreeWriter> jsonTreeWriterClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.JsonTreeWriter> jsonTreeWriterArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.JsonTreeWriter>(gson0, jsonTreeWriterTypeAdapter15, jsonTreeWriterClass16);
        com.google.gson.JsonPrimitive jsonPrimitive19 = new com.google.gson.JsonPrimitive((java.lang.Boolean) true);
        boolean boolean20 = jsonPrimitive19.isJsonArray();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter21 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter22 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date23 = null;
        dateTypeAdapter21.write((com.google.gson.stream.JsonWriter) jsonTreeWriter22, date23);
        com.google.gson.stream.JsonWriter jsonWriter26 = jsonTreeWriter22.value(0.0d);
        boolean boolean27 = jsonPrimitive19.equals((java.lang.Object) jsonTreeWriter22);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter22.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter22.value(false);
        jsonTreeWriter22.flush();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter22.value("true");
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter22.value(10.0d);
        com.google.gson.JsonElement jsonElement36 = jsonTreeWriter22.get();
        java.lang.Appendable appendable37 = null;
        try {
            gson0.toJson(jsonElement36, appendable37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jsonWriter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement36);
    }

    @Test
    public void test0854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0854");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        java.lang.String str9 = gson0.toString();
        com.google.gson.JsonObject jsonObject10 = new com.google.gson.JsonObject();
        jsonObject10.addProperty("a", "");
        com.google.gson.JsonObject jsonObject14 = jsonObject10.getAsJsonObject();
        jsonObject10.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader18 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject10);
        com.google.gson.Gson gson19 = new com.google.gson.Gson();
        java.lang.Object obj20 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter21 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass22 = classTypeAdapter21.getClass();
        com.google.gson.JsonElement jsonElement23 = gson19.toJsonTree(obj20, (java.lang.reflect.Type) wildcardClass22);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken24 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass22);
        java.lang.reflect.AnnotatedElement annotatedElement25 = gson0.fromJson((com.google.gson.stream.JsonReader) jsonTreeReader18, (java.lang.reflect.Type) wildcardClass22);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter26 = null;
        java.lang.Class<java.lang.Exception> exceptionClass27 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter28 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter26, exceptionClass27);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter29 = exceptionArrayTypeAdapter28.nullSafe();
        com.google.gson.internal.Excluder excluder30 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.ExclusionStrategy exclusionStrategy31 = null;
        com.google.gson.internal.Excluder excluder34 = excluder30.withExclusionStrategy(exclusionStrategy31, false, false);
        com.google.gson.internal.Excluder excluder35 = excluder30.excludeFieldsWithoutExposeAnnotation();
        com.google.gson.internal.Excluder excluder36 = excluder35.disableInnerClassSerialization();
        com.google.gson.ExclusionStrategy exclusionStrategy37 = null;
        com.google.gson.internal.Excluder excluder40 = excluder36.withExclusionStrategy(exclusionStrategy37, false, false);
        com.google.gson.internal.Excluder excluder41 = excluder40.disableInnerClassSerialization();
        try {
            com.google.gson.JsonElement jsonElement42 = objTypeAdapter29.toJsonTree((java.lang.Object) excluder41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonObject14);
        org.junit.Assert.assertNotNull(classTypeAdapter21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNotNull(wildcardTypeToken24);
        org.junit.Assert.assertNull(annotatedElement25);
        org.junit.Assert.assertNotNull(objTypeAdapter29);
        org.junit.Assert.assertNotNull(excluder30);
        org.junit.Assert.assertNotNull(excluder34);
        org.junit.Assert.assertNotNull(excluder35);
        org.junit.Assert.assertNotNull(excluder36);
        org.junit.Assert.assertNotNull(excluder40);
        org.junit.Assert.assertNotNull(excluder41);
    }

    @Test
    public void test0914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0914");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.reflect.AnnotatedElement> annotatedElementTypeAdapter9 = null;
        java.lang.Class<java.lang.reflect.AnnotatedElement> annotatedElementClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.AnnotatedElement> annotatedElementArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.AnnotatedElement>(gson0, annotatedElementTypeAdapter9, annotatedElementClass10);
        com.google.gson.JsonElement jsonElement12 = null;
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter13 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter14 = timeTypeAdapter13.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement16 = jsonTreeWriter15.get();
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter15.value(true);
        java.sql.Time time19 = null;
        timeTypeAdapter13.write(jsonWriter18, time19);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter21 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter22 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date23 = null;
        dateTypeAdapter21.write((com.google.gson.stream.JsonWriter) jsonTreeWriter22, date23);
        com.google.gson.stream.JsonWriter jsonWriter25 = jsonTreeWriter22.nullValue();
        jsonWriter25.setLenient(true);
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonWriter25.value((double) ' ');
        java.sql.Time time30 = null;
        timeTypeAdapter13.write(jsonWriter25, time30);
        java.lang.Class<?> wildcardClass32 = jsonWriter25.getClass();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter33 = gson0.fromJson(jsonElement12, (java.lang.reflect.Type) wildcardClass32);
        com.google.gson.TypeAdapter<java.lang.reflect.Type> typeTypeAdapter34 = null;
        java.lang.Class<java.lang.reflect.Type> typeClass35 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.Type> typeArrayTypeAdapter36 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.reflect.Type>(gson0, typeTypeAdapter34, typeClass35);
        com.google.gson.JsonIOException jsonIOException39 = new com.google.gson.JsonIOException("\"a\"");
        com.google.gson.JsonSyntaxException jsonSyntaxException40 = new com.google.gson.JsonSyntaxException("hi!", (java.lang.Throwable) jsonIOException39);
        java.lang.Throwable[] throwableArray41 = jsonIOException39.getSuppressed();
        java.lang.String str42 = typeArrayTypeAdapter36.toJson((java.lang.Object) throwableArray41);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNotNull(timeTypeAdapter14);
        org.junit.Assert.assertNotNull(jsonElement16);
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter25);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNull(jsonTreeWriter33);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "[]" + "'", str42.equals("[]"));
    }

    @Test
    public void test0927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0927");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isNumber();
        com.google.gson.Gson gson7 = new com.google.gson.Gson();
        java.lang.Object obj8 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.JsonElement jsonElement11 = gson7.toJsonTree(obj8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonSyntaxException jsonSyntaxException14 = new com.google.gson.JsonSyntaxException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException15 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonSyntaxException14);
        com.google.gson.stream.MalformedJsonException malformedJsonException16 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonSyntaxException15);
        com.google.gson.JsonSyntaxException jsonSyntaxException17 = new com.google.gson.JsonSyntaxException("hi!", (java.lang.Throwable) malformedJsonException16);
        com.google.gson.JsonElement jsonElement18 = gson7.toJsonTree((java.lang.Object) malformedJsonException16);
        com.google.gson.TypeAdapter<com.google.gson.Gson> gsonTypeAdapter19 = null;
        java.lang.Class<com.google.gson.Gson> gsonClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.Gson> gsonArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.Gson>(gson7, gsonTypeAdapter19, gsonClass20);
        boolean boolean22 = jsonPrimitive1.equals((java.lang.Object) gson7);
        com.google.gson.JsonArray jsonArray23 = new com.google.gson.JsonArray();
        int int24 = jsonArray23.size();
        com.google.gson.JsonArray jsonArray25 = new com.google.gson.JsonArray();
        com.google.gson.JsonPrimitive jsonPrimitive27 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean28 = jsonPrimitive27.isJsonNull();
        java.lang.String str29 = jsonPrimitive27.toString();
        boolean boolean30 = jsonPrimitive27.isJsonArray();
        char char31 = jsonPrimitive27.getAsCharacter();
        boolean boolean32 = jsonPrimitive27.isJsonNull();
        jsonArray25.add((com.google.gson.JsonElement) jsonPrimitive27);
        com.google.gson.JsonElement jsonElement34 = null;
        boolean boolean35 = jsonArray25.remove(jsonElement34);
        boolean boolean36 = jsonArray25.getAsBoolean();
        jsonArray23.addAll(jsonArray25);
        java.lang.String str38 = jsonArray23.toString();
        java.lang.String str39 = gson7.toJson((com.google.gson.JsonElement) jsonArray23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(jsonElement11);
        org.junit.Assert.assertNotNull(jsonElement18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "\"a\"" + "'", str29.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + char31 + "' != '" + 'a' + "'", char31 == 'a');
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "[\"a\"]" + "'", str38.equals("[\"a\"]"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "[\"a\"]" + "'", str39.equals("[\"a\"]"));
    }

    @Test
    public void test0931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0931");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value((double) 0.0f);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value(true);
        try {
            com.google.gson.stream.JsonWriter jsonWriter50 = jsonTreeWriter39.name("$");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
    }

    @Test
    public void test0982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0982");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value(false);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value("com.google.gson.JsonIOException: 1");
        com.google.gson.stream.JsonWriter jsonWriter50 = jsonWriter48.value(true);
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
        org.junit.Assert.assertNotNull(jsonWriter50);
    }

    @Test
    public void test0987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0987");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter1 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter2 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter3 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter4 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter5 = sqlDateTypeAdapter0.nullSafe();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy11 = gson6.fromJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str14 = gson6.toJson((com.google.gson.JsonElement) jsonPrimitive13);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter15 = null;
        java.lang.Class<java.lang.Exception> exceptionClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson6, exceptionTypeAdapter15, exceptionClass16);
        com.google.gson.JsonObject jsonObject18 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive20 = jsonObject18.getAsJsonPrimitive("\"a\"");
        jsonObject18.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter24 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter25 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date26 = null;
        dateTypeAdapter24.write((com.google.gson.stream.JsonWriter) jsonTreeWriter25, date26);
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter25.nullValue();
        jsonTreeWriter25.setHtmlSafe(false);
        boolean boolean31 = jsonTreeWriter25.getSerializeNulls();
        boolean boolean32 = jsonTreeWriter25.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter33 = jsonTreeWriter25.nullValue();
        gson6.toJson((com.google.gson.JsonElement) jsonObject18, (com.google.gson.stream.JsonWriter) jsonTreeWriter25);
        boolean boolean35 = jsonTreeWriter25.isHtmlSafe();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter25.value(0.0d);
        java.sql.Date date38 = null;
        sqlDateTypeAdapter0.write(jsonWriter37, date38);
        java.io.Writer writer40 = null;
        java.sql.Date date41 = null;
        try {
            sqlDateTypeAdapter0.toJson(writer40, date41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(dateTypeAdapter2);
        org.junit.Assert.assertNotNull(dateTypeAdapter3);
        org.junit.Assert.assertNotNull(dateTypeAdapter4);
        org.junit.Assert.assertNotNull(dateTypeAdapter5);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(fieldNamingStrategy11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\"hi!\"" + "'", str14.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive20);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jsonWriter33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(jsonWriter37);
    }

    @Test
    public void test0997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0997");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        jsonObject0.addProperty("a", "");
        com.google.gson.JsonObject jsonObject4 = jsonObject0.getAsJsonObject();
        jsonObject0.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter38 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter39 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date40 = null;
        dateTypeAdapter38.write((com.google.gson.stream.JsonWriter) jsonTreeWriter39, date40);
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter39.nullValue();
        gson8.toJson(jsonElement37, (com.google.gson.stream.JsonWriter) jsonTreeWriter39);
        boolean boolean44 = jsonObject0.equals((java.lang.Object) jsonTreeWriter39);
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonTreeWriter39.value((double) 0.0f);
        com.google.gson.stream.JsonWriter jsonWriter48 = jsonTreeWriter39.value(true);
        try {
            com.google.gson.stream.JsonWriter jsonWriter49 = jsonWriter48.endObject();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jsonObject4);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertNotNull(jsonWriter48);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory>(gson0, reflectiveTypeAdapterFactoryTypeAdapter1, reflectiveTypeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Boolean) true);
        com.google.gson.Gson gson7 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter10 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass11 = classTypeAdapter10.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy12 = gson7.fromJson((com.google.gson.JsonElement) jsonPrimitive9, (java.lang.reflect.Type) wildcardClass11);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter13 = null;
        java.lang.Class<java.lang.Throwable> throwableClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson7, throwableTypeAdapter13, throwableClass14);
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive19 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter20 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass21 = classTypeAdapter20.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy22 = gson17.fromJson((com.google.gson.JsonElement) jsonPrimitive19, (java.lang.reflect.Type) wildcardClass21);
        java.lang.String str23 = gson7.toJson((java.lang.Object) 0.0f, (java.lang.reflect.Type) wildcardClass21);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken24 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass21);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter25 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date27 = null;
        dateTypeAdapter25.write((com.google.gson.stream.JsonWriter) jsonTreeWriter26, date27);
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter26.nullValue();
        jsonTreeWriter26.setHtmlSafe(false);
        boolean boolean32 = jsonTreeWriter26.getSerializeNulls();
        boolean boolean33 = jsonTreeWriter26.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter26.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonWriter34.value((long) (short) -1);
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonWriter36.value(0.0d);
        gson0.toJson((java.lang.Object) true, (java.lang.reflect.Type) wildcardClass21, jsonWriter38);
        boolean boolean40 = jsonWriter38.isLenient();
        org.junit.Assert.assertNotNull(classTypeAdapter10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(fieldNamingStrategy12);
        org.junit.Assert.assertNotNull(classTypeAdapter20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(fieldNamingStrategy22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "null" + "'", str23.equals("null"));
        org.junit.Assert.assertNotNull(wildcardTypeToken24);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter36);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        com.google.gson.JsonParseException jsonParseException46 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException44);
        com.google.gson.JsonSyntaxException jsonSyntaxException47 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException46);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1036");
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter0 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter1 = timeTypeAdapter0.nullSafe();
        java.sql.Time time2 = null;
        com.google.gson.JsonElement jsonElement3 = timeTypeAdapter0.toJsonTree(time2);
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter4 = timeTypeAdapter0.nullSafe();
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = jsonTreeWriter24.get();
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonTreeWriter24.value(false);
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter24.value(0.0d);
        boolean boolean39 = jsonTreeWriter24.isHtmlSafe();
        java.sql.Time time40 = null;
        timeTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, time40);
        java.io.Reader reader42 = null;
        try {
            java.sql.Time time43 = timeTypeAdapter0.fromJson(reader42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: in == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(timeTypeAdapter4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonElement34);
        org.junit.Assert.assertNotNull(jsonWriter36);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test1092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1092");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        try {
            byte byte49 = jsonArray0.getAsByte();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test1125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1125");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        jsonObject14.addProperty("[\"a\",false,true,JsonTreeReader]", (java.lang.Character) 't');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test1134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1134");
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter0 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Date> dateTypeAdapter1 = sqlDateTypeAdapter0.nullSafe();
        java.sql.Date date2 = null;
        com.google.gson.JsonElement jsonElement3 = sqlDateTypeAdapter0.toJsonTree(date2);
        java.sql.Date date4 = null;
        com.google.gson.JsonElement jsonElement5 = sqlDateTypeAdapter0.toJsonTree(date4);
        java.sql.Date date6 = null;
        com.google.gson.JsonElement jsonElement7 = sqlDateTypeAdapter0.toJsonTree(date6);
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonTreeWriter27.beginObject();
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.name("true");
        java.lang.Number number41 = null;
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter27.value(number41);
        java.sql.Date date43 = null;
        try {
            sqlDateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(dateTypeAdapter1);
        org.junit.Assert.assertNotNull(jsonElement3);
        org.junit.Assert.assertNotNull(jsonElement5);
        org.junit.Assert.assertNotNull(jsonElement7);
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
    }

    @Test
    public void test1152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1152");
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter1 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter2 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = classTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter4 = classTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = classTypeAdapter4.nullSafe();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy11 = gson6.fromJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str14 = gson6.toJson((com.google.gson.JsonElement) jsonPrimitive13);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter15 = null;
        java.lang.Class<java.lang.Exception> exceptionClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson6, exceptionTypeAdapter15, exceptionClass16);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter19 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time20 = null;
        com.google.gson.JsonElement jsonElement21 = timeTypeAdapter19.toJsonTree(time20);
        java.sql.Time time22 = null;
        com.google.gson.JsonElement jsonElement23 = timeTypeAdapter19.toJsonTree(time22);
        java.util.Date date24 = dateTypeAdapter18.fromJsonTree(jsonElement23);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter25 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter26 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time27 = null;
        com.google.gson.JsonElement jsonElement28 = timeTypeAdapter26.toJsonTree(time27);
        java.sql.Time time29 = null;
        com.google.gson.JsonElement jsonElement30 = timeTypeAdapter26.toJsonTree(time29);
        java.util.Date date31 = dateTypeAdapter25.fromJsonTree(jsonElement30);
        java.util.Date date32 = dateTypeAdapter18.fromJsonTree(jsonElement30);
        java.lang.String str33 = gson6.toJson(jsonElement30);
        java.lang.Class class34 = classTypeAdapter5.fromJsonTree(jsonElement30);
        try {
            java.lang.Class class36 = classTypeAdapter5.fromJson("com.google.gson.JsonSyntaxException: a");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter0);
        org.junit.Assert.assertNotNull(classTypeAdapter1);
        org.junit.Assert.assertNotNull(classTypeAdapter2);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(classTypeAdapter4);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(fieldNamingStrategy11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\"hi!\"" + "'", str14.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNull(date24);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertNotNull(jsonElement30);
        org.junit.Assert.assertNull(date31);
        org.junit.Assert.assertNull(date32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "null" + "'", str33.equals("null"));
        org.junit.Assert.assertNull(class34);
    }

    @Test
    public void test1191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1191");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        com.google.gson.stream.JsonWriter jsonWriter45 = jsonTreeWriter36.beginArray();
        com.google.gson.stream.JsonWriter jsonWriter46 = jsonWriter45.beginObject();
        boolean boolean47 = jsonWriter46.isHtmlSafe();
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonWriter45);
        org.junit.Assert.assertNotNull(jsonWriter46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test1214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1214");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter45 = dateTypeAdapter0.nullSafe();
        java.io.Writer writer46 = null;
        java.util.Date date47 = null;
        try {
            dateTypeAdapter45.toJson(writer46, date47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(dateTypeAdapter45);
    }

    @Test
    public void test1243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1243");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter30 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date32 = null;
        dateTypeAdapter30.write((com.google.gson.stream.JsonWriter) jsonTreeWriter31, date32);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter31.nullValue();
        gson0.toJson(jsonElement29, (com.google.gson.stream.JsonWriter) jsonTreeWriter31);
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter36 = new com.google.gson.internal.bind.TimeTypeAdapter();
        com.google.gson.TypeAdapter<java.sql.Time> timeTypeAdapter37 = timeTypeAdapter36.nullSafe();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter38 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement39 = jsonTreeWriter38.get();
        com.google.gson.stream.JsonWriter jsonWriter41 = jsonTreeWriter38.value(true);
        java.sql.Time time42 = null;
        timeTypeAdapter36.write(jsonWriter41, time42);
        com.google.gson.JsonElement jsonElement44 = gson0.toJsonTree((java.lang.Object) time42);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(timeTypeAdapter37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNotNull(jsonWriter41);
        org.junit.Assert.assertNotNull(jsonElement44);
    }

    @Test
    public void test1253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1253");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.TypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionTypeAdapter31 = null;
        java.lang.Class<com.google.gson.JsonIOException> jsonIOExceptionClass32 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionArrayTypeAdapter33 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException>(gson0, jsonIOExceptionTypeAdapter31, jsonIOExceptionClass32);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter34 = jsonIOExceptionArrayTypeAdapter33.nullSafe();
        try {
            java.lang.Object obj36 = objTypeAdapter34.fromJson("a");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
        org.junit.Assert.assertNotNull(objTypeAdapter34);
    }

    @Test
    public void test1304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1304");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        com.google.gson.JsonParseException jsonParseException46 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException44);
        com.google.gson.stream.MalformedJsonException malformedJsonException47 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonParseException44);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1313");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.internal.ConstructorConstructor constructorConstructor24 = null;
        com.google.gson.internal.ConstructorConstructor constructorConstructor25 = null;
        com.google.gson.FieldNamingPolicy fieldNamingPolicy26 = com.google.gson.FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES;
        com.google.gson.internal.Excluder excluder27 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory reflectiveTypeAdapterFactory28 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(constructorConstructor25, (com.google.gson.FieldNamingStrategy) fieldNamingPolicy26, excluder27);
        com.google.gson.internal.Excluder excluder29 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.ExclusionStrategy exclusionStrategy30 = null;
        com.google.gson.internal.Excluder excluder33 = excluder29.withExclusionStrategy(exclusionStrategy30, false, false);
        com.google.gson.internal.Excluder excluder34 = excluder29.excludeFieldsWithoutExposeAnnotation();
        com.google.gson.internal.Excluder excluder35 = excluder34.disableInnerClassSerialization();
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory reflectiveTypeAdapterFactory36 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(constructorConstructor24, (com.google.gson.FieldNamingStrategy) fieldNamingPolicy26, excluder34);
        java.lang.Appendable appendable37 = null;
        try {
            gson0.toJson((java.lang.Object) excluder34, appendable37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(fieldNamingPolicy26);
        org.junit.Assert.assertNotNull(excluder27);
        org.junit.Assert.assertNotNull(excluder29);
        org.junit.Assert.assertNotNull(excluder33);
        org.junit.Assert.assertNotNull(excluder34);
        org.junit.Assert.assertNotNull(excluder35);
    }

    @Test
    public void test1351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1351");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean11 = jsonPrimitive10.isJsonNull();
        java.lang.Number number12 = jsonPrimitive10.getAsNumber();
        char char13 = jsonPrimitive10.getAsCharacter();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter14 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date16 = null;
        dateTypeAdapter14.write((com.google.gson.stream.JsonWriter) jsonTreeWriter15, date16);
        com.google.gson.stream.JsonWriter jsonWriter18 = jsonTreeWriter15.nullValue();
        jsonWriter18.setLenient(true);
        com.google.gson.stream.JsonWriter jsonWriter21 = jsonWriter18.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonPrimitive10, jsonWriter18);
        java.lang.Object obj23 = null;
        java.lang.String str24 = gson0.toJson(obj23);
        com.google.gson.JsonObject jsonObject25 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive27 = jsonObject25.getAsJsonPrimitive("\"a\"");
        jsonObject25.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonPrimitive jsonPrimitive33 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean34 = jsonPrimitive33.isJsonNull();
        java.lang.String str35 = jsonPrimitive33.toString();
        jsonObject25.add("", (com.google.gson.JsonElement) jsonPrimitive33);
        jsonObject25.addProperty("a", "-1.0");
        java.lang.String str40 = gson0.toJson((com.google.gson.JsonElement) jsonObject25);
        com.google.gson.JsonPrimitive jsonPrimitive43 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        java.math.BigDecimal bigDecimal44 = jsonPrimitive43.getAsBigDecimal();
        byte byte45 = jsonPrimitive43.getAsByte();
        java.math.BigDecimal bigDecimal46 = jsonPrimitive43.getAsBigDecimal();
        jsonObject25.addProperty("com.google.gson.JsonParseException: com.google.gson.JsonSyntaxException: a", (java.lang.Number) bigDecimal46);
        com.google.gson.JsonObject jsonObject48 = jsonObject25.getAsJsonObject();
        com.google.gson.JsonElement jsonElement50 = jsonObject48.remove("\"null\"");
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(number12);
        org.junit.Assert.assertTrue("'" + char13 + "' != '" + 'a' + "'", char13 == 'a');
        org.junit.Assert.assertNotNull(jsonWriter18);
        org.junit.Assert.assertNotNull(jsonWriter21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "null" + "'", str24.equals("null"));
        org.junit.Assert.assertNull(jsonPrimitive27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "\"a\"" + "'", str35.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{\"\":\"a\",\"a\":\"-1.0\"}" + "'", str40.equals("{\"\":\"a\",\"a\":\"-1.0\"}"));
        org.junit.Assert.assertNotNull(bigDecimal44);
        org.junit.Assert.assertTrue("'" + byte45 + "' != '" + (byte) -1 + "'", byte45 == (byte) -1);
        org.junit.Assert.assertNotNull(bigDecimal46);
        org.junit.Assert.assertNotNull(jsonObject48);
        org.junit.Assert.assertNull(jsonElement50);
    }

    @Test
    public void test1380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1380");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter31 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass32 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter33 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter31, collectionTypeAdapterFactoryClass32);
        java.lang.Object obj34 = null;
        java.lang.Appendable appendable35 = null;
        try {
            gson0.toJson(obj34, appendable35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
    }

    @Test
    public void test1390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1390");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isJsonPrimitive();
        char char7 = jsonPrimitive1.getAsCharacter();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        boolean boolean38 = jsonPrimitive1.equals((java.lang.Object) jsonTreeWriter27);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.value("{}");
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter27.value(100L);
        jsonTreeWriter27.setSerializeNulls(false);
        com.google.gson.stream.JsonWriter jsonWriter45 = jsonTreeWriter27.nullValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertNotNull(jsonWriter45);
    }

}
