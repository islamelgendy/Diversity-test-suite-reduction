import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0018");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter30 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date32 = null;
        dateTypeAdapter30.write((com.google.gson.stream.JsonWriter) jsonTreeWriter31, date32);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter31.nullValue();
        gson0.toJson(jsonElement29, (com.google.gson.stream.JsonWriter) jsonTreeWriter31);
        com.google.gson.JsonPrimitive jsonPrimitive37 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean38 = jsonPrimitive37.isJsonNull();
        java.lang.String str39 = jsonPrimitive37.toString();
        boolean boolean40 = jsonPrimitive37.isJsonArray();
        char char41 = jsonPrimitive37.getAsCharacter();
        boolean boolean42 = jsonPrimitive37.isJsonNull();
        java.lang.Appendable appendable43 = null;
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive37, appendable43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "\"a\"" + "'", str39.equals("\"a\""));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + char41 + "' != '" + 'a' + "'", char41 == 'a');
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        try {
            float float46 = jsonObject12.getAsFloat();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JsonObject");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.TypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionTypeAdapter31 = null;
        java.lang.Class<com.google.gson.JsonIOException> jsonIOExceptionClass32 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException> jsonIOExceptionArrayTypeAdapter33 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.JsonIOException>(gson0, jsonIOExceptionTypeAdapter31, jsonIOExceptionClass32);
        com.google.gson.JsonPrimitive jsonPrimitive35 = new com.google.gson.JsonPrimitive((java.lang.Number) 100);
        double double36 = jsonPrimitive35.getAsDouble();
        boolean boolean37 = jsonPrimitive35.isBoolean();
        java.lang.Appendable appendable38 = null;
        try {
            gson0.toJson((com.google.gson.JsonElement) jsonPrimitive35, appendable38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test0452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0452");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        try {
            int int49 = jsonArray0.getAsInt();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0526");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter43 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.stream.JsonWriter jsonWriter45 = jsonTreeWriter43.value((double) 1);
        boolean boolean46 = jsonTreeWriter43.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter47 = jsonTreeWriter43.beginObject();
        boolean boolean48 = jsonObject12.equals((java.lang.Object) jsonWriter47);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertNotNull(jsonWriter45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(jsonWriter47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0567");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        java.lang.Object obj9 = null;
        boolean boolean10 = jsonPrimitive7.equals(obj9);
        com.google.gson.internal.bind.SqlDateTypeAdapter sqlDateTypeAdapter11 = new com.google.gson.internal.bind.SqlDateTypeAdapter();
        java.sql.Date date12 = null;
        com.google.gson.JsonElement jsonElement13 = sqlDateTypeAdapter11.toJsonTree(date12);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter14 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter15 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date16 = null;
        dateTypeAdapter14.write((com.google.gson.stream.JsonWriter) jsonTreeWriter15, date16);
        com.google.gson.stream.JsonWriter jsonWriter19 = jsonTreeWriter15.value(0.0d);
        java.sql.Date date20 = null;
        sqlDateTypeAdapter11.write(jsonWriter19, date20);
        java.sql.Date date22 = null;
        com.google.gson.JsonElement jsonElement23 = sqlDateTypeAdapter11.toJsonTree(date22);
        java.sql.Date date24 = null;
        com.google.gson.JsonElement jsonElement25 = sqlDateTypeAdapter11.toJsonTree(date24);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter27 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time28 = null;
        com.google.gson.JsonElement jsonElement29 = timeTypeAdapter27.toJsonTree(time28);
        java.sql.Time time30 = null;
        com.google.gson.JsonElement jsonElement31 = timeTypeAdapter27.toJsonTree(time30);
        java.util.Date date32 = dateTypeAdapter26.fromJsonTree(jsonElement31);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter33 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter34 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time35 = null;
        com.google.gson.JsonElement jsonElement36 = timeTypeAdapter34.toJsonTree(time35);
        java.sql.Time time37 = null;
        com.google.gson.JsonElement jsonElement38 = timeTypeAdapter34.toJsonTree(time37);
        java.util.Date date39 = dateTypeAdapter33.fromJsonTree(jsonElement38);
        java.util.Date date40 = dateTypeAdapter26.fromJsonTree(jsonElement38);
        java.util.Date date41 = null;
        com.google.gson.JsonElement jsonElement42 = dateTypeAdapter26.toJsonTree(date41);
        java.sql.Date date43 = sqlDateTypeAdapter11.fromJsonTree(jsonElement42);
        boolean boolean44 = jsonPrimitive7.equals((java.lang.Object) sqlDateTypeAdapter11);
        try {
            java.math.BigDecimal bigDecimal45 = jsonPrimitive7.getAsBigDecimal();
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonElement13);
        org.junit.Assert.assertNotNull(jsonWriter19);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNotNull(jsonElement25);
        org.junit.Assert.assertNotNull(jsonElement29);
        org.junit.Assert.assertNotNull(jsonElement31);
        org.junit.Assert.assertNull(date32);
        org.junit.Assert.assertNotNull(jsonElement36);
        org.junit.Assert.assertNotNull(jsonElement38);
        org.junit.Assert.assertNull(date39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertNotNull(jsonElement42);
        org.junit.Assert.assertNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test0577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0577");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        try {
            java.math.BigDecimal bigDecimal49 = jsonArray0.getAsBigDecimal();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test0581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0581");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        java.lang.Object obj12 = null;
        com.google.gson.JsonElement jsonElement13 = exceptionArrayTypeAdapter11.toJsonTree(obj12);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter14 = exceptionArrayTypeAdapter11.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter15 = exceptionArrayTypeAdapter11.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter16 = objTypeAdapter15.nullSafe();
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        java.lang.Object obj18 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter19 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass20 = classTypeAdapter19.getClass();
        com.google.gson.JsonElement jsonElement21 = gson17.toJsonTree(obj18, (java.lang.reflect.Type) wildcardClass20);
        com.google.gson.JsonSyntaxException jsonSyntaxException24 = new com.google.gson.JsonSyntaxException("hi!");
        com.google.gson.JsonSyntaxException jsonSyntaxException25 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonSyntaxException24);
        com.google.gson.stream.MalformedJsonException malformedJsonException26 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonSyntaxException25);
        com.google.gson.JsonSyntaxException jsonSyntaxException27 = new com.google.gson.JsonSyntaxException("hi!", (java.lang.Throwable) malformedJsonException26);
        com.google.gson.JsonElement jsonElement28 = gson17.toJsonTree((java.lang.Object) malformedJsonException26);
        com.google.gson.TypeAdapter<com.google.gson.Gson> gsonTypeAdapter29 = null;
        java.lang.Class<com.google.gson.Gson> gsonClass30 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.Gson> gsonArrayTypeAdapter31 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.Gson>(gson17, gsonTypeAdapter29, gsonClass30);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter32 = null;
        java.lang.Class<java.lang.Exception> exceptionClass33 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter34 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson17, exceptionTypeAdapter32, exceptionClass33);
        com.google.gson.TypeAdapter<java.lang.Object> objTypeAdapter35 = exceptionArrayTypeAdapter34.nullSafe();
        try {
            com.google.gson.JsonElement jsonElement36 = objTypeAdapter15.toJsonTree((java.lang.Object) objTypeAdapter35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonElement13);
        org.junit.Assert.assertNotNull(objTypeAdapter14);
        org.junit.Assert.assertNotNull(objTypeAdapter15);
        org.junit.Assert.assertNotNull(objTypeAdapter16);
        org.junit.Assert.assertNotNull(classTypeAdapter19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertNotNull(objTypeAdapter35);
    }

    @Test
    public void test0642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0642");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.JsonElement jsonElement29 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter30 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter31 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date32 = null;
        dateTypeAdapter30.write((com.google.gson.stream.JsonWriter) jsonTreeWriter31, date32);
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter31.nullValue();
        gson0.toJson(jsonElement29, (com.google.gson.stream.JsonWriter) jsonTreeWriter31);
        com.google.gson.TypeAdapter<java.lang.Number> numberTypeAdapter36 = com.google.gson.internal.bind.TypeAdapters.FLOAT;
        java.lang.String str37 = gson0.toJson((java.lang.Object) numberTypeAdapter36);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter38 = null;
        java.lang.Class<java.lang.Exception> exceptionClass39 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter40 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter38, exceptionClass39);
        com.google.gson.stream.JsonReader jsonReader41 = null;
        try {
            java.lang.Object obj42 = exceptionArrayTypeAdapter40.read(jsonReader41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(numberTypeAdapter36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "null" + "'", str37.equals("null"));
    }

    @Test
    public void test0772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0772");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter13 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass14 = classTypeAdapter13.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy15 = gson10.fromJson((com.google.gson.JsonElement) jsonPrimitive12, (java.lang.reflect.Type) wildcardClass14);
        java.lang.String str16 = gson0.toJson((java.lang.Object) 0.0f, (java.lang.reflect.Type) wildcardClass14);
        com.google.gson.JsonPrimitive jsonPrimitive18 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean19 = jsonPrimitive18.isJsonNull();
        java.lang.Number number20 = jsonPrimitive18.getAsNumber();
        char char21 = jsonPrimitive18.getAsCharacter();
        com.google.gson.internal.Excluder excluder22 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.Excluder excluder24 = excluder22.withVersion((double) (short) 0);
        com.google.gson.internal.Excluder excluder25 = excluder24.disableInnerClassSerialization();
        boolean boolean26 = jsonPrimitive18.equals((java.lang.Object) excluder24);
        com.google.gson.JsonElement jsonElement27 = gson0.toJsonTree((java.lang.Object) jsonPrimitive18);
        java.lang.Object obj28 = null;
        com.google.gson.Gson gson29 = new com.google.gson.Gson();
        java.lang.Object obj30 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter31 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass32 = classTypeAdapter31.getClass();
        com.google.gson.JsonElement jsonElement33 = gson29.toJsonTree(obj30, (java.lang.reflect.Type) wildcardClass32);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken34 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass32);
        java.lang.String str35 = gson0.toJson(obj28, (java.lang.reflect.Type) wildcardClass32);
        java.io.Writer writer36 = null;
        try {
            com.google.gson.stream.JsonWriter jsonWriter37 = gson0.newJsonWriter(writer36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNotNull(classTypeAdapter13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(fieldNamingStrategy15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null" + "'", str16.equals("null"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(number20);
        org.junit.Assert.assertTrue("'" + char21 + "' != '" + 'a' + "'", char21 == 'a');
        org.junit.Assert.assertNotNull(excluder22);
        org.junit.Assert.assertNotNull(excluder24);
        org.junit.Assert.assertNotNull(excluder25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jsonElement27);
        org.junit.Assert.assertNotNull(classTypeAdapter31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(jsonElement33);
        org.junit.Assert.assertNotNull(wildcardTypeToken34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "null" + "'", str35.equals("null"));
    }

    @Test
    public void test0807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0807");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        java.util.Date date45 = null;
        com.google.gson.JsonElement jsonElement46 = dateTypeAdapter0.toJsonTree(date45);
        java.io.Writer writer47 = null;
        java.util.Date date48 = null;
        try {
            dateTypeAdapter0.toJson(writer47, date48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(jsonElement46);
    }

    @Test
    public void test0853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0853");
        com.google.gson.JsonObject jsonObject0 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive2 = jsonObject0.getAsJsonPrimitive("\"a\"");
        jsonObject0.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonObject jsonObject7 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive9 = jsonObject7.getAsJsonPrimitive("\"a\"");
        jsonObject7.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean16 = jsonPrimitive15.isJsonNull();
        java.lang.String str17 = jsonPrimitive15.toString();
        jsonObject7.add("", (com.google.gson.JsonElement) jsonPrimitive15);
        jsonObject0.add("", (com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.JsonElement jsonElement21 = jsonObject0.remove("\"a\"");
        com.google.gson.JsonElement jsonElement23 = jsonObject0.get("hi!");
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive26 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter27 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass28 = classTypeAdapter27.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy29 = gson24.fromJson((com.google.gson.JsonElement) jsonPrimitive26, (java.lang.reflect.Type) wildcardClass28);
        com.google.gson.JsonPrimitive jsonPrimitive31 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str32 = gson24.toJson((com.google.gson.JsonElement) jsonPrimitive31);
        java.lang.String str33 = gson24.toString();
        com.google.gson.JsonObject jsonObject34 = new com.google.gson.JsonObject();
        jsonObject34.addProperty("a", "");
        com.google.gson.JsonObject jsonObject38 = jsonObject34.getAsJsonObject();
        jsonObject34.addProperty("\"hi!\"", (java.lang.Boolean) false);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader42 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject34);
        com.google.gson.Gson gson43 = new com.google.gson.Gson();
        java.lang.Object obj44 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter45 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass46 = classTypeAdapter45.getClass();
        com.google.gson.JsonElement jsonElement47 = gson43.toJsonTree(obj44, (java.lang.reflect.Type) wildcardClass46);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken48 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass46);
        java.lang.reflect.AnnotatedElement annotatedElement49 = gson24.fromJson((com.google.gson.stream.JsonReader) jsonTreeReader42, (java.lang.reflect.Type) wildcardClass46);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter50 = null;
        java.lang.Class<java.lang.Exception> exceptionClass51 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter52 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson24, exceptionTypeAdapter50, exceptionClass51);
        boolean boolean53 = jsonObject0.equals((java.lang.Object) exceptionClass51);
        boolean boolean54 = jsonObject0.isJsonObject();
        org.junit.Assert.assertNull(jsonPrimitive2);
        org.junit.Assert.assertNull(jsonPrimitive9);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "\"a\"" + "'", str17.equals("\"a\""));
        org.junit.Assert.assertNull(jsonElement21);
        org.junit.Assert.assertNull(jsonElement23);
        org.junit.Assert.assertNotNull(classTypeAdapter27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNull(fieldNamingStrategy29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "\"hi!\"" + "'", str32.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonObject38);
        org.junit.Assert.assertNotNull(classTypeAdapter45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(jsonElement47);
        org.junit.Assert.assertNotNull(wildcardTypeToken48);
        org.junit.Assert.assertNull(annotatedElement49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test0995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0995");
        com.google.gson.Gson gson1 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive3 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter4 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass5 = classTypeAdapter4.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy6 = gson1.fromJson((com.google.gson.JsonElement) jsonPrimitive3, (java.lang.reflect.Type) wildcardClass5);
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str9 = gson1.toJson((com.google.gson.JsonElement) jsonPrimitive8);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter10 = null;
        java.lang.Class<java.lang.Exception> exceptionClass11 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter12 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson1, exceptionTypeAdapter10, exceptionClass11);
        com.google.gson.JsonObject jsonObject13 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive15 = jsonObject13.getAsJsonPrimitive("\"a\"");
        jsonObject13.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter19 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter20 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date21 = null;
        dateTypeAdapter19.write((com.google.gson.stream.JsonWriter) jsonTreeWriter20, date21);
        com.google.gson.stream.JsonWriter jsonWriter23 = jsonTreeWriter20.nullValue();
        jsonTreeWriter20.setHtmlSafe(false);
        boolean boolean26 = jsonTreeWriter20.getSerializeNulls();
        boolean boolean27 = jsonTreeWriter20.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter28 = jsonTreeWriter20.nullValue();
        gson1.toJson((com.google.gson.JsonElement) jsonObject13, (com.google.gson.stream.JsonWriter) jsonTreeWriter20);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader30 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject13);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet31 = jsonObject13.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter33 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter34 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time35 = null;
        com.google.gson.JsonElement jsonElement36 = timeTypeAdapter34.toJsonTree(time35);
        java.sql.Time time37 = null;
        com.google.gson.JsonElement jsonElement38 = timeTypeAdapter34.toJsonTree(time37);
        java.util.Date date39 = dateTypeAdapter33.fromJsonTree(jsonElement38);
        jsonObject13.add("", jsonElement38);
        jsonObject13.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException45 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean46 = jsonObject13.equals((java.lang.Object) jsonParseException45);
        com.google.gson.JsonParseException jsonParseException47 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException45);
        com.google.gson.JsonParseException jsonParseException48 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!", (java.lang.Throwable) jsonParseException47);
        org.junit.Assert.assertNotNull(classTypeAdapter4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(fieldNamingStrategy6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\"hi!\"" + "'", str9.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive15);
        org.junit.Assert.assertNotNull(jsonWriter23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(jsonWriter28);
        org.junit.Assert.assertNotNull(strEntrySet31);
        org.junit.Assert.assertNotNull(jsonElement36);
        org.junit.Assert.assertNotNull(jsonElement38);
        org.junit.Assert.assertNull(date39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test1009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1009");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryTypeAdapter1 = null;
        java.lang.Class<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryClass2 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory> reflectiveTypeAdapterFactoryArrayTypeAdapter3 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.ReflectiveTypeAdapterFactory>(gson0, reflectiveTypeAdapterFactoryTypeAdapter1, reflectiveTypeAdapterFactoryClass2);
        com.google.gson.JsonArray jsonArray4 = new com.google.gson.JsonArray();
        jsonArray4.add((java.lang.Boolean) true);
        com.google.gson.Gson gson7 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter10 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass11 = classTypeAdapter10.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy12 = gson7.fromJson((com.google.gson.JsonElement) jsonPrimitive9, (java.lang.reflect.Type) wildcardClass11);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter13 = null;
        java.lang.Class<java.lang.Throwable> throwableClass14 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter15 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson7, throwableTypeAdapter13, throwableClass14);
        com.google.gson.Gson gson17 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive19 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter20 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass21 = classTypeAdapter20.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy22 = gson17.fromJson((com.google.gson.JsonElement) jsonPrimitive19, (java.lang.reflect.Type) wildcardClass21);
        java.lang.String str23 = gson7.toJson((java.lang.Object) 0.0f, (java.lang.reflect.Type) wildcardClass21);
        com.google.gson.reflect.TypeToken<?> wildcardTypeToken24 = com.google.gson.reflect.TypeToken.get((java.lang.reflect.Type) wildcardClass21);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter25 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter26 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date27 = null;
        dateTypeAdapter25.write((com.google.gson.stream.JsonWriter) jsonTreeWriter26, date27);
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter26.nullValue();
        jsonTreeWriter26.setHtmlSafe(false);
        boolean boolean32 = jsonTreeWriter26.getSerializeNulls();
        boolean boolean33 = jsonTreeWriter26.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter34 = jsonTreeWriter26.nullValue();
        com.google.gson.stream.JsonWriter jsonWriter36 = jsonWriter34.value((long) (short) -1);
        com.google.gson.stream.JsonWriter jsonWriter38 = jsonWriter36.value(0.0d);
        gson0.toJson((java.lang.Object) true, (java.lang.reflect.Type) wildcardClass21, jsonWriter38);
        boolean boolean40 = jsonWriter38.isLenient();
        org.junit.Assert.assertNotNull(classTypeAdapter10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(fieldNamingStrategy12);
        org.junit.Assert.assertNotNull(classTypeAdapter20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNull(fieldNamingStrategy22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "null" + "'", str23.equals("null"));
        org.junit.Assert.assertNotNull(wildcardTypeToken24);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jsonWriter34);
        org.junit.Assert.assertNotNull(jsonWriter36);
        org.junit.Assert.assertNotNull(jsonWriter38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test1017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1017");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        com.google.gson.JsonParseException jsonParseException46 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException44);
        com.google.gson.JsonSyntaxException jsonSyntaxException47 = new com.google.gson.JsonSyntaxException((java.lang.Throwable) jsonParseException46);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1058");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.JsonPrimitive jsonPrimitive3 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean4 = jsonPrimitive3.isJsonNull();
        java.lang.Number number5 = jsonPrimitive3.getAsNumber();
        char char6 = jsonPrimitive3.getAsCharacter();
        boolean boolean7 = jsonArray0.remove((com.google.gson.JsonElement) jsonPrimitive3);
        jsonArray0.add("a");
        com.google.gson.Gson gson10 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter13 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass14 = classTypeAdapter13.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy15 = gson10.fromJson((com.google.gson.JsonElement) jsonPrimitive12, (java.lang.reflect.Type) wildcardClass14);
        com.google.gson.JsonPrimitive jsonPrimitive17 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str18 = gson10.toJson((com.google.gson.JsonElement) jsonPrimitive17);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter19 = null;
        java.lang.Class<java.lang.Exception> exceptionClass20 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter21 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson10, exceptionTypeAdapter19, exceptionClass20);
        com.google.gson.JsonObject jsonObject22 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive24 = jsonObject22.getAsJsonPrimitive("\"a\"");
        jsonObject22.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter28 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter29 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date30 = null;
        dateTypeAdapter28.write((com.google.gson.stream.JsonWriter) jsonTreeWriter29, date30);
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter29.nullValue();
        jsonTreeWriter29.setHtmlSafe(false);
        boolean boolean35 = jsonTreeWriter29.getSerializeNulls();
        boolean boolean36 = jsonTreeWriter29.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter37 = jsonTreeWriter29.nullValue();
        gson10.toJson((com.google.gson.JsonElement) jsonObject22, (com.google.gson.stream.JsonWriter) jsonTreeWriter29);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader39 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject22);
        com.google.gson.JsonArray jsonArray41 = jsonObject22.getAsJsonArray("[{}]");
        com.google.gson.JsonPrimitive jsonPrimitive43 = jsonObject22.getAsJsonPrimitive("1");
        com.google.gson.JsonPrimitive jsonPrimitive45 = jsonObject22.getAsJsonPrimitive("true");
        boolean boolean46 = jsonArray0.contains((com.google.gson.JsonElement) jsonObject22);
        boolean boolean48 = jsonObject22.has("{\"\":\"a\",\"a\":\"-1.0\"}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(number5);
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + 'a' + "'", char6 == 'a');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(classTypeAdapter13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(fieldNamingStrategy15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "\"hi!\"" + "'", str18.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive24);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(jsonWriter37);
        org.junit.Assert.assertNull(jsonArray41);
        org.junit.Assert.assertNull(jsonPrimitive43);
        org.junit.Assert.assertNull(jsonPrimitive45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test1092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1092");
        com.google.gson.JsonArray jsonArray0 = new com.google.gson.JsonArray();
        int int1 = jsonArray0.size();
        com.google.gson.Gson gson2 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive4 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass6 = classTypeAdapter5.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy7 = gson2.fromJson((com.google.gson.JsonElement) jsonPrimitive4, (java.lang.reflect.Type) wildcardClass6);
        com.google.gson.JsonPrimitive jsonPrimitive9 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str10 = gson2.toJson((com.google.gson.JsonElement) jsonPrimitive9);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter11 = null;
        java.lang.Class<java.lang.Exception> exceptionClass12 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter13 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson2, exceptionTypeAdapter11, exceptionClass12);
        com.google.gson.JsonObject jsonObject14 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive16 = jsonObject14.getAsJsonPrimitive("\"a\"");
        jsonObject14.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter20 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter21 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date22 = null;
        dateTypeAdapter20.write((com.google.gson.stream.JsonWriter) jsonTreeWriter21, date22);
        com.google.gson.stream.JsonWriter jsonWriter24 = jsonTreeWriter21.nullValue();
        jsonTreeWriter21.setHtmlSafe(false);
        boolean boolean27 = jsonTreeWriter21.getSerializeNulls();
        boolean boolean28 = jsonTreeWriter21.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter29 = jsonTreeWriter21.nullValue();
        gson2.toJson((com.google.gson.JsonElement) jsonObject14, (com.google.gson.stream.JsonWriter) jsonTreeWriter21);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader31 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject14);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet32 = jsonObject14.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter34 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter35 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter35.toJsonTree(time36);
        java.sql.Time time38 = null;
        com.google.gson.JsonElement jsonElement39 = timeTypeAdapter35.toJsonTree(time38);
        java.util.Date date40 = dateTypeAdapter34.fromJsonTree(jsonElement39);
        jsonObject14.add("", jsonElement39);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) true);
        jsonObject14.addProperty("hi!", (java.lang.Boolean) false);
        boolean boolean48 = jsonArray0.equals((java.lang.Object) jsonObject14);
        try {
            byte byte49 = jsonArray0.getAsByte();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(fieldNamingStrategy7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\"hi!\"" + "'", str10.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive16);
        org.junit.Assert.assertNotNull(jsonWriter24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(jsonWriter29);
        org.junit.Assert.assertNotNull(strEntrySet32);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNotNull(jsonElement39);
        org.junit.Assert.assertNull(date40);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test1152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1152");
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter0 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter1 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter2 = classTypeAdapter0.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = classTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter4 = classTypeAdapter2.nullSafe();
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter5 = classTypeAdapter4.nullSafe();
        com.google.gson.Gson gson6 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive8 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter9 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass10 = classTypeAdapter9.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy11 = gson6.fromJson((com.google.gson.JsonElement) jsonPrimitive8, (java.lang.reflect.Type) wildcardClass10);
        com.google.gson.JsonPrimitive jsonPrimitive13 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str14 = gson6.toJson((com.google.gson.JsonElement) jsonPrimitive13);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter15 = null;
        java.lang.Class<java.lang.Exception> exceptionClass16 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter17 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson6, exceptionTypeAdapter15, exceptionClass16);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter19 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time20 = null;
        com.google.gson.JsonElement jsonElement21 = timeTypeAdapter19.toJsonTree(time20);
        java.sql.Time time22 = null;
        com.google.gson.JsonElement jsonElement23 = timeTypeAdapter19.toJsonTree(time22);
        java.util.Date date24 = dateTypeAdapter18.fromJsonTree(jsonElement23);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter25 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter26 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time27 = null;
        com.google.gson.JsonElement jsonElement28 = timeTypeAdapter26.toJsonTree(time27);
        java.sql.Time time29 = null;
        com.google.gson.JsonElement jsonElement30 = timeTypeAdapter26.toJsonTree(time29);
        java.util.Date date31 = dateTypeAdapter25.fromJsonTree(jsonElement30);
        java.util.Date date32 = dateTypeAdapter18.fromJsonTree(jsonElement30);
        java.lang.String str33 = gson6.toJson(jsonElement30);
        java.lang.Class class34 = classTypeAdapter5.fromJsonTree(jsonElement30);
        try {
            java.lang.Class class36 = classTypeAdapter5.fromJson("com.google.gson.JsonSyntaxException: a");
            org.junit.Assert.fail("Expected exception of type com.google.gson.stream.MalformedJsonException; message: Use JsonReader.setLenient(true) to accept malformed JSON at line 1 column 1 path $");
        } catch (com.google.gson.stream.MalformedJsonException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter0);
        org.junit.Assert.assertNotNull(classTypeAdapter1);
        org.junit.Assert.assertNotNull(classTypeAdapter2);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(classTypeAdapter4);
        org.junit.Assert.assertNotNull(classTypeAdapter5);
        org.junit.Assert.assertNotNull(classTypeAdapter9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(fieldNamingStrategy11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\"hi!\"" + "'", str14.equals("\"hi!\""));
        org.junit.Assert.assertNotNull(jsonElement21);
        org.junit.Assert.assertNotNull(jsonElement23);
        org.junit.Assert.assertNull(date24);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertNotNull(jsonElement30);
        org.junit.Assert.assertNull(date31);
        org.junit.Assert.assertNull(date32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "null" + "'", str33.equals("null"));
        org.junit.Assert.assertNull(class34);
    }

    @Test
    public void test1214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1214");
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter0 = new com.google.gson.internal.bind.DateTypeAdapter();
        java.util.Date date1 = null;
        com.google.gson.JsonElement jsonElement2 = dateTypeAdapter0.toJsonTree(date1);
        java.util.Date date3 = null;
        com.google.gson.JsonElement jsonElement4 = dateTypeAdapter0.toJsonTree(date3);
        com.google.gson.Gson gson5 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter8 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass9 = classTypeAdapter8.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy10 = gson5.fromJson((com.google.gson.JsonElement) jsonPrimitive7, (java.lang.reflect.Type) wildcardClass9);
        com.google.gson.JsonPrimitive jsonPrimitive12 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str13 = gson5.toJson((com.google.gson.JsonElement) jsonPrimitive12);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter14 = null;
        java.lang.Class<java.lang.Exception> exceptionClass15 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter16 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson5, exceptionTypeAdapter14, exceptionClass15);
        com.google.gson.JsonObject jsonObject17 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive19 = jsonObject17.getAsJsonPrimitive("\"a\"");
        jsonObject17.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter23 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter24 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date25 = null;
        dateTypeAdapter23.write((com.google.gson.stream.JsonWriter) jsonTreeWriter24, date25);
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter24.nullValue();
        jsonTreeWriter24.setHtmlSafe(false);
        boolean boolean30 = jsonTreeWriter24.getSerializeNulls();
        boolean boolean31 = jsonTreeWriter24.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter32 = jsonTreeWriter24.nullValue();
        gson5.toJson((com.google.gson.JsonElement) jsonObject17, (com.google.gson.stream.JsonWriter) jsonTreeWriter24);
        com.google.gson.JsonElement jsonElement34 = null;
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter35 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter36 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date37 = null;
        dateTypeAdapter35.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date37);
        com.google.gson.stream.JsonWriter jsonWriter39 = jsonTreeWriter36.nullValue();
        gson5.toJson(jsonElement34, (com.google.gson.stream.JsonWriter) jsonTreeWriter36);
        jsonTreeWriter36.setHtmlSafe(true);
        java.util.Date date43 = null;
        dateTypeAdapter0.write((com.google.gson.stream.JsonWriter) jsonTreeWriter36, date43);
        com.google.gson.TypeAdapter<java.util.Date> dateTypeAdapter45 = dateTypeAdapter0.nullSafe();
        java.io.Writer writer46 = null;
        java.util.Date date47 = null;
        try {
            dateTypeAdapter45.toJson(writer46, date47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: out == null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonElement2);
        org.junit.Assert.assertNotNull(jsonElement4);
        org.junit.Assert.assertNotNull(classTypeAdapter8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(fieldNamingStrategy10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\"hi!\"" + "'", str13.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive19);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jsonWriter32);
        org.junit.Assert.assertNotNull(jsonWriter39);
        org.junit.Assert.assertNotNull(dateTypeAdapter45);
    }

    @Test
    public void test1219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1219");
        com.google.gson.JsonPrimitive jsonPrimitive1 = new com.google.gson.JsonPrimitive((java.lang.Character) 'a');
        boolean boolean2 = jsonPrimitive1.isJsonNull();
        java.lang.Number number3 = jsonPrimitive1.getAsNumber();
        boolean boolean4 = jsonPrimitive1.isJsonObject();
        java.lang.String str5 = jsonPrimitive1.getAsString();
        boolean boolean6 = jsonPrimitive1.isJsonPrimitive();
        char char7 = jsonPrimitive1.getAsCharacter();
        com.google.gson.Gson gson8 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive10 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter11 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass12 = classTypeAdapter11.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy13 = gson8.fromJson((com.google.gson.JsonElement) jsonPrimitive10, (java.lang.reflect.Type) wildcardClass12);
        com.google.gson.JsonPrimitive jsonPrimitive15 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str16 = gson8.toJson((com.google.gson.JsonElement) jsonPrimitive15);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter17 = null;
        java.lang.Class<java.lang.Exception> exceptionClass18 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter19 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson8, exceptionTypeAdapter17, exceptionClass18);
        com.google.gson.JsonObject jsonObject20 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive22 = jsonObject20.getAsJsonPrimitive("\"a\"");
        jsonObject20.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter26 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter27 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date28 = null;
        dateTypeAdapter26.write((com.google.gson.stream.JsonWriter) jsonTreeWriter27, date28);
        com.google.gson.stream.JsonWriter jsonWriter30 = jsonTreeWriter27.nullValue();
        jsonTreeWriter27.setHtmlSafe(false);
        boolean boolean33 = jsonTreeWriter27.getSerializeNulls();
        boolean boolean34 = jsonTreeWriter27.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter35 = jsonTreeWriter27.nullValue();
        gson8.toJson((com.google.gson.JsonElement) jsonObject20, (com.google.gson.stream.JsonWriter) jsonTreeWriter27);
        com.google.gson.JsonElement jsonElement37 = jsonTreeWriter27.get();
        boolean boolean38 = jsonPrimitive1.equals((java.lang.Object) jsonTreeWriter27);
        com.google.gson.stream.JsonWriter jsonWriter40 = jsonTreeWriter27.value("{}");
        com.google.gson.stream.JsonWriter jsonWriter42 = jsonTreeWriter27.value(100L);
        com.google.gson.stream.JsonWriter jsonWriter44 = jsonWriter42.value(true);
        boolean boolean45 = jsonWriter42.isHtmlSafe();
        jsonWriter42.close();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(number3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "a" + "'", str5.equals("a"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + 'a' + "'", char7 == 'a');
        org.junit.Assert.assertNotNull(classTypeAdapter11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNull(fieldNamingStrategy13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "\"hi!\"" + "'", str16.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive22);
        org.junit.Assert.assertNotNull(jsonWriter30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jsonWriter35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonWriter40);
        org.junit.Assert.assertNotNull(jsonWriter42);
        org.junit.Assert.assertNotNull(jsonWriter44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1304");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.JsonPrimitive jsonPrimitive7 = new com.google.gson.JsonPrimitive("hi!");
        java.lang.String str8 = gson0.toJson((com.google.gson.JsonElement) jsonPrimitive7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("\"a\"");
        jsonObject12.addProperty("", (java.lang.Number) 1.0f);
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter18 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter19 = new com.google.gson.internal.bind.JsonTreeWriter();
        java.util.Date date20 = null;
        dateTypeAdapter18.write((com.google.gson.stream.JsonWriter) jsonTreeWriter19, date20);
        com.google.gson.stream.JsonWriter jsonWriter22 = jsonTreeWriter19.nullValue();
        jsonTreeWriter19.setHtmlSafe(false);
        boolean boolean25 = jsonTreeWriter19.getSerializeNulls();
        boolean boolean26 = jsonTreeWriter19.getSerializeNulls();
        com.google.gson.stream.JsonWriter jsonWriter27 = jsonTreeWriter19.nullValue();
        gson0.toJson((com.google.gson.JsonElement) jsonObject12, (com.google.gson.stream.JsonWriter) jsonTreeWriter19);
        com.google.gson.internal.bind.JsonTreeReader jsonTreeReader29 = new com.google.gson.internal.bind.JsonTreeReader((com.google.gson.JsonElement) jsonObject12);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet30 = jsonObject12.entrySet();
        com.google.gson.internal.bind.DateTypeAdapter dateTypeAdapter32 = new com.google.gson.internal.bind.DateTypeAdapter();
        com.google.gson.internal.bind.TimeTypeAdapter timeTypeAdapter33 = new com.google.gson.internal.bind.TimeTypeAdapter();
        java.sql.Time time34 = null;
        com.google.gson.JsonElement jsonElement35 = timeTypeAdapter33.toJsonTree(time34);
        java.sql.Time time36 = null;
        com.google.gson.JsonElement jsonElement37 = timeTypeAdapter33.toJsonTree(time36);
        java.util.Date date38 = dateTypeAdapter32.fromJsonTree(jsonElement37);
        jsonObject12.add("", jsonElement37);
        jsonObject12.addProperty("hi!", (java.lang.Boolean) true);
        com.google.gson.JsonParseException jsonParseException44 = new com.google.gson.JsonParseException("com.google.gson.JsonSyntaxException: hi!");
        boolean boolean45 = jsonObject12.equals((java.lang.Object) jsonParseException44);
        com.google.gson.JsonParseException jsonParseException46 = new com.google.gson.JsonParseException((java.lang.Throwable) jsonParseException44);
        com.google.gson.stream.MalformedJsonException malformedJsonException47 = new com.google.gson.stream.MalformedJsonException((java.lang.Throwable) jsonParseException44);
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "\"hi!\"" + "'", str8.equals("\"hi!\""));
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonWriter22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonWriter27);
        org.junit.Assert.assertNotNull(strEntrySet30);
        org.junit.Assert.assertNotNull(jsonElement35);
        org.junit.Assert.assertNotNull(jsonElement37);
        org.junit.Assert.assertNull(date38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test1307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1307");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.Gson gson24 = new com.google.gson.Gson();
        java.lang.Object obj25 = null;
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter26 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass27 = classTypeAdapter26.getClass();
        com.google.gson.JsonElement jsonElement28 = gson24.toJsonTree(obj25, (java.lang.reflect.Type) wildcardClass27);
        boolean boolean29 = jsonElement28.isJsonArray();
        java.lang.String str30 = gson0.toJson(jsonElement28);
        com.google.gson.TypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryTypeAdapter31 = null;
        java.lang.Class<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryClass32 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory> collectionTypeAdapterFactoryArrayTypeAdapter33 = new com.google.gson.internal.bind.ArrayTypeAdapter<com.google.gson.internal.bind.CollectionTypeAdapterFactory>(gson0, collectionTypeAdapterFactoryTypeAdapter31, collectionTypeAdapterFactoryClass32);
        com.google.gson.LongSerializationPolicy longSerializationPolicy34 = com.google.gson.LongSerializationPolicy.STRING;
        com.google.gson.JsonElement jsonElement36 = longSerializationPolicy34.serialize((java.lang.Long) 100L);
        try {
            java.lang.Object obj37 = collectionTypeAdapterFactoryArrayTypeAdapter33.fromJsonTree(jsonElement36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BEGIN_ARRAY but was STRING");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(classTypeAdapter26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(jsonElement28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "null" + "'", str30.equals("null"));
        org.junit.Assert.assertNotNull(longSerializationPolicy34);
        org.junit.Assert.assertNotNull(jsonElement36);
    }

    @Test
    public void test1313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1313");
        com.google.gson.Gson gson0 = new com.google.gson.Gson();
        com.google.gson.JsonPrimitive jsonPrimitive2 = new com.google.gson.JsonPrimitive((java.lang.Number) (-1.0f));
        com.google.gson.TypeAdapter<java.lang.Class> classTypeAdapter3 = com.google.gson.internal.bind.TypeAdapters.CLASS;
        java.lang.Class<?> wildcardClass4 = classTypeAdapter3.getClass();
        com.google.gson.FieldNamingStrategy fieldNamingStrategy5 = gson0.fromJson((com.google.gson.JsonElement) jsonPrimitive2, (java.lang.reflect.Type) wildcardClass4);
        com.google.gson.TypeAdapter<java.lang.Throwable> throwableTypeAdapter6 = null;
        java.lang.Class<java.lang.Throwable> throwableClass7 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable> throwableArrayTypeAdapter8 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Throwable>(gson0, throwableTypeAdapter6, throwableClass7);
        com.google.gson.TypeAdapter<java.lang.Exception> exceptionTypeAdapter9 = null;
        java.lang.Class<java.lang.Exception> exceptionClass10 = null;
        com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception> exceptionArrayTypeAdapter11 = new com.google.gson.internal.bind.ArrayTypeAdapter<java.lang.Exception>(gson0, exceptionTypeAdapter9, exceptionClass10);
        com.google.gson.JsonObject jsonObject12 = new com.google.gson.JsonObject();
        com.google.gson.JsonPrimitive jsonPrimitive14 = jsonObject12.getAsJsonPrimitive("hi!");
        com.google.gson.JsonObject jsonObject16 = new com.google.gson.JsonObject();
        com.google.gson.internal.bind.JsonTreeWriter jsonTreeWriter18 = new com.google.gson.internal.bind.JsonTreeWriter();
        com.google.gson.JsonElement jsonElement19 = jsonTreeWriter18.get();
        jsonObject16.add("", jsonElement19);
        jsonObject12.add("", (com.google.gson.JsonElement) jsonObject16);
        java.util.Set<java.util.Map.Entry<java.lang.String, com.google.gson.JsonElement>> strEntrySet22 = jsonObject12.entrySet();
        java.lang.String str23 = gson0.toJson((java.lang.Object) strEntrySet22);
        com.google.gson.internal.ConstructorConstructor constructorConstructor24 = null;
        com.google.gson.internal.ConstructorConstructor constructorConstructor25 = null;
        com.google.gson.FieldNamingPolicy fieldNamingPolicy26 = com.google.gson.FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES;
        com.google.gson.internal.Excluder excluder27 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory reflectiveTypeAdapterFactory28 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(constructorConstructor25, (com.google.gson.FieldNamingStrategy) fieldNamingPolicy26, excluder27);
        com.google.gson.internal.Excluder excluder29 = com.google.gson.internal.Excluder.DEFAULT;
        com.google.gson.ExclusionStrategy exclusionStrategy30 = null;
        com.google.gson.internal.Excluder excluder33 = excluder29.withExclusionStrategy(exclusionStrategy30, false, false);
        com.google.gson.internal.Excluder excluder34 = excluder29.excludeFieldsWithoutExposeAnnotation();
        com.google.gson.internal.Excluder excluder35 = excluder34.disableInnerClassSerialization();
        com.google.gson.internal.bind.ReflectiveTypeAdapterFactory reflectiveTypeAdapterFactory36 = new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory(constructorConstructor24, (com.google.gson.FieldNamingStrategy) fieldNamingPolicy26, excluder34);
        java.lang.Appendable appendable37 = null;
        try {
            gson0.toJson((java.lang.Object) excluder34, appendable37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classTypeAdapter3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(fieldNamingStrategy5);
        org.junit.Assert.assertNull(jsonPrimitive14);
        org.junit.Assert.assertNotNull(jsonElement19);
        org.junit.Assert.assertNotNull(strEntrySet22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "[{}]" + "'", str23.equals("[{}]"));
        org.junit.Assert.assertNotNull(fieldNamingPolicy26);
        org.junit.Assert.assertNotNull(excluder27);
        org.junit.Assert.assertNotNull(excluder29);
        org.junit.Assert.assertNotNull(excluder33);
        org.junit.Assert.assertNotNull(excluder34);
        org.junit.Assert.assertNotNull(excluder35);
    }

}
