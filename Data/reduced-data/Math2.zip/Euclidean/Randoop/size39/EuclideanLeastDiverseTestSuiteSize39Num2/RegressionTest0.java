import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1771933557663626E-8d + "'", double1 == 5.1771933557663626E-8d);
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.0000000000000013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1619136520741884E-8d + "'", double1 == 5.1619136520741884E-8d);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(35.00000000000001d, 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.543259751217975E34d + "'", double2 == 4.543259751217975E34d);
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.9477340797526748d, 60.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03991993882471059d + "'", double2 == 0.03991993882471059d);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(5.1771933557663626E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003727046361340435d + "'", double1 == 0.003727046361340435d);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test0322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0322");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.005949889552157361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07713552717235658d + "'", double1 == 0.07713552717235658d);
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.972630067242408d, 60.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-147.53614766643088d) + "'", double2 == (-147.53614766643088d));
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 100, 74.20324596385817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.20324596385817d + "'", double2 == 74.20324596385817d);
    }

    @Test
    public void test0485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0485");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-0.4505495340698077d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4837330092051468d) + "'", double1 == (-0.4837330092051468d));
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.003727046361340435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0037270549900499652d + "'", double1 == 0.0037270549900499652d);
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 32, 0.07713552717235658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3064732953137475d + "'", double2 == 1.3064732953137475d);
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (-5131349491390734479L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4472481130760592d + "'", double1 == 0.4472481130760592d);
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        double double1 = org.apache.commons.math3.util.FastMath.sin(37.221710484165165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45947263750322936d) + "'", double1 == (-0.45947263750322936d));
    }

    @Test
    public void test0655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0655");
        double double2 = org.apache.commons.math3.util.FastMath.pow(9.094947017729282E-13d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.099511627776E12d + "'", double2 == 1.099511627776E12d);
    }

    @Test
    public void test0674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0674");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (-1661989495));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024805649680816708d + "'", double1 == 0.024805649680816708d);
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.4598215102238088d, 9.9498743710662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.9498743710662d + "'", double2 == 9.9498743710662d);
    }

    @Test
    public void test0734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0734");
        double double2 = org.apache.commons.math3.util.FastMath.min(1024.0d, 2.1922076124372905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1922076124372905d + "'", double2 == 2.1922076124372905d);
    }

    @Test
    public void test0782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0782");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.024805649680816708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024808194288585612d + "'", double1 == 0.024808194288585612d);
    }

    @Test
    public void test0804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0804");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.02709489822891885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test0859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0859");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 1.08062323E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test0877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0877");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.275344667466088E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.275085847057931E-4d + "'", double1 == 2.275085847057931E-4d);
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        double double1 = org.apache.commons.math3.util.FastMath.tan(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.8497403445422735E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0679515313825692E-25d + "'", double1 == 2.0679515313825692E-25d);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        double double2 = org.apache.commons.math3.util.FastMath.min((-2.147483648E9d), (double) (-25));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.147483648E9d) + "'", double2 == (-2.147483648E9d));
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        double double1 = org.apache.commons.math3.util.FastMath.tan(1.3833875135814552E-73d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3833875135814552E-73d + "'", double1 == 1.3833875135814552E-73d);
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        double double1 = org.apache.commons.math3.util.FastMath.floor(7.251547794405553E162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.251547794405553E162d + "'", double1 == 7.251547794405553E162d);
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(6.9177770887761845E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9177770887761845E-18d + "'", double1 == 6.9177770887761845E-18d);
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) '4', (double) 0.2f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.000384613973694d + "'", double2 == 52.000384613973694d);
    }

    @Test
    public void test1234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1234");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(5044.0024781913025d, (double) 12);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5044.0167525495d + "'", double2 == 5044.0167525495d);
    }

    @Test
    public void test1241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1241");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(19.276261250694787d, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0697727915221542E10d + "'", double2 == 2.0697727915221542E10d);
    }

    @Test
    public void test1272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1272");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.8484934041747324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8484934041747324d + "'", double2 == 0.8484934041747324d);
    }

    @Test
    public void test1288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1288");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-2.14748339E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963263292353d) + "'", double1 == (-1.5707963263292353d));
    }

    @Test
    public void test1312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1312");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((-2.147483648E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.748066029033894E7d) + "'", double1 == (-3.748066029033894E7d));
    }

    @Test
    public void test1370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1370");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(200.0d, 1.09861228866811d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 200.00301734964103d + "'", double2 == 200.00301734964103d);
    }

    @Test
    public void test1388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1388");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.6666666666666666d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test1441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1441");
        double double2 = org.apache.commons.math3.util.FastMath.max(74.20998390764434d, (-25.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.20998390764434d + "'", double2 == 74.20998390764434d);
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-2.0614401790261978E78d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 381, 1.1276259652063807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 813.4259380574406d + "'", double2 == 813.4259380574406d);
    }

}
