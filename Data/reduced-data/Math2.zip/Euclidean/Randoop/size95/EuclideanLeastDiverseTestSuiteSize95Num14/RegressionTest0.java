import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0010");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1.0000001f, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000007490142924d + "'", double2 == 1.0000007490142924d);
    }

    @Test
    public void test0022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0022");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 100, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.221710484165165d + "'", double2 == 37.221710484165165d);
    }

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1771933557663626E-8d + "'", double1 == 5.1771933557663626E-8d);
    }

    @Test
    public void test0132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0132");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (short) 10, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.180339887498949d + "'", double2 == 11.180339887498949d);
    }

    @Test
    public void test0156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0156");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.4000000953674316d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6747409616071767d + "'", double2 == 0.6747409616071767d);
    }

    @Test
    public void test0170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0170");
        double double1 = org.apache.commons.math3.util.FastMath.exp((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20787957635076193d + "'", double1 == 0.20787957635076193d);
    }

    @Test
    public void test0176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0176");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) -10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-572.9577951308232d) + "'", double1 == (-572.9577951308232d));
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.0000000000000013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1619136520741884E-8d + "'", double1 == 5.1619136520741884E-8d);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(35.00000000000001d, 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.543259751217975E34d + "'", double2 == 4.543259751217975E34d);
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) '4', 0.4548324228266097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.19938689826849196d) + "'", double2 == (-0.19938689826849196d));
    }

    @Test
    public void test0243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0243");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 108004289, 0.7074525319875541d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.08004289E8d + "'", double2 == 1.08004289E8d);
    }

    @Test
    public void test0250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0250");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test0256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0256");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.9477340797526748d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9477340797526748d + "'", double2 == 0.9477340797526748d);
    }

    @Test
    public void test0260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0260");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.01163552869339463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011636053815897385d + "'", double1 == 0.011636053815897385d);
    }

    @Test
    public void test0281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0281");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 1L, 1.0000007490142924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853977888904424d + "'", double2 == 0.7853977888904424d);
    }

    @Test
    public void test0287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0287");
        double double2 = org.apache.commons.math3.util.FastMath.min((-0.9092974268256817d), 140608.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9092974268256817d) + "'", double2 == (-0.9092974268256817d));
    }

    @Test
    public void test0289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0289");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.9477340797526748d, 60.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03991993882471059d + "'", double2 == 0.03991993882471059d);
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(5.1771933557663626E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003727046361340435d + "'", double1 == 0.003727046361340435d);
    }

    @Test
    public void test0302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0302");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test0322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0322");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.005949889552157361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07713552717235658d + "'", double1 == 0.07713552717235658d);
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(4.0d, (double) 5076L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.880219015028782E-4d + "'", double2 == 7.880219015028782E-4d);
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.972630067242408d, 60.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-147.53614766643088d) + "'", double2 == (-147.53614766643088d));
    }

    @Test
    public void test0376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0376");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((long) 200, (long) (-2147483648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-429496729600L) + "'", long2 == (-429496729600L));
    }

    @Test
    public void test0384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0384");
        double double2 = org.apache.commons.math3.util.FastMath.max(140608.00000000003d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 140608.00000000003d + "'", double2 == 140608.00000000003d);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.08671120204036789d, 0.003727046361340435d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.003727046361340435d + "'", double2 == 0.003727046361340435d);
    }

    @Test
    public void test0430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0430");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.8813735870195429d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.881373587019543d + "'", double2 == 0.881373587019543d);
    }

    @Test
    public void test0456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0456");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.0000007490142926d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 100, 74.20324596385817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.20324596385817d + "'", double2 == 74.20324596385817d);
    }

    @Test
    public void test0485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0485");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-0.4505495340698077d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4837330092051468d) + "'", double1 == (-0.4837330092051468d));
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.003727046361340435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0037270549900499652d + "'", double1 == 0.0037270549900499652d);
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 32, 0.07713552717235658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3064732953137475d + "'", double2 == 1.3064732953137475d);
    }

    @Test
    public void test0514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0514");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-6.053272382792838d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.060458951067639564d) + "'", double2 == (-0.060458951067639564d));
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (-5131349491390734479L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4472481130760592d + "'", double1 == 0.4472481130760592d);
    }

    @Test
    public void test0562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0562");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4139922992572981d) + "'", double1 == (-0.4139922992572981d));
    }

    @Test
    public void test0590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0590");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(1.5458015331759765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.56790381583535d + "'", double1 == 88.56790381583535d);
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        double double1 = org.apache.commons.math3.util.FastMath.sin(37.221710484165165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45947263750322936d) + "'", double1 == (-0.45947263750322936d));
    }

    @Test
    public void test0594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0594");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.6108652381980153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47677144967045465d + "'", double1 == 0.47677144967045465d);
    }

    @Test
    public void test0595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0595");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(2.220446049250313E-16d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test0619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0619");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 19.999998f, (double) (-1661989495));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592641556024d + "'", double2 == 3.141592641556024d);
    }

    @Test
    public void test0655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0655");
        double double2 = org.apache.commons.math3.util.FastMath.pow(9.094947017729282E-13d, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.099511627776E12d + "'", double2 == 1.099511627776E12d);
    }

    @Test
    public void test0658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0658");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((long) (-1661989495), (long) (-13));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1661989508L) + "'", long2 == (-1661989508L));
    }

    @Test
    public void test0667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0667");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, (double) 5096L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5095.663284122645d + "'", double2 == 5095.663284122645d);
    }

    @Test
    public void test0674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0674");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (-1661989495));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024805649680816708d + "'", double1 == 0.024805649680816708d);
    }

    @Test
    public void test0681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0681");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 110, 0.9971172387049709d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 109.99999999999999d + "'", double2 == 109.99999999999999d);
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.4598215102238088d, 9.9498743710662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.9498743710662d + "'", double2 == 9.9498743710662d);
    }

    @Test
    public void test0709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0709");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 5.0000005f, (double) 198);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2857848547507853d + "'", double2 == 3.2857848547507853d);
    }

    @Test
    public void test0730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0730");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 9.536743E-7f, 5.1619136520741884E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999992844070772d + "'", double2 == 0.9999992844070772d);
    }

    @Test
    public void test0734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0734");
        double double2 = org.apache.commons.math3.util.FastMath.min(1024.0d, 2.1922076124372905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1922076124372905d + "'", double2 == 2.1922076124372905d);
    }

    @Test
    public void test0750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0750");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(8.881784197001252E-16d, (double) 1587894540);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.58789454E9d + "'", double2 == 1.58789454E9d);
    }

    @Test
    public void test0760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0760");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((long) (-1093385216), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1093385316L) + "'", long2 == (-1093385316L));
    }

    @Test
    public void test0780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0780");
        double double1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((int) (short) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test0782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0782");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.024805649680816708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.024808194288585612d + "'", double1 == 0.024808194288585612d);
    }

    @Test
    public void test0804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0804");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.02709489822891885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test0827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0827");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-1.13340211407629d), 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2169812532937317E9d) + "'", double2 == (-1.2169812532937317E9d));
    }

    @Test
    public void test0859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0859");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 1.08062323E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test0869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0869");
        double double2 = org.apache.commons.math3.util.FastMath.min(3.2284059319236994E-11d, (double) 110L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2284059319236994E-11d + "'", double2 == 3.2284059319236994E-11d);
    }

    @Test
    public void test0877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0877");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.275344667466088E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.275085847057931E-4d + "'", double1 == 2.275085847057931E-4d);
    }

    @Test
    public void test0894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0894");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(1.5574077246549023d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549023d + "'", double2 == 1.5574077246549023d);
    }

    @Test
    public void test0902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0902");
        double double2 = org.apache.commons.math3.util.FastMath.min(60.0d, 1.570796178875084d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796178875084d + "'", double2 == 1.570796178875084d);
    }

    @Test
    public void test0905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0905");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(4.700480365792417d, 4.2967408809394625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.36839837534811d + "'", double2 == 6.36839837534811d);
    }

    @Test
    public void test0925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0925");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(3.2284059319236994E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8497403445422735E-9d + "'", double1 == 1.8497403445422735E-9d);
    }

    @Test
    public void test0941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0941");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5574077246549023d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4425922753450977d) + "'", double2 == (-0.4425922753450977d));
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(4.543259751217975E34d, (double) 5076L, (double) 1023L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1023.0d) + "'", double3 == (-1023.0d));
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (-9.7656244E-4f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.765625970127479E-4d) + "'", double1 == (-9.765625970127479E-4d));
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        double double1 = org.apache.commons.math3.util.FastMath.tan(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.8497403445422735E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0679515313825692E-25d + "'", double1 == 2.0679515313825692E-25d);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (-1661989508L), (double) (-540021445L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.40021445E8d) + "'", double2 == (-5.40021445E8d));
    }

    @Test
    public void test1055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1055");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(53248.0d, (double) 808182912);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.081829137541509E8d + "'", double2 == 8.081829137541509E8d);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        double double2 = org.apache.commons.math3.util.FastMath.min((-2.147483648E9d), (double) (-25));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.147483648E9d) + "'", double2 == (-2.147483648E9d));
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        double double1 = org.apache.commons.math3.util.FastMath.tan(1.3833875135814552E-73d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3833875135814552E-73d + "'", double1 == 1.3833875135814552E-73d);
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        double double1 = org.apache.commons.math3.util.FastMath.floor(7.251547794405553E162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.251547794405553E162d + "'", double1 == 7.251547794405553E162d);
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) (short) -10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(6.9177770887761845E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9177770887761845E-18d + "'", double1 == 6.9177770887761845E-18d);
    }

    @Test
    public void test1217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1217");
        double double2 = org.apache.commons.math3.util.FastMath.log(3.7465132241506285d, 0.4548324228266097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5964649905501589d) + "'", double2 == (-0.5964649905501589d));
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) '4', (double) 0.2f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.000384613973694d + "'", double2 == 52.000384613973694d);
    }

    @Test
    public void test1241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1241");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(19.276261250694787d, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0697727915221542E10d + "'", double2 == 2.0697727915221542E10d);
    }

    @Test
    public void test1269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1269");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((long) 5096, (-429496729600L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-429496724504L) + "'", long2 == (-429496724504L));
    }

    @Test
    public void test1272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1272");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.8484934041747324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8484934041747324d + "'", double2 == 0.8484934041747324d);
    }

    @Test
    public void test1288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1288");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-2.14748339E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963263292353d) + "'", double1 == (-1.5707963263292353d));
    }

    @Test
    public void test1300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1300");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((-5131349491390734479L), 181L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5131349491390734479L + "'", long2 == 5131349491390734479L);
    }

    @Test
    public void test1303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1303");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 0.8f, 7.251547794405553E162d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8000000119209291d + "'", double2 == 0.8000000119209291d);
    }

    @Test
    public void test1304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1304");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 2121622156);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0042995373162688245d + "'", double1 == 0.0042995373162688245d);
    }

    @Test
    public void test1312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1312");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((-2.147483648E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.748066029033894E7d) + "'", double1 == (-3.748066029033894E7d));
    }

    @Test
    public void test1365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1365");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.0038847791937455d, 0.9971172387049709d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0038847791937455d + "'", double2 == 1.0038847791937455d);
    }

    @Test
    public void test1368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1368");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) (short) -1, 1.57079627517576d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.57079627517576d + "'", double2 == 0.57079627517576d);
    }

    @Test
    public void test1370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1370");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(200.0d, 1.09861228866811d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 200.00301734964103d + "'", double2 == 200.00301734964103d);
    }

    @Test
    public void test1388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1388");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.6666666666666666d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test1428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1428");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(6.172526898753366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test1432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1432");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(79.8015379230834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2716298756089954E34d + "'", double1 == 2.2716298756089954E34d);
    }

    @Test
    public void test1441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1441");
        double double2 = org.apache.commons.math3.util.FastMath.max(74.20998390764434d, (-25.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.20998390764434d + "'", double2 == 74.20998390764434d);
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-2.0614401790261978E78d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 381, 1.1276259652063807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 813.4259380574406d + "'", double2 == 813.4259380574406d);
    }

    @Test
    public void test1494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1494");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(10.0d, (double) (-1300L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1296.902543893354d) + "'", double2 == (-1296.902543893354d));
    }

    @Test
    public void test1499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1499");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(1.846840192E9d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.131728887557983d + "'", double2 == 4.131728887557983d);
    }

}
