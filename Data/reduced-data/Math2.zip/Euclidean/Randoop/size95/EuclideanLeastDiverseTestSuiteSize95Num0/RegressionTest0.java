import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0010");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 1.0000001f, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000007490142924d + "'", double2 == 1.0000007490142924d);
    }

    @Test
    public void test0032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0032");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 100, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.221710484165165d + "'", double2 == 37.221710484165165d);
    }

    @Test
    public void test0041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0041");
        org.apache.commons.math3.fraction.FractionConversionException fractionConversionException2 = new org.apache.commons.math3.fraction.FractionConversionException((-0.6321205588285577d), (int) (short) 0);
    }

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1771933557663626E-8d + "'", double1 == 5.1771933557663626E-8d);
    }

    @Test
    public void test0111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0111");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) 19.999998f, 1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.999998092651367d + "'", double2 == 19.999998092651367d);
    }

    @Test
    public void test0132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0132");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (short) 10, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.180339887498949d + "'", double2 == 11.180339887498949d);
    }

    @Test
    public void test0156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0156");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.4000000953674316d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6747409616071767d + "'", double2 == 0.6747409616071767d);
    }

    @Test
    public void test0176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0176");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) -10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-572.9577951308232d) + "'", double1 == (-572.9577951308232d));
    }

    @Test
    public void test0198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0198");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(1.0000000000000013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.1619136520741884E-8d + "'", double1 == 5.1619136520741884E-8d);
    }

    @Test
    public void test0200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0200");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(35.00000000000001d, 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.543259751217975E34d + "'", double2 == 4.543259751217975E34d);
    }

    @Test
    public void test0215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0215");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) '4', 0.4548324228266097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.19938689826849196d) + "'", double2 == (-0.19938689826849196d));
    }

    @Test
    public void test0219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0219");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 3465, 0.4548324228266097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.08660290688743044d + "'", double2 == 0.08660290688743044d);
    }

    @Test
    public void test0243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0243");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 108004289, 0.7074525319875541d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.08004289E8d + "'", double2 == 1.08004289E8d);
    }

    @Test
    public void test0256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0256");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.9477340797526748d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9477340797526748d + "'", double2 == 0.9477340797526748d);
    }

    @Test
    public void test0258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0258");
        double double2 = org.apache.commons.math3.util.ArithmeticUtils.binomialCoefficientDouble((int) 'a', 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.432414667665563E25d + "'", double2 == 4.432414667665563E25d);
    }

    @Test
    public void test0281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0281");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 1L, 1.0000007490142924d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853977888904424d + "'", double2 == 0.7853977888904424d);
    }

    @Test
    public void test0282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0282");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.7853981633974483d), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2284059319236994E-11d + "'", double2 == 3.2284059319236994E-11d);
    }

    @Test
    public void test0287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0287");
        double double2 = org.apache.commons.math3.util.FastMath.min((-0.9092974268256817d), 140608.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9092974268256817d) + "'", double2 == (-0.9092974268256817d));
    }

    @Test
    public void test0291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0291");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(9.030475559542557d, 0.47613905136749957d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.01616641643993455d) + "'", double2 == (-0.01616641643993455d));
    }

    @Test
    public void test0293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0293");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(5.1771933557663626E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003727046361340435d + "'", double1 == 0.003727046361340435d);
    }

    @Test
    public void test0353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0353");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(4.0d, (double) 5076L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.880219015028782E-4d + "'", double2 == 7.880219015028782E-4d);
    }

    @Test
    public void test0362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0362");
        double double2 = org.apache.commons.math3.util.FastMath.log(0.972630067242408d, 60.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-147.53614766643088d) + "'", double2 == (-147.53614766643088d));
    }

    @Test
    public void test0375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0375");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(4.543259751217975E34d, 9.9498743710662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.543259751217974E34d + "'", double2 == 4.543259751217974E34d);
    }

    @Test
    public void test0409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0409");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.08671120204036789d, 0.003727046361340435d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.003727046361340435d + "'", double2 == 0.003727046361340435d);
    }

    @Test
    public void test0430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0430");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter(0.8813735870195429d, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.881373587019543d + "'", double2 == 0.881373587019543d);
    }

    @Test
    public void test0449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0449");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(0.005949889552157361d, (double) (byte) -10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.005949889552157361d + "'", double2 == 0.005949889552157361d);
    }

    @Test
    public void test0478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0478");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 100, 74.20324596385817d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.20324596385817d + "'", double2 == 74.20324596385817d);
    }

    @Test
    public void test0498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0498");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.003727046361340435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0037270549900499652d + "'", double1 == 0.0037270549900499652d);
    }

    @Test
    public void test0506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0506");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 32, 0.07713552717235658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3064732953137475d + "'", double2 == 1.3064732953137475d);
    }

    @Test
    public void test0514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0514");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-6.053272382792838d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.060458951067639564d) + "'", double2 == (-0.060458951067639564d));
    }

    @Test
    public void test0519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0519");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) (-5131349491390734479L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4472481130760592d + "'", double1 == 0.4472481130760592d);
    }

    @Test
    public void test0581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0581");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.073741821E9d), (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0737418209999999E9d) + "'", double2 == (-1.0737418209999999E9d));
    }

    @Test
    public void test0592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0592");
        double double1 = org.apache.commons.math3.util.FastMath.sin(37.221710484165165d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45947263750322936d) + "'", double1 == (-0.45947263750322936d));
    }

    @Test
    public void test0595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0595");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(2.220446049250313E-16d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test0614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0614");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 0, (float) (-5131349491390734479L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.1313493E18f) + "'", float2 == (-5.1313493E18f));
    }

    @Test
    public void test0619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0619");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 19.999998f, (double) (-1661989495));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592641556024d + "'", double2 == 3.141592641556024d);
    }

    @Test
    public void test0626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0626");
        double double1 = org.apache.commons.math3.util.FastMath.rint(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test0658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0658");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((long) (-1661989495), (long) (-13));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1661989508L) + "'", long2 == (-1661989508L));
    }

    @Test
    public void test0667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0667");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(0.0d, (double) 5096L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5095.663284122645d + "'", double2 == 5095.663284122645d);
    }

    @Test
    public void test0681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0681");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 110, 0.9971172387049709d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 109.99999999999999d + "'", double2 == 109.99999999999999d);
    }

    @Test
    public void test0686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0686");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.4598215102238088d, 9.9498743710662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.9498743710662d + "'", double2 == 9.9498743710662d);
    }

    @Test
    public void test0709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0709");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 5.0000005f, (double) 198);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2857848547507853d + "'", double2 == 3.2857848547507853d);
    }

    @Test
    public void test0730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0730");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 9.536743E-7f, 5.1619136520741884E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999992844070772d + "'", double2 == 0.9999992844070772d);
    }

    @Test
    public void test0734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0734");
        double double2 = org.apache.commons.math3.util.FastMath.min(1024.0d, 2.1922076124372905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1922076124372905d + "'", double2 == 2.1922076124372905d);
    }

    @Test
    public void test0737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0737");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) (-1661989508L), (double) 11L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.015949010848999d + "'", double2 == 9.015949010848999d);
    }

    @Test
    public void test0760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0760");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.subAndCheck((long) (-1093385216), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1093385316L) + "'", long2 == (-1093385316L));
    }

    @Test
    public void test0780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0780");
        double double1 = org.apache.commons.math3.util.ArithmeticUtils.factorialDouble((int) (short) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test0804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0804");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.02709489822891885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test0827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0827");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((-1.13340211407629d), 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2169812532937317E9d) + "'", double2 == (-1.2169812532937317E9d));
    }

    @Test
    public void test0847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0847");
        org.apache.commons.math3.fraction.BigFraction bigFraction2 = new org.apache.commons.math3.fraction.BigFraction((long) (-1073741824), (long) (-1));
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (-1));
    }

    @Test
    public void test0869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0869");
        double double2 = org.apache.commons.math3.util.FastMath.min(3.2284059319236994E-11d, (double) 110L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2284059319236994E-11d + "'", double2 == 3.2284059319236994E-11d);
    }

    @Test
    public void test0877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0877");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(2.275344667466088E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.275085847057931E-4d + "'", double1 == 2.275085847057931E-4d);
    }

    @Test
    public void test0894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0894");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(1.5574077246549023d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549023d + "'", double2 == 1.5574077246549023d);
    }

    @Test
    public void test0905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0905");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(4.700480365792417d, 4.2967408809394625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.36839837534811d + "'", double2 == 6.36839837534811d);
    }

    @Test
    public void test0925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0925");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(3.2284059319236994E-11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8497403445422735E-9d + "'", double1 == 1.8497403445422735E-9d);
    }

    @Test
    public void test0941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0941");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(1.5574077246549023d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4425922753450977d) + "'", double2 == (-0.4425922753450977d));
    }

    @Test
    public void test0947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0947");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(4.543259751217975E34d, (double) 5076L, (double) 1023L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1023.0d) + "'", double3 == (-1023.0d));
    }

    @Test
    public void test0979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0979");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (-9.7656244E-4f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.765625970127479E-4d) + "'", double1 == (-9.765625970127479E-4d));
    }

    @Test
    public void test0984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0984");
        double double1 = org.apache.commons.math3.util.FastMath.tan(3.469446951953614E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test1020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1020");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 544773633716L, (double) (-10000000000000L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.44773603E11f + "'", float2 == 5.44773603E11f);
    }

    @Test
    public void test1026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1026");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.8497403445422735E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0679515313825692E-25d + "'", double1 == 2.0679515313825692E-25d);
    }

    @Test
    public void test1040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1040");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-2005335615));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test1047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1047");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (-1661989508L), (double) (-540021445L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.40021445E8d) + "'", double2 == (-5.40021445E8d));
    }

    @Test
    public void test1055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1055");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(53248.0d, (double) 808182912);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.081829137541509E8d + "'", double2 == 8.081829137541509E8d);
    }

    @Test
    public void test1087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1087");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 1.9047619f, 10.000000000000002d, 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.90476191043854d + "'", double3 == 9.90476191043854d);
    }

    @Test
    public void test1095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1095");
        double double2 = org.apache.commons.math3.util.FastMath.min((-2.147483648E9d), (double) (-25));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.147483648E9d) + "'", double2 == (-2.147483648E9d));
    }

    @Test
    public void test1099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1099");
        double double1 = org.apache.commons.math3.util.FastMath.tan(1.3833875135814552E-73d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3833875135814552E-73d + "'", double1 == 1.3833875135814552E-73d);
    }

    @Test
    public void test1147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1147");
        double double1 = org.apache.commons.math3.util.FastMath.floor(7.251547794405553E162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.251547794405553E162d + "'", double1 == 7.251547794405553E162d);
    }

    @Test
    public void test1186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1186");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) (short) -10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test1195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1195");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(6.9177770887761845E-18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9177770887761845E-18d + "'", double1 == 6.9177770887761845E-18d);
    }

    @Test
    public void test1206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1206");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 1.66199309E9f, 156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6619930880000074E9d + "'", double2 == 1.6619930880000074E9d);
    }

    @Test
    public void test1217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1217");
        double double2 = org.apache.commons.math3.util.FastMath.log(3.7465132241506285d, 0.4548324228266097d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5964649905501589d) + "'", double2 == (-0.5964649905501589d));
    }

    @Test
    public void test1225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1225");
        org.apache.commons.math3.fraction.FractionConversionException fractionConversionException3 = new org.apache.commons.math3.fraction.FractionConversionException((double) 98.0f, 808182912L, (long) 200);
    }

    @Test
    public void test1226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1226");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) '4', (double) 0.2f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.000384613973694d + "'", double2 == 52.000384613973694d);
    }

    @Test
    public void test1241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1241");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(19.276261250694787d, 30);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0697727915221542E10d + "'", double2 == 2.0697727915221542E10d);
    }

    @Test
    public void test1269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1269");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.addAndCheck((long) 5096, (-429496729600L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-429496724504L) + "'", long2 == (-429496724504L));
    }

    @Test
    public void test1272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1272");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.8484934041747324d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8484934041747324d + "'", double2 == 0.8484934041747324d);
    }

    @Test
    public void test1288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1288");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-2.14748339E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963263292353d) + "'", double1 == (-1.5707963263292353d));
    }

    @Test
    public void test1303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1303");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 0.8f, 7.251547794405553E162d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8000000119209291d + "'", double2 == 0.8000000119209291d);
    }

    @Test
    public void test1312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1312");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((-2.147483648E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.748066029033894E7d) + "'", double1 == (-3.748066029033894E7d));
    }

    @Test
    public void test1365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1365");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.0038847791937455d, 0.9971172387049709d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0038847791937455d + "'", double2 == 1.0038847791937455d);
    }

    @Test
    public void test1368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1368");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) (short) -1, 1.57079627517576d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.57079627517576d + "'", double2 == 0.57079627517576d);
    }

    @Test
    public void test1388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1388");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((-0.6666666666666666d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test1399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1399");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(5044.000000000001d, 1.7781512503836436d, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.726078919660722d + "'", double3 == 1.726078919660722d);
    }

    @Test
    public void test1420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1420");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.8484934041747324d, (double) 20L, (double) (-98L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.848493404174732d + "'", double3 == 18.848493404174732d);
    }

    @Test
    public void test1428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1428");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(6.172526898753366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test1432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1432");
        double double1 = org.apache.commons.math3.util.FastMath.sinh(79.8015379230834d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2716298756089954E34d + "'", double1 == 2.2716298756089954E34d);
    }

    @Test
    public void test1447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1447");
        org.apache.commons.math3.fraction.FractionConversionException fractionConversionException3 = new org.apache.commons.math3.fraction.FractionConversionException(1.6487542120848298E-4d, (long) (byte) 37, (long) 6);
    }

    @Test
    public void test1448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1448");
        double double1 = org.apache.commons.math3.util.FastMath.exp(3.6129868840628745E86d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test1450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1450");
        double double1 = org.apache.commons.math3.util.FastMath.atan((-2.0614401790261978E78d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 381, 1.1276259652063807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 813.4259380574406d + "'", double2 == 813.4259380574406d);
    }

    @Test
    public void test1460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1460");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.mulAndCheck((-808182912L), (long) (-1846840225));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1492584711039235200L + "'", long2 == 1492584711039235200L);
    }

    @Test
    public void test1468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1468");
        long long2 = org.apache.commons.math3.util.ArithmeticUtils.pow((long) (-808182895), (long) 1072693279);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2173912255149852529L + "'", long2 == 2173912255149852529L);
    }

    @Test
    public void test1494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1494");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(10.0d, (double) (-1300L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1296.902543893354d) + "'", double2 == (-1296.902543893354d));
    }

    @Test
    public void test1499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1499");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(1.846840192E9d, (double) 6L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.131728887557983d + "'", double2 == 4.131728887557983d);
    }

}
