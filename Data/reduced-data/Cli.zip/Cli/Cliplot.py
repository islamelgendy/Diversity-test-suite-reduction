import numpy as np
import matplotlib.pyplot as plt

plt.style.use('ggplot')
#Cli Euclidean
RL1 = []
RM1 = []
EL1 = [30.208333333333332, 40.416666666666664, 59.583333333333336]
EM1 = [51.458333333333336, 60.625, 62.5]
#Cli Hamming
RL2 = []
RM2 = []
EL2 = [26.875, 37.5, 58.541666666666664]
EM2 = [54.583333333333336, 58.958333333333336, 62.5]
#Cli Levenshtein
RL3 = []
RM3 = []
EL3 = [22.708333333333332, 40.833333333333336, 60.0]
EM3 = [53.541666666666664, 61.041666666666664, 62.5]
#Cli Manhattan
RL4 = [25.0, 25.0, 25.0]
RM4 = [28.125, 30.0, 30.625]
EL4 = [28.125, 39.375, 60.625]
EM4 = [50.0, 61.25, 62.5]
#Cli NCD
RL5 = [24.375, 25.0, 25.0]
RM5 = [25.833333333333332, 27.291666666666668, 31.041666666666668]
EL5 = [25.833333333333332, 44.375, 50.833333333333336]
EM5 = [46.666666666666664, 56.458333333333336, 62.5]

newdata = [RL1, RM1, EL1, EM1]
fig1, ax1 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax1.set_xlabel('Mutation Score')
ax1.set_ylabel('Euclidean')
ax1.set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])
ax1.set_title(' Clianalysis')
ax1.boxplot(newdata, vert=False)

fig.savefig('images/Cli_Euclidean.jpg', dpi=100)

newdata = [RL2, RM2, EL2, EM2]
fig2, ax2 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax2.set_xlabel('Mutation Score')
ax2.set_ylabel('Hamming')
ax2.set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])
ax2.set_title(' Clianalysis')
ax2.boxplot(newdata, vert=False)

fig.savefig('images/Cli_Hamming.jpg', dpi=100)

newdata = [RL3, RM3, EL3, EM3]
fig3, ax3 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax3.set_xlabel('Mutation Score')
ax3.set_ylabel('Levenshtein')
ax3.set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])
ax3.set_title(' Clianalysis')
ax3.boxplot(newdata, vert=False)

fig.savefig('images/Cli_Levenshtein.jpg', dpi=100)

newdata = [RL4, RM4, EL4, EM4]
fig4, ax4 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax4.set_xlabel('Mutation Score')
ax4.set_ylabel('Manhattan')
ax4.set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])
ax4.set_title(' Clianalysis')
ax4.boxplot(newdata, vert=False)

fig.savefig('images/Cli_Manhattan.jpg', dpi=100)

newdata = [RL5, RM5, EL5, EM5]
fig5, ax5 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax5.set_xlabel('Mutation Score')
ax5.set_ylabel('NCD')
ax5.set_yticklabels(['Ran_Least', 'Ran_Most', 'Evo_Least', 'Evo_Most'])
ax5.set_title(' Clianalysis')
ax5.boxplot(newdata, vert=False)

fig.savefig('images/Cli_NCD.jpg', dpi=100)

newdata = [RL1, RL2, RL3, RL4, RL5,
		RM1, RM2, RM3, RM4, RM5,
		EL1, EL2, EL3, EL4, EL5,
		EM1, EM2, EM3, EM4, EM5]
fig6, ax6 = plt.subplots()
ax1.axvline(62.5)
plt.subplots_adjust(right=0.95)
fig = plt.gcf()
fig.set_size_inches(8.5, 5)
ax1.set_xlabel('Mutation Score')
ax1.set_yticklabels(['Euc_RL','Ham_RL','Lev_RL','Man_RL','Ncd_RL',
			'Euc_RM','Ham_RM','Lev_RM','Man_RM','Ncd_RM',
			'Euc_EL','Ham_EL','Lev_EL','Man_EL','Ncd_EL',
			'Euc_EM','Ham_EM','Lev_EM','Man_EM','Ncd_EM'])
ax6.set_title(' Clianalysis')
ax6.boxplot(newdata, vert=False)

fig.savefig('images/Cli.jpg', dpi=100)
