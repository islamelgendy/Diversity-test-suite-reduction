package com.fasterxml.jackson.core.util;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test00235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00235");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        java.io.InputStream inputStream19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory1.createJsonParser(inputStream19);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory23 = jsonFactory1.configure(feature21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00268");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        java.io.InputStream inputStream19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory1.createJsonParser(inputStream19);
        com.fasterxml.jackson.core.JsonParser.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory1.disable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00383");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler19 = jsonFactory1._getBufferRecycler();
        char[][] charArray20 = bufferRecycler19._charBuffers;
        try {
            char[] charArray22 = bufferRecycler19.calloc((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(bufferRecycler19);
        org.junit.Assert.assertNotNull(charArray20);
    }

    @Test
    public void test00386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00386");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler19 = jsonFactory1._getBufferRecycler();
        com.fasterxml.jackson.core.JsonParser.Feature feature20 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory1.disable(feature20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(bufferRecycler19);
    }

    @Test
    public void test00406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00406");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory1.setOutputDecorator(outputDecorator19);
        java.net.URL uRL21 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory1.createParser(uRL21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00489");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory6.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: hi!");
        com.fasterxml.jackson.core.JsonFactory.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory20.enable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00542");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory6.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: hi!");
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            boolean boolean22 = jsonFactory20.isEnabled(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00648");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setRootValueSeparator("");
        com.fasterxml.jackson.core.JsonParser.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory18.enable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00716");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory1.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = new com.fasterxml.jackson.core.JsonFactory(objectCodec8);
        com.fasterxml.jackson.core.JsonFactory.Feature feature10 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory9.configure(feature10, false);
        int int13 = feature10.getMask();
        boolean boolean15 = feature10.enabledIn((-1));
        boolean boolean17 = feature10.enabledIn(2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature10);
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setCodec(objectCodec19);
        com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory18.setRootValueSeparator("");
        com.fasterxml.jackson.core.JsonParser.Feature feature23 = null;
        try {
            boolean boolean24 = jsonFactory22.isEnabled(feature23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature10.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(jsonFactory22);
    }

    @Test
    public void test00732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00732");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory(objectCodec2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory3.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.util.TextBuffer textBuffer7 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler6);
        char[] charArray8 = textBuffer7.contentsAsArray();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory3.createParser(charArray8, 0, (int) (byte) 0);
        bufferRecycler0.releaseCharBuffer((int) (byte) 0, charArray8);
        byte[] byteArray14 = bufferRecycler0.balloc((int) (short) 10);
        int int16 = bufferRecycler0.charBufferLength(3);
        byte[] byteArray18 = bufferRecycler0.allocByteBuffer(2);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer19 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        byte[] byteArray21 = null;
        bufferRecycler0.releaseByteBuffer(2, byteArray21);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer23 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        boolean boolean24 = textBuffer23.hasTextAsCharacters();
        char[] charArray25 = textBuffer23.contentsAsArray();
        try {
            char[] charArray26 = textBuffer23.expandCurrentSegment();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 200 + "'", int16 == 200);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray25), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray25), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray25), "[]");
    }

    @Test
    public void test00736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00736");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = new com.fasterxml.jackson.core.JsonFactory(objectCodec7);
        com.fasterxml.jackson.core.JsonFactory.Feature feature9 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory8.configure(feature9, false);
        boolean boolean12 = jsonFactory1.isEnabled(feature9);
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator13 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory1.setOutputDecorator(outputDecorator13);
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator15 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory14.setOutputDecorator(outputDecorator15);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory14.setCharacterEscapes(characterEscapes17);
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser("JSON");
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory23 = jsonFactory18.configure(feature21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature9.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00754");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory1.setOutputDecorator(outputDecorator19);
        java.io.File file21 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory1.createJsonParser(file21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00956");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.Version version16 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory2.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.setCodec(objectCodec19);
        java.io.InputStream inputStream21 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory20.createParser(inputStream21);
        java.io.OutputStream outputStream23 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding24 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator25 = jsonFactory20.createJsonGenerator(outputStream23, jsonEncoding24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(version16);
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(jsonParser22);
    }

    @Test
    public void test00976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00976");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory1.setCharacterEscapes(characterEscapes19);
        com.fasterxml.jackson.core.FormatSchema formatSchema21 = null;
        try {
            boolean boolean22 = jsonFactory20.canUseSchema(formatSchema21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test01282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01282");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory(objectCodec2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory3.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.util.TextBuffer textBuffer7 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler6);
        char[] charArray8 = textBuffer7.contentsAsArray();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory3.createParser(charArray8, 0, (int) (byte) 0);
        bufferRecycler0.releaseCharBuffer((int) (byte) 0, charArray8);
        byte[] byteArray14 = bufferRecycler0.balloc((int) (short) 10);
        byte[][] byteArray15 = bufferRecycler0._byteBuffers;
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = new com.fasterxml.jackson.core.JsonFactory(objectCodec17);
        com.fasterxml.jackson.core.JsonFactory jsonFactory19 = jsonFactory18.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.copy();
        java.lang.String str21 = jsonFactory20.getFormatName();
        byte[] byteArray24 = new byte[] { (byte) 0, (byte) -1 };
        com.fasterxml.jackson.core.JsonParser jsonParser25 = jsonFactory20.createParser(byteArray24);
        try {
            bufferRecycler0.releaseByteBuffer((int) ' ', byteArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(jsonFactory19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JSON" + "'", str21.equals("JSON"));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray24), "[0, -1]");
        org.junit.Assert.assertNotNull(jsonParser25);
    }

    @Test
    public void test01336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01336");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory(objectCodec2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory3.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.util.TextBuffer textBuffer7 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler6);
        char[] charArray8 = textBuffer7.contentsAsArray();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory3.createParser(charArray8, 0, (int) (byte) 0);
        bufferRecycler0.releaseCharBuffer((int) (byte) 0, charArray8);
        byte[] byteArray14 = bufferRecycler0.balloc((int) (short) 10);
        int int16 = bufferRecycler0.charBufferLength(3);
        byte[] byteArray18 = bufferRecycler0.allocByteBuffer(2);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer19 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        byte[] byteArray21 = null;
        bufferRecycler0.releaseByteBuffer(2, byteArray21);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer23 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        boolean boolean24 = textBuffer23.hasTextAsCharacters();
        char[] charArray25 = textBuffer23.contentsAsArray();
        try {
            char[] charArray27 = textBuffer23.expandCurrentSegment(1000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 200 + "'", int16 == 200);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(charArray25);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray25), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray25), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray25), "[]");
    }

    @Test
    public void test01369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01369");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator3 = jsonFactory2.getInputDecorator();
        java.io.InputStream inputStream4 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser5 = jsonFactory2.createJsonParser(inputStream4);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory7 = new com.fasterxml.jackson.core.JsonFactory(objectCodec6);
        boolean boolean8 = jsonFactory7.canUseCharArrays();
        java.io.Writer writer9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = jsonFactory7.createGenerator(writer9);
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory7.setCodec(objectCodec11);
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory7.setRootValueSeparator("hi!");
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator15 = jsonFactory7.getInputDecorator();
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) -1, (byte) -1, (byte) 1, (byte) -1 };
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory7.createJsonParser(byteArray21, (int) (short) 1, (-1));
        com.fasterxml.jackson.core.JsonParser jsonParser25 = jsonFactory2.createJsonParser(byteArray21);
        java.io.InputStream inputStream26 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser27 = jsonFactory2.createJsonParser(inputStream26);
        java.io.File file28 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding29 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = jsonFactory2.createGenerator(file28, jsonEncoding29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNull(inputDecorator3);
        org.junit.Assert.assertNotNull(jsonParser5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNull(inputDecorator15);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[-1, -1, -1, 1, -1]");
        org.junit.Assert.assertNotNull(jsonParser24);
        org.junit.Assert.assertNotNull(jsonParser25);
        org.junit.Assert.assertNotNull(jsonParser27);
    }

    @Test
    public void test01381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01381");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        java.io.Reader reader19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser(reader19);
        boolean boolean21 = jsonFactory18.requiresPropertyOrdering();
        java.io.InputStream inputStream22 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser23 = jsonFactory18.createJsonParser(inputStream22);
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonParser23);
    }

}
