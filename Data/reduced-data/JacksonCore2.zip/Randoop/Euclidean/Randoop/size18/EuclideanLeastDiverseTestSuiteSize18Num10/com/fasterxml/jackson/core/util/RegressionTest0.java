package com.fasterxml.jackson.core.util;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test00024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00024");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        byte[] byteArray19 = new byte[] {};
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory1.createParser(byteArray19, 262144, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 262144");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray19), "[]");
    }

    @Test
    public void test00140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00140");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        boolean boolean19 = jsonFactory2.requiresPropertyOrdering();
        com.fasterxml.jackson.core.JsonParser.Feature feature20 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory2.enable(feature20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test00200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00200");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        boolean boolean21 = jsonFactory20.requiresCustomCodec();
        com.fasterxml.jackson.core.format.InputAccessor inputAccessor22 = null;
        try {
            com.fasterxml.jackson.core.format.MatchStrength matchStrength23 = jsonFactory20.hasFormat(inputAccessor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test00245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00245");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        boolean boolean21 = jsonFactory20.requiresCustomCodec();
        java.io.File file22 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding23 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = jsonFactory20.createJsonGenerator(file22, jsonEncoding23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test00276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00276");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory6.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: hi!");
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator21 = jsonFactory20.getInputDecorator();
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNull(inputDecorator21);
    }

    @Test
    public void test00390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00390");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        java.io.Reader reader19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser(reader19);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            boolean boolean22 = jsonFactory18.isEnabled(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00422");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        java.io.Reader reader19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser(reader19);
        com.fasterxml.jackson.core.JsonParser.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory18.disable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00501");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setRootValueSeparator("");
        java.io.File file21 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory20.createJsonParser(file21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00632");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        boolean boolean2 = jsonFactory1.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature3 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory1.configure(feature3, false);
        java.io.Reader reader6 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory1.createParser(reader6);
        java.io.OutputStream outputStream8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = jsonFactory1.createJsonGenerator(outputStream8);
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = new com.fasterxml.jackson.core.JsonFactory(objectCodec10);
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory11.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser14 = jsonFactory12.createParser("hi!");
        com.fasterxml.jackson.core.JsonParser jsonParser16 = jsonFactory12.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory12.setCodec(objectCodec17);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler19 = new com.fasterxml.jackson.core.util.BufferRecycler();
        byte[][] byteArray20 = bufferRecycler19._byteBuffers;
        byte[] byteArray22 = bufferRecycler19.balloc(6);
        com.fasterxml.jackson.core.JsonParser jsonParser23 = jsonFactory18.createJsonParser(byteArray22);
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory1.createJsonParser(byteArray22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + feature3 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature3.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertNotNull(jsonParser14);
        org.junit.Assert.assertNotNull(jsonParser16);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertNotNull(jsonParser23);
        org.junit.Assert.assertNotNull(jsonParser24);
    }

    @Test
    public void test00686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00686");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory2.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory17.copy();
        java.io.Reader reader19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser(reader19);
        java.io.File file21 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory18.createParser(file21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00872");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory1.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = new com.fasterxml.jackson.core.JsonFactory(objectCodec8);
        com.fasterxml.jackson.core.JsonFactory.Feature feature10 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory9.configure(feature10, false);
        int int13 = feature10.getMask();
        boolean boolean15 = feature10.enabledIn((-1));
        boolean boolean17 = feature10.enabledIn(2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature10);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setInputDecorator(inputDecorator19);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory18.disable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature10.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00891");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        java.io.Reader reader19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory2.createJsonParser(reader19);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature21 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory2.enable(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test01157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01157");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        boolean boolean21 = jsonFactory20.requiresCustomCodec();
        com.fasterxml.jackson.core.JsonParser.Feature feature22 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory20.configure(feature22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test01223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01223");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.Version version16 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory2.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.setCodec(objectCodec19);
        com.fasterxml.jackson.core.Version version21 = jsonFactory20.version();
        java.io.File file22 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding23 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = jsonFactory20.createGenerator(file22, jsonEncoding23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(version16);
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(version21);
    }

    @Test
    public void test01229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01229");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler19 = jsonFactory1._getBufferRecycler();
        try {
            byte[] byteArray22 = bufferRecycler19.allocByteBuffer((int) '4', 262144);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(bufferRecycler19);
    }

    @Test
    public void test01362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01362");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory22 = jsonFactory20.setRootValueSeparator("JSON");
        com.fasterxml.jackson.core.JsonGenerator.Feature feature23 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory20.disable(feature23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(jsonFactory22);
    }

    @Test
    public void test01396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01396");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.lang.String str18 = jsonFactory2.getFormatName();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.setInputDecorator(inputDecorator19);
        boolean boolean21 = jsonFactory20.canUseCharArrays();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature22 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory23 = jsonFactory20.enable(feature22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSON" + "'", str18.equals("JSON"));
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test01411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01411");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory1.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = new com.fasterxml.jackson.core.JsonFactory(objectCodec8);
        com.fasterxml.jackson.core.JsonFactory.Feature feature10 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory9.configure(feature10, false);
        int int13 = feature10.getMask();
        boolean boolean15 = feature10.enabledIn((-1));
        boolean boolean17 = feature10.enabledIn(2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature10);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setInputDecorator(inputDecorator19);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes21 = jsonFactory20.getCharacterEscapes();
        boolean boolean22 = jsonFactory20.canHandleBinaryNatively();
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature10.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNull(characterEscapes21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

}
