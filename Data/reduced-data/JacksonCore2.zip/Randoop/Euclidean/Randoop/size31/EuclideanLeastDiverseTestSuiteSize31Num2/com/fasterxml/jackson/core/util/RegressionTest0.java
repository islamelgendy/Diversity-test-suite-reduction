package com.fasterxml.jackson.core.util;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test00057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00057");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.JsonParser.Feature feature19 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory18.configure(feature19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00140");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory6.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory.Feature feature14 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory13.configure(feature14, false);
        boolean boolean17 = jsonFactory6.isEnabled(feature14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory2.enable(feature14);
        boolean boolean19 = jsonFactory2.requiresPropertyOrdering();
        com.fasterxml.jackson.core.JsonParser.Feature feature20 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory2.enable(feature20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature14.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test00164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00164");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setRootValueSeparator("");
        boolean boolean21 = jsonFactory18.canHandleBinaryNatively();
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test00189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00189");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.Version version16 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory2.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.setCodec(objectCodec19);
        java.io.File file21 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding22 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = jsonFactory20.createJsonGenerator(file21, jsonEncoding22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(version16);
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test00219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00219");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        java.io.File file19 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding20 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = jsonFactory1.createJsonGenerator(file19, jsonEncoding20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00233");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        boolean boolean21 = jsonFactory20.requiresCustomCodec();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature22 = null;
        try {
            boolean boolean23 = jsonFactory20.isEnabled(feature22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test00238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00238");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        java.net.URL uRL19 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createJsonParser(uRL19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00276");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory6.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: hi!");
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator21 = jsonFactory20.getInputDecorator();
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNull(inputDecorator21);
    }

    @Test
    public void test00303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00303");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        byte[] byteArray5 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser8 = jsonFactory2.createJsonParser(byteArray5, (int) (short) 0, (int) (byte) -1);
        com.fasterxml.jackson.core.JsonFactory.Feature feature9 = com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = jsonFactory2.disable(feature9);
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = new com.fasterxml.jackson.core.JsonFactory(objectCodec11);
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory12.copy();
        com.fasterxml.jackson.core.Version version14 = jsonFactory13.version();
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10 };
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory13.createJsonParser(byteArray17);
        com.fasterxml.jackson.core.JsonParser jsonParser21 = jsonFactory2.createParser(byteArray17, 3, (int) (short) 1);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler22 = jsonFactory2._getBufferRecycler();
        java.io.File file23 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding24 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator25 = jsonFactory2.createGenerator(file23, jsonEncoding24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertNotNull(jsonParser8);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES + "'", feature9.equals(com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory10);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(version14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[10, 10]");
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonParser21);
        org.junit.Assert.assertNotNull(bufferRecycler22);
    }

    @Test
    public void test00327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00327");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        boolean boolean2 = jsonFactory1.canUseCharArrays();
        java.io.Writer writer3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = jsonFactory1.createGenerator(writer3);
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setCodec(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = jsonFactory1.setRootValueSeparator("hi!");
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator9 = jsonFactory1.getInputDecorator();
        java.io.Writer writer10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = jsonFactory1.createJsonGenerator(writer10);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler14 = new com.fasterxml.jackson.core.util.BufferRecycler(0, 0);
        byte[][] byteArray15 = bufferRecycler14._byteBuffers;
        byte[] byteArray17 = bufferRecycler14.balloc((int) (byte) 1);
        byte[] byteArray19 = bufferRecycler14.balloc((int) (short) 10);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer20 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler14);
        char[][] charArray21 = bufferRecycler14._charBuffers;
        byte[] byteArray23 = bufferRecycler14.balloc(0);
        com.fasterxml.jackson.core.JsonParser jsonParser24 = jsonFactory1.createJsonParser(byteArray23);
        java.io.File file25 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser26 = jsonFactory1.createJsonParser(file25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonFactory8);
        org.junit.Assert.assertNull(inputDecorator9);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[0]");
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray19), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertNotNull(charArray21);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[]");
        org.junit.Assert.assertNotNull(jsonParser24);
    }

    @Test
    public void test00400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00400");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = new com.fasterxml.jackson.core.JsonFactory(objectCodec7);
        com.fasterxml.jackson.core.JsonFactory.Feature feature9 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = jsonFactory8.configure(feature9, false);
        boolean boolean12 = jsonFactory1.isEnabled(feature9);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes13 = jsonFactory1.getCharacterEscapes();
        boolean boolean14 = jsonFactory1.canHandleBinaryNatively();
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = jsonFactory1.setRootValueSeparator("a");
        java.io.InputStream inputStream17 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory16.createJsonParser(inputStream17);
        com.fasterxml.jackson.core.FormatSchema formatSchema19 = null;
        try {
            boolean boolean20 = jsonFactory16.canUseSchema(formatSchema19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature9.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(characterEscapes13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertNotNull(jsonParser18);
    }

    @Test
    public void test00500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00500");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory(objectCodec2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory3.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.util.TextBuffer textBuffer7 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler6);
        char[] charArray8 = textBuffer7.contentsAsArray();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory3.createParser(charArray8, 0, (int) (byte) 0);
        bufferRecycler0.releaseCharBuffer((int) (byte) 0, charArray8);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer13 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        boolean boolean14 = textBuffer13.hasTextAsCharacters();
        char[] charArray15 = textBuffer13.contentsAsArray();
        boolean boolean16 = textBuffer13.hasTextAsCharacters();
        boolean boolean17 = textBuffer13.hasTextAsCharacters();
        textBuffer13.resetWithString("com.fasterxml.jackson.core.JsonParseException: hi!");
        textBuffer13.resetWithString("com.fasterxml.jackson.core.JsonParseException: ");
        try {
            char[] charArray22 = textBuffer13.expandCurrentSegment();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray15), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray15), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray15), "[]");
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test00554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00554");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory1.setCharacterEscapes(characterEscapes12);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator14 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory15 = jsonFactory1.setInputDecorator(inputDecorator14);
        java.lang.String str16 = jsonFactory1.getRootValueSeparator();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.setCharacterEscapes(characterEscapes17);
        java.io.InputStream inputStream19 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory18.createParser(inputStream19);
        java.io.File file21 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser22 = jsonFactory18.createParser(file21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(jsonFactory15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + " " + "'", str16.equals(" "));
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00641");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonParser.Feature feature19 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory18.configure(feature19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00644");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature19 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory1.configure(feature19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00813");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.JsonParser.Feature feature19 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory6.enable(feature19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test00927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00927");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory2.setRootValueSeparator("JSON");
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = new com.fasterxml.jackson.core.JsonFactory(objectCodec7);
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory8.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory9.createParser("hi!");
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory9.setCodec(objectCodec12);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler16 = new com.fasterxml.jackson.core.util.BufferRecycler(0, 0);
        byte[] byteArray18 = bufferRecycler16.balloc((int) 'a');
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory9.createJsonParser(byteArray18);
        com.fasterxml.jackson.core.JsonParser jsonParser20 = jsonFactory2.createParser(byteArray18);
        java.io.File file21 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding22 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = jsonFactory2.createGenerator(file21, jsonEncoding22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonParser20);
    }

    @Test
    public void test00953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00953");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        boolean boolean15 = jsonFactory2.requiresPropertyOrdering();
        java.io.InputStream inputStream16 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser(inputStream16);
        java.io.InputStream inputStream18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(inputStream18);
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator20 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory21 = jsonFactory2.setOutputDecorator(outputDecorator20);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature22 = null;
        try {
            boolean boolean23 = jsonFactory21.isEnabled(feature22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory21);
    }

    @Test
    public void test01012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01012");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory1.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = new com.fasterxml.jackson.core.JsonFactory(objectCodec8);
        com.fasterxml.jackson.core.JsonFactory.Feature feature10 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory9.configure(feature10, false);
        int int13 = feature10.getMask();
        boolean boolean15 = feature10.enabledIn((-1));
        boolean boolean17 = feature10.enabledIn(2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature10);
        boolean boolean19 = jsonFactory1.canUseCharArrays();
        com.fasterxml.jackson.core.FormatSchema formatSchema20 = null;
        try {
            boolean boolean21 = jsonFactory1.canUseSchema(formatSchema20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature10.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test01058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01058");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory2.setRootValueSeparator("JSON");
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = jsonFactory6.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: JSON");
        boolean boolean9 = jsonFactory6.canHandleBinaryNatively();
        com.fasterxml.jackson.core.JsonFactory.Feature feature10 = com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = jsonFactory6.configure(feature10, false);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler13 = new com.fasterxml.jackson.core.util.BufferRecycler();
        byte[][] byteArray14 = bufferRecycler13._byteBuffers;
        char[] charArray16 = bufferRecycler13.allocCharBuffer(0);
        char[] charArray19 = bufferRecycler13.allocCharBuffer(0, (int) (short) 10);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer20 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler13);
        byte[] byteArray22 = bufferRecycler13.balloc(0);
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser25 = jsonFactory12.createJsonParser(byteArray22, (int) (short) 1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonFactory8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES + "'", feature10.equals(com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertNotNull(charArray16);
        org.junit.Assert.assertNotNull(charArray19);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[]");
    }

    @Test
    public void test01063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01063");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory1.setCodec(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory jsonFactory15 = jsonFactory1.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: JSON");
        boolean boolean16 = jsonFactory1.canUseCharArrays();
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.setOutputDecorator(outputDecorator17);
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory18.setCodec(objectCodec19);
        com.fasterxml.jackson.core.JsonParser.Feature feature21 = null;
        try {
            boolean boolean22 = jsonFactory18.isEnabled(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(jsonFactory15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test01066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01066");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.disable(feature15);
        com.fasterxml.jackson.core.format.InputAccessor inputAccessor19 = null;
        try {
            com.fasterxml.jackson.core.format.MatchStrength matchStrength20 = jsonFactory18.hasFormat(inputAccessor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test01085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01085");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.lang.String str18 = jsonFactory2.getFormatName();
        boolean boolean19 = jsonFactory2.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        com.fasterxml.jackson.core.JsonFactory.Feature feature21 = null;
        try {
            boolean boolean22 = jsonFactory2.isEnabled(feature21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSON" + "'", str18.equals("JSON"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jsonFactory20);
    }

    @Test
    public void test01099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01099");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory3 = new com.fasterxml.jackson.core.JsonFactory(objectCodec2);
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory3.copy();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = jsonFactory3.copy();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler6 = null;
        com.fasterxml.jackson.core.util.TextBuffer textBuffer7 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler6);
        char[] charArray8 = textBuffer7.contentsAsArray();
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory3.createParser(charArray8, 0, (int) (byte) 0);
        bufferRecycler0.releaseCharBuffer((int) (byte) 0, charArray8);
        com.fasterxml.jackson.core.util.TextBuffer textBuffer13 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        byte[] byteArray15 = bufferRecycler0.balloc((int) '4');
        com.fasterxml.jackson.core.util.TextBuffer textBuffer16 = new com.fasterxml.jackson.core.util.TextBuffer(bufferRecycler0);
        boolean boolean17 = textBuffer16.hasTextAsCharacters();
        char[] charArray18 = textBuffer16.getTextBuffer();
        textBuffer16.setCurrentLength(8);
        textBuffer16.setCurrentLength((int) (short) 100);
        textBuffer16.resetWithString("\000\000\000\000\000\000\000\000\000\000");
        int int25 = textBuffer16.size();
        try {
            char[] charArray26 = textBuffer16.finishCurrentSegment();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), "");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]");
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(charArray18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
    }

    @Test
    public void test01131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01131");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        boolean boolean15 = jsonFactory2.requiresPropertyOrdering();
        boolean boolean16 = jsonFactory2.requiresCustomCodec();
        boolean boolean17 = jsonFactory2.canUseCharArrays();
        java.io.Writer writer18 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator19 = jsonFactory2.createJsonGenerator(writer18);
        com.fasterxml.jackson.core.JsonParser jsonParser21 = jsonFactory2.createParser("hi!");
        com.fasterxml.jackson.core.FormatSchema formatSchema22 = null;
        try {
            boolean boolean23 = jsonFactory2.canUseSchema(formatSchema22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jsonGenerator19);
        org.junit.Assert.assertNotNull(jsonParser21);
    }

    @Test
    public void test01157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01157");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        boolean boolean21 = jsonFactory20.requiresCustomCodec();
        com.fasterxml.jackson.core.JsonParser.Feature feature22 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory20.configure(feature22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test01223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01223");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.Version version16 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory2.createJsonParser("");
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.setCodec(objectCodec19);
        com.fasterxml.jackson.core.Version version21 = jsonFactory20.version();
        java.io.File file22 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding23 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = jsonFactory20.createGenerator(file22, jsonEncoding23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(version16);
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(version21);
    }

    @Test
    public void test01274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01274");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator5 = jsonFactory1.getInputDecorator();
        char[] charArray8 = new char[] { ' ', 'a' };
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory1.createParser(charArray8, 10, (int) '4');
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory1.setCodec(objectCodec12);
        com.fasterxml.jackson.core.JsonFactory jsonFactory15 = jsonFactory1.setRootValueSeparator("com.fasterxml.jackson.core.JsonParseException: JSON");
        boolean boolean16 = jsonFactory1.canUseCharArrays();
        com.fasterxml.jackson.core.io.OutputDecorator outputDecorator17 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory1.setOutputDecorator(outputDecorator17);
        boolean boolean19 = jsonFactory1.requiresCustomCodec();
        java.io.OutputStream outputStream20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = jsonFactory1.createJsonGenerator(outputStream20);
        boolean boolean22 = jsonFactory1.requiresPropertyOrdering();
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNull(inputDecorator5);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray8), " a");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray8), "[ , a]");
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(jsonFactory15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonFactory18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test01354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01354");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory.Feature feature2 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory1.configure(feature2, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = jsonFactory1.setRootValueSeparator("");
        java.io.Writer writer7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createJsonGenerator(writer7);
        java.io.InputStream inputStream9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createParser(inputStream9);
        boolean boolean11 = jsonFactory6.canUseCharArrays();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = new com.fasterxml.jackson.core.JsonFactory(objectCodec12);
        boolean boolean14 = jsonFactory13.canUseCharArrays();
        com.fasterxml.jackson.core.JsonFactory.Feature feature15 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory13.configure(feature15, false);
        com.fasterxml.jackson.core.JsonFactory jsonFactory18 = jsonFactory6.enable(feature15);
        com.fasterxml.jackson.core.format.InputAccessor inputAccessor19 = null;
        try {
            com.fasterxml.jackson.core.format.MatchStrength matchStrength20 = jsonFactory18.hasFormat(inputAccessor19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature2.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature15.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonFactory18);
    }

    @Test
    public void test01371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01371");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.Version version3 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonFactory jsonFactory4 = jsonFactory2.copy();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.JsonFactory(objectCodec5);
        com.fasterxml.jackson.core.JsonFactory.Feature feature7 = com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = jsonFactory6.configure(feature7, false);
        int int10 = feature7.getMask();
        boolean boolean12 = feature7.enabledIn((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory14 = jsonFactory2.configure(feature7, true);
        com.fasterxml.jackson.core.Version version15 = jsonFactory2.version();
        com.fasterxml.jackson.core.JsonParser jsonParser17 = jsonFactory2.createParser("com.fasterxml.jackson.core.JsonParseException: JSON");
        java.io.Reader reader18 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser19 = jsonFactory2.createParser(reader18);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = jsonFactory2.copy();
        com.fasterxml.jackson.core.Version version21 = jsonFactory20.version();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature22 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory23 = jsonFactory20.enable(feature22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(version3);
        org.junit.Assert.assertNotNull(jsonFactory4);
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES + "'", feature7.equals(com.fasterxml.jackson.core.JsonFactory.Feature.INTERN_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonFactory14);
        org.junit.Assert.assertNotNull(version15);
        org.junit.Assert.assertNotNull(jsonParser17);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonFactory20);
        org.junit.Assert.assertNotNull(version21);
    }

    @Test
    public void test01412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01412");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory1 = new com.fasterxml.jackson.core.JsonFactory(objectCodec0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = jsonFactory1.copy();
        com.fasterxml.jackson.core.JsonParser jsonParser4 = jsonFactory2.createParser("hi!");
        byte[] byteArray5 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser8 = jsonFactory2.createJsonParser(byteArray5, (int) (short) 0, (int) (byte) -1);
        com.fasterxml.jackson.core.JsonFactory.Feature feature9 = com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES;
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = jsonFactory2.disable(feature9);
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory12 = new com.fasterxml.jackson.core.JsonFactory(objectCodec11);
        com.fasterxml.jackson.core.JsonFactory jsonFactory13 = jsonFactory12.copy();
        com.fasterxml.jackson.core.Version version14 = jsonFactory13.version();
        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10 };
        com.fasterxml.jackson.core.JsonParser jsonParser18 = jsonFactory13.createJsonParser(byteArray17);
        com.fasterxml.jackson.core.JsonParser jsonParser21 = jsonFactory2.createParser(byteArray17, 3, (int) (short) 1);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler22 = jsonFactory2._getBufferRecycler();
        com.fasterxml.jackson.core.JsonFactory jsonFactory23 = jsonFactory2.copy();
        com.fasterxml.jackson.core.FormatSchema formatSchema24 = null;
        try {
            boolean boolean25 = jsonFactory2.canUseSchema(formatSchema24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonFactory2);
        org.junit.Assert.assertNotNull(jsonParser4);
        org.junit.Assert.assertNotNull(jsonParser8);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES + "'", feature9.equals(com.fasterxml.jackson.core.JsonFactory.Feature.CANONICALIZE_FIELD_NAMES));
        org.junit.Assert.assertNotNull(jsonFactory10);
        org.junit.Assert.assertNotNull(jsonFactory13);
        org.junit.Assert.assertNotNull(version14);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[10, 10]");
        org.junit.Assert.assertNotNull(jsonParser18);
        org.junit.Assert.assertNotNull(jsonParser21);
        org.junit.Assert.assertNotNull(bufferRecycler22);
        org.junit.Assert.assertNotNull(jsonFactory23);
    }

}
