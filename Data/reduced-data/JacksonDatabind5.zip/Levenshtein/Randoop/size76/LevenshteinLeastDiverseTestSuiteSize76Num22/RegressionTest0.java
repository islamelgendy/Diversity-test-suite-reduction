import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory5 = objectMapper4.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode6 = objectMapper4.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper4);
        com.fasterxml.jackson.core.Base64Variant base64Variant8 = null;
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory9 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray15 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode16 = jsonNodeFactory9.binaryNode(byteArray15);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType17 = com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT;
        com.fasterxml.jackson.databind.node.ValueNode valueNode18 = jsonNodeFactory9.pojoNode((java.lang.Object) jsonNodeType17);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode19 = new com.fasterxml.jackson.databind.node.ObjectNode(jsonNodeFactory9);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory20 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray26 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode27 = jsonNodeFactory20.binaryNode(byteArray26);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = jsonNodeFactory9.binaryNode(byteArray26);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode29 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray26);
        try {
            tokenBuffer7.writeBinary(base64Variant8, byteArray26, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(typeFactory5);
        org.junit.Assert.assertNotNull(objectNode6);
        org.junit.Assert.assertNotNull(jsonNodeFactory9);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode16);
        org.junit.Assert.assertTrue("'" + jsonNodeType17 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT + "'", jsonNodeType17.equals(com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT));
        org.junit.Assert.assertNotNull(valueNode18);
        org.junit.Assert.assertNotNull(jsonNodeFactory20);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode27);
        org.junit.Assert.assertNotNull(binaryNode28);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = objectMapper4.writer(characterEscapes5);
        com.fasterxml.jackson.databind.InjectableValues injectableValues7 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper4.setInjectableValues(injectableValues7);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper8);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory10 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory10);
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = arrayNode11.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode11.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode16 = arrayNode14.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode18 = arrayNode14.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser19 = new com.fasterxml.jackson.databind.node.TreeTraversingParser((com.fasterxml.jackson.databind.JsonNode) arrayNode18);
        com.fasterxml.jackson.core.JsonLocation jsonLocation20 = treeTraversingParser19.getCurrentLocation();
        java.lang.String str21 = treeTraversingParser19.getCurrentName();
        int int23 = treeTraversingParser19.getValueAsInt((int) (short) 100);
        try {
            tokenBuffer9.copyCurrentStructure((com.fasterxml.jackson.core.JsonParser) treeTraversingParser19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectWriter6);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertNotNull(jsonNodeFactory10);
        org.junit.Assert.assertNull(jsonNode13);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(numericNode16);
        org.junit.Assert.assertNotNull(arrayNode18);
        org.junit.Assert.assertNotNull(jsonLocation20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer0 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper2 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory3 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper2);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext5 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper6 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory3, defaultSerializerProvider4, defaultDeserializationContext5);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory7 = objectMapper6.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = objectMapper6.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper6);
        tokenBuffer9.writeNull();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        longSerializer0.serialize((java.lang.Long) 0L, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer9, serializerProvider11);
        tokenBuffer9.writeBooleanField("DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)", true);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory17 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode18 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory17);
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = arrayNode18.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode21 = arrayNode18.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode23 = arrayNode21.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode25 = arrayNode21.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode27 = arrayNode25.add((java.lang.Float) 0.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode29 = arrayNode25.add("[TypeBindings for [array type, component type: [simple type, class java.lang.Object]]: {E=[simple type, class java.lang.Object]}]");
        com.fasterxml.jackson.databind.JsonNode jsonNode31 = arrayNode29.get("");
        tokenBuffer9.writeObjectField("true", (java.lang.Object) jsonNode31);
        tokenBuffer9.writeNumberField("unknown", 35.0f);
        org.junit.Assert.assertNotNull(typeFactory7);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(jsonNodeFactory17);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(arrayNode21);
        org.junit.Assert.assertNotNull(numericNode23);
        org.junit.Assert.assertNotNull(arrayNode25);
        org.junit.Assert.assertNotNull(arrayNode27);
        org.junit.Assert.assertNotNull(arrayNode29);
        org.junit.Assert.assertNull(jsonNode31);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        float float10 = bigIntegerNode9.floatValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider16 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        try {
            bigIntegerNode9.serializeWithType(jsonGenerator15, serializerProvider16, typeSerializer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        char[] charArray30 = new char[] { '#', ' ', '#', '#' };
        try {
            tokenBuffer1.writeRaw(charArray30, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(charArray30);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray30), "# ##");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray30), "# ##");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray30), "[#,  , #, #]");
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        java.lang.Object obj26 = tokenBuffer1.getOutputTarget();
        com.fasterxml.jackson.core.ObjectCodec objectCodec27 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer28 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec27);
        tokenBuffer28.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer28.setPrettyPrinter(prettyPrinter30);
        com.fasterxml.jackson.core.Base64Variant base64Variant32 = null;
        byte[] byteArray33 = new byte[] {};
        tokenBuffer28.writeBinary(base64Variant32, byteArray33, 0, (int) (byte) 0);
        try {
            tokenBuffer1.writeBinary(byteArray33, (int) (short) 1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(jsonGenerator31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[]");
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        tokenBuffer1.writeNullField("");
        tokenBuffer1.writeStartArray();
        com.fasterxml.jackson.core.SerializableString serializableString29 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer1.setRootValueSeparator(serializableString29);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.fasterxml.jackson.databind.ser.impl.FailingSerializer failingSerializer1 = new com.fasterxml.jackson.databind.ser.impl.FailingSerializer("[parameter #10, annotations: null]");
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode17 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal16);
        boolean boolean18 = decimalNode17.canConvertToLong();
        java.math.BigInteger bigInteger19 = decimalNode17.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        tokenBuffer21.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer21.setPrettyPrinter(prettyPrinter23);
        tokenBuffer21.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes26 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator27 = tokenBuffer21.setCharacterEscapes(characterEscapes26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        decimalNode17.serialize(jsonGenerator27, serializerProvider28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        try {
            failingSerializer1.serialize((java.lang.Object) 100, jsonGenerator27, serializerProvider30);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: [parameter #10, annotations: null]");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertNotNull(decimalNode17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(jsonGenerator27);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.databind.JavaType javaType2 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer4 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer5 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer6 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType2, false, typeSerializer4, objJsonSerializer5);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider7 = null;
        java.lang.reflect.Type type8 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode9 = objectArraySerializer6.getSchema(serializerProvider7, type8);
        java.math.BigInteger bigInteger10 = jsonNode9.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode11 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger10);
        short short12 = bigIntegerNode11.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode14 = bigIntegerNode11.get(100);
        java.math.BigDecimal bigDecimal15 = bigIntegerNode11.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal15);
        char[] charArray23 = new char[] { '4', '#', 'a', '#', 'a', ' ' };
        try {
            tokenBuffer1.writeString(charArray23, 4096, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 4097");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigIntegerNode11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNull(jsonNode14);
        org.junit.Assert.assertNotNull(bigDecimal15);
        org.junit.Assert.assertNotNull(charArray23);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray23), "4#a#a ");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray23), "4#a#a ");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray23), "[4, #, a, #, a,  ]");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer6 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec5);
        tokenBuffer6.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer6.setPrettyPrinter(prettyPrinter8);
        tokenBuffer6.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes11 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = tokenBuffer6.setCharacterEscapes(characterEscapes11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer6.writeNumber(bigDecimal26);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode28 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal26);
        tokenBuffer1.writeNumber(bigDecimal26);
        java.lang.String str30 = tokenBuffer1.toString();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator12);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[TokenBuffer: VALUE_NUMBER_FLOAT]" + "'", str30.equals("[TokenBuffer: VALUE_NUMBER_FLOAT]"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeNumber((double) 'a');
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter2 = tokenBuffer1.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser3 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException5 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser3, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference8 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException5.prependPath(reference8);
        tokenBuffer1.writeTypeId((java.lang.Object) reference8);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory11);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes13 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader14 = objectMapper12.reader(contextAttributes13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        java.lang.String str25 = com.fasterxml.jackson.databind.util.ClassUtil.getClassDescription((java.lang.Object) bigIntegerNode24);
        boolean boolean26 = bigIntegerNode24.isNull();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType27 = bigIntegerNode24.numberType();
        com.fasterxml.jackson.core.JsonParser jsonParser28 = bigIntegerNode24.traverse();
        byte[] byteArray29 = objectMapper12.writeValueAsBytes((java.lang.Object) bigIntegerNode24);
        try {
            tokenBuffer1.writeUTF8String(byteArray29, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(prettyPrinter2);
        org.junit.Assert.assertNotNull(jsonMappingException5);
        org.junit.Assert.assertNotNull(objectReader14);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "com.fasterxml.jackson.databind.node.BigIntegerNode" + "'", str25.equals("com.fasterxml.jackson.databind.node.BigIntegerNode"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + numberType27 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER + "'", numberType27.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER));
        org.junit.Assert.assertNotNull(jsonParser28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray29), "[48]");
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        boolean boolean26 = tokenBuffer1.canWriteBinaryNatively();
        com.fasterxml.jackson.core.ObjectCodec objectCodec27 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer28 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec27);
        tokenBuffer28.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer28.setPrettyPrinter(prettyPrinter30);
        com.fasterxml.jackson.core.Base64Variant base64Variant32 = null;
        byte[] byteArray33 = new byte[] {};
        tokenBuffer28.writeBinary(base64Variant32, byteArray33, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode39 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray33, (int) (short) 0, 0);
        try {
            tokenBuffer1.writeRawUTF8String(byteArray33, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonGenerator31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[]");
        org.junit.Assert.assertNotNull(binaryNode39);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        tokenBuffer12.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        com.fasterxml.jackson.databind.JavaType javaType20 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer22 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer23 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer24 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType20, false, typeSerializer22, objJsonSerializer23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        java.lang.reflect.Type type26 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = objectArraySerializer24.getSchema(serializerProvider25, type26);
        java.math.BigInteger bigInteger28 = jsonNode27.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode29 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger28);
        short short30 = bigIntegerNode29.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = bigIntegerNode29.get(100);
        java.math.BigDecimal bigDecimal33 = bigIntegerNode29.decimalValue();
        tokenBuffer19.writeNumber(bigDecimal33);
        tokenBuffer12.writeNumberField("hi!", bigDecimal33);
        boolean boolean36 = tokenBuffer12.canWriteObjectId();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider37 = null;
        bigIntegerNode9.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer12, serializerProvider37);
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNotNull(jsonGenerator15);
        org.junit.Assert.assertNotNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigIntegerNode29);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigDecimal33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        tokenBuffer1.writeNullField("");
        tokenBuffer1.writeStartArray();
        com.fasterxml.jackson.core.JsonGenerator.Feature feature29 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer1.enable(feature29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = objectReader3.getJsonFactory();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator6 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory7 = jsonFactory5.setInputDecorator(inputDecorator6);
        com.fasterxml.jackson.core.ObjectCodec objectCodec8 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec8);
        tokenBuffer9.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter11 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = tokenBuffer9.setPrettyPrinter(prettyPrinter11);
        com.fasterxml.jackson.core.Base64Variant base64Variant13 = null;
        byte[] byteArray14 = new byte[] {};
        tokenBuffer9.writeBinary(base64Variant13, byteArray14, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode20 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray14, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType21 = binaryNode20.getNodeType();
        byte[] byteArray22 = binaryNode20.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode23 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray22);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode24 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray22);
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser27 = jsonFactory7.createParser(byteArray22, 4096, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4096");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertNotNull(jsonFactory7);
        org.junit.Assert.assertNotNull(jsonGenerator12);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray14), "[]");
        org.junit.Assert.assertNotNull(binaryNode20);
        org.junit.Assert.assertTrue("'" + jsonNodeType21 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType21.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[]");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer1.setFeatureMask((int) (short) 100);
        com.fasterxml.jackson.databind.JavaType javaType10 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer12 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer13 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer14 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType10, false, typeSerializer12, objJsonSerializer13);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider15 = null;
        java.lang.reflect.Type type16 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode17 = objectArraySerializer14.getSchema(serializerProvider15, type16);
        java.math.BigInteger bigInteger18 = jsonNode17.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode19 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger18);
        short short20 = bigIntegerNode19.shortValue();
        int int21 = bigIntegerNode19.asInt();
        int int22 = bigIntegerNode19.asInt();
        tokenBuffer1.writeObjectId((java.lang.Object) int22);
        com.fasterxml.jackson.core.JsonParser jsonParser24 = tokenBuffer1.asParser();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonNode17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigIntegerNode19);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 0 + "'", short20 == (short) 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(jsonParser24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer sqlTimeSerializer0 = new com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer();
        boolean boolean1 = sqlTimeSerializer0.isUnwrappingSerializer();
        java.sql.Time time2 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec3 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer4 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec3);
        tokenBuffer4.flush();
        tokenBuffer4.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec9 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer10 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec9);
        tokenBuffer10.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter12 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator13 = tokenBuffer10.setPrettyPrinter(prettyPrinter12);
        tokenBuffer10.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        com.fasterxml.jackson.databind.JavaType javaType18 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer20 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer21 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer22 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType18, false, typeSerializer20, objJsonSerializer21);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider23 = null;
        java.lang.reflect.Type type24 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = objectArraySerializer22.getSchema(serializerProvider23, type24);
        java.math.BigInteger bigInteger26 = jsonNode25.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode27 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger26);
        short short28 = bigIntegerNode27.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = bigIntegerNode27.get(100);
        java.math.BigDecimal bigDecimal31 = bigIntegerNode27.decimalValue();
        tokenBuffer17.writeNumber(bigDecimal31);
        tokenBuffer10.writeNumberField("hi!", bigDecimal31);
        boolean boolean34 = tokenBuffer10.canWriteObjectId();
        tokenBuffer10.writeNullField("");
        tokenBuffer4.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer10);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider38 = null;
        try {
            sqlTimeSerializer0.serialize(time2, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer10, serializerProvider38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jsonGenerator13);
        org.junit.Assert.assertNotNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigIntegerNode27);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 0 + "'", short28 == (short) 0);
        org.junit.Assert.assertNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigDecimal31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.Version version24 = tokenBuffer5.version();
        com.fasterxml.jackson.core.SerializableString serializableString25 = null;
        tokenBuffer5.writeString(serializableString25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(version24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        java.lang.Object obj26 = tokenBuffer1.getOutputTarget();
        char[] charArray27 = null;
        try {
            tokenBuffer1.writeRawValue(charArray27, (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType22 = shortNode1.getNodeType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jsonNodeType22 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER + "'", jsonNodeType22.equals(com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ObjectNode objectNode11 = objectNode8.put("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]", (float) 10L);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode13 = objectNode8.booleanNode(true);
        com.fasterxml.jackson.databind.node.NullNode nullNode14 = objectNode8.nullNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer16 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec15);
        com.fasterxml.jackson.databind.node.LongNode longNode18 = new com.fasterxml.jackson.databind.node.LongNode((long) (byte) 0);
        boolean boolean20 = longNode18.asBoolean(false);
        int int21 = longNode18.intValue();
        java.math.BigDecimal bigDecimal22 = longNode18.decimalValue();
        tokenBuffer16.writeNumber(bigDecimal22);
        com.fasterxml.jackson.databind.node.NumericNode numericNode24 = objectNode8.numberNode(bigDecimal22);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(objectNode11);
        org.junit.Assert.assertNotNull(booleanNode13);
        org.junit.Assert.assertNotNull(nullNode14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(numericNode24);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        tokenBuffer1.writeNullField("");
        java.lang.String str28 = tokenBuffer1.toString();
        java.io.InputStream inputStream29 = null;
        try {
            int int31 = tokenBuffer1.writeBinary(inputStream29, 16401);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]" + "'", str28.equals("[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode14 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal13);
        boolean boolean15 = decimalNode14.canConvertToLong();
        java.math.BigInteger bigInteger16 = decimalNode14.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer18.setCharacterEscapes(characterEscapes23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        decimalNode14.serialize(jsonGenerator24, serializerProvider25);
        java.lang.String str27 = decimalNode14.asText();
        boolean boolean28 = decimalNode14.isBigDecimal();
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(decimalNode14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        boolean boolean22 = shortNode1.canConvertToInt();
        float float23 = shortNode1.floatValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 10.0f + "'", float23 == 10.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode8 = arrayNode6.numberNode((java.lang.Byte) (byte) 1);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode10 = arrayNode6.add((java.lang.Float) 0.0f);
        int int11 = arrayNode10.size();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer13 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec12);
        tokenBuffer13.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter15 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator16 = tokenBuffer13.setPrettyPrinter(prettyPrinter15);
        com.fasterxml.jackson.core.Base64Variant base64Variant17 = null;
        byte[] byteArray18 = new byte[] {};
        tokenBuffer13.writeBinary(base64Variant17, byteArray18, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode24 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray18, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType25 = binaryNode24.getNodeType();
        byte[] byteArray26 = binaryNode24.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode27 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray26);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = arrayNode10.binaryNode(byteArray26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(valueNode8);
        org.junit.Assert.assertNotNull(arrayNode10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(jsonGenerator16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[]");
        org.junit.Assert.assertNotNull(binaryNode24);
        org.junit.Assert.assertTrue("'" + jsonNodeType25 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType25.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[]");
        org.junit.Assert.assertNotNull(binaryNode28);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = arrayNode14.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode17 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        tokenBuffer19.writeBoolean(true);
        tokenBuffer19.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken29 = tokenBuffer19.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        intNode17.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider30);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode32 = arrayNode15.add((com.fasterxml.jackson.databind.JsonNode) intNode17);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode34 = arrayNode15.findParent("");
        com.fasterxml.jackson.databind.node.ValueNode valueNode36 = arrayNode15.numberNode((java.lang.Byte) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(intNode17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertTrue("'" + jsonToken29 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken29.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode32);
        org.junit.Assert.assertNull(objectNode34);
        org.junit.Assert.assertNotNull(valueNode36);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer1.setFeatureMask((int) (short) 100);
        com.fasterxml.jackson.databind.node.ShortNode shortNode11 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str12 = shortNode11.asText();
        boolean boolean13 = shortNode11.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        com.fasterxml.jackson.databind.JavaType javaType16 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer18 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer19 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer20 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType16, false, typeSerializer18, objJsonSerializer19);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider21 = null;
        java.lang.reflect.Type type22 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode23 = objectArraySerializer20.getSchema(serializerProvider21, type22);
        java.math.BigInteger bigInteger24 = jsonNode23.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode25 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger24);
        short short26 = bigIntegerNode25.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode28 = bigIntegerNode25.get(100);
        java.math.BigDecimal bigDecimal29 = bigIntegerNode25.decimalValue();
        tokenBuffer15.writeNumber(bigDecimal29);
        boolean boolean31 = shortNode11.equals((java.lang.Object) tokenBuffer15);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes32 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = tokenBuffer15.setCharacterEscapes(characterEscapes32);
        tokenBuffer1.writeTypeId((java.lang.Object) tokenBuffer15);
        boolean boolean35 = tokenBuffer15.canOmitFields();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jsonNode23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigIntegerNode25);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNull(jsonNode28);
        org.junit.Assert.assertNotNull(bigDecimal29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.JsonParser jsonParser22 = tokenBuffer5.asParser();
        tokenBuffer5.writeBooleanField("[parameter #97, annotations: null]", false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonParser22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeStartArray();
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        java.lang.String str16 = com.fasterxml.jackson.databind.util.ClassUtil.getClassDescription((java.lang.Object) bigIntegerNode15);
        com.fasterxml.jackson.core.JsonToken jsonToken17 = bigIntegerNode15.asToken();
        boolean boolean19 = bigIntegerNode15.has("");
        java.math.BigInteger bigInteger20 = bigIntegerNode15.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger20);
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "com.fasterxml.jackson.databind.node.BigIntegerNode" + "'", str16.equals("com.fasterxml.jackson.databind.node.BigIntegerNode"));
        org.junit.Assert.assertTrue("'" + jsonToken17 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT + "'", jsonToken17.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        com.fasterxml.jackson.core.JsonParser jsonParser36 = tokenBuffer1.asParser((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35);
        try {
            int int37 = treeTraversingParser35.getTextLength();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(jsonParser36);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.Base64Variant base64Variant5 = null;
        byte[] byteArray6 = new byte[] {};
        tokenBuffer1.writeBinary(base64Variant5, byteArray6, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode10 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray6);
        com.fasterxml.jackson.databind.JavaType javaType11 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer13 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer14 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer15 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType11, false, typeSerializer13, objJsonSerializer14);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider16 = null;
        java.lang.reflect.Type type17 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = objectArraySerializer15.getSchema(serializerProvider16, type17);
        java.math.BigInteger bigInteger19 = jsonNode18.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode20 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger19);
        short short21 = bigIntegerNode20.shortValue();
        boolean boolean23 = bigIntegerNode20.hasNonNull(0);
        long long24 = bigIntegerNode20.longValue();
        boolean boolean25 = binaryNode10.equals((java.lang.Object) long24);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[]");
        org.junit.Assert.assertNotNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigIntegerNode20);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        tokenBuffer1.writeStartObject();
        tokenBuffer1.writeEndObject();
        boolean boolean28 = tokenBuffer1.canWriteBinaryNatively();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        boolean boolean15 = bigIntegerNode9.asBoolean(true);
        boolean boolean16 = bigIntegerNode9.isValueNode();
        boolean boolean17 = bigIntegerNode9.canConvertToInt();
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        tokenBuffer19.writeNumberField("", 100L);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        bigIntegerNode9.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider24);
        tokenBuffer19.writeFieldName("com.fasterxml.jackson.databind.MapperFeature<java.lang.Object>");
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer6 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec5);
        tokenBuffer6.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer6.setPrettyPrinter(prettyPrinter8);
        tokenBuffer6.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes11 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = tokenBuffer6.setCharacterEscapes(characterEscapes11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer6.writeNumber(bigDecimal26);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode28 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal26);
        tokenBuffer1.writeNumber(bigDecimal26);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer1.setCharacterEscapes(characterEscapes30);
        char[] charArray32 = null;
        try {
            tokenBuffer1.writeRawValue(charArray32, 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator12);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(jsonGenerator31);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        com.fasterxml.jackson.core.JsonParser jsonParser36 = tokenBuffer1.asParser((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35);
        java.io.InputStream inputStream37 = null;
        try {
            int int39 = tokenBuffer1.writeBinary(inputStream37, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(jsonParser36);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        java.lang.Object obj26 = tokenBuffer1.getOutputTarget();
        tokenBuffer1.writeNumberField("[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]", (float) (short) -1);
        tokenBuffer1.writeNumberField("{", (long) 0);
        try {
            tokenBuffer1.writeRawValue("hi!", (int) (short) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator3 = tokenBuffer1.setCodec(objectCodec2);
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        tokenBuffer5.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = tokenBuffer5.setPrettyPrinter(prettyPrinter7);
        tokenBuffer5.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer5.setCharacterEscapes(characterEscapes10);
        com.fasterxml.jackson.databind.JavaType javaType12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer14 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer15 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer16 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType12, false, typeSerializer14, objJsonSerializer15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        java.lang.reflect.Type type18 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode19 = objectArraySerializer16.getSchema(serializerProvider17, type18);
        java.math.BigInteger bigInteger20 = jsonNode19.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode21 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        short short22 = bigIntegerNode21.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode24 = bigIntegerNode21.get(100);
        java.math.BigDecimal bigDecimal25 = bigIntegerNode21.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal25);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode27 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal25);
        tokenBuffer1.writeNumber(bigDecimal25);
        org.junit.Assert.assertNotNull(jsonGenerator3);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonNode19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNull(jsonNode24);
        org.junit.Assert.assertNotNull(bigDecimal25);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.json.JsonWriteContext jsonWriteContext24 = tokenBuffer5.getOutputContext();
        tokenBuffer5.writeStringField("enum", "[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonWriteContext24);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer42.writeNumber((long) 0);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        int int43 = tokenBuffer42.getFeatureMask();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 79 + "'", int43 == 79);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        java.lang.Class<java.util.Date> dateClass4 = dateSerializer3.handledType();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer10 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        dateFormat9.setLenient(false);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer13 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer14 = dateSerializer3.withFormat((java.lang.Boolean) false, dateFormat9);
        java.util.Date date15 = null;
        boolean boolean16 = dateSerializer14.isEmpty(date15);
        java.util.Date date17 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec25 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer26 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec25);
        com.fasterxml.jackson.databind.JavaType javaType27 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer29 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer30 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer31 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType27, false, typeSerializer29, objJsonSerializer30);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider32 = null;
        java.lang.reflect.Type type33 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = objectArraySerializer31.getSchema(serializerProvider32, type33);
        java.math.BigInteger bigInteger35 = jsonNode34.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode36 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger35);
        short short37 = bigIntegerNode36.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode39 = bigIntegerNode36.get(100);
        java.math.BigDecimal bigDecimal40 = bigIntegerNode36.decimalValue();
        tokenBuffer26.writeNumber(bigDecimal40);
        tokenBuffer19.writeNumberField("hi!", bigDecimal40);
        boolean boolean43 = tokenBuffer19.canWriteObjectId();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        try {
            dateSerializer14.serialize(date17, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateClass4);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateSerializer14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigIntegerNode36);
        org.junit.Assert.assertTrue("'" + short37 + "' != '" + (short) 0 + "'", short37 == (short) 0);
        org.junit.Assert.assertNull(jsonNode39);
        org.junit.Assert.assertNotNull(bigDecimal40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode17 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal16);
        boolean boolean18 = decimalNode17.canConvertToLong();
        java.math.BigInteger bigInteger19 = decimalNode17.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger19);
        tokenBuffer1.writeArrayFieldStart("[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]");
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertNotNull(decimalNode17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode14 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal13);
        boolean boolean15 = decimalNode14.canConvertToLong();
        java.math.BigInteger bigInteger16 = decimalNode14.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer18.setCharacterEscapes(characterEscapes23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        decimalNode14.serialize(jsonGenerator24, serializerProvider25);
        java.lang.String str27 = decimalNode14.asText();
        int int28 = decimalNode14.intValue();
        java.math.BigDecimal bigDecimal29 = decimalNode14.decimalValue();
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(decimalNode14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(bigDecimal29);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        try {
            tokenBuffer1.writeRaw("com.fasterxml.jackson.core.JsonToken", (int) '#', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper9 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory8);
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper11 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory10);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes12 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader13 = objectMapper11.reader(contextAttributes12);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory14 = objectMapper11.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray15 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper16 = objectMapper11.enable(mapperFeatureArray15);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper17 = objectMapper9.enable(mapperFeatureArray15);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator25 = tokenBuffer19.setFeatureMask((int) '4');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider26 = null;
        objectArraySerializer4.serializeContents((java.lang.Object[]) mapperFeatureArray15, jsonGenerator25, serializerProvider26);
        boolean boolean28 = objectArraySerializer4.isUnwrappingSerializer();
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(objectReader13);
        org.junit.Assert.assertNotNull(typeFactory14);
        org.junit.Assert.assertNotNull(mapperFeatureArray15);
        org.junit.Assert.assertNotNull(objectMapper16);
        org.junit.Assert.assertNotNull(objectMapper17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertNotNull(jsonGenerator25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        java.lang.Object obj26 = tokenBuffer1.getOutputTarget();
        tokenBuffer1.writeNumber((int) '4');
        tokenBuffer1.writeStringField("[collection type; class [Ljava.lang.Object;, contains [simple type, class com.fasterxml.jackson.databind.MapperFeature]]", "\"com.fasterxml.jackson.databind.node.BigIntegerNode\"");
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode23 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode24 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal21);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode26 = decimalNode24.findParent("com.fasterxml.jackson.core.JsonToken");
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
        org.junit.Assert.assertNotNull(decimalNode24);
        org.junit.Assert.assertNull(objectNode26);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeNullField("enum");
        tokenBuffer1.writeNumber(0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        tokenBuffer8.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer8.setPrettyPrinter(prettyPrinter10);
        tokenBuffer8.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer8.setCharacterEscapes(characterEscapes13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal28);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode30 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal28);
        tokenBuffer3.writeNumber(bigDecimal28);
        tokenBuffer1.writeNumber(bigDecimal28);
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode20 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal19);
        boolean boolean21 = decimalNode20.canConvertToLong();
        java.math.BigInteger bigInteger22 = decimalNode20.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger22);
        tokenBuffer1.close();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter25 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator26 = tokenBuffer1.setPrettyPrinter(prettyPrinter25);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertNotNull(decimalNode20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(jsonGenerator26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.text.DateFormat dateFormat1 = null;
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer2 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat1);
        java.text.DateFormat dateFormat4 = null;
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer5 = dateSerializer2.withFormat((java.lang.Boolean) true, dateFormat4);
        java.util.Date date6 = null;
        com.fasterxml.jackson.databind.node.ShortNode shortNode8 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str9 = shortNode8.asText();
        boolean boolean10 = shortNode8.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer12.writeNumber(bigDecimal26);
        boolean boolean28 = shortNode8.equals((java.lang.Object) tokenBuffer12);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes29 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer12.setCharacterEscapes(characterEscapes29);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider31 = null;
        dateSerializer2.serialize(date6, jsonGenerator30, serializerProvider31);
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer33 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Date> dateJsonSerializer34 = dateSerializer2.unwrappingSerializer(nameTransformer33);
        org.junit.Assert.assertNotNull(dateSerializer5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jsonGenerator30);
        org.junit.Assert.assertNotNull(dateJsonSerializer34);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.Version version24 = tokenBuffer5.version();
        boolean boolean25 = tokenBuffer5.canWriteTypeId();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(version24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.json.JsonWriteContext jsonWriteContext24 = tokenBuffer5.getOutputContext();
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        java.math.BigInteger bigInteger33 = jsonNode32.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode34 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger33);
        short short35 = bigIntegerNode34.shortValue();
        boolean boolean37 = bigIntegerNode34.hasNonNull(0);
        tokenBuffer5.writeObject((java.lang.Object) bigIntegerNode34);
        tokenBuffer5.writeFieldName("com.fasterxml.jackson.databind.MapperFeature");
        tokenBuffer5.writeStartArray(16401);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonWriteContext24);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigIntegerNode34);
        org.junit.Assert.assertTrue("'" + short35 + "' != '" + (short) 0 + "'", short35 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory4 = objectMapper1.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray5 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper6 = objectMapper1.enable(mapperFeatureArray5);
        java.text.DateFormat dateFormat8 = java.text.DateFormat.getTimeInstance(1);
        java.text.NumberFormat numberFormat9 = dateFormat8.getNumberFormat();
        java.util.TimeZone timeZone10 = dateFormat8.getTimeZone();
        java.text.DateFormat dateFormat11 = com.fasterxml.jackson.databind.util.StdDateFormat.getRFC1123Format(timeZone10);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = objectMapper6.setTimeZone(timeZone10);
        com.fasterxml.jackson.databind.InjectableValues injectableValues13 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper14 = objectMapper12.setInjectableValues(injectableValues13);
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer16 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec15);
        tokenBuffer16.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter18 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator19 = tokenBuffer16.setPrettyPrinter(prettyPrinter18);
        com.fasterxml.jackson.core.Base64Variant base64Variant20 = null;
        byte[] byteArray21 = new byte[] {};
        tokenBuffer16.writeBinary(base64Variant20, byteArray21, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode25 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray21);
        try {
            com.fasterxml.jackson.databind.JsonNode jsonNode26 = objectMapper14.readTree(byteArray21);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No content to map due to end-of-input? at [Source: [B@3a0fdfbc; line: 1, column: 1]");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(typeFactory4);
        org.junit.Assert.assertNotNull(mapperFeatureArray5);
        org.junit.Assert.assertNotNull(objectMapper6);
        org.junit.Assert.assertNotNull(dateFormat8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertEquals(timeZone10.getDisplayName(), "Pacific Standard Time");
        org.junit.Assert.assertNotNull(dateFormat11);
        org.junit.Assert.assertNotNull(objectMapper12);
        org.junit.Assert.assertNotNull(objectMapper14);
        org.junit.Assert.assertNotNull(jsonGenerator19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[]");
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        java.lang.Object obj26 = tokenBuffer1.getOutputTarget();
        com.fasterxml.jackson.core.ObjectCodec objectCodec27 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer28 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec27);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter29 = tokenBuffer28.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser30 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException32 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser30, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference35 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException32.prependPath(reference35);
        tokenBuffer28.writeTypeId((java.lang.Object) reference35);
        tokenBuffer28.writeArrayFieldStart("com.fasterxml.jackson.databind.MapperFeature");
        try {
            com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer40 = tokenBuffer1.append(tokenBuffer28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNull(prettyPrinter29);
        org.junit.Assert.assertNotNull(jsonMappingException32);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode23 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal21);
        java.lang.String str24 = decimalNode23.asText();
        java.math.BigDecimal bigDecimal25 = decimalNode23.decimalValue();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertNotNull(bigDecimal25);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode23 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal21);
        com.fasterxml.jackson.core.JsonPointer jsonPointer24 = null;
        try {
            com.fasterxml.jackson.databind.JsonNode jsonNode25 = decimalNode23.at(jsonPointer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        tokenBuffer1.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        tokenBuffer1.writeObjectFieldStart("1");
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer14.setPrettyPrinter(prettyPrinter16);
        com.fasterxml.jackson.core.Base64Variant base64Variant18 = null;
        byte[] byteArray19 = new byte[] {};
        tokenBuffer14.writeBinary(base64Variant18, byteArray19, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode25 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray19, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType26 = binaryNode25.getNodeType();
        byte[] byteArray27 = binaryNode25.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray27);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode29 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray27);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode30 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray27);
        tokenBuffer1.writeBinary(byteArray27);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray19), "[]");
        org.junit.Assert.assertNotNull(binaryNode25);
        org.junit.Assert.assertTrue("'" + jsonNodeType26 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType26.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray27);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray27), "[]");
        org.junit.Assert.assertNotNull(binaryNode29);
        org.junit.Assert.assertNotNull(binaryNode30);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer6 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec5);
        tokenBuffer6.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer6.setPrettyPrinter(prettyPrinter8);
        tokenBuffer6.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes11 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = tokenBuffer6.setCharacterEscapes(characterEscapes11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer6.writeNumber(bigDecimal26);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode28 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal26);
        tokenBuffer1.writeNumber(bigDecimal26);
        java.lang.Object obj30 = tokenBuffer1.getOutputTarget();
        boolean boolean31 = tokenBuffer1.canWriteTypeId();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator12);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode23 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal21);
        java.lang.String str24 = decimalNode23.asText();
        boolean boolean25 = decimalNode23.isBigDecimal();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        tokenBuffer17.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter19 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator20 = tokenBuffer17.setPrettyPrinter(prettyPrinter19);
        com.fasterxml.jackson.core.Base64Variant base64Variant21 = null;
        byte[] byteArray22 = new byte[] {};
        tokenBuffer17.writeBinary(base64Variant21, byteArray22, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray22, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType29 = binaryNode28.getNodeType();
        byte[] byteArray30 = binaryNode28.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode31 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray30);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode32 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray30);
        byte[] byteArray33 = binaryNode32.binaryValue();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode34 = arrayNode14.insert((int) (short) 100, byteArray33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(jsonGenerator20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[]");
        org.junit.Assert.assertNotNull(binaryNode28);
        org.junit.Assert.assertTrue("'" + jsonNodeType29 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType29.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray30), "[]");
        org.junit.Assert.assertNotNull(binaryNode32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[]");
        org.junit.Assert.assertNotNull(arrayNode34);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        tokenBuffer1.writeNumber((int) '#');
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer1.setCharacterEscapes(characterEscapes6);
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType8, false, typeSerializer10, objJsonSerializer11);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider13 = null;
        java.lang.reflect.Type type14 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = objectArraySerializer12.getSchema(serializerProvider13, type14);
        java.math.BigInteger bigInteger16 = jsonNode15.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode17 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger16);
        short short18 = bigIntegerNode17.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = bigIntegerNode17.get(100);
        java.math.BigDecimal bigDecimal21 = bigIntegerNode17.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode23 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal21);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode24 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal21);
        float float25 = decimalNode24.floatValue();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigIntegerNode17);
        org.junit.Assert.assertTrue("'" + short18 + "' != '" + (short) 0 + "'", short18 == (short) 0);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigDecimal21);
        org.junit.Assert.assertNotNull(decimalNode24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException2 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser0, "");
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        boolean boolean17 = bigIntegerNode12.isFloat();
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException19 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException2, (java.lang.Object) boolean17, "hi!");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference21 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) 10.0f);
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException22 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException19, reference21);
        java.lang.Throwable[] throwableArray23 = jsonMappingException19.getSuppressed();
        com.fasterxml.jackson.core.ObjectCodec objectCodec24 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer25 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec24);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter26 = tokenBuffer25.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser27 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException29 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser27, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference32 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException29.prependPath(reference32);
        tokenBuffer25.writeTypeId((java.lang.Object) reference32);
        reference32.setFieldName("java.lang.Short[\"hi!\"]");
        jsonMappingException19.prependPath(reference32);
        org.junit.Assert.assertNotNull(jsonMappingException2);
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonMappingException19);
        org.junit.Assert.assertNotNull(jsonMappingException22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNull(prettyPrinter26);
        org.junit.Assert.assertNotNull(jsonMappingException29);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator35 = tokenBuffer7.useDefaultPrettyPrinter();
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jsonGenerator35);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        boolean boolean26 = tokenBuffer1.canWriteBinaryNatively();
        tokenBuffer1.writeFieldName("[parameter #10, annotations: null]");
        tokenBuffer1.writeStartObject();
        int int30 = tokenBuffer1.getHighestEscapedChar();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes31 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator32 = tokenBuffer1.setCharacterEscapes(characterEscapes31);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(jsonGenerator32);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = arrayNode14.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode17 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        tokenBuffer19.writeBoolean(true);
        tokenBuffer19.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken29 = tokenBuffer19.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        intNode17.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider30);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode32 = arrayNode15.add((com.fasterxml.jackson.databind.JsonNode) intNode17);
        boolean boolean34 = intNode17.asBoolean(true);
        com.fasterxml.jackson.core.JsonToken jsonToken35 = intNode17.asToken();
        boolean boolean36 = intNode17.canConvertToLong();
        boolean boolean37 = intNode17.isInt();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(intNode17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertTrue("'" + jsonToken29 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken29.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + jsonToken35 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT + "'", jsonToken35.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        tokenBuffer5.writeNumber((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode17 = arrayNode6.insert((int) (byte) 10, "java.lang.Integer");
        com.fasterxml.jackson.databind.node.ObjectNode objectNode19 = arrayNode17.findParent("{type: [simple type, class java.lang.Object], typed? false}");
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        tokenBuffer21.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer21.setPrettyPrinter(prettyPrinter23);
        tokenBuffer21.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes26 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator27 = tokenBuffer21.setCharacterEscapes(characterEscapes26);
        com.fasterxml.jackson.core.ObjectCodec objectCodec28 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator29 = tokenBuffer21.setCodec(objectCodec28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer31 = null;
        try {
            arrayNode17.serializeWithType(jsonGenerator29, serializerProvider30, typeSerializer31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode17);
        org.junit.Assert.assertNull(objectNode19);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(jsonGenerator27);
        org.junit.Assert.assertNotNull(jsonGenerator29);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode14 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal13);
        boolean boolean15 = decimalNode14.canConvertToLong();
        java.math.BigInteger bigInteger16 = decimalNode14.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer18.setCharacterEscapes(characterEscapes23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        decimalNode14.serialize(jsonGenerator24, serializerProvider25);
        com.fasterxml.jackson.databind.JsonNode jsonNode28 = decimalNode14.get(0);
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(decimalNode14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNull(jsonNode28);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.databind.JavaType javaType2 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer4 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer5 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer6 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType2, false, typeSerializer4, objJsonSerializer5);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider7 = null;
        java.lang.reflect.Type type8 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode9 = objectArraySerializer6.getSchema(serializerProvider7, type8);
        java.math.BigInteger bigInteger10 = jsonNode9.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode11 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger10);
        short short12 = bigIntegerNode11.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode14 = bigIntegerNode11.get(100);
        java.math.BigDecimal bigDecimal15 = bigIntegerNode11.decimalValue();
        tokenBuffer1.writeNumber(bigDecimal15);
        com.fasterxml.jackson.core.SerializableString serializableString17 = null;
        tokenBuffer1.writeString(serializableString17);
        tokenBuffer1.writeNumberField("[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]", (double) 16401);
        com.fasterxml.jackson.core.JsonGenerator.Feature feature22 = null;
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer1.enable(feature22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigIntegerNode11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertNull(jsonNode14);
        org.junit.Assert.assertNotNull(bigDecimal15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        tokenBuffer5.writeArrayFieldStart("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]");
        tokenBuffer5.writeNull();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode17 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal16);
        boolean boolean18 = decimalNode17.canConvertToLong();
        java.math.BigInteger bigInteger19 = decimalNode17.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger19);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.FormatSchema formatSchema22 = null;
        try {
            tokenBuffer1.setSchema(formatSchema22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertNotNull(decimalNode17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        tokenBuffer1.writeStartObject();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter27 = tokenBuffer1.getPrettyPrinter();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(prettyPrinter27);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode17 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal16);
        boolean boolean18 = decimalNode17.canConvertToLong();
        java.math.BigInteger bigInteger19 = decimalNode17.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger19);
        tokenBuffer1.writeNumberField("[parameter #10, annotations: null]", (double) 1);
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertNotNull(decimalNode17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

}
