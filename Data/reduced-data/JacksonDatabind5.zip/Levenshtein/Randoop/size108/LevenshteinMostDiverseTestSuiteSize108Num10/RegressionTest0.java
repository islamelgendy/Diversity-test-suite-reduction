import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory5 = objectMapper4.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode6 = objectMapper4.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper4);
        com.fasterxml.jackson.core.Base64Variant base64Variant8 = null;
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory9 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray15 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode16 = jsonNodeFactory9.binaryNode(byteArray15);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType17 = com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT;
        com.fasterxml.jackson.databind.node.ValueNode valueNode18 = jsonNodeFactory9.pojoNode((java.lang.Object) jsonNodeType17);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode19 = new com.fasterxml.jackson.databind.node.ObjectNode(jsonNodeFactory9);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory20 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray26 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode27 = jsonNodeFactory20.binaryNode(byteArray26);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = jsonNodeFactory9.binaryNode(byteArray26);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode29 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray26);
        try {
            tokenBuffer7.writeBinary(base64Variant8, byteArray26, (int) ' ', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(typeFactory5);
        org.junit.Assert.assertNotNull(objectNode6);
        org.junit.Assert.assertNotNull(jsonNodeFactory9);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode16);
        org.junit.Assert.assertTrue("'" + jsonNodeType17 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT + "'", jsonNodeType17.equals(com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT));
        org.junit.Assert.assertNotNull(valueNode18);
        org.junit.Assert.assertNotNull(jsonNodeFactory20);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode27);
        org.junit.Assert.assertNotNull(binaryNode28);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = objectMapper4.writer(characterEscapes5);
        com.fasterxml.jackson.databind.InjectableValues injectableValues7 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper4.setInjectableValues(injectableValues7);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper8);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = null;
        com.fasterxml.jackson.databind.node.TextNode textNode12 = new com.fasterxml.jackson.databind.node.TextNode("");
        com.fasterxml.jackson.core.JsonParser jsonParser13 = textNode12.traverse();
        com.fasterxml.jackson.core.JsonToken jsonToken14 = textNode12.asToken();
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType15 = textNode12.getNodeType();
        try {
            objectMapper8.writeTree(jsonGenerator10, (com.fasterxml.jackson.databind.JsonNode) textNode12);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: [no message for java.lang.NullPointerException]");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectWriter6);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertNotNull(jsonParser13);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_STRING + "'", jsonToken14.equals(com.fasterxml.jackson.core.JsonToken.VALUE_STRING));
        org.junit.Assert.assertTrue("'" + jsonNodeType15 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.STRING + "'", jsonNodeType15.equals(com.fasterxml.jackson.databind.node.JsonNodeType.STRING));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.fasterxml.jackson.databind.deser.std.TokenBufferDeserializer tokenBufferDeserializer0 = new com.fasterxml.jackson.databind.deser.std.TokenBufferDeserializer();
        java.lang.Class<?> wildcardClass1 = tokenBufferDeserializer0.handledType();
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer2 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<com.fasterxml.jackson.databind.util.TokenBuffer> tokenBufferJsonDeserializer3 = tokenBufferDeserializer0.unwrappingDeserializer(nameTransformer2);
        com.fasterxml.jackson.databind.JavaType javaType4 = tokenBufferDeserializer0.getValueType();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = tokenBufferDeserializer0.getEmptyValue();
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory6 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode7 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory6);
        com.fasterxml.jackson.databind.JsonNode jsonNode9 = arrayNode7.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode10 = arrayNode7.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode12 = arrayNode10.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode10.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser15 = new com.fasterxml.jackson.databind.node.TreeTraversingParser((com.fasterxml.jackson.databind.JsonNode) arrayNode14);
        com.fasterxml.jackson.core.JsonLocation jsonLocation16 = treeTraversingParser15.getCurrentLocation();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext17 = null;
        try {
            com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = tokenBufferDeserializer0.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser15, deserializationContext17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(tokenBufferJsonDeserializer3);
        org.junit.Assert.assertNull(javaType4);
        org.junit.Assert.assertNull(tokenBuffer5);
        org.junit.Assert.assertNotNull(jsonNodeFactory6);
        org.junit.Assert.assertNull(jsonNode9);
        org.junit.Assert.assertNotNull(arrayNode10);
        org.junit.Assert.assertNotNull(numericNode12);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(jsonLocation16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = objectMapper4.writer(characterEscapes5);
        com.fasterxml.jackson.databind.InjectableValues injectableValues7 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper4.setInjectableValues(injectableValues7);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper8);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory10 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory10);
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = arrayNode11.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode11.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode16 = arrayNode14.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode18 = arrayNode14.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser19 = new com.fasterxml.jackson.databind.node.TreeTraversingParser((com.fasterxml.jackson.databind.JsonNode) arrayNode18);
        com.fasterxml.jackson.core.JsonLocation jsonLocation20 = treeTraversingParser19.getCurrentLocation();
        java.lang.String str21 = treeTraversingParser19.getCurrentName();
        int int23 = treeTraversingParser19.getValueAsInt((int) (short) 100);
        try {
            tokenBuffer9.copyCurrentStructure((com.fasterxml.jackson.core.JsonParser) treeTraversingParser19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectWriter6);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertNotNull(jsonNodeFactory10);
        org.junit.Assert.assertNull(jsonNode13);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(numericNode16);
        org.junit.Assert.assertNotNull(arrayNode18);
        org.junit.Assert.assertNotNull(jsonLocation20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.fasterxml.jackson.databind.deser.std.TokenBufferDeserializer tokenBufferDeserializer0 = new com.fasterxml.jackson.databind.deser.std.TokenBufferDeserializer();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = tokenBufferDeserializer0.getNullValue();
        java.lang.Class<?> wildcardClass2 = tokenBufferDeserializer0.getValueClass();
        com.fasterxml.jackson.databind.JavaType javaType3 = tokenBufferDeserializer0.getValueType();
        com.fasterxml.jackson.databind.node.LongNode longNode5 = com.fasterxml.jackson.databind.node.LongNode.valueOf(0L);
        com.fasterxml.jackson.core.JsonParser jsonParser6 = longNode5.traverse();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper7 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory8 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper7);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider9 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext10 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper11 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory8, defaultSerializerProvider9, defaultDeserializationContext10);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes12 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter13 = objectMapper11.writer(characterEscapes12);
        com.fasterxml.jackson.databind.InjectableValues injectableValues14 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper15 = objectMapper11.setInjectableValues(injectableValues14);
        com.fasterxml.jackson.core.JsonFactory jsonFactory16 = objectMapper11.getJsonFactory();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper17 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory16);
        com.fasterxml.jackson.core.Version version18 = jsonFactory16.version();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper19 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory20 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper19);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider21 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext22 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper23 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory20, defaultSerializerProvider21, defaultDeserializationContext22);
        com.fasterxml.jackson.core.JsonFactory jsonFactory24 = jsonFactory16.setCodec((com.fasterxml.jackson.core.ObjectCodec) objectMapper23);
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer25 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider26 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty27 = null;
        com.fasterxml.jackson.databind.JsonSerializer jsonSerializer28 = longSerializer25.createContextual(serializerProvider26, beanProperty27);
        java.net.InetAddress inetAddress29 = null;
        boolean boolean30 = jsonSerializer28.isEmpty(inetAddress29);
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer31 = jsonSerializer28.getDelegatee();
        boolean boolean32 = jsonSerializer28.isUnwrappingSerializer();
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer33 = jsonSerializer28.getDelegatee();
        java.util.TimeZone timeZone34 = com.fasterxml.jackson.databind.util.StdDateFormat.getDefaultTimeZone();
        boolean boolean35 = jsonSerializer28.isEmpty(timeZone34);
        java.text.DateFormat dateFormat36 = com.fasterxml.jackson.databind.util.StdDateFormat.getRFC1123Format(timeZone34);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper37 = objectMapper23.setDateFormat(dateFormat36);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext38 = objectMapper23.getDeserializationContext();
        try {
            com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer39 = tokenBufferDeserializer0.deserialize(jsonParser6, deserializationContext38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(tokenBuffer1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(javaType3);
        org.junit.Assert.assertNotNull(longNode5);
        org.junit.Assert.assertNotNull(jsonParser6);
        org.junit.Assert.assertNotNull(objectWriter13);
        org.junit.Assert.assertNotNull(objectMapper15);
        org.junit.Assert.assertNotNull(jsonFactory16);
        org.junit.Assert.assertNotNull(version18);
        org.junit.Assert.assertNotNull(jsonFactory24);
        org.junit.Assert.assertNotNull(jsonSerializer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(wildcardJsonSerializer31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(wildcardJsonSerializer33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertEquals(timeZone34.getDisplayName(), "Greenwich Mean Time");
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateFormat36);
        org.junit.Assert.assertNotNull(objectMapper37);
        org.junit.Assert.assertNotNull(deserializationContext38);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = objectMapper4.writer(characterEscapes5);
        com.fasterxml.jackson.databind.InjectableValues injectableValues7 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper4.setInjectableValues(injectableValues7);
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = objectMapper4.getJsonFactory();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper10 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory9);
        com.fasterxml.jackson.core.Version version11 = jsonFactory9.version();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory13 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper12);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider14 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext15 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper16 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory13, defaultSerializerProvider14, defaultDeserializationContext15);
        com.fasterxml.jackson.core.JsonFactory jsonFactory17 = jsonFactory9.setCodec((com.fasterxml.jackson.core.ObjectCodec) objectMapper16);
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer18 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider19 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty20 = null;
        com.fasterxml.jackson.databind.JsonSerializer jsonSerializer21 = longSerializer18.createContextual(serializerProvider19, beanProperty20);
        java.net.InetAddress inetAddress22 = null;
        boolean boolean23 = jsonSerializer21.isEmpty(inetAddress22);
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer24 = jsonSerializer21.getDelegatee();
        boolean boolean25 = jsonSerializer21.isUnwrappingSerializer();
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer26 = jsonSerializer21.getDelegatee();
        java.util.TimeZone timeZone27 = com.fasterxml.jackson.databind.util.StdDateFormat.getDefaultTimeZone();
        boolean boolean28 = jsonSerializer21.isEmpty(timeZone27);
        java.text.DateFormat dateFormat29 = com.fasterxml.jackson.databind.util.StdDateFormat.getRFC1123Format(timeZone27);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper30 = objectMapper16.setDateFormat(dateFormat29);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext31 = objectMapper16.getDeserializationContext();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer33 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper16, false);
        org.junit.Assert.assertNotNull(objectWriter6);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertNotNull(jsonFactory9);
        org.junit.Assert.assertNotNull(version11);
        org.junit.Assert.assertNotNull(jsonFactory17);
        org.junit.Assert.assertNotNull(jsonSerializer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(wildcardJsonSerializer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(wildcardJsonSerializer26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertEquals(timeZone27.getDisplayName(), "Greenwich Mean Time");
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateFormat29);
        org.junit.Assert.assertNotNull(objectMapper30);
        org.junit.Assert.assertNotNull(deserializationContext31);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory5 = objectMapper4.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode6 = objectMapper4.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper4);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory8 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode9 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory8);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode10 = jsonNodeFactory8.arrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode12 = jsonNodeFactory8.numberNode((java.lang.Long) 97L);
        com.fasterxml.jackson.databind.node.NumericNode numericNode14 = jsonNodeFactory8.numberNode((short) 12);
        com.fasterxml.jackson.databind.ObjectReader objectReader15 = objectMapper4.reader(jsonNodeFactory8);
        com.fasterxml.jackson.databind.node.ValueNode valueNode17 = jsonNodeFactory8.numberNode((java.lang.Double) 0.0d);
        org.junit.Assert.assertNotNull(typeFactory5);
        org.junit.Assert.assertNotNull(objectNode6);
        org.junit.Assert.assertNotNull(jsonNodeFactory8);
        org.junit.Assert.assertNotNull(arrayNode10);
        org.junit.Assert.assertNotNull(valueNode12);
        org.junit.Assert.assertNotNull(numericNode14);
        org.junit.Assert.assertNotNull(objectReader15);
        org.junit.Assert.assertNotNull(valueNode17);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.fasterxml.jackson.databind.ObjectMapper objectMapper0 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory1 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper0);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider2 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext3 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper4 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory1, defaultSerializerProvider2, defaultDeserializationContext3);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = objectMapper4.writer(characterEscapes5);
        com.fasterxml.jackson.databind.InjectableValues injectableValues7 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper4.setInjectableValues(injectableValues7);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper8);
        tokenBuffer9.writeNumber((short) 12);
        com.fasterxml.jackson.databind.util.LRUMap<com.fasterxml.jackson.databind.node.JsonNodeType, com.fasterxml.jackson.databind.node.ContainerNode<com.fasterxml.jackson.databind.node.ObjectNode>> jsonNodeTypeMap14 = new com.fasterxml.jackson.databind.util.LRUMap<com.fasterxml.jackson.databind.node.JsonNodeType, com.fasterxml.jackson.databind.node.ContainerNode<com.fasterxml.jackson.databind.node.ObjectNode>>((int) (byte) 100, (int) (short) 100);
        boolean boolean15 = jsonNodeTypeMap14.isEmpty();
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory16 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray22 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode23 = jsonNodeFactory16.binaryNode(byteArray22);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType24 = com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT;
        com.fasterxml.jackson.databind.node.ValueNode valueNode25 = jsonNodeFactory16.pojoNode((java.lang.Object) jsonNodeType24);
        com.fasterxml.jackson.core.JsonLocation jsonLocation27 = null;
        com.fasterxml.jackson.databind.deser.impl.ReadableObjectId readableObjectId28 = null;
        com.fasterxml.jackson.databind.deser.UnresolvedForwardReference unresolvedForwardReference29 = new com.fasterxml.jackson.databind.deser.UnresolvedForwardReference("hi!", jsonLocation27, readableObjectId28);
        com.fasterxml.jackson.core.JsonLocation jsonLocation31 = null;
        com.fasterxml.jackson.databind.deser.impl.ReadableObjectId readableObjectId32 = null;
        com.fasterxml.jackson.databind.deser.UnresolvedForwardReference unresolvedForwardReference33 = new com.fasterxml.jackson.databind.deser.UnresolvedForwardReference("hi!", jsonLocation31, readableObjectId32);
        unresolvedForwardReference29.addSuppressed((java.lang.Throwable) unresolvedForwardReference33);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory35 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        byte[] byteArray41 = new byte[] { (byte) 0, (byte) -1, (byte) 10, (byte) 100, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode42 = jsonNodeFactory35.binaryNode(byteArray41);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType43 = com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT;
        com.fasterxml.jackson.databind.node.ValueNode valueNode44 = jsonNodeFactory35.pojoNode((java.lang.Object) jsonNodeType43);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode45 = new com.fasterxml.jackson.databind.node.ObjectNode(jsonNodeFactory35);
        unresolvedForwardReference33.prependPath((java.lang.Object) objectNode45, "hi!");
        com.fasterxml.jackson.databind.node.NumericNode numericNode49 = objectNode45.numberNode((short) 10);
        com.fasterxml.jackson.databind.node.ContainerNode<com.fasterxml.jackson.databind.node.ObjectNode> objectNodeContainerNode50 = jsonNodeTypeMap14.putIfAbsent(jsonNodeType24, (com.fasterxml.jackson.databind.node.ContainerNode<com.fasterxml.jackson.databind.node.ObjectNode>) objectNode45);
        int int51 = jsonNodeTypeMap14.size();
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType52 = com.fasterxml.jackson.databind.node.JsonNodeType.BOOLEAN;
        boolean boolean53 = jsonNodeTypeMap14.containsValue((java.lang.Object) jsonNodeType52);
        com.fasterxml.jackson.databind.node.LongNode longNode55 = com.fasterxml.jackson.databind.node.LongNode.valueOf((long) '4');
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer56 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider57 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty58 = null;
        com.fasterxml.jackson.databind.JsonSerializer jsonSerializer59 = longSerializer56.createContextual(serializerProvider57, beanProperty58);
        boolean boolean60 = jsonSerializer59.isUnwrappingSerializer();
        boolean boolean61 = jsonSerializer59.usesObjectId();
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer62 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.concurrent.atomic.AtomicInteger> atomicIntegerJsonSerializer63 = jsonSerializer59.unwrappingSerializer(nameTransformer62);
        boolean boolean64 = jsonSerializer59.isUnwrappingSerializer();
        boolean boolean65 = longNode55.equals((java.lang.Object) boolean64);
        long long66 = longNode55.longValue();
        boolean boolean67 = jsonNodeTypeMap14.containsValue((java.lang.Object) longNode55);
        com.fasterxml.jackson.databind.node.ShortNode shortNode69 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 100);
        java.util.Iterator<java.util.Map.Entry<java.lang.String, com.fasterxml.jackson.databind.JsonNode>> strEntryItor70 = shortNode69.fields();
        java.math.BigInteger bigInteger71 = shortNode69.bigIntegerValue();
        boolean boolean72 = jsonNodeTypeMap14.containsValue((java.lang.Object) shortNode69);
        boolean boolean73 = shortNode69.isShort();
        short short74 = shortNode69.shortValue();
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser75 = new com.fasterxml.jackson.databind.node.TreeTraversingParser((com.fasterxml.jackson.databind.JsonNode) shortNode69);
        com.fasterxml.jackson.core.Version version76 = treeTraversingParser75.version();
        try {
            tokenBuffer9.copyCurrentStructure((com.fasterxml.jackson.core.JsonParser) treeTraversingParser75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectWriter6);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jsonNodeFactory16);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode23);
        org.junit.Assert.assertTrue("'" + jsonNodeType24 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT + "'", jsonNodeType24.equals(com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT));
        org.junit.Assert.assertNotNull(valueNode25);
        org.junit.Assert.assertNotNull(jsonNodeFactory35);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray41), "[0, -1, 10, 100, -1]");
        org.junit.Assert.assertNotNull(binaryNode42);
        org.junit.Assert.assertTrue("'" + jsonNodeType43 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT + "'", jsonNodeType43.equals(com.fasterxml.jackson.databind.node.JsonNodeType.OBJECT));
        org.junit.Assert.assertNotNull(valueNode44);
        org.junit.Assert.assertNotNull(numericNode49);
        org.junit.Assert.assertNull(objectNodeContainerNode50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + jsonNodeType52 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BOOLEAN + "'", jsonNodeType52.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BOOLEAN));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(longNode55);
        org.junit.Assert.assertNotNull(jsonSerializer59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(atomicIntegerJsonSerializer63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 52L + "'", long66 == 52L);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(strEntryItor70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + short74 + "' != '" + (short) 100 + "'", short74 == (short) 100);
        org.junit.Assert.assertNotNull(version76);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer0 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper2 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory3 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper2);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext5 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper6 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory3, defaultSerializerProvider4, defaultDeserializationContext5);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory7 = objectMapper6.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = objectMapper6.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer9 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper6);
        tokenBuffer9.writeNull();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        longSerializer0.serialize((java.lang.Long) 0L, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer9, serializerProvider11);
        tokenBuffer9.writeBooleanField("DateFormat com.fasterxml.jackson.databind.util.StdDateFormat(locale: en_US)", true);
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory17 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode18 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory17);
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = arrayNode18.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode21 = arrayNode18.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode23 = arrayNode21.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode25 = arrayNode21.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode27 = arrayNode25.add((java.lang.Float) 0.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode29 = arrayNode25.add("[TypeBindings for [array type, component type: [simple type, class java.lang.Object]]: {E=[simple type, class java.lang.Object]}]");
        com.fasterxml.jackson.databind.JsonNode jsonNode31 = arrayNode29.get("");
        tokenBuffer9.writeObjectField("true", (java.lang.Object) jsonNode31);
        tokenBuffer9.writeNumberField("unknown", 35.0f);
        org.junit.Assert.assertNotNull(typeFactory7);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(jsonNodeFactory17);
        org.junit.Assert.assertNull(jsonNode20);
        org.junit.Assert.assertNotNull(arrayNode21);
        org.junit.Assert.assertNotNull(numericNode23);
        org.junit.Assert.assertNotNull(arrayNode25);
        org.junit.Assert.assertNotNull(arrayNode27);
        org.junit.Assert.assertNotNull(arrayNode29);
        org.junit.Assert.assertNull(jsonNode31);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory0 = com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode1 = new com.fasterxml.jackson.databind.node.ArrayNode(jsonNodeFactory0);
        com.fasterxml.jackson.databind.JsonNode jsonNode3 = arrayNode1.get("{}");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode4 = arrayNode1.deepCopy();
        com.fasterxml.jackson.databind.node.NumericNode numericNode6 = arrayNode4.numberNode((double) 100.0f);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode8 = arrayNode4.insertNull((int) ' ');
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser9 = new com.fasterxml.jackson.databind.node.TreeTraversingParser((com.fasterxml.jackson.databind.JsonNode) arrayNode8);
        com.fasterxml.jackson.core.JsonLocation jsonLocation10 = treeTraversingParser9.getCurrentLocation();
        double double12 = treeTraversingParser9.getValueAsDouble(0.0d);
        com.fasterxml.jackson.core.Base64Variant base64Variant13 = null;
        byte[] byteArray14 = treeTraversingParser9.getBinaryValue(base64Variant13);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.JsonParser) treeTraversingParser9);
        try {
            long long16 = treeTraversingParser9.getLongValue();
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Current token (null) not numeric, can not use numeric value accessors? at [Source: N/A; line: -1, column: -1]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        }
        org.junit.Assert.assertNotNull(jsonNodeFactory0);
        org.junit.Assert.assertNull(jsonNode3);
        org.junit.Assert.assertNotNull(arrayNode4);
        org.junit.Assert.assertNotNull(numericNode6);
        org.junit.Assert.assertNotNull(arrayNode8);
        org.junit.Assert.assertNotNull(jsonLocation10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(byteArray14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.fasterxml.jackson.databind.node.FloatNode floatNode1 = com.fasterxml.jackson.databind.node.FloatNode.valueOf((float) 12);
        byte[] byteArray2 = floatNode1.binaryValue();
        com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer longSerializer3 = new com.fasterxml.jackson.databind.ser.std.NumberSerializers.LongSerializer();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = null;
        com.fasterxml.jackson.databind.MappingJsonFactory mappingJsonFactory6 = new com.fasterxml.jackson.databind.MappingJsonFactory(objectMapper5);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider7 = null;
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext8 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper9 = new com.fasterxml.jackson.databind.ObjectMapper((com.fasterxml.jackson.core.JsonFactory) mappingJsonFactory6, defaultSerializerProvider7, defaultDeserializationContext8);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory10 = objectMapper9.getTypeFactory();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode11 = objectMapper9.createObjectNode();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectMapper9);
        tokenBuffer12.writeNull();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        longSerializer3.serialize((java.lang.Long) 0L, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer12, serializerProvider14);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider16 = null;
        floatNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer12, serializerProvider16);
        com.fasterxml.jackson.core.JsonParser.NumberType numberType18 = floatNode1.numberType();
        boolean boolean19 = floatNode1.canConvertToLong();
        org.junit.Assert.assertNotNull(floatNode1);
        org.junit.Assert.assertNull(byteArray2);
        org.junit.Assert.assertNotNull(typeFactory10);
        org.junit.Assert.assertNotNull(objectNode11);
        org.junit.Assert.assertTrue("'" + numberType18 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.FLOAT + "'", numberType18.equals(com.fasterxml.jackson.core.JsonParser.NumberType.FLOAT));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        float float10 = bigIntegerNode9.floatValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider16 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        try {
            bigIntegerNode9.serializeWithType(jsonGenerator15, serializerProvider16, typeSerializer17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.text.DateFormat dateFormat1 = java.text.DateFormat.getTimeInstance(1);
        java.text.NumberFormat numberFormat2 = dateFormat1.getNumberFormat();
        com.fasterxml.jackson.core.ObjectCodec objectCodec3 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer4 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec3);
        tokenBuffer4.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer4.setPrettyPrinter(prettyPrinter6);
        tokenBuffer4.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        com.fasterxml.jackson.databind.JavaType javaType12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer14 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer15 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer16 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType12, false, typeSerializer14, objJsonSerializer15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        java.lang.reflect.Type type18 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode19 = objectArraySerializer16.getSchema(serializerProvider17, type18);
        java.math.BigInteger bigInteger20 = jsonNode19.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode21 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        short short22 = bigIntegerNode21.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode24 = bigIntegerNode21.get(100);
        java.math.BigDecimal bigDecimal25 = bigIntegerNode21.decimalValue();
        tokenBuffer11.writeNumber(bigDecimal25);
        tokenBuffer4.writeNumberField("hi!", bigDecimal25);
        com.fasterxml.jackson.databind.JavaType javaType28 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer30 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer31 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer32 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType28, false, typeSerializer30, objJsonSerializer31);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider33 = null;
        java.lang.reflect.Type type34 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = objectArraySerializer32.getSchema(serializerProvider33, type34);
        com.fasterxml.jackson.databind.JsonNode jsonNode37 = jsonNode35.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser38 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode35);
        long long40 = treeTraversingParser38.nextLongValue((long) 100);
        java.lang.String str41 = treeTraversingParser38.getText();
        java.io.Writer writer42 = null;
        int int43 = treeTraversingParser38.releaseBuffered(writer42);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext44 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer45 = tokenBuffer4.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser38, deserializationContext44);
        try {
            java.lang.String str46 = numberFormat2.format((java.lang.Object) treeTraversingParser38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNull(jsonNode24);
        org.junit.Assert.assertNotNull(bigDecimal25);
        org.junit.Assert.assertNotNull(jsonNode35);
        org.junit.Assert.assertNotNull(jsonNode37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{" + "'", str41.equals("{"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer45);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.fasterxml.jackson.databind.util.Converter<java.lang.Object, java.util.Spliterator<java.lang.String>> objConverter0 = null;
        com.fasterxml.jackson.databind.JavaType javaType1 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer2 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer3 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer4 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer5 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer6 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer7 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer2, objJsonDeserializer3, objJsonDeserializer4, objJsonDeserializer5, objJsonDeserializer6);
        com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>> strSpliteratorStdDelegatingDeserializer8 = new com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>>(objConverter0, javaType1, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer7);
        com.fasterxml.jackson.databind.util.Converter<java.lang.Object, java.util.Spliterator<java.lang.String>> objConverter9 = null;
        com.fasterxml.jackson.databind.JavaType javaType10 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer11 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer12 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer13 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer14 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer15 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer16 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer11, objJsonDeserializer12, objJsonDeserializer13, objJsonDeserializer14, objJsonDeserializer15);
        com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>> strSpliteratorStdDelegatingDeserializer17 = new com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>>(objConverter9, javaType10, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer16);
        com.fasterxml.jackson.databind.util.Converter<java.lang.Object, java.util.Spliterator<java.lang.String>> objConverter18 = null;
        com.fasterxml.jackson.databind.JavaType javaType19 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer20 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer21 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer22 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer23 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer24 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer25 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer20, objJsonDeserializer21, objJsonDeserializer22, objJsonDeserializer23, objJsonDeserializer24);
        com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>> strSpliteratorStdDelegatingDeserializer26 = new com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer<java.util.Spliterator<java.lang.String>>(objConverter18, javaType19, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer25);
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer27 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer28 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer29 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer30 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer31 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer32 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer27, objJsonDeserializer28, objJsonDeserializer29, objJsonDeserializer30, objJsonDeserializer31);
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer33 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer34 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer35 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer36 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer37 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer38 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer33, objJsonDeserializer34, objJsonDeserializer35, objJsonDeserializer36, objJsonDeserializer37);
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer39 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer7, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer16, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer25, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer27, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object>) untypedObjectDeserializer33);
        java.lang.Class<?> wildcardClass40 = untypedObjectDeserializer39.getValueClass();
        java.lang.Object obj41 = untypedObjectDeserializer39.getEmptyValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec42 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer43 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec42);
        tokenBuffer43.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter45 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator46 = tokenBuffer43.setPrettyPrinter(prettyPrinter45);
        tokenBuffer43.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec49 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer50 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec49);
        com.fasterxml.jackson.databind.JavaType javaType51 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer53 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer54 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer55 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType51, false, typeSerializer53, objJsonSerializer54);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider56 = null;
        java.lang.reflect.Type type57 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = objectArraySerializer55.getSchema(serializerProvider56, type57);
        java.math.BigInteger bigInteger59 = jsonNode58.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode60 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger59);
        short short61 = bigIntegerNode60.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode63 = bigIntegerNode60.get(100);
        java.math.BigDecimal bigDecimal64 = bigIntegerNode60.decimalValue();
        tokenBuffer50.writeNumber(bigDecimal64);
        tokenBuffer43.writeNumberField("hi!", bigDecimal64);
        com.fasterxml.jackson.databind.JavaType javaType67 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer69 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer70 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer71 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType67, false, typeSerializer69, objJsonSerializer70);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider72 = null;
        java.lang.reflect.Type type73 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode74 = objectArraySerializer71.getSchema(serializerProvider72, type73);
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = jsonNode74.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser77 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode74);
        long long79 = treeTraversingParser77.nextLongValue((long) 100);
        java.lang.String str80 = treeTraversingParser77.getText();
        java.io.Writer writer81 = null;
        int int82 = treeTraversingParser77.releaseBuffered(writer81);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext83 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer84 = tokenBuffer43.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser77, deserializationContext83);
        boolean boolean85 = treeTraversingParser77.hasCurrentToken();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext86 = null;
        try {
            java.lang.Object obj87 = untypedObjectDeserializer39.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser77, deserializationContext86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNotNull(jsonGenerator46);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigIntegerNode60);
        org.junit.Assert.assertTrue("'" + short61 + "' != '" + (short) 0 + "'", short61 == (short) 0);
        org.junit.Assert.assertNull(jsonNode63);
        org.junit.Assert.assertNotNull(bigDecimal64);
        org.junit.Assert.assertNotNull(jsonNode74);
        org.junit.Assert.assertNotNull(jsonNode76);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "{" + "'", str80.equals("{"));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer1 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer2 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer3 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer4 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<java.lang.Object> objJsonDeserializer5 = null;
        com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer untypedObjectDeserializer6 = new com.fasterxml.jackson.databind.deser.std.UntypedObjectDeserializer(untypedObjectDeserializer1, objJsonDeserializer2, objJsonDeserializer3, objJsonDeserializer4, objJsonDeserializer5);
        com.fasterxml.jackson.databind.deser.ValueInstantiator valueInstantiator7 = null;
        com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer stringCollectionDeserializer8 = new com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer(javaType0, objJsonDeserializer3, valueInstantiator7);
        com.fasterxml.jackson.databind.JavaType javaType9 = stringCollectionDeserializer8.getValueType();
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        tokenBuffer11.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer11.setPrettyPrinter(prettyPrinter13);
        tokenBuffer11.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        com.fasterxml.jackson.databind.JavaType javaType19 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer21 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer22 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer23 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType19, false, typeSerializer21, objJsonSerializer22);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        java.lang.reflect.Type type25 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode26 = objectArraySerializer23.getSchema(serializerProvider24, type25);
        java.math.BigInteger bigInteger27 = jsonNode26.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode28 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger27);
        short short29 = bigIntegerNode28.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode31 = bigIntegerNode28.get(100);
        java.math.BigDecimal bigDecimal32 = bigIntegerNode28.decimalValue();
        tokenBuffer18.writeNumber(bigDecimal32);
        tokenBuffer11.writeNumberField("hi!", bigDecimal32);
        com.fasterxml.jackson.databind.JavaType javaType35 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer37 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer38 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer39 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType35, false, typeSerializer37, objJsonSerializer38);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider40 = null;
        java.lang.reflect.Type type41 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode42 = objectArraySerializer39.getSchema(serializerProvider40, type41);
        com.fasterxml.jackson.databind.JsonNode jsonNode44 = jsonNode42.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser45 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode42);
        long long47 = treeTraversingParser45.nextLongValue((long) 100);
        java.lang.String str48 = treeTraversingParser45.getText();
        java.io.Writer writer49 = null;
        int int50 = treeTraversingParser45.releaseBuffered(writer49);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext51 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer52 = tokenBuffer11.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser45, deserializationContext51);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext53 = null;
        java.lang.String[] strArray59 = new java.lang.String[] { "{", "hi!", "enum", "java.lang.Integer", "com.fasterxml.jackson.databind.node.BigIntegerNode" };
        java.util.ArrayList<java.lang.String> strList60 = new java.util.ArrayList<java.lang.String>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList60, strArray59);
        try {
            java.util.Collection<java.lang.String> strCollection62 = stringCollectionDeserializer8.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser45, deserializationContext53, (java.util.Collection<java.lang.String>) strList60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(javaType9);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(jsonNode26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigIntegerNode28);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNull(jsonNode31);
        org.junit.Assert.assertNotNull(bigDecimal32);
        org.junit.Assert.assertNotNull(jsonNode42);
        org.junit.Assert.assertNotNull(jsonNode44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 100L + "'", long47 == 100L);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{" + "'", str48.equals("{"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer52);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        com.fasterxml.jackson.databind.node.LongNode longNode44 = new com.fasterxml.jackson.databind.node.LongNode((long) (byte) 0);
        boolean boolean46 = longNode44.asBoolean(false);
        int int47 = longNode44.intValue();
        boolean boolean48 = longNode44.isBigInteger();
        boolean boolean50 = longNode44.asBoolean(false);
        try {
            tokenBuffer42.writeObjectRef((java.lang.Object) longNode44);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: No native support for writing Object Ids");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer3 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat2);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider4 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer6 = calendarSerializer3.createContextual(serializerProvider4, beanProperty5);
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer7 = calendarSerializer3.getDelegatee();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        java.util.Calendar calendar10 = dateFormat9.getCalendar();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        tokenBuffer12.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        com.fasterxml.jackson.databind.JavaType javaType20 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer22 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer23 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer24 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType20, false, typeSerializer22, objJsonSerializer23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        java.lang.reflect.Type type26 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = objectArraySerializer24.getSchema(serializerProvider25, type26);
        java.math.BigInteger bigInteger28 = jsonNode27.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode29 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger28);
        short short30 = bigIntegerNode29.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = bigIntegerNode29.get(100);
        java.math.BigDecimal bigDecimal33 = bigIntegerNode29.decimalValue();
        tokenBuffer19.writeNumber(bigDecimal33);
        tokenBuffer12.writeNumberField("hi!", bigDecimal33);
        com.fasterxml.jackson.databind.JavaType javaType36 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer38 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer39 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer40 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType36, false, typeSerializer38, objJsonSerializer39);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider41 = null;
        java.lang.reflect.Type type42 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode43 = objectArraySerializer40.getSchema(serializerProvider41, type42);
        com.fasterxml.jackson.databind.JsonNode jsonNode45 = jsonNode43.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser46 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode43);
        long long48 = treeTraversingParser46.nextLongValue((long) 100);
        java.lang.String str49 = treeTraversingParser46.getText();
        java.io.Writer writer50 = null;
        int int51 = treeTraversingParser46.releaseBuffered(writer50);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext52 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer53 = tokenBuffer12.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser46, deserializationContext52);
        tokenBuffer12.writeNull();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider55 = null;
        calendarSerializer3.serialize(calendar10, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer12, serializerProvider55);
        try {
            tokenBuffer12.writeRaw("com.fasterxml.jackson.databind.node.BigIntegerNode");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(wildcardJsonSerializer6);
        org.junit.Assert.assertNull(wildcardJsonSerializer7);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertNotNull(jsonGenerator15);
        org.junit.Assert.assertNotNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigIntegerNode29);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigDecimal33);
        org.junit.Assert.assertNotNull(jsonNode43);
        org.junit.Assert.assertNotNull(jsonNode45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{" + "'", str49.equals("{"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer53);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.fasterxml.jackson.databind.node.FloatNode floatNode1 = new com.fasterxml.jackson.databind.node.FloatNode(1.0f);
        int int2 = floatNode1.intValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec3 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer4 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec3);
        tokenBuffer4.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer4.setPrettyPrinter(prettyPrinter6);
        tokenBuffer4.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        com.fasterxml.jackson.databind.JavaType javaType12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer14 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer15 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer16 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType12, false, typeSerializer14, objJsonSerializer15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        java.lang.reflect.Type type18 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode19 = objectArraySerializer16.getSchema(serializerProvider17, type18);
        java.math.BigInteger bigInteger20 = jsonNode19.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode21 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        short short22 = bigIntegerNode21.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode24 = bigIntegerNode21.get(100);
        java.math.BigDecimal bigDecimal25 = bigIntegerNode21.decimalValue();
        tokenBuffer11.writeNumber(bigDecimal25);
        tokenBuffer4.writeNumberField("hi!", bigDecimal25);
        com.fasterxml.jackson.databind.JavaType javaType28 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer30 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer31 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer32 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType28, false, typeSerializer30, objJsonSerializer31);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider33 = null;
        java.lang.reflect.Type type34 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = objectArraySerializer32.getSchema(serializerProvider33, type34);
        com.fasterxml.jackson.databind.JsonNode jsonNode37 = jsonNode35.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser38 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode35);
        long long40 = treeTraversingParser38.nextLongValue((long) 100);
        java.lang.String str41 = treeTraversingParser38.getText();
        java.io.Writer writer42 = null;
        int int43 = treeTraversingParser38.releaseBuffered(writer42);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext44 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer45 = tokenBuffer4.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser38, deserializationContext44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        floatNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer45, serializerProvider46);
        com.fasterxml.jackson.databind.JavaType javaType48 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer50 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer51 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer52 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType48, false, typeSerializer50, objJsonSerializer51);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider53 = null;
        java.lang.reflect.Type type54 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode55 = objectArraySerializer52.getSchema(serializerProvider53, type54);
        com.fasterxml.jackson.databind.JsonNode jsonNode57 = jsonNode55.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser58 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode55);
        long long60 = treeTraversingParser58.nextLongValue((long) 100);
        java.lang.String str62 = treeTraversingParser58.getValueAsString("\"com.fasterxml.jackson.databind.node.BigIntegerNode\"");
        boolean boolean63 = floatNode1.equals((java.lang.Object) treeTraversingParser58);
        try {
            com.fasterxml.jackson.databind.node.BinaryNode binaryNode64 = treeTraversingParser58.readValueAsTree();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: No ObjectCodec defined for parser, needed for deserialization");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNull(jsonNode24);
        org.junit.Assert.assertNotNull(bigDecimal25);
        org.junit.Assert.assertNotNull(jsonNode35);
        org.junit.Assert.assertNotNull(jsonNode37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{" + "'", str41.equals("{"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer45);
        org.junit.Assert.assertNotNull(jsonNode55);
        org.junit.Assert.assertNotNull(jsonNode57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 100L + "'", long60 == 100L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "\"com.fasterxml.jackson.databind.node.BigIntegerNode\"" + "'", str62.equals("\"com.fasterxml.jackson.databind.node.BigIntegerNode\""));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        com.fasterxml.jackson.databind.JsonNode jsonNode3 = shortNode1.get("hi!");
        double double4 = shortNode1.doubleValue();
        com.fasterxml.jackson.databind.node.TextNode textNode6 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        tokenBuffer8.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer8.setPrettyPrinter(prettyPrinter10);
        tokenBuffer8.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer8.setCharacterEscapes(characterEscapes13);
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator16 = tokenBuffer8.setCodec(objectCodec15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        textNode6.serialize(jsonGenerator16, serializerProvider17);
        jsonGenerator16.writeNumberField("{", (int) (byte) 1);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider22 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer23 = null;
        try {
            shortNode1.serializeWithType(jsonGenerator16, serializerProvider22, typeSerializer23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jsonNode3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(textNode6);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(jsonGenerator16);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        long long11 = bigIntegerNode9.asLong();
        int int12 = bigIntegerNode9.intValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer14.setPrettyPrinter(prettyPrinter16);
        tokenBuffer14.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        com.fasterxml.jackson.databind.JavaType javaType22 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer24 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer25 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer26 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType22, false, typeSerializer24, objJsonSerializer25);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider27 = null;
        java.lang.reflect.Type type28 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode29 = objectArraySerializer26.getSchema(serializerProvider27, type28);
        java.math.BigInteger bigInteger30 = jsonNode29.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode31 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger30);
        short short32 = bigIntegerNode31.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = bigIntegerNode31.get(100);
        java.math.BigDecimal bigDecimal35 = bigIntegerNode31.decimalValue();
        tokenBuffer21.writeNumber(bigDecimal35);
        tokenBuffer14.writeNumberField("hi!", bigDecimal35);
        boolean boolean38 = tokenBuffer14.canWriteObjectId();
        java.lang.Object obj39 = tokenBuffer14.getOutputTarget();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider40 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer41 = null;
        try {
            bigIntegerNode9.serializeWithType((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer14, serializerProvider40, typeSerializer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertNotNull(jsonNode29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigIntegerNode31);
        org.junit.Assert.assertTrue("'" + short32 + "' != '" + (short) 0 + "'", short32 == (short) 0);
        org.junit.Assert.assertNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigDecimal35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(obj39);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty6 = null;
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer9 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer10 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer11 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType7, false, typeSerializer9, objJsonSerializer10);
        com.fasterxml.jackson.databind.BeanProperty beanProperty12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer13 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Map<?, ?>> wildcardMapJsonSerializer14 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer15 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(objectArraySerializer11, beanProperty12, typeSerializer13, wildcardMapJsonSerializer14);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer16 = null;
        com.fasterxml.jackson.databind.ser.ContainerSerializer<?> wildcardContainerSerializer17 = objectArraySerializer11.withValueTypeSerializer(typeSerializer16);
        com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer indexedListSerializer18 = new com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer(javaType3, false, typeSerializer5, beanProperty6, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer17);
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, true, typeSerializer2, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer17);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException22 = new com.fasterxml.jackson.databind.JsonMappingException("enum");
        java.lang.Object obj23 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException25 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException22, obj23, "");
        com.fasterxml.jackson.core.ObjectCodec objectCodec26 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer27 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec26);
        tokenBuffer27.flush();
        tokenBuffer27.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec32 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer33 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec32);
        tokenBuffer33.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter35 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator36 = tokenBuffer33.setPrettyPrinter(prettyPrinter35);
        tokenBuffer33.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec39 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer40 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec39);
        com.fasterxml.jackson.databind.JavaType javaType41 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer43 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer44 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer45 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType41, false, typeSerializer43, objJsonSerializer44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        java.lang.reflect.Type type47 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode48 = objectArraySerializer45.getSchema(serializerProvider46, type47);
        java.math.BigInteger bigInteger49 = jsonNode48.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode50 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger49);
        short short51 = bigIntegerNode50.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode53 = bigIntegerNode50.get(100);
        java.math.BigDecimal bigDecimal54 = bigIntegerNode50.decimalValue();
        tokenBuffer40.writeNumber(bigDecimal54);
        tokenBuffer33.writeNumberField("hi!", bigDecimal54);
        boolean boolean57 = tokenBuffer33.canWriteObjectId();
        tokenBuffer33.writeNullField("");
        tokenBuffer27.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer33);
        com.fasterxml.jackson.core.ObjectCodec objectCodec61 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer62 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec61);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter63 = tokenBuffer62.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser64 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException66 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser64, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference69 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException66.prependPath(reference69);
        tokenBuffer62.writeTypeId((java.lang.Object) reference69);
        reference69.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer33.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        try {
            objectArraySerializer19.wrapAndThrow(serializerProvider20, (java.lang.Throwable) jsonMappingException25, (java.lang.Object) "java.lang.Short[\"hi!\"]", 10);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException whose getMessage() throws an exception");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(wildcardContainerSerializer17);
        org.junit.Assert.assertNotNull(jsonMappingException25);
        org.junit.Assert.assertNotNull(jsonGenerator36);
        org.junit.Assert.assertNotNull(jsonNode48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigIntegerNode50);
        org.junit.Assert.assertTrue("'" + short51 + "' != '" + (short) 0 + "'", short51 == (short) 0);
        org.junit.Assert.assertNull(jsonNode53);
        org.junit.Assert.assertNotNull(bigDecimal54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(prettyPrinter63);
        org.junit.Assert.assertNotNull(jsonMappingException66);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer3 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat2);
        java.text.DateFormat dateFormat6 = java.text.DateFormat.getTimeInstance(1);
        java.text.NumberFormat numberFormat7 = dateFormat6.getNumberFormat();
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer8 = calendarSerializer3.withFormat((java.lang.Boolean) true, dateFormat6);
        java.text.DateFormat dateFormat10 = java.text.DateFormat.getTimeInstance(1);
        java.util.Calendar calendar11 = dateFormat10.getCalendar();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer13 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec12);
        tokenBuffer13.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter15 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator16 = tokenBuffer13.setPrettyPrinter(prettyPrinter15);
        tokenBuffer13.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes18 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator19 = tokenBuffer13.setCharacterEscapes(characterEscapes18);
        tokenBuffer13.writeObjectFieldStart("");
        boolean boolean22 = tokenBuffer13.canWriteBinaryNatively();
        tokenBuffer13.writeNull();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = null;
        try {
            calendarSerializer3.serializeWithType(calendar11, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer13, serializerProvider24, typeSerializer25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateFormat6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(calendarSerializer8);
        org.junit.Assert.assertNotNull(dateFormat10);
        org.junit.Assert.assertNotNull(calendar11);
        org.junit.Assert.assertNotNull(jsonGenerator16);
        org.junit.Assert.assertNotNull(jsonGenerator19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.fasterxml.jackson.databind.ser.impl.FailingSerializer failingSerializer1 = new com.fasterxml.jackson.databind.ser.impl.FailingSerializer("[parameter #10, annotations: null]");
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode17 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal16);
        boolean boolean18 = decimalNode17.canConvertToLong();
        java.math.BigInteger bigInteger19 = decimalNode17.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        tokenBuffer21.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer21.setPrettyPrinter(prettyPrinter23);
        tokenBuffer21.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes26 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator27 = tokenBuffer21.setCharacterEscapes(characterEscapes26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        decimalNode17.serialize(jsonGenerator27, serializerProvider28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        try {
            failingSerializer1.serialize((java.lang.Object) 100, jsonGenerator27, serializerProvider30);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: [parameter #10, annotations: null]");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertNotNull(decimalNode17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(jsonGenerator27);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.fasterxml.jackson.databind.node.TextNode textNode1 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        tokenBuffer3.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer3.setCharacterEscapes(characterEscapes8);
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer3.setCodec(objectCodec10);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider12 = null;
        textNode1.serialize(jsonGenerator11, serializerProvider12);
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        tokenBuffer15.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter17 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator18 = tokenBuffer15.setPrettyPrinter(prettyPrinter17);
        tokenBuffer15.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec21 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer22 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec21);
        com.fasterxml.jackson.databind.JavaType javaType23 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer26 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer27 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType23, false, typeSerializer25, objJsonSerializer26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        java.lang.reflect.Type type29 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = objectArraySerializer27.getSchema(serializerProvider28, type29);
        java.math.BigInteger bigInteger31 = jsonNode30.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode32 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger31);
        short short33 = bigIntegerNode32.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = bigIntegerNode32.get(100);
        java.math.BigDecimal bigDecimal36 = bigIntegerNode32.decimalValue();
        tokenBuffer22.writeNumber(bigDecimal36);
        tokenBuffer15.writeNumberField("hi!", bigDecimal36);
        com.fasterxml.jackson.databind.JavaType javaType39 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer41 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer42 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer43 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType39, false, typeSerializer41, objJsonSerializer42);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        java.lang.reflect.Type type45 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode46 = objectArraySerializer43.getSchema(serializerProvider44, type45);
        com.fasterxml.jackson.databind.JsonNode jsonNode48 = jsonNode46.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser49 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode46);
        long long51 = treeTraversingParser49.nextLongValue((long) 100);
        java.lang.String str52 = treeTraversingParser49.getText();
        java.io.Writer writer53 = null;
        int int54 = treeTraversingParser49.releaseBuffered(writer53);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext55 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer56 = tokenBuffer15.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser49, deserializationContext55);
        boolean boolean57 = textNode1.equals((java.lang.Object) treeTraversingParser49);
        com.fasterxml.jackson.databind.node.TextNode textNode59 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec60 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer61 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec60);
        tokenBuffer61.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter63 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator64 = tokenBuffer61.setPrettyPrinter(prettyPrinter63);
        tokenBuffer61.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes66 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator67 = tokenBuffer61.setCharacterEscapes(characterEscapes66);
        com.fasterxml.jackson.core.ObjectCodec objectCodec68 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator69 = tokenBuffer61.setCodec(objectCodec68);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider70 = null;
        textNode59.serialize(jsonGenerator69, serializerProvider70);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider72 = null;
        textNode1.serialize(jsonGenerator69, serializerProvider72);
        jsonGenerator69.writeBooleanField("java.lang.Short[\"hi!\"]", false);
        org.junit.Assert.assertNotNull(textNode1);
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonGenerator18);
        org.junit.Assert.assertNotNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigIntegerNode32);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigDecimal36);
        org.junit.Assert.assertNotNull(jsonNode46);
        org.junit.Assert.assertNotNull(jsonNode48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{" + "'", str52.equals("{"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(textNode59);
        org.junit.Assert.assertNotNull(jsonGenerator64);
        org.junit.Assert.assertNotNull(jsonGenerator67);
        org.junit.Assert.assertNotNull(jsonGenerator69);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        tokenBuffer5.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = tokenBuffer5.setPrettyPrinter(prettyPrinter7);
        com.fasterxml.jackson.core.Base64Variant base64Variant9 = null;
        byte[] byteArray10 = new byte[] {};
        tokenBuffer5.writeBinary(base64Variant9, byteArray10, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode16 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray10, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType17 = binaryNode16.getNodeType();
        byte[] byteArray18 = binaryNode16.binaryValue();
        try {
            java.lang.Enum<com.fasterxml.jackson.databind.node.JsonNodeType> jsonNodeTypeEnum19 = objectReader3.readValue(byteArray18);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No content to map due to end-of-input? at [Source: [B@24bdf185; line: 1, column: 1]");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[]");
        org.junit.Assert.assertNotNull(binaryNode16);
        org.junit.Assert.assertTrue("'" + jsonNodeType17 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType17.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[]");
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer6 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec5);
        tokenBuffer6.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer6.setPrettyPrinter(prettyPrinter8);
        tokenBuffer6.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer13 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec12);
        com.fasterxml.jackson.databind.JavaType javaType14 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer16 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer17 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer18 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType14, false, typeSerializer16, objJsonSerializer17);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider19 = null;
        java.lang.reflect.Type type20 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = objectArraySerializer18.getSchema(serializerProvider19, type20);
        java.math.BigInteger bigInteger22 = jsonNode21.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode23 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger22);
        short short24 = bigIntegerNode23.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode26 = bigIntegerNode23.get(100);
        java.math.BigDecimal bigDecimal27 = bigIntegerNode23.decimalValue();
        tokenBuffer13.writeNumber(bigDecimal27);
        tokenBuffer6.writeNumberField("hi!", bigDecimal27);
        com.fasterxml.jackson.databind.JavaType javaType30 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer32 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer33 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer34 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType30, false, typeSerializer32, objJsonSerializer33);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider35 = null;
        java.lang.reflect.Type type36 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode37 = objectArraySerializer34.getSchema(serializerProvider35, type36);
        com.fasterxml.jackson.databind.JsonNode jsonNode39 = jsonNode37.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser40 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode37);
        long long42 = treeTraversingParser40.nextLongValue((long) 100);
        java.lang.String str43 = treeTraversingParser40.getText();
        java.io.Writer writer44 = null;
        int int45 = treeTraversingParser40.releaseBuffered(writer44);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext46 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer47 = tokenBuffer6.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser40, deserializationContext46);
        com.fasterxml.jackson.core.ObjectCodec objectCodec48 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer49 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec48);
        tokenBuffer49.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter51 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator52 = tokenBuffer49.setPrettyPrinter(prettyPrinter51);
        tokenBuffer49.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec55 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer56 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec55);
        com.fasterxml.jackson.databind.JavaType javaType57 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer59 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer60 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer61 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType57, false, typeSerializer59, objJsonSerializer60);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider62 = null;
        java.lang.reflect.Type type63 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode64 = objectArraySerializer61.getSchema(serializerProvider62, type63);
        java.math.BigInteger bigInteger65 = jsonNode64.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode66 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger65);
        short short67 = bigIntegerNode66.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode69 = bigIntegerNode66.get(100);
        java.math.BigDecimal bigDecimal70 = bigIntegerNode66.decimalValue();
        tokenBuffer56.writeNumber(bigDecimal70);
        tokenBuffer49.writeNumberField("hi!", bigDecimal70);
        boolean boolean73 = tokenBuffer49.canWriteObjectId();
        tokenBuffer49.writeNullField("");
        java.lang.String str76 = tokenBuffer49.toString();
        try {
            objectReader3.writeValue((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer6, (java.lang.Object) str76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Not implemented for ObjectReader");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigIntegerNode23);
        org.junit.Assert.assertTrue("'" + short24 + "' != '" + (short) 0 + "'", short24 == (short) 0);
        org.junit.Assert.assertNull(jsonNode26);
        org.junit.Assert.assertNotNull(bigDecimal27);
        org.junit.Assert.assertNotNull(jsonNode37);
        org.junit.Assert.assertNotNull(jsonNode39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 100L + "'", long42 == 100L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{" + "'", str43.equals("{"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer47);
        org.junit.Assert.assertNotNull(jsonGenerator52);
        org.junit.Assert.assertNotNull(jsonNode64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigIntegerNode66);
        org.junit.Assert.assertTrue("'" + short67 + "' != '" + (short) 0 + "'", short67 == (short) 0);
        org.junit.Assert.assertNull(jsonNode69);
        org.junit.Assert.assertNotNull(bigDecimal70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]" + "'", str76.equals("[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty6 = null;
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer9 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer10 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer11 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType7, false, typeSerializer9, objJsonSerializer10);
        com.fasterxml.jackson.databind.BeanProperty beanProperty12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer13 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Map<?, ?>> wildcardMapJsonSerializer14 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer15 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(objectArraySerializer11, beanProperty12, typeSerializer13, wildcardMapJsonSerializer14);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer16 = null;
        com.fasterxml.jackson.databind.ser.ContainerSerializer<?> wildcardContainerSerializer17 = objectArraySerializer11.withValueTypeSerializer(typeSerializer16);
        com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer indexedListSerializer18 = new com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer(javaType3, false, typeSerializer5, beanProperty6, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer17);
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, true, typeSerializer2, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer17);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        com.fasterxml.jackson.databind.JavaType javaType22 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer24 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer25 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer26 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType22, false, typeSerializer24, objJsonSerializer25);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider27 = null;
        java.lang.reflect.Type type28 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode29 = objectArraySerializer26.getSchema(serializerProvider27, type28);
        com.fasterxml.jackson.databind.JsonNode jsonNode31 = jsonNode29.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser32 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode29);
        boolean boolean33 = treeTraversingParser32.requiresCustomCodec();
        boolean boolean34 = treeTraversingParser32.canReadTypeId();
        com.fasterxml.jackson.core.JsonLocation jsonLocation35 = treeTraversingParser32.getCurrentLocation();
        com.fasterxml.jackson.core.JsonParser jsonParser36 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException38 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser36, "");
        com.fasterxml.jackson.databind.JavaType javaType39 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer41 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer42 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer43 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType39, false, typeSerializer41, objJsonSerializer42);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        java.lang.reflect.Type type45 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode46 = objectArraySerializer43.getSchema(serializerProvider44, type45);
        java.math.BigInteger bigInteger47 = jsonNode46.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode48 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger47);
        short short49 = bigIntegerNode48.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = bigIntegerNode48.get(100);
        java.math.BigDecimal bigDecimal52 = bigIntegerNode48.decimalValue();
        boolean boolean53 = bigIntegerNode48.isFloat();
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException55 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException38, (java.lang.Object) boolean53, "hi!");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference57 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) 10.0f);
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException58 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException55, reference57);
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException59 = new com.fasterxml.jackson.databind.JsonMappingException("com.fasterxml.jackson.databind.node.BigIntegerNode", jsonLocation35, (java.lang.Throwable) jsonMappingException58);
        com.fasterxml.jackson.core.ObjectCodec objectCodec60 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer61 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec60);
        tokenBuffer61.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter63 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator64 = tokenBuffer61.setPrettyPrinter(prettyPrinter63);
        tokenBuffer61.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec67 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer68 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec67);
        com.fasterxml.jackson.databind.JavaType javaType69 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer71 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer72 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer73 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType69, false, typeSerializer71, objJsonSerializer72);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider74 = null;
        java.lang.reflect.Type type75 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = objectArraySerializer73.getSchema(serializerProvider74, type75);
        java.math.BigInteger bigInteger77 = jsonNode76.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode78 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger77);
        short short79 = bigIntegerNode78.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode81 = bigIntegerNode78.get(100);
        java.math.BigDecimal bigDecimal82 = bigIntegerNode78.decimalValue();
        tokenBuffer68.writeNumber(bigDecimal82);
        tokenBuffer61.writeNumberField("hi!", bigDecimal82);
        boolean boolean85 = tokenBuffer61.canWriteObjectId();
        try {
            wildcardContainerSerializer17.wrapAndThrow(serializerProvider20, (java.lang.Throwable) jsonMappingException59, (java.lang.Object) tokenBuffer61, 0);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: com.fasterxml.jackson.databind.node.BigIntegerNode? at [Source: N/A; line: -1, column: -1] (through reference chain: com.fasterxml.jackson.databind.util.TokenBuffer[0])");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(wildcardContainerSerializer17);
        org.junit.Assert.assertNotNull(jsonNode29);
        org.junit.Assert.assertNotNull(jsonNode31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jsonLocation35);
        org.junit.Assert.assertNotNull(jsonMappingException38);
        org.junit.Assert.assertNotNull(jsonNode46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigIntegerNode48);
        org.junit.Assert.assertTrue("'" + short49 + "' != '" + (short) 0 + "'", short49 == (short) 0);
        org.junit.Assert.assertNull(jsonNode51);
        org.junit.Assert.assertNotNull(bigDecimal52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(jsonMappingException55);
        org.junit.Assert.assertNotNull(jsonMappingException58);
        org.junit.Assert.assertNotNull(jsonGenerator64);
        org.junit.Assert.assertNotNull(jsonNode76);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigIntegerNode78);
        org.junit.Assert.assertTrue("'" + short79 + "' != '" + (short) 0 + "'", short79 == (short) 0);
        org.junit.Assert.assertNull(jsonNode81);
        org.junit.Assert.assertNotNull(bigDecimal82);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter2 = tokenBuffer1.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser3 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException5 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser3, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference8 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException5.prependPath(reference8);
        tokenBuffer1.writeTypeId((java.lang.Object) reference8);
        com.fasterxml.jackson.core.JsonFactory jsonFactory11 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory11);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes13 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader14 = objectMapper12.reader(contextAttributes13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        java.lang.String str25 = com.fasterxml.jackson.databind.util.ClassUtil.getClassDescription((java.lang.Object) bigIntegerNode24);
        boolean boolean26 = bigIntegerNode24.isNull();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType27 = bigIntegerNode24.numberType();
        com.fasterxml.jackson.core.JsonParser jsonParser28 = bigIntegerNode24.traverse();
        byte[] byteArray29 = objectMapper12.writeValueAsBytes((java.lang.Object) bigIntegerNode24);
        try {
            tokenBuffer1.writeUTF8String(byteArray29, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(prettyPrinter2);
        org.junit.Assert.assertNotNull(jsonMappingException5);
        org.junit.Assert.assertNotNull(objectReader14);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "com.fasterxml.jackson.databind.node.BigIntegerNode" + "'", str25.equals("com.fasterxml.jackson.databind.node.BigIntegerNode"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + numberType27 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER + "'", numberType27.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER));
        org.junit.Assert.assertNotNull(jsonParser28);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray29), "[48]");
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeNumber((short) 10);
        try {
            tokenBuffer7.writeRawValue("");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        boolean boolean26 = tokenBuffer1.canWriteBinaryNatively();
        com.fasterxml.jackson.core.ObjectCodec objectCodec27 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer28 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec27);
        tokenBuffer28.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer28.setPrettyPrinter(prettyPrinter30);
        com.fasterxml.jackson.core.Base64Variant base64Variant32 = null;
        byte[] byteArray33 = new byte[] {};
        tokenBuffer28.writeBinary(base64Variant32, byteArray33, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode39 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray33, (int) (short) 0, 0);
        try {
            tokenBuffer1.writeRawUTF8String(byteArray33, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jsonGenerator31);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[]");
        org.junit.Assert.assertNotNull(binaryNode39);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ObjectNode objectNode11 = objectNode8.put("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]", (float) 10L);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode13 = objectNode8.booleanNode(true);
        com.fasterxml.jackson.databind.node.NullNode nullNode14 = objectNode8.nullNode();
        com.fasterxml.jackson.databind.node.ShortNode shortNode16 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str17 = shortNode16.asText();
        boolean boolean18 = shortNode16.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer20 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec19);
        com.fasterxml.jackson.databind.JavaType javaType21 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer23 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer24 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer25 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType21, false, typeSerializer23, objJsonSerializer24);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider26 = null;
        java.lang.reflect.Type type27 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode28 = objectArraySerializer25.getSchema(serializerProvider26, type27);
        java.math.BigInteger bigInteger29 = jsonNode28.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode30 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger29);
        short short31 = bigIntegerNode30.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode33 = bigIntegerNode30.get(100);
        java.math.BigDecimal bigDecimal34 = bigIntegerNode30.decimalValue();
        tokenBuffer20.writeNumber(bigDecimal34);
        boolean boolean36 = shortNode16.equals((java.lang.Object) tokenBuffer20);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes37 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator38 = tokenBuffer20.setCharacterEscapes(characterEscapes37);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider39 = null;
        try {
            nullNode14.serialize(jsonGenerator38, serializerProvider39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(objectNode11);
        org.junit.Assert.assertNotNull(booleanNode13);
        org.junit.Assert.assertNotNull(nullNode14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jsonNode28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigIntegerNode30);
        org.junit.Assert.assertTrue("'" + short31 + "' != '" + (short) 0 + "'", short31 == (short) 0);
        org.junit.Assert.assertNull(jsonNode33);
        org.junit.Assert.assertNotNull(bigDecimal34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jsonGenerator38);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.text.DateFormat dateFormat1 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.node.ShortNode shortNode3 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.Number number4 = shortNode3.numberValue();
        com.fasterxml.jackson.databind.node.ShortNode shortNode6 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str7 = shortNode6.asText();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType8 = shortNode6.numberType();
        boolean boolean9 = shortNode3.equals((java.lang.Object) numberType8);
        java.util.Iterator<com.fasterxml.jackson.databind.JsonNode> jsonNodeItor10 = shortNode3.elements();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        tokenBuffer12.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec24 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer25 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec24);
        com.fasterxml.jackson.databind.JavaType javaType26 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer28 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer29 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer30 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType26, false, typeSerializer28, objJsonSerializer29);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider31 = null;
        java.lang.reflect.Type type32 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode33 = objectArraySerializer30.getSchema(serializerProvider31, type32);
        java.math.BigInteger bigInteger34 = jsonNode33.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode35 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger34);
        short short36 = bigIntegerNode35.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode38 = bigIntegerNode35.get(100);
        java.math.BigDecimal bigDecimal39 = bigIntegerNode35.decimalValue();
        tokenBuffer25.writeNumber(bigDecimal39);
        tokenBuffer18.writeNumberField("hi!", bigDecimal39);
        boolean boolean42 = tokenBuffer18.canWriteObjectId();
        tokenBuffer18.writeNullField("");
        tokenBuffer12.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer18);
        com.fasterxml.jackson.core.ObjectCodec objectCodec46 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer47 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec46);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter48 = tokenBuffer47.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser49 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException51 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser49, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference54 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException51.prependPath(reference54);
        tokenBuffer47.writeTypeId((java.lang.Object) reference54);
        reference54.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer18.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType60 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer62 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer63 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer64 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType60, false, typeSerializer62, objJsonSerializer63);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider65 = null;
        java.lang.reflect.Type type66 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode67 = objectArraySerializer64.getSchema(serializerProvider65, type66);
        com.fasterxml.jackson.databind.JsonNode jsonNode69 = jsonNode67.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser70 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode67);
        long long72 = treeTraversingParser70.nextLongValue((long) 100);
        int int73 = treeTraversingParser70.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext74 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer75 = tokenBuffer18.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser70, deserializationContext74);
        tokenBuffer75.writeNullField("enum");
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider78 = null;
        shortNode3.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer75, serializerProvider78);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator80 = dateFormat1.formatToCharacterIterator((java.lang.Object) serializerProvider78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: formatToCharacterIterator must be passed non-null object");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + numberType8 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.INT + "'", numberType8.equals(com.fasterxml.jackson.core.JsonParser.NumberType.INT));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jsonNodeItor10);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonNode33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigIntegerNode35);
        org.junit.Assert.assertTrue("'" + short36 + "' != '" + (short) 0 + "'", short36 == (short) 0);
        org.junit.Assert.assertNull(jsonNode38);
        org.junit.Assert.assertNotNull(bigDecimal39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(prettyPrinter48);
        org.junit.Assert.assertNotNull(jsonMappingException51);
        org.junit.Assert.assertNotNull(jsonNode67);
        org.junit.Assert.assertNotNull(jsonNode69);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 100L + "'", long72 == 100L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer75);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.databind.JavaType javaType5 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer7 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer8 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer9 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType5, false, typeSerializer7, objJsonSerializer8);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider10 = null;
        java.lang.reflect.Type type11 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = objectArraySerializer9.getSchema(serializerProvider10, type11);
        java.math.BigInteger bigInteger13 = jsonNode12.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode14 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger13);
        short short15 = bigIntegerNode14.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode17 = bigIntegerNode14.get(100);
        java.math.BigDecimal bigDecimal18 = bigIntegerNode14.decimalValue();
        com.fasterxml.jackson.core.JsonParser jsonParser19 = objectReader3.treeAsTokens((com.fasterxml.jackson.core.TreeNode) bigIntegerNode14);
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        tokenBuffer21.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer21.setPrettyPrinter(prettyPrinter23);
        com.fasterxml.jackson.core.Base64Variant base64Variant25 = null;
        byte[] byteArray26 = new byte[] {};
        tokenBuffer21.writeBinary(base64Variant25, byteArray26, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode32 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray26, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType33 = binaryNode32.getNodeType();
        byte[] byteArray34 = binaryNode32.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode35 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray34);
        try {
            com.fasterxml.jackson.databind.MappingIterator<com.fasterxml.jackson.databind.MappingIterator<com.fasterxml.jackson.databind.util.BeanUtil>> beanUtilItorItor38 = objectReader3.readValues(byteArray34, (int) (byte) 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No value type configured for ObjectReader");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigIntegerNode14);
        org.junit.Assert.assertTrue("'" + short15 + "' != '" + (short) 0 + "'", short15 == (short) 0);
        org.junit.Assert.assertNull(jsonNode17);
        org.junit.Assert.assertNotNull(bigDecimal18);
        org.junit.Assert.assertNotNull(jsonParser19);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[]");
        org.junit.Assert.assertNotNull(binaryNode32);
        org.junit.Assert.assertTrue("'" + jsonNodeType33 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType33.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray34), "[]");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer1.setFeatureMask((int) (short) 100);
        com.fasterxml.jackson.databind.JavaType javaType10 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer12 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer13 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer14 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType10, false, typeSerializer12, objJsonSerializer13);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider15 = null;
        java.lang.reflect.Type type16 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode17 = objectArraySerializer14.getSchema(serializerProvider15, type16);
        java.math.BigInteger bigInteger18 = jsonNode17.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode19 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger18);
        short short20 = bigIntegerNode19.shortValue();
        int int21 = bigIntegerNode19.asInt();
        int int22 = bigIntegerNode19.asInt();
        tokenBuffer1.writeObjectId((java.lang.Object) int22);
        com.fasterxml.jackson.core.JsonParser jsonParser24 = tokenBuffer1.asParser();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonNode17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigIntegerNode19);
        org.junit.Assert.assertTrue("'" + short20 + "' != '" + (short) 0 + "'", short20 == (short) 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(jsonParser24);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer sqlTimeSerializer0 = new com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer();
        boolean boolean1 = sqlTimeSerializer0.isUnwrappingSerializer();
        java.sql.Time time2 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec3 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer4 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec3);
        tokenBuffer4.flush();
        tokenBuffer4.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec9 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer10 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec9);
        tokenBuffer10.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter12 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator13 = tokenBuffer10.setPrettyPrinter(prettyPrinter12);
        tokenBuffer10.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        com.fasterxml.jackson.databind.JavaType javaType18 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer20 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer21 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer22 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType18, false, typeSerializer20, objJsonSerializer21);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider23 = null;
        java.lang.reflect.Type type24 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = objectArraySerializer22.getSchema(serializerProvider23, type24);
        java.math.BigInteger bigInteger26 = jsonNode25.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode27 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger26);
        short short28 = bigIntegerNode27.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = bigIntegerNode27.get(100);
        java.math.BigDecimal bigDecimal31 = bigIntegerNode27.decimalValue();
        tokenBuffer17.writeNumber(bigDecimal31);
        tokenBuffer10.writeNumberField("hi!", bigDecimal31);
        boolean boolean34 = tokenBuffer10.canWriteObjectId();
        tokenBuffer10.writeNullField("");
        tokenBuffer4.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer10);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider38 = null;
        try {
            sqlTimeSerializer0.serialize(time2, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer10, serializerProvider38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jsonGenerator13);
        org.junit.Assert.assertNotNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigIntegerNode27);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 0 + "'", short28 == (short) 0);
        org.junit.Assert.assertNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigDecimal31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        java.lang.Class<java.util.Date> dateClass4 = dateSerializer3.handledType();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer10 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        dateFormat9.setLenient(false);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer13 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer14 = dateSerializer3.withFormat((java.lang.Boolean) false, dateFormat9);
        boolean boolean15 = dateSerializer14.isUnwrappingSerializer();
        java.util.Date date16 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeStartArray();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider23 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer24 = null;
        try {
            dateSerializer14.serializeWithType(date16, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer18, serializerProvider23, typeSerializer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateClass4);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateSerializer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jsonGenerator21);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec44 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer45 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec44);
        tokenBuffer45.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter47 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator48 = tokenBuffer45.setPrettyPrinter(prettyPrinter47);
        tokenBuffer45.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec51 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer52 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec51);
        com.fasterxml.jackson.databind.JavaType javaType53 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer55 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer56 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer57 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType53, false, typeSerializer55, objJsonSerializer56);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider58 = null;
        java.lang.reflect.Type type59 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode60 = objectArraySerializer57.getSchema(serializerProvider58, type59);
        java.math.BigInteger bigInteger61 = jsonNode60.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode62 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger61);
        short short63 = bigIntegerNode62.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode65 = bigIntegerNode62.get(100);
        java.math.BigDecimal bigDecimal66 = bigIntegerNode62.decimalValue();
        tokenBuffer52.writeNumber(bigDecimal66);
        tokenBuffer45.writeNumberField("hi!", bigDecimal66);
        com.fasterxml.jackson.databind.JavaType javaType69 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer71 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer72 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer73 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType69, false, typeSerializer71, objJsonSerializer72);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider74 = null;
        java.lang.reflect.Type type75 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = objectArraySerializer73.getSchema(serializerProvider74, type75);
        com.fasterxml.jackson.databind.JsonNode jsonNode78 = jsonNode76.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser79 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode76);
        long long81 = treeTraversingParser79.nextLongValue((long) 100);
        java.lang.String str82 = treeTraversingParser79.getText();
        java.io.Writer writer83 = null;
        int int84 = treeTraversingParser79.releaseBuffered(writer83);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext85 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer86 = tokenBuffer45.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser79, deserializationContext85);
        tokenBuffer45.writeNull();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer88 = tokenBuffer1.append(tokenBuffer45);
        tokenBuffer45.writeStartObject();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonGenerator48);
        org.junit.Assert.assertNotNull(jsonNode60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigIntegerNode62);
        org.junit.Assert.assertTrue("'" + short63 + "' != '" + (short) 0 + "'", short63 == (short) 0);
        org.junit.Assert.assertNull(jsonNode65);
        org.junit.Assert.assertNotNull(bigDecimal66);
        org.junit.Assert.assertNotNull(jsonNode76);
        org.junit.Assert.assertNotNull(jsonNode78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "{" + "'", str82.equals("{"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer86);
        org.junit.Assert.assertNotNull(tokenBuffer88);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType22 = shortNode1.getNodeType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + jsonNodeType22 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER + "'", jsonNodeType22.equals(com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode14 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal13);
        boolean boolean15 = decimalNode14.canConvertToLong();
        java.math.BigInteger bigInteger16 = decimalNode14.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer18.setCharacterEscapes(characterEscapes23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        decimalNode14.serialize(jsonGenerator24, serializerProvider25);
        java.lang.String str27 = decimalNode14.asText();
        com.fasterxml.jackson.core.JsonParser jsonParser28 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException30 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser28, "");
        com.fasterxml.jackson.databind.JavaType javaType31 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer33 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer34 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer35 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType31, false, typeSerializer33, objJsonSerializer34);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider36 = null;
        java.lang.reflect.Type type37 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode38 = objectArraySerializer35.getSchema(serializerProvider36, type37);
        java.math.BigInteger bigInteger39 = jsonNode38.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode40 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger39);
        short short41 = bigIntegerNode40.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode43 = bigIntegerNode40.get(100);
        java.math.BigDecimal bigDecimal44 = bigIntegerNode40.decimalValue();
        boolean boolean45 = bigIntegerNode40.isFloat();
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException47 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException30, (java.lang.Object) boolean45, "hi!");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference49 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) 10.0f);
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException50 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException47, reference49);
        java.lang.Throwable[] throwableArray51 = jsonMappingException47.getSuppressed();
        boolean boolean52 = decimalNode14.equals((java.lang.Object) jsonMappingException47);
        com.fasterxml.jackson.core.JsonParser.NumberType numberType53 = decimalNode14.numberType();
        com.fasterxml.jackson.core.JsonToken jsonToken54 = decimalNode14.asToken();
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(decimalNode14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0" + "'", str27.equals("0"));
        org.junit.Assert.assertNotNull(jsonMappingException30);
        org.junit.Assert.assertNotNull(jsonNode38);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigIntegerNode40);
        org.junit.Assert.assertTrue("'" + short41 + "' != '" + (short) 0 + "'", short41 == (short) 0);
        org.junit.Assert.assertNull(jsonNode43);
        org.junit.Assert.assertNotNull(bigDecimal44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(jsonMappingException47);
        org.junit.Assert.assertNotNull(jsonMappingException50);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + numberType53 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL + "'", numberType53.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL));
        org.junit.Assert.assertTrue("'" + jsonToken54 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken54.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.databind.JsonNode jsonNode5 = objectReader3.createObjectNode();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = objectReader3.getFactory();
        com.fasterxml.jackson.core.Base64Variant base64Variant7 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader8 = objectReader3.with(base64Variant7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec9 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer10 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec9);
        tokenBuffer10.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter12 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator13 = tokenBuffer10.setPrettyPrinter(prettyPrinter12);
        com.fasterxml.jackson.core.Base64Variant base64Variant14 = null;
        byte[] byteArray15 = new byte[] {};
        tokenBuffer10.writeBinary(base64Variant14, byteArray15, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode19 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray15);
        try {
            com.fasterxml.jackson.databind.MappingIterator<com.fasterxml.jackson.databind.deser.std.EnumMapDeserializer> enumMapDeserializerItor20 = objectReader3.readValues(byteArray15);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No value type configured for ObjectReader");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonNode5);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(objectReader8);
        org.junit.Assert.assertNotNull(jsonGenerator13);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[]");
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType49 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer51 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer52 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer53 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType49, false, typeSerializer51, objJsonSerializer52);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider54 = null;
        java.lang.reflect.Type type55 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = objectArraySerializer53.getSchema(serializerProvider54, type55);
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = jsonNode56.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser59 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode56);
        long long61 = treeTraversingParser59.nextLongValue((long) 100);
        int int62 = treeTraversingParser59.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext63 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer64 = tokenBuffer7.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser59, deserializationContext63);
        boolean boolean65 = tokenBuffer64.canWriteBinaryNatively();
        tokenBuffer64.writeNumber((long) '#');
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
        org.junit.Assert.assertNotNull(jsonNode56);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.fasterxml.jackson.databind.ser.std.StdJdkSerializers.AtomicBooleanSerializer atomicBooleanSerializer0 = new com.fasterxml.jackson.databind.ser.std.StdJdkSerializers.AtomicBooleanSerializer();
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer1 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.concurrent.atomic.AtomicBoolean> atomicBooleanJsonSerializer2 = atomicBooleanSerializer0.unwrappingSerializer(nameTransformer1);
        java.util.concurrent.atomic.AtomicBoolean atomicBoolean3 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        tokenBuffer5.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = tokenBuffer5.setPrettyPrinter(prettyPrinter7);
        tokenBuffer5.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer12.writeNumber(bigDecimal26);
        tokenBuffer5.writeNumberField("hi!", bigDecimal26);
        com.fasterxml.jackson.databind.JavaType javaType29 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer31 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer32 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer33 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType29, false, typeSerializer31, objJsonSerializer32);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider34 = null;
        java.lang.reflect.Type type35 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode36 = objectArraySerializer33.getSchema(serializerProvider34, type35);
        com.fasterxml.jackson.databind.JsonNode jsonNode38 = jsonNode36.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser39 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode36);
        long long41 = treeTraversingParser39.nextLongValue((long) 100);
        java.lang.String str42 = treeTraversingParser39.getText();
        java.io.Writer writer43 = null;
        int int44 = treeTraversingParser39.releaseBuffered(writer43);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext45 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer46 = tokenBuffer5.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser39, deserializationContext45);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider47 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer48 = null;
        try {
            atomicBooleanSerializer0.serializeWithType(atomicBoolean3, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer46, serializerProvider47, typeSerializer48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(atomicBooleanJsonSerializer2);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(jsonNode36);
        org.junit.Assert.assertNotNull(jsonNode38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{" + "'", str42.equals("{"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer46);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = arrayNode14.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode17 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        tokenBuffer19.writeBoolean(true);
        tokenBuffer19.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken29 = tokenBuffer19.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        intNode17.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider30);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode32 = arrayNode15.add((com.fasterxml.jackson.databind.JsonNode) intNode17);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode34 = arrayNode15.findParent("");
        com.fasterxml.jackson.databind.node.ValueNode valueNode36 = arrayNode15.numberNode((java.lang.Byte) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(intNode17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertTrue("'" + jsonToken29 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken29.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode32);
        org.junit.Assert.assertNull(objectNode34);
        org.junit.Assert.assertNotNull(valueNode36);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer sqlTimeSerializer0 = new com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer();
        boolean boolean1 = sqlTimeSerializer0.isUnwrappingSerializer();
        boolean boolean2 = sqlTimeSerializer0.usesObjectId();
        java.sql.Time time3 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        tokenBuffer5.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = tokenBuffer5.setPrettyPrinter(prettyPrinter7);
        tokenBuffer5.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer12.writeNumber(bigDecimal26);
        tokenBuffer5.writeNumberField("hi!", bigDecimal26);
        com.fasterxml.jackson.databind.JavaType javaType29 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer31 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer32 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer33 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType29, false, typeSerializer31, objJsonSerializer32);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider34 = null;
        java.lang.reflect.Type type35 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode36 = objectArraySerializer33.getSchema(serializerProvider34, type35);
        com.fasterxml.jackson.databind.JsonNode jsonNode38 = jsonNode36.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser39 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode36);
        long long41 = treeTraversingParser39.nextLongValue((long) 100);
        java.lang.String str42 = treeTraversingParser39.getText();
        java.io.Writer writer43 = null;
        int int44 = treeTraversingParser39.releaseBuffered(writer43);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext45 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer46 = tokenBuffer5.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser39, deserializationContext45);
        tokenBuffer5.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec48 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer49 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec48);
        tokenBuffer49.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter51 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator52 = tokenBuffer49.setPrettyPrinter(prettyPrinter51);
        tokenBuffer49.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec55 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer56 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec55);
        com.fasterxml.jackson.databind.JavaType javaType57 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer59 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer60 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer61 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType57, false, typeSerializer59, objJsonSerializer60);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider62 = null;
        java.lang.reflect.Type type63 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode64 = objectArraySerializer61.getSchema(serializerProvider62, type63);
        java.math.BigInteger bigInteger65 = jsonNode64.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode66 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger65);
        short short67 = bigIntegerNode66.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode69 = bigIntegerNode66.get(100);
        java.math.BigDecimal bigDecimal70 = bigIntegerNode66.decimalValue();
        tokenBuffer56.writeNumber(bigDecimal70);
        tokenBuffer49.writeNumberField("hi!", bigDecimal70);
        com.fasterxml.jackson.databind.JavaType javaType73 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer75 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer76 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer77 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType73, false, typeSerializer75, objJsonSerializer76);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider78 = null;
        java.lang.reflect.Type type79 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode80 = objectArraySerializer77.getSchema(serializerProvider78, type79);
        com.fasterxml.jackson.databind.JsonNode jsonNode82 = jsonNode80.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser83 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode80);
        long long85 = treeTraversingParser83.nextLongValue((long) 100);
        java.lang.String str86 = treeTraversingParser83.getText();
        java.io.Writer writer87 = null;
        int int88 = treeTraversingParser83.releaseBuffered(writer87);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext89 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer90 = tokenBuffer49.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser83, deserializationContext89);
        tokenBuffer49.writeNull();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer92 = tokenBuffer5.append(tokenBuffer49);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator94 = tokenBuffer5.setHighestNonEscapedChar((int) ' ');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider95 = null;
        try {
            sqlTimeSerializer0.serialize(time3, jsonGenerator94, serializerProvider95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(jsonNode36);
        org.junit.Assert.assertNotNull(jsonNode38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 100L + "'", long41 == 100L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{" + "'", str42.equals("{"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer46);
        org.junit.Assert.assertNotNull(jsonGenerator52);
        org.junit.Assert.assertNotNull(jsonNode64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigIntegerNode66);
        org.junit.Assert.assertTrue("'" + short67 + "' != '" + (short) 0 + "'", short67 == (short) 0);
        org.junit.Assert.assertNull(jsonNode69);
        org.junit.Assert.assertNotNull(bigDecimal70);
        org.junit.Assert.assertNotNull(jsonNode80);
        org.junit.Assert.assertNotNull(jsonNode82);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 100L + "'", long85 == 100L);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "{" + "'", str86.equals("{"));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer90);
        org.junit.Assert.assertNotNull(tokenBuffer92);
        org.junit.Assert.assertNotNull(jsonGenerator94);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.InjectableValues injectableValues6 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper7 = objectMapper1.setInjectableValues(injectableValues6);
        java.io.File file8 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory9 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper10 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory9);
        java.lang.String str12 = objectMapper10.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider13 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper14 = objectMapper10.setSerializerProvider(defaultSerializerProvider13);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = objectMapper14.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode17 = arrayNode15.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode20 = arrayNode15.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode23 = arrayNode15.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode24 = arrayNode23.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode26 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec27 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer28 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec27);
        tokenBuffer28.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer28.setPrettyPrinter(prettyPrinter30);
        tokenBuffer28.writeNull();
        tokenBuffer28.writeBoolean(true);
        tokenBuffer28.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken38 = tokenBuffer28.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider39 = null;
        intNode26.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer28, serializerProvider39);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode41 = arrayNode24.add((com.fasterxml.jackson.databind.JsonNode) intNode26);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode43 = arrayNode24.findParent("");
        try {
            objectMapper1.writeValue(file8, (java.lang.Object) objectNode43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(objectMapper7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(objectNode17);
        org.junit.Assert.assertNotNull(arrayNode20);
        org.junit.Assert.assertNotNull(arrayNode23);
        org.junit.Assert.assertNotNull(arrayNode24);
        org.junit.Assert.assertNotNull(intNode26);
        org.junit.Assert.assertNotNull(jsonGenerator31);
        org.junit.Assert.assertTrue("'" + jsonToken38 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken38.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode41);
        org.junit.Assert.assertNull(objectNode43);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer1.setFeatureMask((int) (short) 100);
        com.fasterxml.jackson.databind.node.ShortNode shortNode11 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str12 = shortNode11.asText();
        boolean boolean13 = shortNode11.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        com.fasterxml.jackson.databind.JavaType javaType16 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer18 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer19 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer20 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType16, false, typeSerializer18, objJsonSerializer19);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider21 = null;
        java.lang.reflect.Type type22 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode23 = objectArraySerializer20.getSchema(serializerProvider21, type22);
        java.math.BigInteger bigInteger24 = jsonNode23.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode25 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger24);
        short short26 = bigIntegerNode25.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode28 = bigIntegerNode25.get(100);
        java.math.BigDecimal bigDecimal29 = bigIntegerNode25.decimalValue();
        tokenBuffer15.writeNumber(bigDecimal29);
        boolean boolean31 = shortNode11.equals((java.lang.Object) tokenBuffer15);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes32 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = tokenBuffer15.setCharacterEscapes(characterEscapes32);
        tokenBuffer1.writeTypeId((java.lang.Object) tokenBuffer15);
        boolean boolean35 = tokenBuffer15.canOmitFields();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(jsonNode23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigIntegerNode25);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNull(jsonNode28);
        org.junit.Assert.assertNotNull(bigDecimal29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.databind.JsonNode jsonNode5 = objectReader3.createObjectNode();
        com.fasterxml.jackson.databind.deser.DeserializationProblemHandler deserializationProblemHandler6 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader7 = objectReader3.withHandler(deserializationProblemHandler6);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer((com.fasterxml.jackson.core.ObjectCodec) objectReader3);
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonNode5);
        org.junit.Assert.assertNotNull(objectReader7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        boolean boolean4 = dateSerializer3.isUnwrappingSerializer();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        com.fasterxml.jackson.databind.deser.UnresolvedForwardReference unresolvedForwardReference7 = new com.fasterxml.jackson.databind.deser.UnresolvedForwardReference("\"com.fasterxml.jackson.databind.node.BigIntegerNode\"");
        java.util.List<com.fasterxml.jackson.databind.deser.UnresolvedId> unresolvedIdList8 = unresolvedForwardReference7.getUnresolvedIds();
        java.util.List<com.fasterxml.jackson.databind.deser.UnresolvedId> unresolvedIdList9 = unresolvedForwardReference7.getUnresolvedIds();
        com.fasterxml.jackson.databind.deser.impl.ReadableObjectId readableObjectId10 = unresolvedForwardReference7.getRoid();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        com.fasterxml.jackson.core.Base64Variant base64Variant16 = null;
        byte[] byteArray17 = new byte[] {};
        tokenBuffer12.writeBinary(base64Variant16, byteArray17, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode23 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray17, (int) (short) 0, 0);
        try {
            dateSerializer3.wrapAndThrow(serializerProvider5, (java.lang.Throwable) unresolvedForwardReference7, (java.lang.Object) byteArray17, "[TokenBuffer: VALUE_NUMBER_FLOAT]");
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.deser.UnresolvedForwardReference; message: \"com.fasterxml.jackson.databind.node.BigIntegerNode\" (through reference chain: byte[][\"[TokenBuffer: VALUE_NUMBER_FLOAT]\"]).");
        } catch (com.fasterxml.jackson.databind.deser.UnresolvedForwardReference e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(unresolvedIdList8);
        org.junit.Assert.assertNotNull(unresolvedIdList9);
        org.junit.Assert.assertNull(readableObjectId10);
        org.junit.Assert.assertNotNull(jsonGenerator15);
        org.junit.Assert.assertNotNull(byteArray17);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray17), "[]");
        org.junit.Assert.assertNotNull(binaryNode23);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeStartArray();
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        java.lang.String str16 = com.fasterxml.jackson.databind.util.ClassUtil.getClassDescription((java.lang.Object) bigIntegerNode15);
        com.fasterxml.jackson.core.JsonToken jsonToken17 = bigIntegerNode15.asToken();
        boolean boolean19 = bigIntegerNode15.has("");
        java.math.BigInteger bigInteger20 = bigIntegerNode15.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger20);
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "com.fasterxml.jackson.databind.node.BigIntegerNode" + "'", str16.equals("com.fasterxml.jackson.databind.node.BigIntegerNode"));
        org.junit.Assert.assertTrue("'" + jsonToken17 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT + "'", jsonToken17.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.json.JsonWriteContext jsonWriteContext24 = tokenBuffer5.getOutputContext();
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        java.math.BigInteger bigInteger33 = jsonNode32.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode34 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger33);
        short short35 = bigIntegerNode34.shortValue();
        boolean boolean37 = bigIntegerNode34.hasNonNull(0);
        tokenBuffer5.writeObject((java.lang.Object) bigIntegerNode34);
        com.fasterxml.jackson.databind.JsonNode jsonNode40 = bigIntegerNode34.findPath("[parameter #10, annotations: null]");
        float float41 = bigIntegerNode34.floatValue();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonWriteContext24);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigIntegerNode34);
        org.junit.Assert.assertTrue("'" + short35 + "' != '" + (short) 0 + "'", short35 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(jsonNode40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        com.fasterxml.jackson.core.JsonParser jsonParser36 = tokenBuffer1.asParser((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35);
        try {
            int int37 = treeTraversingParser35.getTextLength();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(jsonParser36);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType44 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer46 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer47 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer48 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType44, false, typeSerializer46, objJsonSerializer47);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider49 = null;
        java.lang.reflect.Type type50 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = objectArraySerializer48.getSchema(serializerProvider49, type50);
        java.math.BigInteger bigInteger52 = jsonNode51.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode53 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger52);
        short short54 = bigIntegerNode53.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = bigIntegerNode53.get(100);
        java.math.BigDecimal bigDecimal57 = bigIntegerNode53.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode58 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal57);
        boolean boolean59 = decimalNode58.canConvertToLong();
        java.math.BigInteger bigInteger60 = decimalNode58.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken61 = decimalNode58.asToken();
        float float62 = decimalNode58.floatValue();
        tokenBuffer1.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode58);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList65 = null;
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList66 = decimalNode58.findParents("java.lang.Integer", jsonNodeList65);
        com.fasterxml.jackson.databind.node.ShortNode shortNode68 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        com.fasterxml.jackson.core.ObjectCodec objectCodec69 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer70 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec69);
        tokenBuffer70.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter72 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator73 = tokenBuffer70.setPrettyPrinter(prettyPrinter72);
        tokenBuffer70.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes75 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator76 = tokenBuffer70.setCharacterEscapes(characterEscapes75);
        com.fasterxml.jackson.core.ObjectCodec objectCodec77 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator78 = tokenBuffer70.setCodec(objectCodec77);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider79 = null;
        shortNode68.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer70, serializerProvider79);
        boolean boolean81 = decimalNode58.equals((java.lang.Object) tokenBuffer70);
        double double82 = decimalNode58.doubleValue();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonNode51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigIntegerNode53);
        org.junit.Assert.assertTrue("'" + short54 + "' != '" + (short) 0 + "'", short54 == (short) 0);
        org.junit.Assert.assertNull(jsonNode56);
        org.junit.Assert.assertNotNull(bigDecimal57);
        org.junit.Assert.assertNotNull(decimalNode58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertTrue("'" + jsonToken61 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken61.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNull(jsonNodeList66);
        org.junit.Assert.assertNotNull(jsonGenerator73);
        org.junit.Assert.assertNotNull(jsonGenerator76);
        org.junit.Assert.assertNotNull(jsonGenerator78);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType49 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer51 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer52 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer53 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType49, false, typeSerializer51, objJsonSerializer52);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider54 = null;
        java.lang.reflect.Type type55 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = objectArraySerializer53.getSchema(serializerProvider54, type55);
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = jsonNode56.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser59 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode56);
        long long61 = treeTraversingParser59.nextLongValue((long) 100);
        int int62 = treeTraversingParser59.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext63 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer64 = tokenBuffer7.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser59, deserializationContext63);
        tokenBuffer64.writeNullField("enum");
        com.fasterxml.jackson.core.ObjectCodec objectCodec67 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer68 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec67);
        tokenBuffer68.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter70 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator71 = tokenBuffer68.setPrettyPrinter(prettyPrinter70);
        tokenBuffer68.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator74 = tokenBuffer68.setFeatureMask((int) '4');
        tokenBuffer68.writeNumber((short) (byte) 0);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer77 = tokenBuffer64.append(tokenBuffer68);
        com.fasterxml.jackson.core.JsonFactory jsonFactory78 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper79 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory78);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes80 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader81 = objectMapper79.reader(contextAttributes80);
        com.fasterxml.jackson.databind.JsonNode jsonNode82 = objectReader81.createArrayNode();
        com.fasterxml.jackson.core.JsonFactory jsonFactory83 = objectReader81.getJsonFactory();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator84 = null;
        com.fasterxml.jackson.core.JsonFactory jsonFactory85 = jsonFactory83.setInputDecorator(inputDecorator84);
        java.io.OutputStream outputStream86 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator87 = jsonFactory85.createGenerator(outputStream86);
        byte[] byteArray92 = new byte[] { (byte) 10, (byte) -1, (byte) 100, (byte) 10 };
        jsonGenerator87.writeBinary(byteArray92, (int) (short) 100, 0);
        tokenBuffer68.writeBinary(byteArray92);
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
        org.junit.Assert.assertNotNull(jsonNode56);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer64);
        org.junit.Assert.assertNotNull(jsonGenerator71);
        org.junit.Assert.assertNotNull(jsonGenerator74);
        org.junit.Assert.assertNotNull(tokenBuffer77);
        org.junit.Assert.assertNotNull(objectReader81);
        org.junit.Assert.assertNotNull(jsonNode82);
        org.junit.Assert.assertNotNull(jsonFactory83);
        org.junit.Assert.assertNotNull(jsonFactory85);
        org.junit.Assert.assertNotNull(jsonGenerator87);
        org.junit.Assert.assertNotNull(byteArray92);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray92), "[10, -1, 100, 10]");
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        java.lang.Class<java.util.Date> dateClass4 = dateSerializer3.handledType();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer10 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        dateFormat9.setLenient(false);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer13 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer14 = dateSerializer3.withFormat((java.lang.Boolean) false, dateFormat9);
        boolean boolean15 = dateSerializer14.isUnwrappingSerializer();
        java.util.Date date16 = null;
        com.fasterxml.jackson.databind.node.ShortNode shortNode18 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str19 = shortNode18.asText();
        boolean boolean20 = shortNode18.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec21 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer22 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec21);
        com.fasterxml.jackson.databind.JavaType javaType23 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer26 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer27 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType23, false, typeSerializer25, objJsonSerializer26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        java.lang.reflect.Type type29 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = objectArraySerializer27.getSchema(serializerProvider28, type29);
        java.math.BigInteger bigInteger31 = jsonNode30.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode32 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger31);
        short short33 = bigIntegerNode32.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = bigIntegerNode32.get(100);
        java.math.BigDecimal bigDecimal36 = bigIntegerNode32.decimalValue();
        tokenBuffer22.writeNumber(bigDecimal36);
        boolean boolean38 = shortNode18.equals((java.lang.Object) tokenBuffer22);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes39 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator40 = tokenBuffer22.setCharacterEscapes(characterEscapes39);
        com.fasterxml.jackson.core.json.JsonWriteContext jsonWriteContext41 = tokenBuffer22.getOutputContext();
        com.fasterxml.jackson.databind.JavaType javaType42 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer44 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer45 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer46 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType42, false, typeSerializer44, objJsonSerializer45);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider47 = null;
        java.lang.reflect.Type type48 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode49 = objectArraySerializer46.getSchema(serializerProvider47, type48);
        java.math.BigInteger bigInteger50 = jsonNode49.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode51 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger50);
        short short52 = bigIntegerNode51.shortValue();
        boolean boolean54 = bigIntegerNode51.hasNonNull(0);
        tokenBuffer22.writeObject((java.lang.Object) bigIntegerNode51);
        tokenBuffer22.writeFieldName("com.fasterxml.jackson.databind.MapperFeature");
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider58 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer59 = null;
        try {
            dateSerializer14.serializeWithType(date16, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer22, serializerProvider58, typeSerializer59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateClass4);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateSerializer14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigIntegerNode32);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigDecimal36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jsonGenerator40);
        org.junit.Assert.assertNotNull(jsonWriteContext41);
        org.junit.Assert.assertNotNull(jsonNode49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigIntegerNode51);
        org.junit.Assert.assertTrue("'" + short52 + "' != '" + (short) 0 + "'", short52 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.fasterxml.jackson.databind.node.TextNode textNode1 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        tokenBuffer3.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer3.setCharacterEscapes(characterEscapes8);
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer3.setCodec(objectCodec10);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider12 = null;
        textNode1.serialize(jsonGenerator11, serializerProvider12);
        com.fasterxml.jackson.core.JsonToken jsonToken14 = textNode1.asToken();
        java.util.Iterator<java.lang.String> strItor15 = textNode1.fieldNames();
        java.lang.String str17 = textNode1.asText("[map type; class java.lang.Object, [simple type, class com.fasterxml.jackson.databind.MapperFeature] -> [simple type, class java.util.concurrent.atomic.AtomicBoolean]]");
        org.junit.Assert.assertNotNull(textNode1);
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertTrue("'" + jsonToken14 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_STRING + "'", jsonToken14.equals(com.fasterxml.jackson.core.JsonToken.VALUE_STRING));
        org.junit.Assert.assertNotNull(strItor15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "com.fasterxml.jackson.databind.node.BigIntegerNode" + "'", str17.equals("com.fasterxml.jackson.databind.node.BigIntegerNode"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = arrayNode14.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode17 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        tokenBuffer19.writeBoolean(true);
        tokenBuffer19.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken29 = tokenBuffer19.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        intNode17.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider30);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode32 = arrayNode15.add((com.fasterxml.jackson.databind.JsonNode) intNode17);
        com.fasterxml.jackson.databind.JavaType javaType34 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer36 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer37 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer38 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType34, false, typeSerializer36, objJsonSerializer37);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider39 = null;
        java.lang.reflect.Type type40 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode41 = objectArraySerializer38.getSchema(serializerProvider39, type40);
        java.math.BigInteger bigInteger42 = jsonNode41.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode43 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger42);
        short short44 = bigIntegerNode43.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode46 = bigIntegerNode43.get(100);
        java.math.BigDecimal bigDecimal47 = bigIntegerNode43.decimalValue();
        boolean boolean49 = bigIntegerNode43.asBoolean(true);
        int int51 = bigIntegerNode43.asInt((int) (byte) 100);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode54 = com.fasterxml.jackson.databind.node.BooleanNode.valueOf(true);
        double double56 = booleanNode54.asDouble((double) (short) 10);
        java.lang.String str58 = booleanNode54.asText("hi!");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList60 = booleanNode54.findValues("");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList61 = bigIntegerNode43.findValues("hi!", jsonNodeList60);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList62 = arrayNode15.findValues("com.fasterxml.jackson.databind.JsonMappingException:  (through reference chain: java.lang.Boolean[\"hi!\"])", jsonNodeList60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(intNode17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertTrue("'" + jsonToken29 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken29.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode32);
        org.junit.Assert.assertNotNull(jsonNode41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigIntegerNode43);
        org.junit.Assert.assertTrue("'" + short44 + "' != '" + (short) 0 + "'", short44 == (short) 0);
        org.junit.Assert.assertNull(jsonNode46);
        org.junit.Assert.assertNotNull(bigDecimal47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(booleanNode54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "true" + "'", str58.equals("true"));
        org.junit.Assert.assertNotNull(jsonNodeList60);
        org.junit.Assert.assertNotNull(jsonNodeList61);
        org.junit.Assert.assertNotNull(jsonNodeList62);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer sqlTimeSerializer0 = new com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider1 = null;
        java.lang.reflect.Type type2 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = sqlTimeSerializer0.getSchema(serializerProvider1, type2, false);
        java.sql.Time time5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes12 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator13 = tokenBuffer7.setCharacterEscapes(characterEscapes12);
        tokenBuffer7.writeObjectFieldStart("");
        java.lang.String str16 = tokenBuffer7.toString();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer18 = null;
        try {
            sqlTimeSerializer0.serializeWithType(time5, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7, serializerProvider17, typeSerializer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonGenerator13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[TokenBuffer: VALUE_NULL, FIELD_NAME(), START_OBJECT]" + "'", str16.equals("[TokenBuffer: VALUE_NULL, FIELD_NAME(), START_OBJECT]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        boolean boolean15 = bigIntegerNode9.asBoolean(true);
        boolean boolean16 = bigIntegerNode9.isValueNode();
        boolean boolean17 = bigIntegerNode9.canConvertToInt();
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        tokenBuffer19.writeNumberField("", 100L);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        bigIntegerNode9.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider24);
        tokenBuffer19.writeFieldName("com.fasterxml.jackson.databind.MapperFeature<java.lang.Object>");
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.ObjectCodec objectCodec5 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer6 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec5);
        tokenBuffer6.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer6.setPrettyPrinter(prettyPrinter8);
        tokenBuffer6.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes11 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = tokenBuffer6.setCharacterEscapes(characterEscapes11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer6.writeNumber(bigDecimal26);
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode28 = new com.fasterxml.jackson.databind.node.DecimalNode(bigDecimal26);
        tokenBuffer1.writeNumber(bigDecimal26);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes30 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator31 = tokenBuffer1.setCharacterEscapes(characterEscapes30);
        char[] charArray32 = null;
        try {
            tokenBuffer1.writeRawValue(charArray32, 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator12);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertNotNull(jsonGenerator31);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.Base64Variant base64Variant5 = null;
        byte[] byteArray6 = new byte[] {};
        tokenBuffer1.writeBinary(base64Variant5, byteArray6, 0, (int) (byte) 0);
        int int10 = tokenBuffer1.getFeatureMask();
        com.fasterxml.jackson.core.Base64Variant base64Variant11 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec12 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer13 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec12);
        tokenBuffer13.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter15 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator16 = tokenBuffer13.setPrettyPrinter(prettyPrinter15);
        com.fasterxml.jackson.core.Base64Variant base64Variant17 = null;
        byte[] byteArray18 = new byte[] {};
        tokenBuffer13.writeBinary(base64Variant17, byteArray18, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode24 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray18, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType25 = binaryNode24.getNodeType();
        byte[] byteArray26 = binaryNode24.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode27 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray26);
        try {
            tokenBuffer1.writeBinary(base64Variant11, byteArray26, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[]");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 79 + "'", int10 == 79);
        org.junit.Assert.assertNotNull(jsonGenerator16);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray18), "[]");
        org.junit.Assert.assertNotNull(binaryNode24);
        org.junit.Assert.assertTrue("'" + jsonNodeType25 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType25.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray26), "[]");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str2 = shortNode1.asText();
        boolean boolean3 = shortNode1.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec4 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer5 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec4);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        tokenBuffer5.writeNumber(bigDecimal19);
        boolean boolean21 = shortNode1.equals((java.lang.Object) tokenBuffer5);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer5.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.json.JsonWriteContext jsonWriteContext24 = tokenBuffer5.getOutputContext();
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        java.math.BigInteger bigInteger33 = jsonNode32.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode34 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger33);
        short short35 = bigIntegerNode34.shortValue();
        boolean boolean37 = bigIntegerNode34.hasNonNull(0);
        tokenBuffer5.writeObject((java.lang.Object) bigIntegerNode34);
        com.fasterxml.jackson.core.JsonFactory jsonFactory39 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper40 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory39);
        java.lang.String str42 = objectMapper40.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider43 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper44 = objectMapper40.setSerializerProvider(defaultSerializerProvider43);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode45 = objectMapper44.createArrayNode();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode48 = arrayNode45.insert(16401, "hi!");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode50 = arrayNode48.add((-1));
        tokenBuffer5.writeTree((com.fasterxml.jackson.core.TreeNode) arrayNode50);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10" + "'", str2.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonWriteContext24);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigIntegerNode34);
        org.junit.Assert.assertTrue("'" + short35 + "' != '" + (short) 0 + "'", short35 == (short) 0);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper44);
        org.junit.Assert.assertNotNull(arrayNode45);
        org.junit.Assert.assertNotNull(arrayNode48);
        org.junit.Assert.assertNotNull(arrayNode50);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode1 = com.fasterxml.jackson.databind.node.BooleanNode.valueOf(true);
        boolean boolean3 = booleanNode1.has("");
        boolean boolean5 = booleanNode1.has("java.lang.Integer");
        boolean boolean6 = booleanNode1.isInt();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        tokenBuffer8.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer8.setPrettyPrinter(prettyPrinter10);
        com.fasterxml.jackson.core.Base64Variant base64Variant12 = null;
        byte[] byteArray13 = new byte[] {};
        tokenBuffer8.writeBinary(base64Variant12, byteArray13, 0, (int) (byte) 0);
        int int17 = tokenBuffer8.getFeatureMask();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        booleanNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer8, serializerProvider18);
        boolean boolean20 = tokenBuffer8.canOmitFields();
        org.junit.Assert.assertNotNull(booleanNode1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray13), "[]");
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 79 + "'", int17 == 79);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        com.fasterxml.jackson.databind.JsonSerializer<?> wildcardJsonSerializer4 = dateSerializer3.getDelegatee();
        java.util.Date date5 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        com.fasterxml.jackson.databind.JavaType javaType31 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer33 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer34 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer35 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType31, false, typeSerializer33, objJsonSerializer34);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider36 = null;
        java.lang.reflect.Type type37 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode38 = objectArraySerializer35.getSchema(serializerProvider36, type37);
        com.fasterxml.jackson.databind.JsonNode jsonNode40 = jsonNode38.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser41 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode38);
        long long43 = treeTraversingParser41.nextLongValue((long) 100);
        java.lang.String str44 = treeTraversingParser41.getText();
        java.io.Writer writer45 = null;
        int int46 = treeTraversingParser41.releaseBuffered(writer45);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext47 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer48 = tokenBuffer7.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser41, deserializationContext47);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType50 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer52 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer53 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer54 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType50, false, typeSerializer52, objJsonSerializer53);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider55 = null;
        java.lang.reflect.Type type56 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode57 = objectArraySerializer54.getSchema(serializerProvider55, type56);
        java.math.BigInteger bigInteger58 = jsonNode57.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode59 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger58);
        short short60 = bigIntegerNode59.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode62 = bigIntegerNode59.get(100);
        java.math.BigDecimal bigDecimal63 = bigIntegerNode59.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode64 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal63);
        boolean boolean65 = decimalNode64.canConvertToLong();
        java.math.BigInteger bigInteger66 = decimalNode64.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken67 = decimalNode64.asToken();
        float float68 = decimalNode64.floatValue();
        tokenBuffer7.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode64);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator71 = tokenBuffer7.setFeatureMask((int) ' ');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider72 = null;
        dateSerializer3.serialize(date5, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7, serializerProvider72);
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer74 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Date> dateJsonSerializer75 = dateSerializer3.unwrappingSerializer(nameTransformer74);
        boolean boolean76 = dateJsonSerializer75.isUnwrappingSerializer();
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNull(wildcardJsonSerializer4);
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertNotNull(jsonNode38);
        org.junit.Assert.assertNotNull(jsonNode40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 100L + "'", long43 == 100L);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{" + "'", str44.equals("{"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer48);
        org.junit.Assert.assertNotNull(jsonNode57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigIntegerNode59);
        org.junit.Assert.assertTrue("'" + short60 + "' != '" + (short) 0 + "'", short60 == (short) 0);
        org.junit.Assert.assertNull(jsonNode62);
        org.junit.Assert.assertNotNull(bigDecimal63);
        org.junit.Assert.assertNotNull(decimalNode64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertTrue("'" + jsonToken67 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken67.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float68 + "' != '" + 0.0f + "'", float68 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator71);
        org.junit.Assert.assertNotNull(dateJsonSerializer75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty3 = null;
        com.fasterxml.jackson.databind.JavaType javaType4 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer6 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer7 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer8 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType4, false, typeSerializer6, objJsonSerializer7);
        com.fasterxml.jackson.databind.BeanProperty beanProperty9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer10 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Map<?, ?>> wildcardMapJsonSerializer11 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer12 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(objectArraySerializer8, beanProperty9, typeSerializer10, wildcardMapJsonSerializer11);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer13 = null;
        com.fasterxml.jackson.databind.ser.ContainerSerializer<?> wildcardContainerSerializer14 = objectArraySerializer8.withValueTypeSerializer(typeSerializer13);
        com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer indexedListSerializer15 = new com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer(javaType0, false, typeSerializer2, beanProperty3, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer14);
        com.fasterxml.jackson.databind.Module[] moduleArray16 = new com.fasterxml.jackson.databind.Module[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.Module> moduleList17 = new java.util.ArrayList<com.fasterxml.jackson.databind.Module>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.Module>) moduleList17, moduleArray16);
        com.fasterxml.jackson.databind.JavaType javaType19 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer21 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer22 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer23 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType19, false, typeSerializer21, objJsonSerializer22);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        java.lang.reflect.Type type25 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode26 = objectArraySerializer23.getSchema(serializerProvider24, type25);
        java.math.BigInteger bigInteger27 = jsonNode26.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode28 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger27);
        short short29 = bigIntegerNode28.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode31 = bigIntegerNode28.get(100);
        java.math.BigDecimal bigDecimal32 = bigIntegerNode28.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode33 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal32);
        boolean boolean34 = decimalNode33.canConvertToLong();
        java.math.BigInteger bigInteger35 = decimalNode33.bigIntegerValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec36 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer37 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec36);
        tokenBuffer37.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter39 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator40 = tokenBuffer37.setPrettyPrinter(prettyPrinter39);
        tokenBuffer37.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes42 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator43 = tokenBuffer37.setCharacterEscapes(characterEscapes42);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        decimalNode33.serialize(jsonGenerator43, serializerProvider44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        com.fasterxml.jackson.databind.JavaType javaType47 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer49 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty50 = null;
        com.fasterxml.jackson.databind.JavaType javaType51 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer53 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer54 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer55 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType51, false, typeSerializer53, objJsonSerializer54);
        com.fasterxml.jackson.databind.BeanProperty beanProperty56 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer57 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Map<?, ?>> wildcardMapJsonSerializer58 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer59 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(objectArraySerializer55, beanProperty56, typeSerializer57, wildcardMapJsonSerializer58);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer60 = null;
        com.fasterxml.jackson.databind.ser.ContainerSerializer<?> wildcardContainerSerializer61 = objectArraySerializer55.withValueTypeSerializer(typeSerializer60);
        com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer indexedListSerializer62 = new com.fasterxml.jackson.databind.ser.impl.IndexedListSerializer(javaType47, false, typeSerializer49, beanProperty50, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer61);
        indexedListSerializer15.serializeContentsUsing((java.util.List<com.fasterxml.jackson.databind.Module>) moduleList17, jsonGenerator43, serializerProvider46, (com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object>) wildcardContainerSerializer61);
        com.fasterxml.jackson.databind.Module[] moduleArray64 = new com.fasterxml.jackson.databind.Module[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.Module> moduleList65 = new java.util.ArrayList<com.fasterxml.jackson.databind.Module>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.Module>) moduleList65, moduleArray64);
        boolean boolean67 = indexedListSerializer15.hasSingleElement((java.util.List<com.fasterxml.jackson.databind.Module>) moduleList65);
        org.junit.Assert.assertNotNull(wildcardContainerSerializer14);
        org.junit.Assert.assertNotNull(moduleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jsonNode26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigIntegerNode28);
        org.junit.Assert.assertTrue("'" + short29 + "' != '" + (short) 0 + "'", short29 == (short) 0);
        org.junit.Assert.assertNull(jsonNode31);
        org.junit.Assert.assertNotNull(bigDecimal32);
        org.junit.Assert.assertNotNull(decimalNode33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(jsonGenerator40);
        org.junit.Assert.assertNotNull(jsonGenerator43);
        org.junit.Assert.assertNotNull(wildcardContainerSerializer61);
        org.junit.Assert.assertNotNull(moduleArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.fasterxml.jackson.databind.node.LongNode longNode1 = new com.fasterxml.jackson.databind.node.LongNode((long) (byte) 0);
        boolean boolean3 = longNode1.asBoolean(false);
        short short4 = longNode1.shortValue();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType5 = longNode1.numberType();
        float float6 = longNode1.floatValue();
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper9 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory8);
        java.lang.String str11 = objectMapper9.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider12 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper13 = objectMapper9.setSerializerProvider(defaultSerializerProvider12);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = objectMapper13.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode16 = arrayNode14.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode19 = arrayNode14.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode22 = arrayNode14.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode23 = arrayNode22.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode25 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec26 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer27 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec26);
        tokenBuffer27.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter29 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer27.setPrettyPrinter(prettyPrinter29);
        tokenBuffer27.writeNull();
        tokenBuffer27.writeBoolean(true);
        tokenBuffer27.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken37 = tokenBuffer27.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider38 = null;
        intNode25.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer27, serializerProvider38);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode40 = arrayNode23.add((com.fasterxml.jackson.databind.JsonNode) intNode25);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode42 = arrayNode23.findParent("");
        com.fasterxml.jackson.core.JsonFactory jsonFactory44 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper45 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory44);
        java.lang.String str47 = objectMapper45.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider48 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper49 = objectMapper45.setSerializerProvider(defaultSerializerProvider48);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode50 = objectMapper49.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode52 = arrayNode50.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode55 = arrayNode50.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode58 = arrayNode50.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.JsonNode jsonNode60 = arrayNode50.path("[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]");
        com.fasterxml.jackson.databind.JsonNode jsonNode62 = arrayNode50.findValue("[map type; class java.lang.Object, [simple type, class com.fasterxml.jackson.databind.MapperFeature] -> [simple type, class java.util.concurrent.atomic.AtomicBoolean]]");
        com.fasterxml.jackson.databind.JavaType javaType64 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer66 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer67 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer68 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType64, false, typeSerializer66, objJsonSerializer67);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider69 = null;
        java.lang.reflect.Type type70 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode71 = objectArraySerializer68.getSchema(serializerProvider69, type70);
        java.math.BigInteger bigInteger72 = jsonNode71.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode73 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger72);
        short short74 = bigIntegerNode73.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = bigIntegerNode73.get(100);
        java.math.BigDecimal bigDecimal77 = bigIntegerNode73.decimalValue();
        boolean boolean79 = bigIntegerNode73.asBoolean(true);
        int int81 = bigIntegerNode73.asInt((int) (byte) 100);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList83 = bigIntegerNode73.findValues("");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList84 = arrayNode50.findValues("hi!", jsonNodeList83);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList85 = arrayNode23.findValues("java.lang.Short[\"hi!\"]", jsonNodeList84);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList86 = longNode1.findParents("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]", jsonNodeList84);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 0 + "'", short4 == (short) 0);
        org.junit.Assert.assertTrue("'" + numberType5 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.LONG + "'", numberType5.equals(com.fasterxml.jackson.core.JsonParser.NumberType.LONG));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper13);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(objectNode16);
        org.junit.Assert.assertNotNull(arrayNode19);
        org.junit.Assert.assertNotNull(arrayNode22);
        org.junit.Assert.assertNotNull(arrayNode23);
        org.junit.Assert.assertNotNull(intNode25);
        org.junit.Assert.assertNotNull(jsonGenerator30);
        org.junit.Assert.assertTrue("'" + jsonToken37 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken37.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode40);
        org.junit.Assert.assertNull(objectNode42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper49);
        org.junit.Assert.assertNotNull(arrayNode50);
        org.junit.Assert.assertNotNull(objectNode52);
        org.junit.Assert.assertNotNull(arrayNode55);
        org.junit.Assert.assertNotNull(arrayNode58);
        org.junit.Assert.assertNotNull(jsonNode60);
        org.junit.Assert.assertNull(jsonNode62);
        org.junit.Assert.assertNotNull(jsonNode71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigIntegerNode73);
        org.junit.Assert.assertTrue("'" + short74 + "' != '" + (short) 0 + "'", short74 == (short) 0);
        org.junit.Assert.assertNull(jsonNode76);
        org.junit.Assert.assertNotNull(bigDecimal77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(jsonNodeList83);
        org.junit.Assert.assertNotNull(jsonNodeList84);
        org.junit.Assert.assertNotNull(jsonNodeList85);
        org.junit.Assert.assertNotNull(jsonNodeList86);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        java.lang.Class<java.util.Date> dateClass4 = dateSerializer3.handledType();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer10 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        dateFormat9.setLenient(false);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer13 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer14 = dateSerializer3.withFormat((java.lang.Boolean) false, dateFormat9);
        java.util.Date date15 = null;
        boolean boolean16 = dateSerializer14.isEmpty(date15);
        java.util.Date date17 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec25 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer26 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec25);
        com.fasterxml.jackson.databind.JavaType javaType27 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer29 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer30 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer31 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType27, false, typeSerializer29, objJsonSerializer30);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider32 = null;
        java.lang.reflect.Type type33 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = objectArraySerializer31.getSchema(serializerProvider32, type33);
        java.math.BigInteger bigInteger35 = jsonNode34.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode36 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger35);
        short short37 = bigIntegerNode36.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode39 = bigIntegerNode36.get(100);
        java.math.BigDecimal bigDecimal40 = bigIntegerNode36.decimalValue();
        tokenBuffer26.writeNumber(bigDecimal40);
        tokenBuffer19.writeNumberField("hi!", bigDecimal40);
        boolean boolean43 = tokenBuffer19.canWriteObjectId();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        try {
            dateSerializer14.serialize(date17, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateClass4);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateSerializer14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigIntegerNode36);
        org.junit.Assert.assertTrue("'" + short37 + "' != '" + (short) 0 + "'", short37 == (short) 0);
        org.junit.Assert.assertNull(jsonNode39);
        org.junit.Assert.assertNotNull(bigDecimal40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.fasterxml.jackson.databind.node.TextNode textNode1 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        tokenBuffer3.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes8 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator9 = tokenBuffer3.setCharacterEscapes(characterEscapes8);
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer3.setCodec(objectCodec10);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider12 = null;
        textNode1.serialize(jsonGenerator11, serializerProvider12);
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        tokenBuffer15.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter17 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator18 = tokenBuffer15.setPrettyPrinter(prettyPrinter17);
        tokenBuffer15.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec21 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer22 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec21);
        com.fasterxml.jackson.databind.JavaType javaType23 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer26 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer27 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType23, false, typeSerializer25, objJsonSerializer26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        java.lang.reflect.Type type29 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = objectArraySerializer27.getSchema(serializerProvider28, type29);
        java.math.BigInteger bigInteger31 = jsonNode30.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode32 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger31);
        short short33 = bigIntegerNode32.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = bigIntegerNode32.get(100);
        java.math.BigDecimal bigDecimal36 = bigIntegerNode32.decimalValue();
        tokenBuffer22.writeNumber(bigDecimal36);
        tokenBuffer15.writeNumberField("hi!", bigDecimal36);
        com.fasterxml.jackson.databind.JavaType javaType39 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer41 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer42 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer43 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType39, false, typeSerializer41, objJsonSerializer42);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        java.lang.reflect.Type type45 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode46 = objectArraySerializer43.getSchema(serializerProvider44, type45);
        com.fasterxml.jackson.databind.JsonNode jsonNode48 = jsonNode46.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser49 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode46);
        long long51 = treeTraversingParser49.nextLongValue((long) 100);
        java.lang.String str52 = treeTraversingParser49.getText();
        java.io.Writer writer53 = null;
        int int54 = treeTraversingParser49.releaseBuffered(writer53);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext55 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer56 = tokenBuffer15.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser49, deserializationContext55);
        boolean boolean57 = textNode1.equals((java.lang.Object) treeTraversingParser49);
        treeTraversingParser49.close();
        com.fasterxml.jackson.core.Version version59 = treeTraversingParser49.version();
        com.fasterxml.jackson.core.JsonParser.Feature feature60 = null;
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser61 = treeTraversingParser49.disable(feature60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textNode1);
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertNotNull(jsonGenerator9);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonGenerator18);
        org.junit.Assert.assertNotNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigIntegerNode32);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigDecimal36);
        org.junit.Assert.assertNotNull(jsonNode46);
        org.junit.Assert.assertNotNull(jsonNode48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{" + "'", str52.equals("{"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(version59);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        com.fasterxml.jackson.core.JsonFactory jsonFactory8 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper9 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory8);
        com.fasterxml.jackson.core.JsonFactory jsonFactory10 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper11 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory10);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes12 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader13 = objectMapper11.reader(contextAttributes12);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory14 = objectMapper11.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray15 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper16 = objectMapper11.enable(mapperFeatureArray15);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper17 = objectMapper9.enable(mapperFeatureArray15);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator25 = tokenBuffer19.setFeatureMask((int) '4');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider26 = null;
        objectArraySerializer4.serializeContents((java.lang.Object[]) mapperFeatureArray15, jsonGenerator25, serializerProvider26);
        boolean boolean28 = objectArraySerializer4.isUnwrappingSerializer();
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(objectReader13);
        org.junit.Assert.assertNotNull(typeFactory14);
        org.junit.Assert.assertNotNull(mapperFeatureArray15);
        org.junit.Assert.assertNotNull(objectMapper16);
        org.junit.Assert.assertNotNull(objectMapper17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertNotNull(jsonGenerator25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        java.lang.Class<java.util.Date> dateClass4 = dateSerializer3.handledType();
        java.text.DateFormat dateFormat9 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer10 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        dateFormat9.setLenient(false);
        com.fasterxml.jackson.databind.ser.std.CalendarSerializer calendarSerializer13 = new com.fasterxml.jackson.databind.ser.std.CalendarSerializer((java.lang.Boolean) true, dateFormat9);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer14 = dateSerializer3.withFormat((java.lang.Boolean) false, dateFormat9);
        java.util.Date date15 = null;
        boolean boolean16 = dateSerializer3.isEmpty(date15);
        java.util.Date date17 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        tokenBuffer19.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec24 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer25 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec24);
        tokenBuffer25.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter27 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator28 = tokenBuffer25.setPrettyPrinter(prettyPrinter27);
        tokenBuffer25.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec31 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer32 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec31);
        com.fasterxml.jackson.databind.JavaType javaType33 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer35 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer36 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer37 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType33, false, typeSerializer35, objJsonSerializer36);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider38 = null;
        java.lang.reflect.Type type39 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode40 = objectArraySerializer37.getSchema(serializerProvider38, type39);
        java.math.BigInteger bigInteger41 = jsonNode40.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode42 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger41);
        short short43 = bigIntegerNode42.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode45 = bigIntegerNode42.get(100);
        java.math.BigDecimal bigDecimal46 = bigIntegerNode42.decimalValue();
        tokenBuffer32.writeNumber(bigDecimal46);
        tokenBuffer25.writeNumberField("hi!", bigDecimal46);
        boolean boolean49 = tokenBuffer25.canWriteObjectId();
        tokenBuffer25.writeNullField("");
        tokenBuffer19.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer25);
        com.fasterxml.jackson.core.ObjectCodec objectCodec53 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer54 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec53);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter55 = tokenBuffer54.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser56 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException58 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser56, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference61 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException58.prependPath(reference61);
        tokenBuffer54.writeTypeId((java.lang.Object) reference61);
        reference61.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer25.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType67 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer69 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer70 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer71 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType67, false, typeSerializer69, objJsonSerializer70);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider72 = null;
        java.lang.reflect.Type type73 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode74 = objectArraySerializer71.getSchema(serializerProvider72, type73);
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = jsonNode74.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser77 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode74);
        long long79 = treeTraversingParser77.nextLongValue((long) 100);
        int int80 = treeTraversingParser77.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext81 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer82 = tokenBuffer25.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser77, deserializationContext81);
        com.fasterxml.jackson.core.Version version83 = tokenBuffer25.version();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider84 = null;
        dateSerializer3.serialize(date17, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer25, serializerProvider84);
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateClass4);
        org.junit.Assert.assertNotNull(dateFormat9);
        org.junit.Assert.assertNotNull(dateSerializer14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonGenerator28);
        org.junit.Assert.assertNotNull(jsonNode40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigIntegerNode42);
        org.junit.Assert.assertTrue("'" + short43 + "' != '" + (short) 0 + "'", short43 == (short) 0);
        org.junit.Assert.assertNull(jsonNode45);
        org.junit.Assert.assertNotNull(bigDecimal46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(prettyPrinter55);
        org.junit.Assert.assertNotNull(jsonMappingException58);
        org.junit.Assert.assertNotNull(jsonNode74);
        org.junit.Assert.assertNotNull(jsonNode76);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 100L + "'", long79 == 100L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer82);
        org.junit.Assert.assertNotNull(version83);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        boolean boolean25 = tokenBuffer1.canWriteObjectId();
        boolean boolean26 = tokenBuffer1.canWriteBinaryNatively();
        com.fasterxml.jackson.core.JsonFactory jsonFactory28 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper29 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory28);
        java.lang.String str31 = objectMapper29.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider32 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper33 = objectMapper29.setSerializerProvider(defaultSerializerProvider32);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode34 = objectMapper33.createArrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode36 = arrayNode34.numberNode((java.lang.Byte) (byte) 1);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode38 = arrayNode34.add((java.lang.Float) 0.0f);
        com.fasterxml.jackson.core.JsonFactory jsonFactory39 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper40 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory39);
        java.lang.String str42 = objectMapper40.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider43 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper44 = objectMapper40.setSerializerProvider(defaultSerializerProvider43);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode45 = objectMapper44.createArrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode47 = arrayNode45.numberNode((java.lang.Byte) (byte) 1);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode49 = arrayNode45.add((java.lang.Float) 0.0f);
        java.lang.String str50 = arrayNode49.asText();
        byte[] byteArray54 = new byte[] { (byte) -1, (byte) 1, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode55 = arrayNode49.binaryNode(byteArray54);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode56 = arrayNode38.add(byteArray54);
        tokenBuffer1.writeBinaryField("{{}com.fasterxml.jackson.databind.node.BigIntegerNode", byteArray54);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1" + "'", str31.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper33);
        org.junit.Assert.assertNotNull(arrayNode34);
        org.junit.Assert.assertNotNull(valueNode36);
        org.junit.Assert.assertNotNull(arrayNode38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1" + "'", str42.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper44);
        org.junit.Assert.assertNotNull(arrayNode45);
        org.junit.Assert.assertNotNull(valueNode47);
        org.junit.Assert.assertNotNull(arrayNode49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[-1, 1, -1]");
        org.junit.Assert.assertNotNull(binaryNode55);
        org.junit.Assert.assertNotNull(arrayNode56);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.databind.JavaType javaType6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer8 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer9 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer10 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType6, false, typeSerializer8, objJsonSerializer9);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider11 = null;
        java.lang.reflect.Type type12 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode13 = objectArraySerializer10.getSchema(serializerProvider11, type12);
        java.math.BigInteger bigInteger14 = jsonNode13.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode15 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger14);
        short short16 = bigIntegerNode15.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = bigIntegerNode15.get(100);
        java.math.BigDecimal bigDecimal19 = bigIntegerNode15.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode20 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal19);
        boolean boolean21 = decimalNode20.canConvertToLong();
        java.math.BigInteger bigInteger22 = decimalNode20.bigIntegerValue();
        tokenBuffer1.writeNumber(bigInteger22);
        tokenBuffer1.close();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter25 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator26 = tokenBuffer1.setPrettyPrinter(prettyPrinter25);
        org.junit.Assert.assertNotNull(jsonNode13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigIntegerNode15);
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigDecimal19);
        org.junit.Assert.assertNotNull(decimalNode20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(jsonGenerator26);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.text.DateFormat dateFormat1 = null;
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer2 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat1);
        java.text.DateFormat dateFormat4 = null;
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer5 = dateSerializer2.withFormat((java.lang.Boolean) true, dateFormat4);
        java.util.Date date6 = null;
        com.fasterxml.jackson.databind.node.ShortNode shortNode8 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str9 = shortNode8.asText();
        boolean boolean10 = shortNode8.isContainerNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        com.fasterxml.jackson.databind.JavaType javaType13 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer15 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer16 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer17 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType13, false, typeSerializer15, objJsonSerializer16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        java.lang.reflect.Type type19 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode20 = objectArraySerializer17.getSchema(serializerProvider18, type19);
        java.math.BigInteger bigInteger21 = jsonNode20.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode22 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger21);
        short short23 = bigIntegerNode22.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = bigIntegerNode22.get(100);
        java.math.BigDecimal bigDecimal26 = bigIntegerNode22.decimalValue();
        tokenBuffer12.writeNumber(bigDecimal26);
        boolean boolean28 = shortNode8.equals((java.lang.Object) tokenBuffer12);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes29 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer12.setCharacterEscapes(characterEscapes29);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider31 = null;
        dateSerializer2.serialize(date6, jsonGenerator30, serializerProvider31);
        com.fasterxml.jackson.databind.util.NameTransformer nameTransformer33 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.util.Date> dateJsonSerializer34 = dateSerializer2.unwrappingSerializer(nameTransformer33);
        org.junit.Assert.assertNotNull(dateSerializer5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jsonNode20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigIntegerNode22);
        org.junit.Assert.assertTrue("'" + short23 + "' != '" + (short) 0 + "'", short23 == (short) 0);
        org.junit.Assert.assertNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigDecimal26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jsonGenerator30);
        org.junit.Assert.assertNotNull(dateJsonSerializer34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode10 = new com.fasterxml.jackson.databind.node.BigIntegerNode(bigInteger8);
        float float11 = bigIntegerNode10.floatValue();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType12 = bigIntegerNode10.numberType();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer14.setPrettyPrinter(prettyPrinter16);
        tokenBuffer14.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        com.fasterxml.jackson.databind.JavaType javaType22 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer24 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer25 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer26 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType22, false, typeSerializer24, objJsonSerializer25);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider27 = null;
        java.lang.reflect.Type type28 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode29 = objectArraySerializer26.getSchema(serializerProvider27, type28);
        java.math.BigInteger bigInteger30 = jsonNode29.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode31 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger30);
        short short32 = bigIntegerNode31.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = bigIntegerNode31.get(100);
        java.math.BigDecimal bigDecimal35 = bigIntegerNode31.decimalValue();
        tokenBuffer21.writeNumber(bigDecimal35);
        tokenBuffer14.writeNumberField("hi!", bigDecimal35);
        com.fasterxml.jackson.databind.JavaType javaType38 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer40 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer41 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer42 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType38, false, typeSerializer40, objJsonSerializer41);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider43 = null;
        java.lang.reflect.Type type44 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode45 = objectArraySerializer42.getSchema(serializerProvider43, type44);
        com.fasterxml.jackson.databind.JsonNode jsonNode47 = jsonNode45.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser48 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode45);
        long long50 = treeTraversingParser48.nextLongValue((long) 100);
        java.lang.String str51 = treeTraversingParser48.getText();
        java.io.Writer writer52 = null;
        int int53 = treeTraversingParser48.releaseBuffered(writer52);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext54 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer55 = tokenBuffer14.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser48, deserializationContext54);
        tokenBuffer14.writeNull();
        tokenBuffer14.writeNullField("enum");
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider59 = null;
        bigIntegerNode10.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer14, serializerProvider59);
        try {
            tokenBuffer14.writeRawValue("com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException: Unrecognized field \"\" (class com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer), not marked as ignorable (5 known properties: \"-1\", \"false\", \"null\", \"0\", \"100.0\"])\n at [Source: N/A; line: -1, column: -1] (through reference chain: com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer[\"\"])", (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + numberType12 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER + "'", numberType12.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_INTEGER));
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertNotNull(jsonNode29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigIntegerNode31);
        org.junit.Assert.assertTrue("'" + short32 + "' != '" + (short) 0 + "'", short32 == (short) 0);
        org.junit.Assert.assertNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigDecimal35);
        org.junit.Assert.assertNotNull(jsonNode45);
        org.junit.Assert.assertNotNull(jsonNode47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{" + "'", str51.equals("{"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer55);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeNumber((short) 10);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes51 = tokenBuffer7.getCharacterEscapes();
        tokenBuffer7.writeObjectFieldStart("[array type, component type: [collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]]");
        com.fasterxml.jackson.core.JsonFactory jsonFactory54 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper55 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory54);
        java.lang.String str57 = objectMapper55.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider58 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper59 = objectMapper55.setSerializerProvider(defaultSerializerProvider58);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode60 = objectMapper59.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode62 = arrayNode60.insertObject((-1));
        com.fasterxml.jackson.core.JsonFactory jsonFactory63 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper64 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory63);
        java.lang.String str66 = objectMapper64.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider67 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper68 = objectMapper64.setSerializerProvider(defaultSerializerProvider67);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode69 = objectMapper68.createArrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode71 = arrayNode69.numberNode((java.lang.Byte) (byte) 1);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode73 = arrayNode69.add((java.lang.Float) 0.0f);
        java.lang.String str74 = arrayNode73.asText();
        byte[] byteArray78 = new byte[] { (byte) -1, (byte) 1, (byte) -1 };
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode79 = arrayNode73.binaryNode(byteArray78);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode82 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray78, 0, (int) (byte) 1);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode83 = objectNode62.binaryNode(byteArray78);
        try {
            tokenBuffer7.writeRawUTF8String(byteArray78, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Called operation not supported for TokenBuffer");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
        org.junit.Assert.assertNull(characterEscapes51);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "1" + "'", str57.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper59);
        org.junit.Assert.assertNotNull(arrayNode60);
        org.junit.Assert.assertNotNull(objectNode62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "1" + "'", str66.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper68);
        org.junit.Assert.assertNotNull(arrayNode69);
        org.junit.Assert.assertNotNull(valueNode71);
        org.junit.Assert.assertNotNull(arrayNode73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNotNull(byteArray78);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray78), "[-1, 1, -1]");
        org.junit.Assert.assertNotNull(binaryNode79);
        org.junit.Assert.assertNotNull(binaryNode83);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.NumericNode numericNode10 = objectNode8.numberNode((byte) 0);
        int int11 = objectNode8.size();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode13 = objectNode8.putArray("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.databind.node.ObjectNode objectNode14 = arrayNode13.objectNode();
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        tokenBuffer17.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter19 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator20 = tokenBuffer17.setPrettyPrinter(prettyPrinter19);
        com.fasterxml.jackson.core.Base64Variant base64Variant21 = null;
        byte[] byteArray22 = new byte[] {};
        tokenBuffer17.writeBinary(base64Variant21, byteArray22, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.JavaType javaType27 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer29 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer30 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer31 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType27, false, typeSerializer29, objJsonSerializer30);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider32 = null;
        java.lang.reflect.Type type33 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = objectArraySerializer31.getSchema(serializerProvider32, type33);
        java.math.BigInteger bigInteger35 = jsonNode34.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode36 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger35);
        short short37 = bigIntegerNode36.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode39 = bigIntegerNode36.get(100);
        java.math.BigDecimal bigDecimal40 = bigIntegerNode36.decimalValue();
        boolean boolean42 = bigIntegerNode36.asBoolean(true);
        int int44 = bigIntegerNode36.asInt((int) (byte) 100);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode47 = com.fasterxml.jackson.databind.node.BooleanNode.valueOf(true);
        double double49 = booleanNode47.asDouble((double) (short) 10);
        java.lang.String str51 = booleanNode47.asText("hi!");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList53 = booleanNode47.findValues("");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList54 = bigIntegerNode36.findValues("hi!", jsonNodeList53);
        float float55 = bigIntegerNode36.floatValue();
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType56 = bigIntegerNode36.getNodeType();
        java.math.BigDecimal bigDecimal57 = bigIntegerNode36.decimalValue();
        tokenBuffer17.writeNumberField("\"com.fasterxml.jackson.databind.node.BigIntegerNode\"", bigDecimal57);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode59 = arrayNode13.insert(4096, bigDecimal57);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(numericNode10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(arrayNode13);
        org.junit.Assert.assertNotNull(objectNode14);
        org.junit.Assert.assertNotNull(jsonGenerator20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[]");
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigIntegerNode36);
        org.junit.Assert.assertTrue("'" + short37 + "' != '" + (short) 0 + "'", short37 == (short) 0);
        org.junit.Assert.assertNull(jsonNode39);
        org.junit.Assert.assertNotNull(bigDecimal40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(booleanNode47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "true" + "'", str51.equals("true"));
        org.junit.Assert.assertNotNull(jsonNodeList53);
        org.junit.Assert.assertNotNull(jsonNodeList54);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 0.0f + "'", float55 == 0.0f);
        org.junit.Assert.assertTrue("'" + jsonNodeType56 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER + "'", jsonNodeType56.equals(com.fasterxml.jackson.databind.node.JsonNodeType.NUMBER));
        org.junit.Assert.assertNotNull(bigDecimal57);
        org.junit.Assert.assertNotNull(arrayNode59);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec44 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer45 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec44);
        tokenBuffer45.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter47 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator48 = tokenBuffer45.setPrettyPrinter(prettyPrinter47);
        tokenBuffer45.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec51 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer52 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec51);
        com.fasterxml.jackson.databind.JavaType javaType53 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer55 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer56 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer57 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType53, false, typeSerializer55, objJsonSerializer56);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider58 = null;
        java.lang.reflect.Type type59 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode60 = objectArraySerializer57.getSchema(serializerProvider58, type59);
        java.math.BigInteger bigInteger61 = jsonNode60.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode62 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger61);
        short short63 = bigIntegerNode62.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode65 = bigIntegerNode62.get(100);
        java.math.BigDecimal bigDecimal66 = bigIntegerNode62.decimalValue();
        tokenBuffer52.writeNumber(bigDecimal66);
        tokenBuffer45.writeNumberField("hi!", bigDecimal66);
        com.fasterxml.jackson.databind.JavaType javaType69 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer71 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer72 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer73 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType69, false, typeSerializer71, objJsonSerializer72);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider74 = null;
        java.lang.reflect.Type type75 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode76 = objectArraySerializer73.getSchema(serializerProvider74, type75);
        com.fasterxml.jackson.databind.JsonNode jsonNode78 = jsonNode76.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser79 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode76);
        long long81 = treeTraversingParser79.nextLongValue((long) 100);
        java.lang.String str82 = treeTraversingParser79.getText();
        java.io.Writer writer83 = null;
        int int84 = treeTraversingParser79.releaseBuffered(writer83);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext85 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer86 = tokenBuffer45.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser79, deserializationContext85);
        tokenBuffer45.writeNull();
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer88 = tokenBuffer1.append(tokenBuffer45);
        com.fasterxml.jackson.core.JsonFactory jsonFactory89 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper90 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory89);
        java.lang.String str92 = objectMapper90.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.core.Version version93 = objectMapper90.version();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator94 = tokenBuffer45.setCodec((com.fasterxml.jackson.core.ObjectCodec) objectMapper90);
        com.fasterxml.jackson.databind.Module module95 = null;
        try {
            com.fasterxml.jackson.databind.ObjectMapper objectMapper96 = objectMapper90.registerModule(module95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonGenerator48);
        org.junit.Assert.assertNotNull(jsonNode60);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigIntegerNode62);
        org.junit.Assert.assertTrue("'" + short63 + "' != '" + (short) 0 + "'", short63 == (short) 0);
        org.junit.Assert.assertNull(jsonNode65);
        org.junit.Assert.assertNotNull(bigDecimal66);
        org.junit.Assert.assertNotNull(jsonNode76);
        org.junit.Assert.assertNotNull(jsonNode78);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 100L + "'", long81 == 100L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "{" + "'", str82.equals("{"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer86);
        org.junit.Assert.assertNotNull(tokenBuffer88);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "1" + "'", str92.equals("1"));
        org.junit.Assert.assertNotNull(version93);
        org.junit.Assert.assertNotNull(jsonGenerator94);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter2 = tokenBuffer1.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser3 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException5 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser3, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference8 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException5.prependPath(reference8);
        tokenBuffer1.writeTypeId((java.lang.Object) reference8);
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser12 = tokenBuffer1.asParser(objectCodec11);
        try {
            byte byte13 = jsonParser12.getByteValue();
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Current token (null) not numeric, can not use numeric value accessors? at [Source: N/A; line: -1, column: -1]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        }
        org.junit.Assert.assertNull(prettyPrinter2);
        org.junit.Assert.assertNotNull(jsonMappingException5);
        org.junit.Assert.assertNotNull(jsonParser12);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.fasterxml.jackson.databind.node.LongNode longNode1 = new com.fasterxml.jackson.databind.node.LongNode((long) (byte) 0);
        boolean boolean3 = longNode1.asBoolean(false);
        int int4 = longNode1.intValue();
        int int5 = longNode1.intValue();
        com.fasterxml.jackson.core.JsonToken jsonToken6 = longNode1.asToken();
        boolean boolean8 = longNode1.asBoolean(false);
        com.fasterxml.jackson.core.ObjectCodec objectCodec9 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer10 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec9);
        tokenBuffer10.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter12 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator13 = tokenBuffer10.setPrettyPrinter(prettyPrinter12);
        tokenBuffer10.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        com.fasterxml.jackson.databind.JavaType javaType18 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer20 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer21 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer22 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType18, false, typeSerializer20, objJsonSerializer21);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider23 = null;
        java.lang.reflect.Type type24 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode25 = objectArraySerializer22.getSchema(serializerProvider23, type24);
        java.math.BigInteger bigInteger26 = jsonNode25.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode27 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger26);
        short short28 = bigIntegerNode27.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = bigIntegerNode27.get(100);
        java.math.BigDecimal bigDecimal31 = bigIntegerNode27.decimalValue();
        tokenBuffer17.writeNumber(bigDecimal31);
        tokenBuffer10.writeNumberField("hi!", bigDecimal31);
        com.fasterxml.jackson.databind.JavaType javaType34 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer36 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer37 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer38 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType34, false, typeSerializer36, objJsonSerializer37);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider39 = null;
        java.lang.reflect.Type type40 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode41 = objectArraySerializer38.getSchema(serializerProvider39, type40);
        com.fasterxml.jackson.databind.JsonNode jsonNode43 = jsonNode41.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser44 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode41);
        com.fasterxml.jackson.core.JsonParser jsonParser45 = tokenBuffer10.asParser((com.fasterxml.jackson.core.JsonParser) treeTraversingParser44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        longNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer10, serializerProvider46);
        com.fasterxml.jackson.core.JsonToken jsonToken48 = tokenBuffer10.firstToken();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + jsonToken6 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT + "'", jsonToken6.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_INT));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jsonGenerator13);
        org.junit.Assert.assertNotNull(jsonNode25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigIntegerNode27);
        org.junit.Assert.assertTrue("'" + short28 + "' != '" + (short) 0 + "'", short28 == (short) 0);
        org.junit.Assert.assertNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigDecimal31);
        org.junit.Assert.assertNotNull(jsonNode41);
        org.junit.Assert.assertNotNull(jsonNode43);
        org.junit.Assert.assertNotNull(jsonParser45);
        org.junit.Assert.assertTrue("'" + jsonToken48 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken48.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.databind.JavaType javaType35 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer37 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer38 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer39 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType35, false, typeSerializer37, objJsonSerializer38);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider40 = null;
        java.lang.reflect.Type type41 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode42 = objectArraySerializer39.getSchema(serializerProvider40, type41);
        com.fasterxml.jackson.databind.JsonNode jsonNode44 = jsonNode42.withArray("");
        short short45 = jsonNode44.shortValue();
        tokenBuffer1.writeObject((java.lang.Object) short45);
        tokenBuffer1.writeString("[TokenBuffer: VALUE_NULL, FIELD_NAME(), START_OBJECT]");
        com.fasterxml.jackson.databind.JavaType javaType49 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer51 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer52 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer53 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType49, false, typeSerializer51, objJsonSerializer52);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider54 = null;
        java.lang.reflect.Type type55 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = objectArraySerializer53.getSchema(serializerProvider54, type55);
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = jsonNode56.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser59 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode56);
        byte[] byteArray60 = treeTraversingParser59.getBinaryValue();
        com.fasterxml.jackson.core.JsonToken jsonToken61 = treeTraversingParser59.nextToken();
        java.lang.String str63 = treeTraversingParser59.getValueAsString("");
        long long65 = treeTraversingParser59.nextLongValue((long) (-1));
        char[] charArray66 = treeTraversingParser59.getTextCharacters();
        try {
            tokenBuffer1.writeString(charArray66, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jsonNode42);
        org.junit.Assert.assertNotNull(jsonNode44);
        org.junit.Assert.assertTrue("'" + short45 + "' != '" + (short) 0 + "'", short45 == (short) 0);
        org.junit.Assert.assertNotNull(jsonNode56);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertNull(byteArray60);
        org.junit.Assert.assertTrue("'" + jsonToken61 + "' != '" + com.fasterxml.jackson.core.JsonToken.START_OBJECT + "'", jsonToken61.equals(com.fasterxml.jackson.core.JsonToken.START_OBJECT));
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-1L) + "'", long65 == (-1L));
        org.junit.Assert.assertNotNull(charArray66);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray66), "type");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray66), "type");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray66), "[t, y, p, e]");
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory4 = objectMapper1.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray5 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper6 = objectMapper1.enable(mapperFeatureArray5);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper7 = objectMapper1.findAndRegisterModules();
        com.fasterxml.jackson.databind.ObjectReader objectReader8 = objectMapper7.reader();
        java.lang.Object obj9 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader10 = objectReader8.withValueToUpdate(obj9);
        com.fasterxml.jackson.core.ObjectCodec objectCodec11 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer12 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec11);
        tokenBuffer12.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter14 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator15 = tokenBuffer12.setPrettyPrinter(prettyPrinter14);
        tokenBuffer12.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        com.fasterxml.jackson.databind.JavaType javaType20 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer22 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer23 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer24 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType20, false, typeSerializer22, objJsonSerializer23);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        java.lang.reflect.Type type26 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = objectArraySerializer24.getSchema(serializerProvider25, type26);
        java.math.BigInteger bigInteger28 = jsonNode27.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode29 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger28);
        short short30 = bigIntegerNode29.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = bigIntegerNode29.get(100);
        java.math.BigDecimal bigDecimal33 = bigIntegerNode29.decimalValue();
        tokenBuffer19.writeNumber(bigDecimal33);
        tokenBuffer12.writeNumberField("hi!", bigDecimal33);
        com.fasterxml.jackson.databind.JavaType javaType36 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer38 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer39 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer40 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType36, false, typeSerializer38, objJsonSerializer39);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider41 = null;
        java.lang.reflect.Type type42 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode43 = objectArraySerializer40.getSchema(serializerProvider41, type42);
        com.fasterxml.jackson.databind.JsonNode jsonNode45 = jsonNode43.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser46 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode43);
        long long48 = treeTraversingParser46.nextLongValue((long) 100);
        java.lang.String str49 = treeTraversingParser46.getText();
        java.io.Writer writer50 = null;
        int int51 = treeTraversingParser46.releaseBuffered(writer50);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext52 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer53 = tokenBuffer12.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser46, deserializationContext52);
        boolean boolean54 = treeTraversingParser46.hasCurrentToken();
        try {
            com.fasterxml.jackson.databind.MappingIterator<com.fasterxml.jackson.databind.util.ClassUtil> classUtilItor55 = objectReader10.readValues((com.fasterxml.jackson.core.JsonParser) treeTraversingParser46);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No value type configured for ObjectReader");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(typeFactory4);
        org.junit.Assert.assertNotNull(mapperFeatureArray5);
        org.junit.Assert.assertNotNull(objectMapper6);
        org.junit.Assert.assertNotNull(objectMapper7);
        org.junit.Assert.assertNotNull(objectReader8);
        org.junit.Assert.assertNotNull(objectReader10);
        org.junit.Assert.assertNotNull(jsonGenerator15);
        org.junit.Assert.assertNotNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigIntegerNode29);
        org.junit.Assert.assertTrue("'" + short30 + "' != '" + (short) 0 + "'", short30 == (short) 0);
        org.junit.Assert.assertNull(jsonNode32);
        org.junit.Assert.assertNotNull(bigDecimal33);
        org.junit.Assert.assertNotNull(jsonNode43);
        org.junit.Assert.assertNotNull(jsonNode45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 100L + "'", long48 == 100L);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{" + "'", str49.equals("{"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.core.JsonFactory jsonFactory2 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper3 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory2);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes4 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader5 = objectMapper3.reader(contextAttributes4);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory6 = objectMapper3.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray7 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper8 = objectMapper3.enable(mapperFeatureArray7);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper9 = objectMapper1.enable(mapperFeatureArray7);
        com.fasterxml.jackson.databind.deser.DeserializationProblemHandler deserializationProblemHandler10 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper11 = objectMapper1.addHandler(deserializationProblemHandler10);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory12 = objectMapper1.getSerializerFactory();
        com.fasterxml.jackson.databind.node.JsonNodeFactory jsonNodeFactory13 = objectMapper1.getNodeFactory();
        com.fasterxml.jackson.databind.node.TextNode textNode15 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        tokenBuffer17.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter19 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator20 = tokenBuffer17.setPrettyPrinter(prettyPrinter19);
        tokenBuffer17.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer17.setCharacterEscapes(characterEscapes22);
        com.fasterxml.jackson.core.ObjectCodec objectCodec24 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator25 = tokenBuffer17.setCodec(objectCodec24);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider26 = null;
        textNode15.serialize(jsonGenerator25, serializerProvider26);
        com.fasterxml.jackson.core.ObjectCodec objectCodec28 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer29 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec28);
        tokenBuffer29.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter31 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator32 = tokenBuffer29.setPrettyPrinter(prettyPrinter31);
        tokenBuffer29.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.databind.JavaType javaType37 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer39 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer40 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer41 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType37, false, typeSerializer39, objJsonSerializer40);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider42 = null;
        java.lang.reflect.Type type43 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode44 = objectArraySerializer41.getSchema(serializerProvider42, type43);
        java.math.BigInteger bigInteger45 = jsonNode44.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode46 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger45);
        short short47 = bigIntegerNode46.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode49 = bigIntegerNode46.get(100);
        java.math.BigDecimal bigDecimal50 = bigIntegerNode46.decimalValue();
        tokenBuffer36.writeNumber(bigDecimal50);
        tokenBuffer29.writeNumberField("hi!", bigDecimal50);
        com.fasterxml.jackson.databind.JavaType javaType53 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer55 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer56 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer57 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType53, false, typeSerializer55, objJsonSerializer56);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider58 = null;
        java.lang.reflect.Type type59 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode60 = objectArraySerializer57.getSchema(serializerProvider58, type59);
        com.fasterxml.jackson.databind.JsonNode jsonNode62 = jsonNode60.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser63 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode60);
        long long65 = treeTraversingParser63.nextLongValue((long) 100);
        java.lang.String str66 = treeTraversingParser63.getText();
        java.io.Writer writer67 = null;
        int int68 = treeTraversingParser63.releaseBuffered(writer67);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext69 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer70 = tokenBuffer29.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser63, deserializationContext69);
        boolean boolean71 = textNode15.equals((java.lang.Object) treeTraversingParser63);
        treeTraversingParser63.close();
        java.lang.String str73 = treeTraversingParser63.getText();
        java.io.Writer writer74 = null;
        int int75 = treeTraversingParser63.releaseBuffered(writer74);
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode76 = objectMapper1.readTree((com.fasterxml.jackson.core.JsonParser) treeTraversingParser63);
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes77 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter78 = objectMapper1.writer(characterEscapes77);
        org.junit.Assert.assertNotNull(objectReader5);
        org.junit.Assert.assertNotNull(typeFactory6);
        org.junit.Assert.assertNotNull(mapperFeatureArray7);
        org.junit.Assert.assertNotNull(objectMapper8);
        org.junit.Assert.assertNotNull(objectMapper9);
        org.junit.Assert.assertNotNull(objectMapper11);
        org.junit.Assert.assertNotNull(serializerFactory12);
        org.junit.Assert.assertNotNull(jsonNodeFactory13);
        org.junit.Assert.assertNotNull(textNode15);
        org.junit.Assert.assertNotNull(jsonGenerator20);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonGenerator25);
        org.junit.Assert.assertNotNull(jsonGenerator32);
        org.junit.Assert.assertNotNull(jsonNode44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigIntegerNode46);
        org.junit.Assert.assertTrue("'" + short47 + "' != '" + (short) 0 + "'", short47 == (short) 0);
        org.junit.Assert.assertNull(jsonNode49);
        org.junit.Assert.assertNotNull(bigDecimal50);
        org.junit.Assert.assertNotNull(jsonNode60);
        org.junit.Assert.assertNotNull(jsonNode62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 100L + "'", long65 == 100L);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{" + "'", str66.equals("{"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNull(bigIntegerNode76);
        org.junit.Assert.assertNotNull(objectWriter78);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ObjectNode objectNode11 = objectNode8.put("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]", (float) 10L);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode13 = objectNode8.booleanNode(true);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode16 = objectNode8.put("1", (long) 10);
        com.fasterxml.jackson.databind.node.NumericNode numericNode18 = objectNode16.numberNode((byte) 1);
        com.fasterxml.jackson.core.JsonFactory jsonFactory20 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper21 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory20);
        java.lang.String str23 = objectMapper21.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider24 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper25 = objectMapper21.setSerializerProvider(defaultSerializerProvider24);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode26 = objectMapper25.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode28 = arrayNode26.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode31 = arrayNode26.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode34 = arrayNode26.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode35 = arrayNode34.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode37 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec38 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer39 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec38);
        tokenBuffer39.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter41 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator42 = tokenBuffer39.setPrettyPrinter(prettyPrinter41);
        tokenBuffer39.writeNull();
        tokenBuffer39.writeBoolean(true);
        tokenBuffer39.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken49 = tokenBuffer39.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider50 = null;
        intNode37.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer39, serializerProvider50);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode52 = arrayNode35.add((com.fasterxml.jackson.databind.JsonNode) intNode37);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode54 = arrayNode35.findParent("");
        com.fasterxml.jackson.databind.JsonNode jsonNode55 = objectNode16.put("[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]", (com.fasterxml.jackson.databind.JsonNode) arrayNode35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(objectNode11);
        org.junit.Assert.assertNotNull(booleanNode13);
        org.junit.Assert.assertNotNull(objectNode16);
        org.junit.Assert.assertNotNull(numericNode18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1" + "'", str23.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper25);
        org.junit.Assert.assertNotNull(arrayNode26);
        org.junit.Assert.assertNotNull(objectNode28);
        org.junit.Assert.assertNotNull(arrayNode31);
        org.junit.Assert.assertNotNull(arrayNode34);
        org.junit.Assert.assertNotNull(arrayNode35);
        org.junit.Assert.assertNotNull(intNode37);
        org.junit.Assert.assertNotNull(jsonGenerator42);
        org.junit.Assert.assertTrue("'" + jsonToken49 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken49.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode52);
        org.junit.Assert.assertNull(objectNode54);
        org.junit.Assert.assertNull(jsonNode55);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        boolean boolean43 = treeTraversingParser35.hasCurrentToken();
        boolean boolean45 = treeTraversingParser35.getValueAsBoolean(false);
        char[] charArray46 = treeTraversingParser35.getTextCharacters();
        int int47 = treeTraversingParser35.getTextLength();
        boolean boolean48 = treeTraversingParser35.canReadObjectId();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(charArray46);
        org.junit.Assert.assertEquals(java.lang.String.copyValueOf(charArray46), "}");
        org.junit.Assert.assertEquals(java.lang.String.valueOf(charArray46), "}");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(charArray46), "[}]");
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.fasterxml.jackson.databind.node.FloatNode floatNode1 = new com.fasterxml.jackson.databind.node.FloatNode(1.0f);
        int int2 = floatNode1.intValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec3 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer4 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec3);
        tokenBuffer4.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = tokenBuffer4.setPrettyPrinter(prettyPrinter6);
        tokenBuffer4.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        com.fasterxml.jackson.databind.JavaType javaType12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer14 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer15 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer16 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType12, false, typeSerializer14, objJsonSerializer15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        java.lang.reflect.Type type18 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode19 = objectArraySerializer16.getSchema(serializerProvider17, type18);
        java.math.BigInteger bigInteger20 = jsonNode19.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode21 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger20);
        short short22 = bigIntegerNode21.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode24 = bigIntegerNode21.get(100);
        java.math.BigDecimal bigDecimal25 = bigIntegerNode21.decimalValue();
        tokenBuffer11.writeNumber(bigDecimal25);
        tokenBuffer4.writeNumberField("hi!", bigDecimal25);
        com.fasterxml.jackson.databind.JavaType javaType28 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer30 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer31 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer32 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType28, false, typeSerializer30, objJsonSerializer31);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider33 = null;
        java.lang.reflect.Type type34 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = objectArraySerializer32.getSchema(serializerProvider33, type34);
        com.fasterxml.jackson.databind.JsonNode jsonNode37 = jsonNode35.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser38 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode35);
        long long40 = treeTraversingParser38.nextLongValue((long) 100);
        java.lang.String str41 = treeTraversingParser38.getText();
        java.io.Writer writer42 = null;
        int int43 = treeTraversingParser38.releaseBuffered(writer42);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext44 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer45 = tokenBuffer4.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser38, deserializationContext44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        floatNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer45, serializerProvider46);
        float float48 = floatNode1.floatValue();
        double double50 = floatNode1.asDouble((double) 10L);
        int int51 = floatNode1.intValue();
        try {
            com.fasterxml.jackson.databind.node.POJONode pOJONode52 = floatNode1.deepCopy();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: Cannot cast com.fasterxml.jackson.databind.node.FloatNode to com.fasterxml.jackson.databind.node.POJONode");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(jsonGenerator7);
        org.junit.Assert.assertNotNull(jsonNode19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigIntegerNode21);
        org.junit.Assert.assertTrue("'" + short22 + "' != '" + (short) 0 + "'", short22 == (short) 0);
        org.junit.Assert.assertNull(jsonNode24);
        org.junit.Assert.assertNotNull(bigDecimal25);
        org.junit.Assert.assertNotNull(jsonNode35);
        org.junit.Assert.assertNotNull(jsonNode37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 100L + "'", long40 == 100L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{" + "'", str41.equals("{"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer45);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.fasterxml.jackson.databind.node.ShortNode shortNode1 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.Number number2 = shortNode1.numberValue();
        com.fasterxml.jackson.databind.node.ShortNode shortNode4 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str5 = shortNode4.asText();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType6 = shortNode4.numberType();
        boolean boolean7 = shortNode1.equals((java.lang.Object) numberType6);
        java.math.BigDecimal bigDecimal8 = shortNode1.decimalValue();
        boolean boolean10 = shortNode1.hasNonNull((int) (short) 0);
        boolean boolean12 = shortNode1.asBoolean(true);
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer14.setPrettyPrinter(prettyPrinter16);
        tokenBuffer14.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator20 = tokenBuffer14.setFeatureMask((int) '4');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider21 = null;
        shortNode1.serialize(jsonGenerator20, serializerProvider21);
        float float23 = shortNode1.floatValue();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 10 + "'", number2.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
        org.junit.Assert.assertTrue("'" + numberType6 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.INT + "'", numberType6.equals(com.fasterxml.jackson.core.JsonParser.NumberType.INT));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(bigDecimal8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertNotNull(jsonGenerator20);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 10.0f + "'", float23 == 10.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType44 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer46 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer47 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer48 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType44, false, typeSerializer46, objJsonSerializer47);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider49 = null;
        java.lang.reflect.Type type50 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = objectArraySerializer48.getSchema(serializerProvider49, type50);
        java.math.BigInteger bigInteger52 = jsonNode51.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode53 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger52);
        short short54 = bigIntegerNode53.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = bigIntegerNode53.get(100);
        java.math.BigDecimal bigDecimal57 = bigIntegerNode53.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode58 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal57);
        boolean boolean59 = decimalNode58.canConvertToLong();
        java.math.BigInteger bigInteger60 = decimalNode58.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken61 = decimalNode58.asToken();
        float float62 = decimalNode58.floatValue();
        tokenBuffer1.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode58);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator65 = tokenBuffer1.setFeatureMask((int) ' ');
        com.fasterxml.jackson.core.Version version66 = tokenBuffer1.version();
        tokenBuffer1.writeStartArray(1);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonNode51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigIntegerNode53);
        org.junit.Assert.assertTrue("'" + short54 + "' != '" + (short) 0 + "'", short54 == (short) 0);
        org.junit.Assert.assertNull(jsonNode56);
        org.junit.Assert.assertNotNull(bigDecimal57);
        org.junit.Assert.assertNotNull(decimalNode58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertTrue("'" + jsonToken61 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken61.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator65);
        org.junit.Assert.assertNotNull(version66);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory4 = objectMapper1.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray5 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper6 = objectMapper1.enable(mapperFeatureArray5);
        java.text.DateFormat dateFormat8 = java.text.DateFormat.getTimeInstance(1);
        java.text.NumberFormat numberFormat9 = dateFormat8.getNumberFormat();
        java.util.TimeZone timeZone10 = dateFormat8.getTimeZone();
        java.text.DateFormat dateFormat11 = com.fasterxml.jackson.databind.util.StdDateFormat.getRFC1123Format(timeZone10);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = objectMapper6.setTimeZone(timeZone10);
        com.fasterxml.jackson.databind.InjectableValues injectableValues13 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper14 = objectMapper12.setInjectableValues(injectableValues13);
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer16 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec15);
        tokenBuffer16.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter18 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator19 = tokenBuffer16.setPrettyPrinter(prettyPrinter18);
        com.fasterxml.jackson.core.Base64Variant base64Variant20 = null;
        byte[] byteArray21 = new byte[] {};
        tokenBuffer16.writeBinary(base64Variant20, byteArray21, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode25 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray21);
        try {
            com.fasterxml.jackson.databind.JsonNode jsonNode26 = objectMapper14.readTree(byteArray21);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.databind.JsonMappingException; message: No content to map due to end-of-input? at [Source: [B@3a0fdfbc; line: 1, column: 1]");
        } catch (com.fasterxml.jackson.databind.JsonMappingException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(typeFactory4);
        org.junit.Assert.assertNotNull(mapperFeatureArray5);
        org.junit.Assert.assertNotNull(objectMapper6);
        org.junit.Assert.assertNotNull(dateFormat8);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertEquals(timeZone10.getDisplayName(), "Pacific Standard Time");
        org.junit.Assert.assertNotNull(dateFormat11);
        org.junit.Assert.assertNotNull(objectMapper12);
        org.junit.Assert.assertNotNull(objectMapper14);
        org.junit.Assert.assertNotNull(jsonGenerator19);
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[]");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType44 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer46 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer47 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer48 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType44, false, typeSerializer46, objJsonSerializer47);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider49 = null;
        java.lang.reflect.Type type50 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = objectArraySerializer48.getSchema(serializerProvider49, type50);
        java.math.BigInteger bigInteger52 = jsonNode51.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode53 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger52);
        short short54 = bigIntegerNode53.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = bigIntegerNode53.get(100);
        java.math.BigDecimal bigDecimal57 = bigIntegerNode53.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode58 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal57);
        boolean boolean59 = decimalNode58.canConvertToLong();
        java.math.BigInteger bigInteger60 = decimalNode58.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken61 = decimalNode58.asToken();
        float float62 = decimalNode58.floatValue();
        tokenBuffer1.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode58);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator65 = tokenBuffer1.setFeatureMask((int) ' ');
        com.fasterxml.jackson.core.ObjectCodec objectCodec67 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer68 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec67);
        tokenBuffer68.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter70 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator71 = tokenBuffer68.setPrettyPrinter(prettyPrinter70);
        com.fasterxml.jackson.core.Base64Variant base64Variant72 = null;
        byte[] byteArray73 = new byte[] {};
        tokenBuffer68.writeBinary(base64Variant72, byteArray73, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode79 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray73, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType80 = binaryNode79.getNodeType();
        byte[] byteArray81 = binaryNode79.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode82 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray81);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode83 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray81);
        tokenBuffer1.writeBinaryField("[AnnotedClass com.fasterxml.jackson.databind.MapperFeature]", byteArray81);
        com.fasterxml.jackson.core.Version version85 = tokenBuffer1.version();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonNode51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigIntegerNode53);
        org.junit.Assert.assertTrue("'" + short54 + "' != '" + (short) 0 + "'", short54 == (short) 0);
        org.junit.Assert.assertNull(jsonNode56);
        org.junit.Assert.assertNotNull(bigDecimal57);
        org.junit.Assert.assertNotNull(decimalNode58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertTrue("'" + jsonToken61 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken61.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator65);
        org.junit.Assert.assertNotNull(jsonGenerator71);
        org.junit.Assert.assertNotNull(byteArray73);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray73), "[]");
        org.junit.Assert.assertNotNull(binaryNode79);
        org.junit.Assert.assertTrue("'" + jsonNodeType80 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType80.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[]");
        org.junit.Assert.assertNotNull(binaryNode83);
        org.junit.Assert.assertNotNull(version85);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode15 = arrayNode14.deepCopy();
        com.fasterxml.jackson.databind.node.IntNode intNode17 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec18 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer19 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec18);
        tokenBuffer19.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter21 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator22 = tokenBuffer19.setPrettyPrinter(prettyPrinter21);
        tokenBuffer19.writeNull();
        tokenBuffer19.writeBoolean(true);
        tokenBuffer19.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken29 = tokenBuffer19.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        intNode17.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer19, serializerProvider30);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode32 = arrayNode15.add((com.fasterxml.jackson.databind.JsonNode) intNode17);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode34 = arrayNode15.findParent("");
        com.fasterxml.jackson.core.JsonFactory jsonFactory36 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper37 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory36);
        java.lang.String str39 = objectMapper37.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider40 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper41 = objectMapper37.setSerializerProvider(defaultSerializerProvider40);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode42 = objectMapper41.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode44 = arrayNode42.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode47 = arrayNode42.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode50 = arrayNode42.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.JsonNode jsonNode52 = arrayNode42.path("[TokenBuffer: VALUE_NULL, FIELD_NAME(hi!), VALUE_NUMBER_FLOAT, FIELD_NAME(), VALUE_NULL]");
        com.fasterxml.jackson.databind.JsonNode jsonNode54 = arrayNode42.findValue("[map type; class java.lang.Object, [simple type, class com.fasterxml.jackson.databind.MapperFeature] -> [simple type, class java.util.concurrent.atomic.AtomicBoolean]]");
        com.fasterxml.jackson.databind.JavaType javaType56 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer58 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer59 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer60 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType56, false, typeSerializer58, objJsonSerializer59);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider61 = null;
        java.lang.reflect.Type type62 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode63 = objectArraySerializer60.getSchema(serializerProvider61, type62);
        java.math.BigInteger bigInteger64 = jsonNode63.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode65 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger64);
        short short66 = bigIntegerNode65.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode68 = bigIntegerNode65.get(100);
        java.math.BigDecimal bigDecimal69 = bigIntegerNode65.decimalValue();
        boolean boolean71 = bigIntegerNode65.asBoolean(true);
        int int73 = bigIntegerNode65.asInt((int) (byte) 100);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList75 = bigIntegerNode65.findValues("");
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList76 = arrayNode42.findValues("hi!", jsonNodeList75);
        java.util.List<com.fasterxml.jackson.databind.JsonNode> jsonNodeList77 = arrayNode15.findValues("java.lang.Short[\"hi!\"]", jsonNodeList76);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode79 = arrayNode15.insertArray(0);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode81 = arrayNode79.add((java.lang.Long) 10L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode15);
        org.junit.Assert.assertNotNull(intNode17);
        org.junit.Assert.assertNotNull(jsonGenerator22);
        org.junit.Assert.assertTrue("'" + jsonToken29 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken29.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertNotNull(arrayNode32);
        org.junit.Assert.assertNull(objectNode34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper41);
        org.junit.Assert.assertNotNull(arrayNode42);
        org.junit.Assert.assertNotNull(objectNode44);
        org.junit.Assert.assertNotNull(arrayNode47);
        org.junit.Assert.assertNotNull(arrayNode50);
        org.junit.Assert.assertNotNull(jsonNode52);
        org.junit.Assert.assertNull(jsonNode54);
        org.junit.Assert.assertNotNull(jsonNode63);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigIntegerNode65);
        org.junit.Assert.assertTrue("'" + short66 + "' != '" + (short) 0 + "'", short66 == (short) 0);
        org.junit.Assert.assertNull(jsonNode68);
        org.junit.Assert.assertNotNull(bigDecimal69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(jsonNodeList75);
        org.junit.Assert.assertNotNull(jsonNodeList76);
        org.junit.Assert.assertNotNull(jsonNodeList77);
        org.junit.Assert.assertNotNull(arrayNode79);
        org.junit.Assert.assertNotNull(arrayNode81);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper7 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory6);
        com.fasterxml.jackson.databind.MapperFeature mapperFeature8 = com.fasterxml.jackson.databind.MapperFeature.DEFAULT_VIEW_INCLUSION;
        boolean boolean9 = mapperFeature8.enabledByDefault();
        boolean boolean10 = mapperFeature8.enabledByDefault();
        com.fasterxml.jackson.databind.ObjectMapper objectMapper12 = objectMapper7.configure(mapperFeature8, true);
        tokenBuffer1.writeObjectId((java.lang.Object) objectMapper7);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertTrue("'" + mapperFeature8 + "' != '" + com.fasterxml.jackson.databind.MapperFeature.DEFAULT_VIEW_INCLUSION + "'", mapperFeature8.equals(com.fasterxml.jackson.databind.MapperFeature.DEFAULT_VIEW_INCLUSION));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(objectMapper12);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        tokenBuffer3.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec9 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer10 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec9);
        com.fasterxml.jackson.databind.JavaType javaType11 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer13 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer14 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer15 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType11, false, typeSerializer13, objJsonSerializer14);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider16 = null;
        java.lang.reflect.Type type17 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode18 = objectArraySerializer15.getSchema(serializerProvider16, type17);
        java.math.BigInteger bigInteger19 = jsonNode18.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode20 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger19);
        short short21 = bigIntegerNode20.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode23 = bigIntegerNode20.get(100);
        java.math.BigDecimal bigDecimal24 = bigIntegerNode20.decimalValue();
        tokenBuffer10.writeNumber(bigDecimal24);
        tokenBuffer3.writeNumberField("hi!", bigDecimal24);
        com.fasterxml.jackson.databind.JavaType javaType27 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer29 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer30 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer31 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType27, false, typeSerializer29, objJsonSerializer30);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider32 = null;
        java.lang.reflect.Type type33 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = objectArraySerializer31.getSchema(serializerProvider32, type33);
        com.fasterxml.jackson.databind.JsonNode jsonNode36 = jsonNode34.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser37 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode34);
        long long39 = treeTraversingParser37.nextLongValue((long) 100);
        java.lang.String str40 = treeTraversingParser37.getText();
        java.io.Writer writer41 = null;
        int int42 = treeTraversingParser37.releaseBuffered(writer41);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext43 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer44 = tokenBuffer3.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser37, deserializationContext43);
        tokenBuffer3.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType46 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer48 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer49 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer50 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType46, false, typeSerializer48, objJsonSerializer49);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider51 = null;
        java.lang.reflect.Type type52 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode53 = objectArraySerializer50.getSchema(serializerProvider51, type52);
        java.math.BigInteger bigInteger54 = jsonNode53.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode55 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger54);
        short short56 = bigIntegerNode55.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = bigIntegerNode55.get(100);
        java.math.BigDecimal bigDecimal59 = bigIntegerNode55.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode60 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal59);
        boolean boolean61 = decimalNode60.canConvertToLong();
        java.math.BigInteger bigInteger62 = decimalNode60.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken63 = decimalNode60.asToken();
        float float64 = decimalNode60.floatValue();
        tokenBuffer3.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode60);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator67 = tokenBuffer3.setFeatureMask((int) ' ');
        boolean boolean68 = tokenBuffer3.canOmitFields();
        com.fasterxml.jackson.databind.node.ShortNode shortNode70 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str71 = shortNode70.asText();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType72 = shortNode70.numberType();
        objectMapper1.writeTree((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer3, (com.fasterxml.jackson.databind.JsonNode) shortNode70);
        tokenBuffer3.writeNumberField("com.fasterxml.jackson.databind.ser.std.CalendarSerializer", (float) (-1L));
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference78 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) tokenBuffer3, "\"com.fasterxml.jackson.databind.node.BigIntegerNode\"");
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertNotNull(jsonNode18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigIntegerNode20);
        org.junit.Assert.assertTrue("'" + short21 + "' != '" + (short) 0 + "'", short21 == (short) 0);
        org.junit.Assert.assertNull(jsonNode23);
        org.junit.Assert.assertNotNull(bigDecimal24);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertNotNull(jsonNode36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 100L + "'", long39 == 100L);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{" + "'", str40.equals("{"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer44);
        org.junit.Assert.assertNotNull(jsonNode53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigIntegerNode55);
        org.junit.Assert.assertTrue("'" + short56 + "' != '" + (short) 0 + "'", short56 == (short) 0);
        org.junit.Assert.assertNull(jsonNode58);
        org.junit.Assert.assertNotNull(bigDecimal59);
        org.junit.Assert.assertNotNull(decimalNode60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertTrue("'" + jsonToken63 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken63.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float64 + "' != '" + 0.0f + "'", float64 == 0.0f);
        org.junit.Assert.assertNotNull(jsonGenerator67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10" + "'", str71.equals("10"));
        org.junit.Assert.assertTrue("'" + numberType72 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.INT + "'", numberType72.equals(com.fasterxml.jackson.core.JsonParser.NumberType.INT));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.databind.JsonNode jsonNode5 = objectReader3.createObjectNode();
        com.fasterxml.jackson.core.JsonFactory jsonFactory6 = objectReader3.getFactory();
        java.io.OutputStream outputStream7 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = jsonFactory6.createGenerator(outputStream7);
        java.io.Reader reader9 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser10 = jsonFactory6.createJsonParser(reader9);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper11 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory6);
        com.fasterxml.jackson.databind.node.TextNode textNode13 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        tokenBuffer15.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter17 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator18 = tokenBuffer15.setPrettyPrinter(prettyPrinter17);
        tokenBuffer15.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer15.setCharacterEscapes(characterEscapes20);
        com.fasterxml.jackson.core.ObjectCodec objectCodec22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer15.setCodec(objectCodec22);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider24 = null;
        textNode13.serialize(jsonGenerator23, serializerProvider24);
        com.fasterxml.jackson.core.ObjectCodec objectCodec26 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer27 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec26);
        tokenBuffer27.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter29 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator30 = tokenBuffer27.setPrettyPrinter(prettyPrinter29);
        tokenBuffer27.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec33 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer34 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec33);
        com.fasterxml.jackson.databind.JavaType javaType35 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer37 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer38 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer39 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType35, false, typeSerializer37, objJsonSerializer38);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider40 = null;
        java.lang.reflect.Type type41 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode42 = objectArraySerializer39.getSchema(serializerProvider40, type41);
        java.math.BigInteger bigInteger43 = jsonNode42.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode44 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger43);
        short short45 = bigIntegerNode44.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode47 = bigIntegerNode44.get(100);
        java.math.BigDecimal bigDecimal48 = bigIntegerNode44.decimalValue();
        tokenBuffer34.writeNumber(bigDecimal48);
        tokenBuffer27.writeNumberField("hi!", bigDecimal48);
        com.fasterxml.jackson.databind.JavaType javaType51 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer53 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer54 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer55 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType51, false, typeSerializer53, objJsonSerializer54);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider56 = null;
        java.lang.reflect.Type type57 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = objectArraySerializer55.getSchema(serializerProvider56, type57);
        com.fasterxml.jackson.databind.JsonNode jsonNode60 = jsonNode58.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser61 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode58);
        long long63 = treeTraversingParser61.nextLongValue((long) 100);
        java.lang.String str64 = treeTraversingParser61.getText();
        java.io.Writer writer65 = null;
        int int66 = treeTraversingParser61.releaseBuffered(writer65);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext67 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer68 = tokenBuffer27.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser61, deserializationContext67);
        boolean boolean69 = textNode13.equals((java.lang.Object) treeTraversingParser61);
        treeTraversingParser61.close();
        int int71 = treeTraversingParser61.getFeatureMask();
        com.fasterxml.jackson.core.JsonParser jsonParser73 = treeTraversingParser61.setFeatureMask(16401);
        com.fasterxml.jackson.databind.node.ValueNode valueNode74 = objectMapper11.readTree(jsonParser73);
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonNode5);
        org.junit.Assert.assertNotNull(jsonFactory6);
        org.junit.Assert.assertNotNull(jsonGenerator8);
        org.junit.Assert.assertNotNull(jsonParser10);
        org.junit.Assert.assertNotNull(textNode13);
        org.junit.Assert.assertNotNull(jsonGenerator18);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonGenerator30);
        org.junit.Assert.assertNotNull(jsonNode42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigIntegerNode44);
        org.junit.Assert.assertTrue("'" + short45 + "' != '" + (short) 0 + "'", short45 == (short) 0);
        org.junit.Assert.assertNull(jsonNode47);
        org.junit.Assert.assertNotNull(bigDecimal48);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertNotNull(jsonNode60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 100L + "'", long63 == 100L);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "{" + "'", str64.equals("{"));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(jsonParser73);
        org.junit.Assert.assertNull(valueNode74);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ObjectNode objectNode11 = objectNode8.put("[collection-like type; class com.fasterxml.jackson.databind.MapperFeature, contains [simple type, class java.lang.Object]]", (float) 10L);
        com.fasterxml.jackson.databind.node.BooleanNode booleanNode13 = objectNode8.booleanNode(true);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode16 = objectNode8.put("1", (long) 10);
        com.fasterxml.jackson.databind.node.ValueNode valueNode18 = objectNode16.numberNode((java.lang.Integer) 0);
        com.fasterxml.jackson.databind.node.ObjectNode objectNode21 = objectNode16.put("{", (java.lang.Float) 0.0f);
        java.lang.String[] strArray27 = new java.lang.String[] { "type", "[TokenBuffer: VALUE_NULL, FIELD_NAME(), START_OBJECT]", "Unrecognized field \"\" (class com.fasterxml.jackson.databind.deser.std.StringCollectionDeserializer), not marked as ignorable", "\"com.fasterxml.jackson.databind.node.BigIntegerNode\"", "[{},\"com.fasterxml.jackson.databind.exc.InvalidFormatException: \",35.0]" };
        com.fasterxml.jackson.databind.node.ObjectNode objectNode28 = objectNode21.retain(strArray27);
        com.fasterxml.jackson.core.ObjectCodec objectCodec29 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer30 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec29);
        tokenBuffer30.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter32 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = tokenBuffer30.setPrettyPrinter(prettyPrinter32);
        com.fasterxml.jackson.core.Base64Variant base64Variant34 = null;
        byte[] byteArray35 = new byte[] {};
        tokenBuffer30.writeBinary(base64Variant34, byteArray35, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode41 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray35, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType42 = binaryNode41.getNodeType();
        byte[] byteArray43 = binaryNode41.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode44 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray43);
        java.lang.String str45 = binaryNode44.asText();
        byte[] byteArray46 = binaryNode44.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode47 = objectNode21.binaryNode(byteArray46);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(objectNode11);
        org.junit.Assert.assertNotNull(booleanNode13);
        org.junit.Assert.assertNotNull(objectNode16);
        org.junit.Assert.assertNotNull(valueNode18);
        org.junit.Assert.assertNotNull(objectNode21);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(objectNode28);
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertNotNull(byteArray35);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray35), "[]");
        org.junit.Assert.assertNotNull(binaryNode41);
        org.junit.Assert.assertTrue("'" + jsonNodeType42 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType42.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray43);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray43), "[]");
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray46), "[]");
        org.junit.Assert.assertNotNull(binaryNode47);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.fasterxml.jackson.databind.node.DoubleNode doubleNode1 = new com.fasterxml.jackson.databind.node.DoubleNode((double) (short) -1);
        com.fasterxml.jackson.core.JsonParser.NumberType numberType2 = doubleNode1.numberType();
        java.lang.String str3 = doubleNode1.asText();
        com.fasterxml.jackson.databind.node.ShortNode shortNode5 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.Number number6 = shortNode5.numberValue();
        com.fasterxml.jackson.databind.node.ShortNode shortNode8 = new com.fasterxml.jackson.databind.node.ShortNode((short) (byte) 10);
        java.lang.String str9 = shortNode8.asText();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType10 = shortNode8.numberType();
        boolean boolean11 = shortNode5.equals((java.lang.Object) numberType10);
        java.math.BigDecimal bigDecimal12 = shortNode5.decimalValue();
        boolean boolean14 = shortNode5.hasNonNull((int) (short) 0);
        boolean boolean16 = shortNode5.asBoolean(true);
        com.fasterxml.jackson.core.ObjectCodec objectCodec17 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer18 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec17);
        tokenBuffer18.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter20 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator21 = tokenBuffer18.setPrettyPrinter(prettyPrinter20);
        tokenBuffer18.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer18.setFeatureMask((int) '4');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider25 = null;
        shortNode5.serialize(jsonGenerator24, serializerProvider25);
        com.fasterxml.jackson.databind.node.TextNode textNode28 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec29 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer30 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec29);
        tokenBuffer30.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter32 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator33 = tokenBuffer30.setPrettyPrinter(prettyPrinter32);
        tokenBuffer30.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes35 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator36 = tokenBuffer30.setCharacterEscapes(characterEscapes35);
        com.fasterxml.jackson.core.ObjectCodec objectCodec37 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator38 = tokenBuffer30.setCodec(objectCodec37);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider39 = null;
        textNode28.serialize(jsonGenerator38, serializerProvider39);
        jsonGenerator38.writeNumberField("{", (int) (byte) 1);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        shortNode5.serialize(jsonGenerator38, serializerProvider44);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider46 = null;
        doubleNode1.serialize(jsonGenerator38, serializerProvider46);
        org.junit.Assert.assertTrue("'" + numberType2 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.DOUBLE + "'", numberType2.equals(com.fasterxml.jackson.core.JsonParser.NumberType.DOUBLE));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10" + "'", str9.equals("10"));
        org.junit.Assert.assertTrue("'" + numberType10 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.INT + "'", numberType10.equals(com.fasterxml.jackson.core.JsonParser.NumberType.INT));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(bigDecimal12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(jsonGenerator21);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(textNode28);
        org.junit.Assert.assertNotNull(jsonGenerator33);
        org.junit.Assert.assertNotNull(jsonGenerator36);
        org.junit.Assert.assertNotNull(jsonGenerator38);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.core.ObjectCodec objectCodec16 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer17 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec16);
        tokenBuffer17.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter19 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator20 = tokenBuffer17.setPrettyPrinter(prettyPrinter19);
        com.fasterxml.jackson.core.Base64Variant base64Variant21 = null;
        byte[] byteArray22 = new byte[] {};
        tokenBuffer17.writeBinary(base64Variant21, byteArray22, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode28 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray22, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType29 = binaryNode28.getNodeType();
        byte[] byteArray30 = binaryNode28.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode31 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray30);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode32 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray30);
        byte[] byteArray33 = binaryNode32.binaryValue();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode34 = arrayNode14.insert((int) (short) 100, byteArray33);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(jsonGenerator20);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[]");
        org.junit.Assert.assertNotNull(binaryNode28);
        org.junit.Assert.assertTrue("'" + jsonNodeType29 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType29.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray30), "[]");
        org.junit.Assert.assertNotNull(binaryNode32);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[]");
        org.junit.Assert.assertNotNull(arrayNode34);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.ObjectReader objectReader2 = objectMapper1.reader();
        com.fasterxml.jackson.databind.ObjectWriter objectWriter3 = objectMapper1.writer();
        java.io.File file4 = null;
        com.fasterxml.jackson.databind.node.TextNode textNode6 = com.fasterxml.jackson.databind.node.TextNode.valueOf("com.fasterxml.jackson.databind.node.BigIntegerNode");
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        tokenBuffer8.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer8.setPrettyPrinter(prettyPrinter10);
        tokenBuffer8.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer8.setCharacterEscapes(characterEscapes13);
        com.fasterxml.jackson.core.ObjectCodec objectCodec15 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator16 = tokenBuffer8.setCodec(objectCodec15);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider17 = null;
        textNode6.serialize(jsonGenerator16, serializerProvider17);
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer20 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec19);
        tokenBuffer20.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer20.setPrettyPrinter(prettyPrinter22);
        tokenBuffer20.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec26 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer27 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec26);
        com.fasterxml.jackson.databind.JavaType javaType28 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer30 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer31 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer32 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType28, false, typeSerializer30, objJsonSerializer31);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider33 = null;
        java.lang.reflect.Type type34 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = objectArraySerializer32.getSchema(serializerProvider33, type34);
        java.math.BigInteger bigInteger36 = jsonNode35.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode37 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger36);
        short short38 = bigIntegerNode37.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode40 = bigIntegerNode37.get(100);
        java.math.BigDecimal bigDecimal41 = bigIntegerNode37.decimalValue();
        tokenBuffer27.writeNumber(bigDecimal41);
        tokenBuffer20.writeNumberField("hi!", bigDecimal41);
        com.fasterxml.jackson.databind.JavaType javaType44 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer46 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer47 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer48 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType44, false, typeSerializer46, objJsonSerializer47);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider49 = null;
        java.lang.reflect.Type type50 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = objectArraySerializer48.getSchema(serializerProvider49, type50);
        com.fasterxml.jackson.databind.JsonNode jsonNode53 = jsonNode51.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser54 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode51);
        long long56 = treeTraversingParser54.nextLongValue((long) 100);
        java.lang.String str57 = treeTraversingParser54.getText();
        java.io.Writer writer58 = null;
        int int59 = treeTraversingParser54.releaseBuffered(writer58);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext60 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer61 = tokenBuffer20.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser54, deserializationContext60);
        boolean boolean62 = textNode6.equals((java.lang.Object) treeTraversingParser54);
        try {
            objectWriter3.writeValue(file4, (java.lang.Object) textNode6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectReader2);
        org.junit.Assert.assertNotNull(objectWriter3);
        org.junit.Assert.assertNotNull(textNode6);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(jsonGenerator16);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigIntegerNode37);
        org.junit.Assert.assertTrue("'" + short38 + "' != '" + (short) 0 + "'", short38 == (short) 0);
        org.junit.Assert.assertNull(jsonNode40);
        org.junit.Assert.assertNotNull(bigDecimal41);
        org.junit.Assert.assertNotNull(jsonNode51);
        org.junit.Assert.assertNotNull(jsonNode53);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 100L + "'", long56 == 100L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{" + "'", str57.equals("{"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ValueNode valueNode8 = arrayNode6.numberNode((java.lang.Byte) (byte) 1);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode10 = arrayNode6.insertNull(0);
        com.fasterxml.jackson.databind.node.FloatNode floatNode12 = new com.fasterxml.jackson.databind.node.FloatNode(1.0f);
        int int13 = floatNode12.intValue();
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        tokenBuffer15.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter17 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator18 = tokenBuffer15.setPrettyPrinter(prettyPrinter17);
        tokenBuffer15.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec21 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer22 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec21);
        com.fasterxml.jackson.databind.JavaType javaType23 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer26 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer27 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType23, false, typeSerializer25, objJsonSerializer26);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider28 = null;
        java.lang.reflect.Type type29 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode30 = objectArraySerializer27.getSchema(serializerProvider28, type29);
        java.math.BigInteger bigInteger31 = jsonNode30.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode32 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger31);
        short short33 = bigIntegerNode32.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = bigIntegerNode32.get(100);
        java.math.BigDecimal bigDecimal36 = bigIntegerNode32.decimalValue();
        tokenBuffer22.writeNumber(bigDecimal36);
        tokenBuffer15.writeNumberField("hi!", bigDecimal36);
        com.fasterxml.jackson.databind.JavaType javaType39 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer41 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer42 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer43 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType39, false, typeSerializer41, objJsonSerializer42);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider44 = null;
        java.lang.reflect.Type type45 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode46 = objectArraySerializer43.getSchema(serializerProvider44, type45);
        com.fasterxml.jackson.databind.JsonNode jsonNode48 = jsonNode46.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser49 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode46);
        long long51 = treeTraversingParser49.nextLongValue((long) 100);
        java.lang.String str52 = treeTraversingParser49.getText();
        java.io.Writer writer53 = null;
        int int54 = treeTraversingParser49.releaseBuffered(writer53);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext55 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer56 = tokenBuffer15.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser49, deserializationContext55);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider57 = null;
        floatNode12.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer56, serializerProvider57);
        float float59 = floatNode12.floatValue();
        java.math.BigDecimal bigDecimal60 = floatNode12.decimalValue();
        com.fasterxml.jackson.databind.node.NumericNode numericNode61 = arrayNode10.numberNode(bigDecimal60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(valueNode8);
        org.junit.Assert.assertNotNull(arrayNode10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(jsonGenerator18);
        org.junit.Assert.assertNotNull(jsonNode30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigIntegerNode32);
        org.junit.Assert.assertTrue("'" + short33 + "' != '" + (short) 0 + "'", short33 == (short) 0);
        org.junit.Assert.assertNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigDecimal36);
        org.junit.Assert.assertNotNull(jsonNode46);
        org.junit.Assert.assertNotNull(jsonNode48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 100L + "'", long51 == 100L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{" + "'", str52.equals("{"));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 1.0f + "'", float59 == 1.0f);
        org.junit.Assert.assertNotNull(bigDecimal60);
        org.junit.Assert.assertNotNull(numericNode61);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException2 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser0, "");
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer5 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer6 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer7 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType3, false, typeSerializer5, objJsonSerializer6);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider8 = null;
        java.lang.reflect.Type type9 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode10 = objectArraySerializer7.getSchema(serializerProvider8, type9);
        java.math.BigInteger bigInteger11 = jsonNode10.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode12 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger11);
        short short13 = bigIntegerNode12.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode15 = bigIntegerNode12.get(100);
        java.math.BigDecimal bigDecimal16 = bigIntegerNode12.decimalValue();
        boolean boolean17 = bigIntegerNode12.isFloat();
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException19 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException2, (java.lang.Object) boolean17, "hi!");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference21 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) 10.0f);
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException22 = com.fasterxml.jackson.databind.JsonMappingException.wrapWithPath((java.lang.Throwable) jsonMappingException19, reference21);
        java.lang.Throwable[] throwableArray23 = jsonMappingException19.getSuppressed();
        com.fasterxml.jackson.core.ObjectCodec objectCodec24 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer25 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec24);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter26 = tokenBuffer25.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser27 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException29 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser27, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference32 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException29.prependPath(reference32);
        tokenBuffer25.writeTypeId((java.lang.Object) reference32);
        reference32.setFieldName("java.lang.Short[\"hi!\"]");
        jsonMappingException19.prependPath(reference32);
        org.junit.Assert.assertNotNull(jsonMappingException2);
        org.junit.Assert.assertNotNull(jsonNode10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigIntegerNode12);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 0 + "'", short13 == (short) 0);
        org.junit.Assert.assertNull(jsonNode15);
        org.junit.Assert.assertNotNull(bigDecimal16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jsonMappingException19);
        org.junit.Assert.assertNotNull(jsonMappingException22);
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertNull(prettyPrinter26);
        org.junit.Assert.assertNotNull(jsonMappingException29);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.text.DateFormat dateFormat2 = java.text.DateFormat.getTimeInstance(1);
        com.fasterxml.jackson.databind.ser.std.DateSerializer dateSerializer3 = new com.fasterxml.jackson.databind.ser.std.DateSerializer((java.lang.Boolean) true, dateFormat2);
        boolean boolean4 = dateSerializer3.usesObjectId();
        boolean boolean5 = dateSerializer3.usesObjectId();
        java.util.Date date6 = null;
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        tokenBuffer8.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter10 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator11 = tokenBuffer8.setPrettyPrinter(prettyPrinter10);
        tokenBuffer8.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec14 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer15 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec14);
        com.fasterxml.jackson.databind.JavaType javaType16 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer18 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer19 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer20 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType16, false, typeSerializer18, objJsonSerializer19);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider21 = null;
        java.lang.reflect.Type type22 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode23 = objectArraySerializer20.getSchema(serializerProvider21, type22);
        java.math.BigInteger bigInteger24 = jsonNode23.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode25 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger24);
        short short26 = bigIntegerNode25.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode28 = bigIntegerNode25.get(100);
        java.math.BigDecimal bigDecimal29 = bigIntegerNode25.decimalValue();
        tokenBuffer15.writeNumber(bigDecimal29);
        tokenBuffer8.writeNumberField("hi!", bigDecimal29);
        com.fasterxml.jackson.databind.JavaType javaType32 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer34 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer35 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer36 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType32, false, typeSerializer34, objJsonSerializer35);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider37 = null;
        java.lang.reflect.Type type38 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode39 = objectArraySerializer36.getSchema(serializerProvider37, type38);
        com.fasterxml.jackson.databind.JsonNode jsonNode41 = jsonNode39.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser42 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode39);
        long long44 = treeTraversingParser42.nextLongValue((long) 100);
        java.lang.String str45 = treeTraversingParser42.getText();
        java.io.Writer writer46 = null;
        int int47 = treeTraversingParser42.releaseBuffered(writer46);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext48 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer49 = tokenBuffer8.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser42, deserializationContext48);
        tokenBuffer8.writeNull();
        tokenBuffer8.writeNullField("enum");
        boolean boolean53 = tokenBuffer8.canWriteTypeId();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider54 = null;
        dateSerializer3.serialize(date6, (com.fasterxml.jackson.core.JsonGenerator) tokenBuffer8, serializerProvider54);
        org.junit.Assert.assertNotNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(jsonGenerator11);
        org.junit.Assert.assertNotNull(jsonNode23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigIntegerNode25);
        org.junit.Assert.assertTrue("'" + short26 + "' != '" + (short) 0 + "'", short26 == (short) 0);
        org.junit.Assert.assertNull(jsonNode28);
        org.junit.Assert.assertNotNull(bigDecimal29);
        org.junit.Assert.assertNotNull(jsonNode39);
        org.junit.Assert.assertNotNull(jsonNode41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 100L + "'", long44 == 100L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{" + "'", str45.equals("{"));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ObjectNode objectNode8 = arrayNode6.insertObject((-1));
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode11 = arrayNode6.insert((int) '#', "com.fasterxml.jackson.databind.exc.InvalidFormatException: ");
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode14 = arrayNode6.insert(16401, (float) '#');
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode17 = arrayNode6.insert((int) (byte) 10, "java.lang.Integer");
        com.fasterxml.jackson.databind.node.ObjectNode objectNode19 = arrayNode17.findParent("{type: [simple type, class java.lang.Object], typed? false}");
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        tokenBuffer21.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter23 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator24 = tokenBuffer21.setPrettyPrinter(prettyPrinter23);
        tokenBuffer21.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes26 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator27 = tokenBuffer21.setCharacterEscapes(characterEscapes26);
        com.fasterxml.jackson.core.ObjectCodec objectCodec28 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator29 = tokenBuffer21.setCodec(objectCodec28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer31 = null;
        try {
            arrayNode17.serializeWithType(jsonGenerator29, serializerProvider30, typeSerializer31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(objectNode8);
        org.junit.Assert.assertNotNull(arrayNode11);
        org.junit.Assert.assertNotNull(arrayNode14);
        org.junit.Assert.assertNotNull(arrayNode17);
        org.junit.Assert.assertNull(objectNode19);
        org.junit.Assert.assertNotNull(jsonGenerator24);
        org.junit.Assert.assertNotNull(jsonGenerator27);
        org.junit.Assert.assertNotNull(jsonGenerator29);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        com.fasterxml.jackson.core.Base64Variant base64Variant5 = null;
        byte[] byteArray6 = new byte[] {};
        tokenBuffer1.writeBinary(base64Variant5, byteArray6, 0, (int) (byte) 0);
        tokenBuffer1.writeString("type");
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer14.setPrettyPrinter(prettyPrinter16);
        tokenBuffer14.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        com.fasterxml.jackson.databind.JavaType javaType22 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer24 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer25 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer26 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType22, false, typeSerializer24, objJsonSerializer25);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider27 = null;
        java.lang.reflect.Type type28 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode29 = objectArraySerializer26.getSchema(serializerProvider27, type28);
        java.math.BigInteger bigInteger30 = jsonNode29.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode31 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger30);
        short short32 = bigIntegerNode31.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = bigIntegerNode31.get(100);
        java.math.BigDecimal bigDecimal35 = bigIntegerNode31.decimalValue();
        tokenBuffer21.writeNumber(bigDecimal35);
        tokenBuffer14.writeNumberField("hi!", bigDecimal35);
        com.fasterxml.jackson.databind.JavaType javaType38 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer40 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer41 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer42 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType38, false, typeSerializer40, objJsonSerializer41);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider43 = null;
        java.lang.reflect.Type type44 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode45 = objectArraySerializer42.getSchema(serializerProvider43, type44);
        com.fasterxml.jackson.databind.JsonNode jsonNode47 = jsonNode45.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser48 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode45);
        long long50 = treeTraversingParser48.nextLongValue((long) 100);
        java.lang.String str51 = treeTraversingParser48.getText();
        java.io.Writer writer52 = null;
        int int53 = treeTraversingParser48.releaseBuffered(writer52);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext54 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer55 = tokenBuffer14.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser48, deserializationContext54);
        tokenBuffer14.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType57 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer59 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer60 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer61 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType57, false, typeSerializer59, objJsonSerializer60);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider62 = null;
        java.lang.reflect.Type type63 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode64 = objectArraySerializer61.getSchema(serializerProvider62, type63);
        java.math.BigInteger bigInteger65 = jsonNode64.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode66 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger65);
        short short67 = bigIntegerNode66.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode69 = bigIntegerNode66.get(100);
        java.math.BigDecimal bigDecimal70 = bigIntegerNode66.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode71 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal70);
        boolean boolean72 = decimalNode71.canConvertToLong();
        java.math.BigInteger bigInteger73 = decimalNode71.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken74 = decimalNode71.asToken();
        float float75 = decimalNode71.floatValue();
        tokenBuffer14.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode71);
        com.fasterxml.jackson.core.JsonParser.NumberType numberType77 = decimalNode71.numberType();
        boolean boolean78 = decimalNode71.canConvertToLong();
        java.math.BigDecimal bigDecimal79 = decimalNode71.decimalValue();
        tokenBuffer1.writeNumberField("java.lang.Integer", bigDecimal79);
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[]");
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertNotNull(jsonNode29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigIntegerNode31);
        org.junit.Assert.assertTrue("'" + short32 + "' != '" + (short) 0 + "'", short32 == (short) 0);
        org.junit.Assert.assertNull(jsonNode34);
        org.junit.Assert.assertNotNull(bigDecimal35);
        org.junit.Assert.assertNotNull(jsonNode45);
        org.junit.Assert.assertNotNull(jsonNode47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 100L + "'", long50 == 100L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{" + "'", str51.equals("{"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer55);
        org.junit.Assert.assertNotNull(jsonNode64);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigIntegerNode66);
        org.junit.Assert.assertTrue("'" + short67 + "' != '" + (short) 0 + "'", short67 == (short) 0);
        org.junit.Assert.assertNull(jsonNode69);
        org.junit.Assert.assertNotNull(bigDecimal70);
        org.junit.Assert.assertNotNull(decimalNode71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertTrue("'" + jsonToken74 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken74.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 0.0f + "'", float75 == 0.0f);
        org.junit.Assert.assertTrue("'" + numberType77 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL + "'", numberType77.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(bigDecimal79);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec7 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer8 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec7);
        com.fasterxml.jackson.databind.JavaType javaType9 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer12 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer13 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType9, false, typeSerializer11, objJsonSerializer12);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        java.lang.reflect.Type type15 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode16 = objectArraySerializer13.getSchema(serializerProvider14, type15);
        java.math.BigInteger bigInteger17 = jsonNode16.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode18 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger17);
        short short19 = bigIntegerNode18.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode21 = bigIntegerNode18.get(100);
        java.math.BigDecimal bigDecimal22 = bigIntegerNode18.decimalValue();
        tokenBuffer8.writeNumber(bigDecimal22);
        tokenBuffer1.writeNumberField("hi!", bigDecimal22);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.databind.JsonNode jsonNode34 = jsonNode32.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser35 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode32);
        long long37 = treeTraversingParser35.nextLongValue((long) 100);
        java.lang.String str38 = treeTraversingParser35.getText();
        java.io.Writer writer39 = null;
        int int40 = treeTraversingParser35.releaseBuffered(writer39);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext41 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer42 = tokenBuffer1.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser35, deserializationContext41);
        tokenBuffer1.writeNull();
        com.fasterxml.jackson.databind.JavaType javaType44 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer46 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer47 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer48 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType44, false, typeSerializer46, objJsonSerializer47);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider49 = null;
        java.lang.reflect.Type type50 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode51 = objectArraySerializer48.getSchema(serializerProvider49, type50);
        java.math.BigInteger bigInteger52 = jsonNode51.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode53 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger52);
        short short54 = bigIntegerNode53.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = bigIntegerNode53.get(100);
        java.math.BigDecimal bigDecimal57 = bigIntegerNode53.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode58 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal57);
        boolean boolean59 = decimalNode58.canConvertToLong();
        java.math.BigInteger bigInteger60 = decimalNode58.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken61 = decimalNode58.asToken();
        float float62 = decimalNode58.floatValue();
        tokenBuffer1.writeTree((com.fasterxml.jackson.core.TreeNode) decimalNode58);
        com.fasterxml.jackson.core.JsonParser.NumberType numberType64 = decimalNode58.numberType();
        boolean boolean65 = decimalNode58.canConvertToLong();
        java.math.BigDecimal bigDecimal66 = decimalNode58.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode67 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal66);
        java.math.BigInteger bigInteger68 = decimalNode67.bigIntegerValue();
        com.fasterxml.jackson.core.JsonParser.NumberType numberType69 = decimalNode67.numberType();
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(jsonNode16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigIntegerNode18);
        org.junit.Assert.assertTrue("'" + short19 + "' != '" + (short) 0 + "'", short19 == (short) 0);
        org.junit.Assert.assertNull(jsonNode21);
        org.junit.Assert.assertNotNull(bigDecimal22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(jsonNode34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "{" + "'", str38.equals("{"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(tokenBuffer42);
        org.junit.Assert.assertNotNull(jsonNode51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigIntegerNode53);
        org.junit.Assert.assertTrue("'" + short54 + "' != '" + (short) 0 + "'", short54 == (short) 0);
        org.junit.Assert.assertNull(jsonNode56);
        org.junit.Assert.assertNotNull(bigDecimal57);
        org.junit.Assert.assertNotNull(decimalNode58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertTrue("'" + jsonToken61 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken61.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float62 + "' != '" + 0.0f + "'", float62 == 0.0f);
        org.junit.Assert.assertTrue("'" + numberType64 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL + "'", numberType64.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(bigDecimal66);
        org.junit.Assert.assertNotNull(decimalNode67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertTrue("'" + numberType69 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL + "'", numberType69.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        tokenBuffer1.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec6 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer7 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec6);
        tokenBuffer7.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter9 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator10 = tokenBuffer7.setPrettyPrinter(prettyPrinter9);
        tokenBuffer7.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        com.fasterxml.jackson.databind.JavaType javaType15 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer17 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer18 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer19 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType15, false, typeSerializer17, objJsonSerializer18);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        java.lang.reflect.Type type21 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode22 = objectArraySerializer19.getSchema(serializerProvider20, type21);
        java.math.BigInteger bigInteger23 = jsonNode22.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode24 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger23);
        short short25 = bigIntegerNode24.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode27 = bigIntegerNode24.get(100);
        java.math.BigDecimal bigDecimal28 = bigIntegerNode24.decimalValue();
        tokenBuffer14.writeNumber(bigDecimal28);
        tokenBuffer7.writeNumberField("hi!", bigDecimal28);
        boolean boolean31 = tokenBuffer7.canWriteObjectId();
        tokenBuffer7.writeNullField("");
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer7);
        com.fasterxml.jackson.core.ObjectCodec objectCodec35 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer36 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec35);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter37 = tokenBuffer36.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser38 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException40 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser38, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference43 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException40.prependPath(reference43);
        tokenBuffer36.writeTypeId((java.lang.Object) reference43);
        reference43.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer7.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType49 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer51 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer52 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer53 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType49, false, typeSerializer51, objJsonSerializer52);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider54 = null;
        java.lang.reflect.Type type55 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode56 = objectArraySerializer53.getSchema(serializerProvider54, type55);
        com.fasterxml.jackson.databind.JsonNode jsonNode58 = jsonNode56.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser59 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode56);
        long long61 = treeTraversingParser59.nextLongValue((long) 100);
        int int62 = treeTraversingParser59.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext63 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer64 = tokenBuffer7.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser59, deserializationContext63);
        tokenBuffer64.writeNullField("enum");
        com.fasterxml.jackson.core.ObjectCodec objectCodec67 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer68 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec67);
        tokenBuffer68.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter70 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator71 = tokenBuffer68.setPrettyPrinter(prettyPrinter70);
        tokenBuffer68.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator74 = tokenBuffer68.setFeatureMask((int) '4');
        tokenBuffer68.writeNumber((short) (byte) 0);
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer77 = tokenBuffer64.append(tokenBuffer68);
        com.fasterxml.jackson.databind.JavaType javaType78 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer80 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer81 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer82 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType78, false, typeSerializer80, objJsonSerializer81);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider83 = null;
        java.lang.reflect.Type type84 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode85 = objectArraySerializer82.getSchema(serializerProvider83, type84);
        java.math.BigInteger bigInteger86 = jsonNode85.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode87 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger86);
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode88 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger86);
        tokenBuffer68.writeNumber(bigInteger86);
        org.junit.Assert.assertNotNull(jsonGenerator10);
        org.junit.Assert.assertNotNull(jsonNode22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigIntegerNode24);
        org.junit.Assert.assertTrue("'" + short25 + "' != '" + (short) 0 + "'", short25 == (short) 0);
        org.junit.Assert.assertNull(jsonNode27);
        org.junit.Assert.assertNotNull(bigDecimal28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(prettyPrinter37);
        org.junit.Assert.assertNotNull(jsonMappingException40);
        org.junit.Assert.assertNotNull(jsonNode56);
        org.junit.Assert.assertNotNull(jsonNode58);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 100L + "'", long61 == 100L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer64);
        org.junit.Assert.assertNotNull(jsonGenerator71);
        org.junit.Assert.assertNotNull(jsonGenerator74);
        org.junit.Assert.assertNotNull(tokenBuffer77);
        org.junit.Assert.assertNotNull(jsonNode85);
        org.junit.Assert.assertNotNull(bigInteger86);
        org.junit.Assert.assertNotNull(bigIntegerNode87);
        org.junit.Assert.assertNotNull(bigIntegerNode88);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.fasterxml.jackson.core.ObjectCodec objectCodec0 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer1 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec0);
        tokenBuffer1.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter3 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenBuffer1.setPrettyPrinter(prettyPrinter3);
        tokenBuffer1.writeNull();
        tokenBuffer1.writeBoolean(true);
        com.fasterxml.jackson.databind.node.ShortNode shortNode9 = com.fasterxml.jackson.databind.node.ShortNode.valueOf((short) (byte) 10);
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        tokenBuffer11.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer11.setPrettyPrinter(prettyPrinter13);
        tokenBuffer11.writeNull();
        com.fasterxml.jackson.core.io.CharacterEscapes characterEscapes16 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator17 = tokenBuffer11.setCharacterEscapes(characterEscapes16);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider18 = null;
        shortNode9.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer11, serializerProvider18);
        java.lang.String str20 = tokenBuffer11.toString();
        tokenBuffer1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer11);
        tokenBuffer11.writeString("type");
        org.junit.Assert.assertNotNull(jsonGenerator4);
        org.junit.Assert.assertNotNull(shortNode9);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(jsonGenerator17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]" + "'", str20.equals("[TokenBuffer: VALUE_NULL, VALUE_NUMBER_INT]"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.fasterxml.jackson.databind.JavaType javaType0 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer2 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer3 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer4 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType0, false, typeSerializer2, objJsonSerializer3);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider5 = null;
        java.lang.reflect.Type type6 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode7 = objectArraySerializer4.getSchema(serializerProvider5, type6);
        java.math.BigInteger bigInteger8 = jsonNode7.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode9 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger8);
        short short10 = bigIntegerNode9.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode12 = bigIntegerNode9.get(100);
        java.math.BigDecimal bigDecimal13 = bigIntegerNode9.decimalValue();
        com.fasterxml.jackson.databind.node.DecimalNode decimalNode14 = com.fasterxml.jackson.databind.node.DecimalNode.valueOf(bigDecimal13);
        boolean boolean15 = decimalNode14.canConvertToLong();
        java.math.BigInteger bigInteger16 = decimalNode14.bigIntegerValue();
        com.fasterxml.jackson.core.JsonToken jsonToken17 = decimalNode14.asToken();
        float float18 = decimalNode14.floatValue();
        boolean boolean19 = decimalNode14.isFloatingPointNumber();
        com.fasterxml.jackson.core.ObjectCodec objectCodec20 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer21 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec20);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter22 = tokenBuffer21.getPrettyPrinter();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider23 = null;
        decimalNode14.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer21, serializerProvider23);
        com.fasterxml.jackson.databind.JavaType javaType25 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer27 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer28 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer29 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType25, false, typeSerializer27, objJsonSerializer28);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider30 = null;
        java.lang.reflect.Type type31 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode32 = objectArraySerializer29.getSchema(serializerProvider30, type31);
        com.fasterxml.jackson.core.JsonFactory jsonFactory33 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper34 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory33);
        com.fasterxml.jackson.core.JsonFactory jsonFactory35 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper36 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory35);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes37 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader38 = objectMapper36.reader(contextAttributes37);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory39 = objectMapper36.getTypeFactory();
        com.fasterxml.jackson.databind.MapperFeature[] mapperFeatureArray40 = new com.fasterxml.jackson.databind.MapperFeature[] {};
        com.fasterxml.jackson.databind.ObjectMapper objectMapper41 = objectMapper36.enable(mapperFeatureArray40);
        com.fasterxml.jackson.databind.ObjectMapper objectMapper42 = objectMapper34.enable(mapperFeatureArray40);
        com.fasterxml.jackson.core.ObjectCodec objectCodec43 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer44 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec43);
        tokenBuffer44.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter46 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator47 = tokenBuffer44.setPrettyPrinter(prettyPrinter46);
        tokenBuffer44.writeNull();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator50 = tokenBuffer44.setFeatureMask((int) '4');
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider51 = null;
        objectArraySerializer29.serializeContents((java.lang.Object[]) mapperFeatureArray40, jsonGenerator50, serializerProvider51);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider53 = null;
        decimalNode14.serialize(jsonGenerator50, serializerProvider53);
        org.junit.Assert.assertNotNull(jsonNode7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigIntegerNode9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertNull(jsonNode12);
        org.junit.Assert.assertNotNull(bigDecimal13);
        org.junit.Assert.assertNotNull(decimalNode14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertTrue("'" + jsonToken17 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken17.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(prettyPrinter22);
        org.junit.Assert.assertNotNull(jsonNode32);
        org.junit.Assert.assertNotNull(objectReader38);
        org.junit.Assert.assertNotNull(typeFactory39);
        org.junit.Assert.assertNotNull(mapperFeatureArray40);
        org.junit.Assert.assertNotNull(objectMapper41);
        org.junit.Assert.assertNotNull(objectMapper42);
        org.junit.Assert.assertNotNull(jsonGenerator47);
        org.junit.Assert.assertNotNull(jsonGenerator50);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.fasterxml.jackson.databind.node.IntNode intNode1 = com.fasterxml.jackson.databind.node.IntNode.valueOf((int) (short) 100);
        com.fasterxml.jackson.core.ObjectCodec objectCodec2 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer3 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec2);
        tokenBuffer3.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = tokenBuffer3.setPrettyPrinter(prettyPrinter5);
        tokenBuffer3.writeNull();
        tokenBuffer3.writeBoolean(true);
        tokenBuffer3.writeNumberField("com.fasterxml.jackson.databind.MapperFeature", (long) '#');
        com.fasterxml.jackson.core.JsonToken jsonToken13 = tokenBuffer3.firstToken();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider14 = null;
        intNode1.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer3, serializerProvider14);
        float float16 = intNode1.floatValue();
        boolean boolean17 = intNode1.isInt();
        java.lang.Number number18 = intNode1.numberValue();
        float float19 = intNode1.floatValue();
        org.junit.Assert.assertNotNull(intNode1);
        org.junit.Assert.assertNotNull(jsonGenerator6);
        org.junit.Assert.assertTrue("'" + jsonToken13 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken13.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 100.0f + "'", float16 == 100.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100 + "'", number18.equals(100));
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 100.0f + "'", float19 == 100.0f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes2 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader3 = objectMapper1.reader(contextAttributes2);
        com.fasterxml.jackson.databind.JsonNode jsonNode4 = objectReader3.createArrayNode();
        com.fasterxml.jackson.core.JsonFactory jsonFactory5 = objectReader3.getJsonFactory();
        boolean boolean6 = jsonFactory5.canUseCharArrays();
        com.fasterxml.jackson.core.JsonParser jsonParser8 = jsonFactory5.createJsonParser("[parameter #97, annotations: null]");
        boolean boolean9 = jsonFactory5.requiresPropertyOrdering();
        com.fasterxml.jackson.core.ObjectCodec objectCodec10 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer11 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec10);
        tokenBuffer11.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter13 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator14 = tokenBuffer11.setPrettyPrinter(prettyPrinter13);
        com.fasterxml.jackson.core.Base64Variant base64Variant15 = null;
        byte[] byteArray16 = new byte[] {};
        tokenBuffer11.writeBinary(base64Variant15, byteArray16, 0, (int) (byte) 0);
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode22 = com.fasterxml.jackson.databind.node.BinaryNode.valueOf(byteArray16, (int) (short) 0, 0);
        com.fasterxml.jackson.databind.node.JsonNodeType jsonNodeType23 = binaryNode22.getNodeType();
        byte[] byteArray24 = binaryNode22.binaryValue();
        com.fasterxml.jackson.databind.node.BinaryNode binaryNode25 = new com.fasterxml.jackson.databind.node.BinaryNode(byteArray24);
        com.fasterxml.jackson.core.JsonParser jsonParser28 = jsonFactory5.createJsonParser(byteArray24, 10, 0);
        com.fasterxml.jackson.core.JsonParser.Feature feature29 = null;
        try {
            com.fasterxml.jackson.core.JsonFactory jsonFactory30 = jsonFactory5.enable(feature29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectReader3);
        org.junit.Assert.assertNotNull(jsonNode4);
        org.junit.Assert.assertNotNull(jsonFactory5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(jsonParser8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jsonGenerator14);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray16), "[]");
        org.junit.Assert.assertNotNull(binaryNode22);
        org.junit.Assert.assertTrue("'" + jsonNodeType23 + "' != '" + com.fasterxml.jackson.databind.node.JsonNodeType.BINARY + "'", jsonNodeType23.equals(com.fasterxml.jackson.databind.node.JsonNodeType.BINARY));
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray24), "[]");
        org.junit.Assert.assertNotNull(jsonParser28);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.fasterxml.jackson.core.JsonFactory jsonFactory0 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper1 = new com.fasterxml.jackson.databind.ObjectMapper(jsonFactory0);
        java.lang.String str3 = objectMapper1.writeValueAsString((java.lang.Object) 1L);
        com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider4 = null;
        com.fasterxml.jackson.databind.ObjectMapper objectMapper5 = objectMapper1.setSerializerProvider(defaultSerializerProvider4);
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = objectMapper5.createArrayNode();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode9 = arrayNode6.insert(16401, "hi!");
        java.util.Iterator<com.fasterxml.jackson.databind.JsonNode> jsonNodeItor10 = arrayNode6.elements();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode12 = arrayNode6.add(0.0d);
        com.fasterxml.jackson.core.ObjectCodec objectCodec13 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer14 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec13);
        tokenBuffer14.flush();
        tokenBuffer14.writeNumberField("", 100L);
        com.fasterxml.jackson.core.ObjectCodec objectCodec19 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer20 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec19);
        tokenBuffer20.flush();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter22 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator23 = tokenBuffer20.setPrettyPrinter(prettyPrinter22);
        tokenBuffer20.writeNull();
        com.fasterxml.jackson.core.ObjectCodec objectCodec26 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer27 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec26);
        com.fasterxml.jackson.databind.JavaType javaType28 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer30 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer31 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer32 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType28, false, typeSerializer30, objJsonSerializer31);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider33 = null;
        java.lang.reflect.Type type34 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode35 = objectArraySerializer32.getSchema(serializerProvider33, type34);
        java.math.BigInteger bigInteger36 = jsonNode35.bigIntegerValue();
        com.fasterxml.jackson.databind.node.BigIntegerNode bigIntegerNode37 = com.fasterxml.jackson.databind.node.BigIntegerNode.valueOf(bigInteger36);
        short short38 = bigIntegerNode37.shortValue();
        com.fasterxml.jackson.databind.JsonNode jsonNode40 = bigIntegerNode37.get(100);
        java.math.BigDecimal bigDecimal41 = bigIntegerNode37.decimalValue();
        tokenBuffer27.writeNumber(bigDecimal41);
        tokenBuffer20.writeNumberField("hi!", bigDecimal41);
        boolean boolean44 = tokenBuffer20.canWriteObjectId();
        tokenBuffer20.writeNullField("");
        tokenBuffer14.serialize((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer20);
        com.fasterxml.jackson.core.ObjectCodec objectCodec48 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer49 = new com.fasterxml.jackson.databind.util.TokenBuffer(objectCodec48);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter50 = tokenBuffer49.getPrettyPrinter();
        com.fasterxml.jackson.core.JsonParser jsonParser51 = null;
        com.fasterxml.jackson.databind.JsonMappingException jsonMappingException53 = com.fasterxml.jackson.databind.JsonMappingException.from(jsonParser51, "");
        com.fasterxml.jackson.databind.JsonMappingException.Reference reference56 = new com.fasterxml.jackson.databind.JsonMappingException.Reference((java.lang.Object) (short) 100, "hi!");
        jsonMappingException53.prependPath(reference56);
        tokenBuffer49.writeTypeId((java.lang.Object) reference56);
        reference56.setFieldName("java.lang.Short[\"hi!\"]");
        tokenBuffer20.writeObject((java.lang.Object) "java.lang.Short[\"hi!\"]");
        com.fasterxml.jackson.databind.JavaType javaType62 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer64 = null;
        com.fasterxml.jackson.databind.JsonSerializer<java.lang.Object> objJsonSerializer65 = null;
        com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer objectArraySerializer66 = new com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer(javaType62, false, typeSerializer64, objJsonSerializer65);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider67 = null;
        java.lang.reflect.Type type68 = null;
        com.fasterxml.jackson.databind.JsonNode jsonNode69 = objectArraySerializer66.getSchema(serializerProvider67, type68);
        com.fasterxml.jackson.databind.JsonNode jsonNode71 = jsonNode69.withArray("");
        com.fasterxml.jackson.databind.node.TreeTraversingParser treeTraversingParser72 = new com.fasterxml.jackson.databind.node.TreeTraversingParser(jsonNode69);
        long long74 = treeTraversingParser72.nextLongValue((long) 100);
        int int75 = treeTraversingParser72.getTextOffset();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext76 = null;
        com.fasterxml.jackson.databind.util.TokenBuffer tokenBuffer77 = tokenBuffer20.deserialize((com.fasterxml.jackson.core.JsonParser) treeTraversingParser72, deserializationContext76);
        tokenBuffer77.writeNullField("enum");
        int int80 = tokenBuffer77.getHighestEscapedChar();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider81 = null;
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer82 = null;
        try {
            arrayNode12.serializeWithType((com.fasterxml.jackson.core.JsonGenerator) tokenBuffer77, serializerProvider81, typeSerializer82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertNotNull(objectMapper5);
        org.junit.Assert.assertNotNull(arrayNode6);
        org.junit.Assert.assertNotNull(arrayNode9);
        org.junit.Assert.assertNotNull(jsonNodeItor10);
        org.junit.Assert.assertNotNull(arrayNode12);
        org.junit.Assert.assertNotNull(jsonGenerator23);
        org.junit.Assert.assertNotNull(jsonNode35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigIntegerNode37);
        org.junit.Assert.assertTrue("'" + short38 + "' != '" + (short) 0 + "'", short38 == (short) 0);
        org.junit.Assert.assertNull(jsonNode40);
        org.junit.Assert.assertNotNull(bigDecimal41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(prettyPrinter50);
        org.junit.Assert.assertNotNull(jsonMappingException53);
        org.junit.Assert.assertNotNull(jsonNode69);
        org.junit.Assert.assertNotNull(jsonNode71);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 100L + "'", long74 == 100L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(tokenBuffer77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

}
