import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0045");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream1 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream(outputStream0);
        java.io.InputStream inputStream2 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream2, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream5 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream4);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream6 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream4);
        tarArchiveInputStream4.close();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream4, (int) (byte) 10);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry10 = tarArchiveInputStream9.getNextEntry();
        tarArchiveInputStream9.reset();
        java.io.InputStream inputStream12 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream14 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream12, 1);
        tarArchiveInputStream14.reset();
        java.io.InputStream inputStream16 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream18 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream16, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream18);
        java.io.OutputStream outputStream20 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream18, outputStream20);
        java.io.OutputStream outputStream22 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream22, 0);
        tarArchiveInputStream18.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream24);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream14, (java.io.OutputStream) tarArchiveOutputStream24);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream27 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream14);
        java.io.InputStream inputStream28 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream30 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream28, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream30);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream32 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream30);
        byte[] byteArray34 = new byte[] { (byte) 0 };
        int int35 = jarArchiveInputStream32.read(byteArray34);
        boolean boolean37 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray34, 512);
        boolean boolean39 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray34, (int) (byte) 10);
        int int42 = arArchiveInputStream27.read(byteArray34, (int) (short) 10, (int) ' ');
        int int43 = arArchiveInputStream27.read();
        java.io.InputStream inputStream44 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream46 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream44, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream47 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream46);
        byte[] byteArray48 = new byte[] {};
        int int51 = tarArchiveInputStream47.read(byteArray48, 0, (int) (byte) 100);
        int int54 = arArchiveInputStream27.read(byteArray48, 0, 2048);
        java.io.InputStream inputStream55 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream57 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream55, 1);
        tarArchiveInputStream57.reset();
        java.io.InputStream inputStream59 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream61 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream59, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream62 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream61);
        java.io.OutputStream outputStream63 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream61, outputStream63);
        java.io.OutputStream outputStream65 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream67 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream65, 0);
        tarArchiveInputStream61.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream67);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream57, (java.io.OutputStream) tarArchiveOutputStream67);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream70 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream57);
        java.io.InputStream inputStream71 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream73 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream71, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream74 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream73);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream75 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream73);
        byte[] byteArray77 = new byte[] { (byte) 0 };
        int int78 = jarArchiveInputStream75.read(byteArray77);
        boolean boolean80 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray77, 512);
        boolean boolean82 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray77, (int) (byte) 10);
        int int85 = arArchiveInputStream70.read(byteArray77, (int) (short) 10, (int) ' ');
        boolean boolean87 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray77, (int) (short) -1);
        int int88 = arArchiveInputStream27.read(byteArray77);
        int int89 = tarArchiveInputStream9.read(byteArray77);
        try {
            cpioArchiveOutputStream1.write(byteArray77, 512, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(archiveEntry10);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray34), "[0]");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray48), "[]");
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(byteArray77);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray77), "[0]");
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test0179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0179");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream1 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream(outputStream0);
        org.apache.commons.compress.archivers.cpio.CpioArchiveEntry cpioArchiveEntry4 = new org.apache.commons.compress.archivers.cpio.CpioArchiveEntry("", (long) 1);
        long long5 = cpioArchiveEntry4.getDeviceMaj();
        cpioArchiveEntry4.setDeviceMin((long) 10);
        boolean boolean8 = cpioArchiveEntry4.isCharacterDevice();
        long long9 = cpioArchiveEntry4.getChksum();
        cpioArchiveEntry4.setDeviceMin((long) 128);
        cpioArchiveEntry4.setRemoteDeviceMin((long) 128);
        long long14 = cpioArchiveEntry4.getSize();
        long long15 = cpioArchiveEntry4.getRemoteDeviceMin();
        boolean boolean16 = cpioArchiveEntry4.isNetwork();
        short short17 = cpioArchiveEntry4.getFormat();
        try {
            cpioArchiveOutputStream1.putNextEntry(cpioArchiveEntry4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 128L + "'", long15 == 128L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + short17 + "' != '" + (short) 1 + "'", short17 == (short) 1);
    }

    @Test
    public void test0731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0731");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream2 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream(outputStream0, (short) 2);
    }

    @Test
    public void test1187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1187");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        zipArchiveOutputStream7.setMethod((int) (short) 0);
        zipArchiveOutputStream7.setLevel((int) (short) 0);
        zipArchiveOutputStream7.closeEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy13 = null;
        zipArchiveOutputStream7.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy13);
        zipArchiveOutputStream7.closeArchiveEntry();
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream16 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream7);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream17 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) arArchiveOutputStream16);
        java.io.InputStream inputStream18 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream18, (int) (byte) 100);
        java.io.OutputStream outputStream21 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream23 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream21, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream21, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream27 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream25, (int) (short) 10);
        byte[] byteArray28 = new byte[] {};
        tarArchiveOutputStream27.write(byteArray28);
        tarArchiveInputStream20.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream27);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream31 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream20);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream32 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream31);
        long long34 = arArchiveInputStream31.skip((long) (short) 1);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream35 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) arArchiveInputStream31);
        long long37 = cpioArchiveInputStream35.skip(0L);
        cpioArchiveInputStream35.closeEntry();
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream39, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream42 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream41);
        cpioArchiveInputStream42.closeEntry();
        byte[] byteArray47 = new byte[] { (byte) -1, (byte) 100, (byte) 10 };
        boolean boolean49 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray47, 0);
        boolean boolean51 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray47, (int) '#');
        boolean boolean53 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray47, 1);
        boolean boolean55 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray47, (int) (byte) 1);
        int int58 = cpioArchiveInputStream42.read(byteArray47, (int) (short) 1, (int) (short) 1);
        boolean boolean60 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray47, (int) (byte) 100);
        int int63 = cpioArchiveInputStream35.read(byteArray47, (int) (byte) 1, (int) (byte) 0);
        byte[] byteArray66 = new byte[] { (byte) 10, (byte) -1 };
        boolean boolean68 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray66, (-1));
        int int71 = cpioArchiveInputStream35.read(byteArray66, (int) (short) 0, (int) (byte) 1);
        try {
            arArchiveOutputStream16.write(byteArray66, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray28), "[]");
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray47), "[-1, 100, 10]");
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray66), "[10, -1]");
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
    }

    @Test
    public void test1296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1296");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        java.io.OutputStream outputStream3 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream5 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream7, (int) (short) 10);
        byte[] byteArray10 = new byte[] {};
        tarArchiveOutputStream9.write(byteArray10);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream9);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream13 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream9);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream14 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream13);
        java.io.InputStream inputStream15 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream17 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream15, (int) (byte) 100);
        int int18 = tarArchiveInputStream17.available();
        byte[] byteArray22 = new byte[] { (byte) -1, (byte) 100, (byte) 10 };
        boolean boolean24 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray22, 0);
        boolean boolean26 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray22, (int) '#');
        boolean boolean28 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray22, 1);
        boolean boolean30 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray22, (int) '#');
        boolean boolean32 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray22, (int) (byte) 10);
        int int35 = tarArchiveInputStream17.read(byteArray22, (int) (byte) -1, (int) 'a');
        try {
            arArchiveOutputStream14.write(byteArray22);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: no current CPIO entry");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[]");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[-1, 100, 10]");
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test1342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1342");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        java.io.OutputStream outputStream3 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream5 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream7, (int) (short) 10);
        byte[] byteArray10 = new byte[] {};
        tarArchiveOutputStream9.write(byteArray10);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream9);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream13 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream14 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream13);
        int int15 = arArchiveInputStream14.read();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry16 = arArchiveInputStream14.getNextEntry();
        org.apache.commons.compress.archivers.ar.ArArchiveEntry arArchiveEntry17 = arArchiveInputStream14.getNextArEntry();
        java.io.InputStream inputStream18 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream18, (int) (byte) 100);
        int int21 = tarArchiveInputStream20.available();
        java.io.InputStream inputStream22 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream22, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream25 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream24);
        cpioArchiveInputStream25.closeEntry();
        byte[] byteArray33 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int36 = cpioArchiveInputStream25.read(byteArray33, (int) (byte) 1, 0);
        int int37 = tarArchiveInputStream20.read(byteArray33);
        java.io.InputStream inputStream38 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream40 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream38, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream41 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream40);
        cpioArchiveInputStream41.closeEntry();
        byte[] byteArray49 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int52 = cpioArchiveInputStream41.read(byteArray49, (int) (byte) 1, 0);
        int int55 = tarArchiveInputStream20.read(byteArray49, (int) '4', (int) '4');
        boolean boolean57 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray49, (int) (byte) 100);
        int int58 = arArchiveInputStream14.read(byteArray49);
        java.io.InputStream inputStream59 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream61 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream59, (int) (byte) 100);
        java.io.OutputStream outputStream62 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream64 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream62, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream66 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream62, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream68 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream66, (int) (short) 10);
        byte[] byteArray69 = new byte[] {};
        tarArchiveOutputStream68.write(byteArray69);
        tarArchiveInputStream61.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream68);
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream72 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream68);
        jarArchiveOutputStream72.closeArchiveEntry();
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) arArchiveInputStream14, (java.io.OutputStream) jarArchiveOutputStream72, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream76 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) jarArchiveOutputStream72);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream77 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream76);
        org.apache.commons.compress.archivers.cpio.CpioArchiveEntry cpioArchiveEntry80 = new org.apache.commons.compress.archivers.cpio.CpioArchiveEntry("hi!", (long) (short) 10);
        long long81 = cpioArchiveEntry80.getNumberOfLinks();
        long long82 = cpioArchiveEntry80.getDeviceMin();
        cpioArchiveEntry80.setChksum((long) 10);
        cpioArchiveEntry80.setMode((long) 10);
        long long87 = cpioArchiveEntry80.getDeviceMaj();
        try {
            cpioArchiveOutputStream77.putArchiveEntry((org.apache.commons.compress.archivers.ArchiveEntry) cpioArchiveEntry80);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: request to write '1' bytes exceeds size in header of '0' bytes for entry 'null'");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[]");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(archiveEntry16);
        org.junit.Assert.assertNull(arArchiveEntry17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(byteArray33);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray33), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray49), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(byteArray69);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray69), "[]");
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 0L + "'", long87 == 0L);
    }

    @Test
    public void test1486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1486");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream3 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        cpioArchiveInputStream3.closeEntry();
        cpioArchiveInputStream3.closeEntry();
        long long7 = cpioArchiveInputStream3.skip((long) 1);
        java.io.OutputStream outputStream8 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream10 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream8, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream12 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream8, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream14 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream12, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream15 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream12);
        tarArchiveOutputStream12.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream18 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream12, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream19 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream18);
        arArchiveOutputStream19.closeArchiveEntry();
        arArchiveOutputStream19.flush();
        java.io.InputStream inputStream22 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream22, (int) (byte) 100);
        java.io.OutputStream outputStream25 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream27 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream25, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream25, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream29, (int) (short) 10);
        byte[] byteArray32 = new byte[] {};
        tarArchiveOutputStream31.write(byteArray32);
        tarArchiveInputStream24.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream31);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream35 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream24);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream36 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream35);
        int int37 = arArchiveInputStream36.read();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry38 = arArchiveInputStream36.getNextEntry();
        java.io.OutputStream outputStream39 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream39, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream43 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream39, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream45 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream43, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream46 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream43);
        tarArchiveOutputStream43.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream49 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream43, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream50 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream49);
        java.io.InputStream inputStream51 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream53 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream51, (int) (byte) 100);
        java.io.OutputStream outputStream54 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream56 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream54, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream58 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream54, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream60 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream58, (int) (short) 10);
        byte[] byteArray61 = new byte[] {};
        tarArchiveOutputStream60.write(byteArray61);
        tarArchiveInputStream53.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream60);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream64 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream53);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream65 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream64);
        byte[] byteArray66 = new byte[] {};
        int int69 = arArchiveInputStream65.read(byteArray66, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream50.write(byteArray66);
        java.io.InputStream inputStream71 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream73 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream71, (int) (byte) 100);
        java.io.OutputStream outputStream74 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream76 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream74, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream78 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream74, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream80 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream78, (int) (short) 10);
        byte[] byteArray81 = new byte[] {};
        tarArchiveOutputStream80.write(byteArray81);
        tarArchiveInputStream73.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream80);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream84 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream73);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream85 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream84);
        byte[] byteArray86 = new byte[] {};
        int int89 = arArchiveInputStream85.read(byteArray86, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream50.write(byteArray86);
        int int93 = arArchiveInputStream36.read(byteArray86, (int) (short) -1, (int) (byte) -1);
        arArchiveOutputStream19.write(byteArray86);
        try {
            int int97 = cpioArchiveInputStream3.read(byteArray86, (int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray32), "[]");
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(archiveEntry38);
        org.junit.Assert.assertNotNull(byteArray61);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray61), "[]");
        org.junit.Assert.assertNotNull(byteArray66);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray66), "[]");
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[]");
        org.junit.Assert.assertNotNull(byteArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray86), "[]");
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
    }

}
