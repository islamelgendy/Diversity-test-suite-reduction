import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0112");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        tarArchiveInputStream2.reset();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream4, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream6);
        java.io.OutputStream outputStream8 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream6, outputStream8);
        java.io.OutputStream outputStream10 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream12 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream10, 0);
        tarArchiveInputStream6.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, (java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream16 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream12, 512);
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream17 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream16);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream18 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) jarArchiveOutputStream17);
        java.io.InputStream inputStream19 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream21 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream19, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream22 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream21);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream23 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream21);
        tarArchiveInputStream21.close();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream26 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream21, (int) (byte) 10);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry27 = tarArchiveInputStream26.getNextEntry();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream30 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream26, 0, (int) (short) 100);
        java.io.InputStream inputStream31 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream31, 1);
        tarArchiveInputStream33.reset();
        java.io.InputStream inputStream35 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream37 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream35, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream38 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream37);
        java.io.OutputStream outputStream39 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream37, outputStream39);
        java.io.OutputStream outputStream41 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream43 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream41, 0);
        tarArchiveInputStream37.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream43);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream33, (java.io.OutputStream) tarArchiveOutputStream43);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream46 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream33);
        java.io.InputStream inputStream47 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream49 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream47, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream50 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream49);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream51 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream49);
        byte[] byteArray53 = new byte[] { (byte) 0 };
        int int54 = jarArchiveInputStream51.read(byteArray53);
        boolean boolean56 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray53, 512);
        boolean boolean58 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray53, (int) (byte) 10);
        int int61 = arArchiveInputStream46.read(byteArray53, (int) (short) 10, (int) ' ');
        int int62 = arArchiveInputStream46.read();
        java.io.InputStream inputStream63 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream65 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream63, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream66 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream65);
        byte[] byteArray67 = new byte[] {};
        int int70 = tarArchiveInputStream66.read(byteArray67, 0, (int) (byte) 100);
        int int73 = arArchiveInputStream46.read(byteArray67, 0, 2048);
        java.io.InputStream inputStream74 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream76 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream74, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream77 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream76);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream78 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream76);
        byte[] byteArray80 = new byte[] { (byte) 0 };
        int int81 = jarArchiveInputStream78.read(byteArray80);
        boolean boolean83 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray80, 512);
        boolean boolean85 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray80, (int) (byte) 10);
        boolean boolean87 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray80, (int) (short) 8);
        boolean boolean89 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray80, (int) (byte) 100);
        int int90 = arArchiveInputStream46.read(byteArray80);
        int int91 = tarArchiveInputStream26.read(byteArray80);
        try {
            jarArchiveOutputStream17.write(byteArray80, 49152, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(archiveEntry27);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray53), "[0]");
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray67), "[]");
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(byteArray80);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray80), "[0]");
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
    }

    @Test
    public void test0405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0405");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, 0);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream3 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream(outputStream0);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream5 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) arArchiveOutputStream3, (short) 4);
        arArchiveOutputStream3.closeArchiveEntry();
        java.io.InputStream inputStream7 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream7, 1);
        tarArchiveInputStream9.reset();
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream13 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream11, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream14 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream13);
        java.io.OutputStream outputStream15 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream13, outputStream15);
        java.io.OutputStream outputStream17 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream17, 0);
        tarArchiveInputStream13.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream19);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream9, (java.io.OutputStream) tarArchiveOutputStream19);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream22 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream9);
        java.io.InputStream inputStream23 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream23, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream26 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream25);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream27 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream25);
        byte[] byteArray29 = new byte[] { (byte) 0 };
        int int30 = jarArchiveInputStream27.read(byteArray29);
        boolean boolean32 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray29, 512);
        boolean boolean34 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray29, (int) (byte) 10);
        int int37 = arArchiveInputStream22.read(byteArray29, (int) (short) 10, (int) ' ');
        long long39 = arArchiveInputStream22.skip((long) 4096);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) arArchiveInputStream22, 512);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream42 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) arArchiveInputStream22);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream43 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) arArchiveInputStream22);
        org.apache.commons.compress.archivers.ar.ArArchiveEntry arArchiveEntry44 = arArchiveInputStream22.getNextArEntry();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream45 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) arArchiveInputStream22);
        org.apache.commons.compress.archivers.ar.ArArchiveEntry arArchiveEntry46 = arArchiveInputStream22.getNextArEntry();
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry47 = arArchiveInputStream22.getNextEntry();
        java.io.InputStream inputStream48 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream50 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream48, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream51 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream50);
        java.io.OutputStream outputStream52 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream50, outputStream52);
        int int54 = tarArchiveInputStream50.available();
        long long56 = tarArchiveInputStream50.skip((long) 10);
        java.io.InputStream inputStream57 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream59 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream57, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream60 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream59);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream61 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream59);
        byte[] byteArray63 = new byte[] { (byte) 0 };
        int int64 = jarArchiveInputStream61.read(byteArray63);
        int int65 = tarArchiveInputStream50.read(byteArray63);
        boolean boolean67 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray63, 8);
        boolean boolean69 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray63, 2);
        boolean boolean71 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray63, 16);
        int int72 = arArchiveInputStream22.read(byteArray63);
        try {
            arArchiveOutputStream3.write(byteArray63, 4, (int) (short) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray29), "[0]");
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNull(arArchiveEntry44);
        org.junit.Assert.assertNull(arArchiveEntry46);
        org.junit.Assert.assertNull(archiveEntry47);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(byteArray63);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray63), "[0]");
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test0759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0759");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        tarArchiveInputStream2.reset();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream4, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream6);
        java.io.OutputStream outputStream8 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream6, outputStream8);
        java.io.OutputStream outputStream10 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream12 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream10, 0);
        tarArchiveInputStream6.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, (java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream16 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream12, 512);
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream17 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream16);
        tarArchiveOutputStream16.setBufferDebug(false);
        tarArchiveOutputStream16.closeEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream21 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream16);
        try {
            cpioArchiveOutputStream21.closeArchiveEntry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test1036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1036");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy8 = null;
        zipArchiveOutputStream7.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy8);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream10 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream7);
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream13 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream11, (int) (byte) 100);
        java.io.OutputStream outputStream14 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream16 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream14, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream18 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream14, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream18, (int) (short) 10);
        byte[] byteArray21 = new byte[] {};
        tarArchiveOutputStream20.write(byteArray21);
        tarArchiveInputStream13.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream20);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream24 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream13);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream25 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream24);
        int int26 = arArchiveInputStream25.read();
        java.io.OutputStream outputStream27 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream34 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy35 = null;
        zipArchiveOutputStream34.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy35);
        zipArchiveOutputStream34.setMethod(100);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) arArchiveInputStream25, (java.io.OutputStream) zipArchiveOutputStream34);
        int int40 = arArchiveInputStream25.read();
        java.io.InputStream inputStream41 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream43 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream41, (int) (byte) 100);
        int int44 = tarArchiveInputStream43.available();
        java.io.InputStream inputStream45 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream47 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream45, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream48 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream47);
        cpioArchiveInputStream48.closeEntry();
        byte[] byteArray56 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int59 = cpioArchiveInputStream48.read(byteArray56, (int) (byte) 1, 0);
        int int60 = tarArchiveInputStream43.read(byteArray56);
        long long62 = tarArchiveInputStream43.skip((long) 0);
        int int63 = tarArchiveInputStream43.getRecordSize();
        java.io.InputStream inputStream64 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream66 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream64, (int) (byte) 100);
        java.io.OutputStream outputStream67 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream69 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream67, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream71 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream67, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream73 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream71, (int) (short) 10);
        byte[] byteArray74 = new byte[] {};
        tarArchiveOutputStream73.write(byteArray74);
        tarArchiveInputStream66.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream73);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream77 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream66);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream78 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream77);
        byte[] byteArray82 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        int int85 = arArchiveInputStream77.read(byteArray82, 0, (int) (short) -1);
        int int88 = tarArchiveInputStream43.read(byteArray82, (int) (byte) 100, (int) (short) 10);
        int int89 = arArchiveInputStream25.read(byteArray82);
        try {
            cpioArchiveOutputStream10.write(byteArray82);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: no current CPIO entry");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(byteArray21);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray21), "[]");
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(byteArray56);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray56), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 512 + "'", int63 == 512);
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray74), "[]");
        org.junit.Assert.assertNotNull(byteArray82);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray82), "[10, 0, 1]");
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1) + "'", int85 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
    }

    @Test
    public void test1453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1453");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream3 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream2);
        jarArchiveOutputStream3.setLevel(0);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream6 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) jarArchiveOutputStream3);
        java.io.InputStream inputStream7 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream7, (int) (byte) 100);
        int int10 = tarArchiveInputStream9.available();
        java.io.InputStream inputStream11 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream13 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream11, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream14 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream13);
        cpioArchiveInputStream14.closeEntry();
        byte[] byteArray22 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int25 = cpioArchiveInputStream14.read(byteArray22, (int) (byte) 1, 0);
        int int26 = tarArchiveInputStream9.read(byteArray22);
        long long28 = tarArchiveInputStream9.skip((long) 0);
        int int29 = tarArchiveInputStream9.getRecordSize();
        java.io.InputStream inputStream30 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream32 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream30, (int) (byte) 100);
        java.io.OutputStream outputStream33 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream35 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream33, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream37 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream33, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream39 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream37, (int) (short) 10);
        byte[] byteArray40 = new byte[] {};
        tarArchiveOutputStream39.write(byteArray40);
        tarArchiveInputStream32.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream39);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream43 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream32);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream44 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream43);
        byte[] byteArray48 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        int int51 = arArchiveInputStream43.read(byteArray48, 0, (int) (short) -1);
        int int54 = tarArchiveInputStream9.read(byteArray48, (int) (byte) 100, (int) (short) 10);
        try {
            cpioArchiveOutputStream6.write(byteArray48, (int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 512 + "'", int29 == 512);
        org.junit.Assert.assertNotNull(byteArray40);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray40), "[]");
        org.junit.Assert.assertNotNull(byteArray48);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray48), "[10, 0, 1]");
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test1492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1492");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        int int3 = tarArchiveInputStream2.available();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream4, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream7 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream6);
        cpioArchiveInputStream7.closeEntry();
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int18 = cpioArchiveInputStream7.read(byteArray15, (int) (byte) 1, 0);
        int int19 = tarArchiveInputStream2.read(byteArray15);
        long long21 = tarArchiveInputStream2.skip((long) 0);
        int int22 = tarArchiveInputStream2.getRecordSize();
        java.io.OutputStream outputStream23 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream23, (int) (byte) 100);
        java.lang.String str26 = tarArchiveOutputStream25.getDefaultFileExtension();
        java.io.OutputStream outputStream27 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream34 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31);
        tarArchiveOutputStream31.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream37 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream38 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream37);
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream39, (int) (byte) 100);
        java.io.OutputStream outputStream42 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream44 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream42, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream46 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream42, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream48 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream46, (int) (short) 10);
        byte[] byteArray49 = new byte[] {};
        tarArchiveOutputStream48.write(byteArray49);
        tarArchiveInputStream41.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream48);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream52 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream41);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream53 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream52);
        byte[] byteArray54 = new byte[] {};
        int int57 = arArchiveInputStream53.read(byteArray54, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream38.write(byteArray54);
        tarArchiveOutputStream25.write(byteArray54, (int) (short) 10, 0);
        java.lang.String str62 = tarArchiveOutputStream25.getName();
        tarArchiveOutputStream25.closeEntry();
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream25);
        try {
            tarArchiveOutputStream25.finish();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: writing to an input buffer");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 512 + "'", int22 == 512);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "tar" + "'", str26.equals("tar"));
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray49), "[]");
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[]");
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "tar" + "'", str62.equals("tar"));
    }

    @Test
    public void test1494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1494");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        zipArchiveOutputStream7.setMethod((int) (short) 0);
        boolean boolean10 = zipArchiveOutputStream7.isSeekable();
        java.lang.String str11 = zipArchiveOutputStream7.getEncoding();
        java.lang.String str12 = zipArchiveOutputStream7.getEncoding();
        zipArchiveOutputStream7.setFallbackToUTF8(true);
        zipArchiveOutputStream7.setFallbackToUTF8(false);
        java.io.OutputStream outputStream17 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream17, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream21 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream17, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream23 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream21, (int) (short) 10);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream24 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream21);
        java.lang.String str25 = tarArchiveOutputStream21.getDefaultFileExtension();
        tarArchiveOutputStream21.setLongFileMode((int) (byte) -1);
        tarArchiveOutputStream21.closeEntry();
        java.io.InputStream inputStream29 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream29, (int) (byte) 100);
        int int32 = tarArchiveInputStream31.available();
        java.io.InputStream inputStream33 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream35 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream33, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream36 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream35);
        cpioArchiveInputStream36.closeEntry();
        byte[] byteArray44 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int47 = cpioArchiveInputStream36.read(byteArray44, (int) (byte) 1, 0);
        int int48 = tarArchiveInputStream31.read(byteArray44);
        long long50 = tarArchiveInputStream31.skip((long) 0);
        int int51 = tarArchiveInputStream31.getRecordSize();
        java.io.InputStream inputStream52 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream54 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream52, (int) (byte) 100);
        java.io.OutputStream outputStream55 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream57 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream55, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream59 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream55, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream61 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream59, (int) (short) 10);
        byte[] byteArray62 = new byte[] {};
        tarArchiveOutputStream61.write(byteArray62);
        tarArchiveInputStream54.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream61);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream65 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream54);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream66 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream65);
        byte[] byteArray70 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        int int73 = arArchiveInputStream65.read(byteArray70, 0, (int) (short) -1);
        int int76 = tarArchiveInputStream31.read(byteArray70, (int) (byte) 100, (int) (short) 10);
        boolean boolean78 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray70, (int) '4');
        boolean boolean80 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray70, (int) (byte) 10);
        boolean boolean82 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray70, (int) (short) 1);
        tarArchiveOutputStream21.write(byteArray70, (int) ' ', 0);
        try {
            zipArchiveOutputStream7.write(byteArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTF8" + "'", str11.equals("UTF8"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UTF8" + "'", str12.equals("UTF8"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "tar" + "'", str25.equals("tar"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray44), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 512 + "'", int51 == 512);
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray62), "[]");
        org.junit.Assert.assertNotNull(byteArray70);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray70), "[10, 0, 1]");
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

}
