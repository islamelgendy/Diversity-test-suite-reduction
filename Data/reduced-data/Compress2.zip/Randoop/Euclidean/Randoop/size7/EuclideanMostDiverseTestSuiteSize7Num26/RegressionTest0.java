import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0257");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream3 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        java.io.OutputStream outputStream4 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, outputStream4);
        java.io.OutputStream outputStream6 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream8 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream6, 0);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream8);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream10 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream8);
        zipArchiveOutputStream10.closeEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy12 = org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE;
        java.lang.String str13 = unicodeExtraFieldPolicy12.toString();
        zipArchiveOutputStream10.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy12);
        zipArchiveOutputStream10.setFallbackToUTF8(true);
        zipArchiveOutputStream10.closeArchiveEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream18 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        java.lang.String str19 = zipArchiveOutputStream18.getEncoding();
        java.lang.String str20 = zipArchiveOutputStream18.getEncoding();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream21 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream18);
        java.io.InputStream inputStream22 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream22, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream24);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream26 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream24);
        tarArchiveInputStream24.close();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream24, (int) (byte) 10);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry30 = tarArchiveInputStream29.getNextEntry();
        long long32 = tarArchiveInputStream29.skip((long) 2048);
        java.io.InputStream inputStream33 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream35 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream33, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream36 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream35);
        byte[] byteArray37 = new byte[] {};
        int int40 = tarArchiveInputStream36.read(byteArray37, 0, (int) (byte) 100);
        boolean boolean42 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray37, (int) (short) 3);
        int int43 = tarArchiveInputStream29.read(byteArray37);
        cpioArchiveOutputStream21.write(byteArray37);
        java.io.InputStream inputStream45 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream47 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream45, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream48 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream47);
        java.io.OutputStream outputStream49 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream47, outputStream49);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream53 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream47, 0, 61440);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream54 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream47);
        tarArchiveInputStream47.close();
        java.io.InputStream inputStream56 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream58 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream56, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream59 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream58);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream60 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream58);
        byte[] byteArray62 = new byte[] { (byte) 0 };
        int int63 = jarArchiveInputStream60.read(byteArray62);
        boolean boolean65 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray62, 512);
        boolean boolean67 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray62, (int) (byte) 10);
        boolean boolean69 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray62, (int) (short) 8);
        boolean boolean71 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray62, 0);
        int int74 = tarArchiveInputStream47.read(byteArray62, 0, 0);
        boolean boolean76 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray62, (int) (short) 10);
        boolean boolean78 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray62, 2048);
        try {
            cpioArchiveOutputStream21.write(byteArray62, (int) (short) 2, 36864);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(unicodeExtraFieldPolicy12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "not encodeable" + "'", str13.equals("not encodeable"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTF8" + "'", str19.equals("UTF8"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTF8" + "'", str20.equals("UTF8"));
        org.junit.Assert.assertNull(archiveEntry30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNotNull(byteArray37);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray37), "[]");
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(byteArray62);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray62), "[0]");
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test0544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0544");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        tarArchiveInputStream2.reset();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream4, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream6);
        java.io.OutputStream outputStream8 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream6, outputStream8);
        java.io.OutputStream outputStream10 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream12 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream10, 0);
        tarArchiveInputStream6.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, (java.io.OutputStream) tarArchiveOutputStream12);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream15 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        java.io.InputStream inputStream16 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream18 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream16, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream18);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream20 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream18);
        byte[] byteArray22 = new byte[] { (byte) 0 };
        int int23 = jarArchiveInputStream20.read(byteArray22);
        boolean boolean25 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray22, 512);
        boolean boolean27 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray22, (int) (byte) 10);
        boolean boolean29 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray22, (int) (short) 8);
        int int32 = arArchiveInputStream15.read(byteArray22, 0, 10);
        java.io.InputStream inputStream33 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream35 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream33, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream36 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream35);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream37 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream35);
        byte[] byteArray39 = new byte[] { (byte) 0 };
        int int40 = jarArchiveInputStream37.read(byteArray39);
        boolean boolean42 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray39, 512);
        boolean boolean44 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray39, 2);
        int int45 = arArchiveInputStream15.read(byteArray39);
        java.io.OutputStream outputStream46 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream48 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream46, 0);
        java.io.InputStream inputStream49 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream51 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream49, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream52 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream51);
        java.io.OutputStream outputStream53 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream51, outputStream53);
        java.io.OutputStream outputStream55 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream57 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream55, 0);
        tarArchiveInputStream51.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream57);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream59 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream57);
        zipArchiveOutputStream59.closeEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy61 = org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE;
        java.lang.String str62 = unicodeExtraFieldPolicy61.toString();
        zipArchiveOutputStream59.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy61);
        zipArchiveOutputStream59.setFallbackToUTF8(true);
        zipArchiveOutputStream59.closeArchiveEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream67 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream59);
        java.lang.String str68 = zipArchiveOutputStream67.getEncoding();
        java.lang.String str69 = zipArchiveOutputStream67.getEncoding();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream70 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream67);
        java.io.InputStream inputStream71 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream73 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream71, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream74 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream73);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream75 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream73);
        tarArchiveInputStream73.close();
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream78 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream73, (int) (byte) 10);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry79 = tarArchiveInputStream78.getNextEntry();
        long long81 = tarArchiveInputStream78.skip((long) 2048);
        java.io.InputStream inputStream82 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream84 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream82, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream85 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream84);
        byte[] byteArray86 = new byte[] {};
        int int89 = tarArchiveInputStream85.read(byteArray86, 0, (int) (byte) 100);
        boolean boolean91 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray86, (int) (short) 3);
        int int92 = tarArchiveInputStream78.read(byteArray86);
        cpioArchiveOutputStream70.write(byteArray86);
        tarArchiveOutputStream48.write(byteArray86);
        int int95 = arArchiveInputStream15.read(byteArray86);
        org.junit.Assert.assertNotNull(byteArray22);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray22), "[0]");
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(byteArray39);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray39), "[0]");
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(unicodeExtraFieldPolicy61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "not encodeable" + "'", str62.equals("not encodeable"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "UTF8" + "'", str68.equals("UTF8"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "UTF8" + "'", str69.equals("UTF8"));
        org.junit.Assert.assertNull(archiveEntry79);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertNotNull(byteArray86);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray86), "[]");
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1) + "'", int95 == (-1));
    }

    @Test
    public void test0731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0731");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream2 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream(outputStream0, (short) 2);
    }

    @Test
    public void test1212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1212");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        int int3 = tarArchiveInputStream2.available();
        boolean boolean4 = tarArchiveInputStream2.markSupported();
        long long6 = tarArchiveInputStream2.skip((long) (short) 100);
        java.io.OutputStream outputStream7 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream7, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream11 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream7, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream13 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream11, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream14 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream11);
        zipArchiveOutputStream14.setMethod((int) (short) 0);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, (java.io.OutputStream) zipArchiveOutputStream14);
        java.io.OutputStream outputStream18 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream18, (int) (byte) 100);
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream21 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream20);
        jarArchiveOutputStream21.setLevel(0);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) jarArchiveOutputStream21);
        java.io.OutputStream outputStream25 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream27 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream25, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream25, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream29, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream32 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream29);
        tarArchiveOutputStream29.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream35 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream29, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream36 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream35);
        java.io.InputStream inputStream37 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream39 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream37, (int) (byte) 100);
        java.io.OutputStream outputStream40 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream42 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream40, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream44 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream40, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream46 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream44, (int) (short) 10);
        byte[] byteArray47 = new byte[] {};
        tarArchiveOutputStream46.write(byteArray47);
        tarArchiveInputStream39.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream46);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream50 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream39);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream51 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream50);
        byte[] byteArray52 = new byte[] {};
        int int55 = arArchiveInputStream51.read(byteArray52, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream36.write(byteArray52);
        java.io.InputStream inputStream57 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream59 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream57, (int) (byte) 100);
        java.io.OutputStream outputStream60 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream62 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream60, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream64 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream60, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream66 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream64, (int) (short) 10);
        byte[] byteArray67 = new byte[] {};
        tarArchiveOutputStream66.write(byteArray67);
        tarArchiveInputStream59.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream66);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream70 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream59);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream71 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream70);
        byte[] byteArray72 = new byte[] {};
        int int75 = arArchiveInputStream71.read(byteArray72, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream36.write(byteArray72);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream77 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) arArchiveOutputStream36);
        byte[] byteArray81 = new byte[] { (byte) -1, (byte) 100, (byte) 10 };
        boolean boolean83 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray81, 0);
        boolean boolean85 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray81, (int) '#');
        boolean boolean87 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray81, 1);
        boolean boolean89 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray81, (int) '#');
        arArchiveOutputStream36.write(byteArray81, 0, (int) (byte) 0);
        try {
            jarArchiveOutputStream21.write(byteArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(byteArray47);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray47), "[]");
        org.junit.Assert.assertNotNull(byteArray52);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray52), "[]");
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(byteArray67);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray67), "[]");
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray72), "[]");
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[-1, 100, 10]");
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test1234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1234");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        zipArchiveOutputStream7.setMethod((int) (short) 0);
        zipArchiveOutputStream7.setLevel((int) (short) 0);
        zipArchiveOutputStream7.closeEntry();
        zipArchiveOutputStream7.setUseLanguageEncodingFlag(true);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream17 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream7, (int) (short) 0, (int) (byte) 10);
        zipArchiveOutputStream7.closeEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream19 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream7);
        java.io.InputStream inputStream20 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream22 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream20, (int) (byte) 100);
        long long24 = tarArchiveInputStream22.skip((long) 100);
        org.apache.commons.compress.archivers.zip.ZipArchiveInputStream zipArchiveInputStream25 = new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream((java.io.InputStream) tarArchiveInputStream22);
        org.apache.commons.compress.archivers.ArchiveEntry archiveEntry26 = zipArchiveInputStream25.getNextEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream27 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) zipArchiveInputStream25);
        java.io.InputStream inputStream28 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream30 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream28, (int) (byte) 100);
        byte[] byteArray34 = new byte[] { (byte) 10, (byte) 0, (byte) -1 };
        int int35 = tarArchiveInputStream30.read(byteArray34);
        int int38 = zipArchiveInputStream25.read(byteArray34, 0, (int) (short) 0);
        boolean boolean40 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray34, (int) (short) -1);
        cpioArchiveOutputStream19.write(byteArray34, 0, 0);
        try {
            org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream45 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream19, (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown header type");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNull(archiveEntry26);
        org.junit.Assert.assertNotNull(byteArray34);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray34), "[10, 0, -1]");
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test1436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1436");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        int int3 = tarArchiveInputStream2.available();
        java.io.InputStream inputStream4 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream4, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream7 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream6);
        cpioArchiveInputStream7.closeEntry();
        byte[] byteArray15 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int18 = cpioArchiveInputStream7.read(byteArray15, (int) (byte) 1, 0);
        int int19 = tarArchiveInputStream2.read(byteArray15);
        long long21 = tarArchiveInputStream2.skip((long) 0);
        int int22 = tarArchiveInputStream2.getRecordSize();
        java.io.OutputStream outputStream23 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream23, (int) (byte) 100);
        java.lang.String str26 = tarArchiveOutputStream25.getDefaultFileExtension();
        java.io.OutputStream outputStream27 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream27, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream34 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31);
        tarArchiveOutputStream31.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream37 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream31, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream38 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream37);
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream39, (int) (byte) 100);
        java.io.OutputStream outputStream42 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream44 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream42, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream46 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream42, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream48 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream46, (int) (short) 10);
        byte[] byteArray49 = new byte[] {};
        tarArchiveOutputStream48.write(byteArray49);
        tarArchiveInputStream41.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream48);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream52 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream41);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream53 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream52);
        byte[] byteArray54 = new byte[] {};
        int int57 = arArchiveInputStream53.read(byteArray54, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream38.write(byteArray54);
        tarArchiveOutputStream25.write(byteArray54, (int) (short) 10, 0);
        java.lang.String str62 = tarArchiveOutputStream25.getName();
        tarArchiveOutputStream25.closeEntry();
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream25);
        tarArchiveOutputStream25.closeArchiveEntry();
        tarArchiveOutputStream25.setDebug(false);
        byte[] byteArray74 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 0 };
        boolean boolean76 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray74, (int) '4');
        try {
            tarArchiveOutputStream25.write(byteArray74);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: request to write '6' bytes exceeds size in header of '0' bytes for entry 'null'");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray15), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 512 + "'", int22 == 512);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "tar" + "'", str26.equals("tar"));
        org.junit.Assert.assertNotNull(byteArray49);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray49), "[]");
        org.junit.Assert.assertNotNull(byteArray54);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray54), "[]");
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "tar" + "'", str62.equals("tar"));
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray74), "[0, 1, 1, 1, 1, 0]");
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test1466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1466");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        java.io.OutputStream outputStream3 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream5 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream7 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream3, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream9 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream7, (int) (short) 10);
        byte[] byteArray10 = new byte[] {};
        tarArchiveOutputStream9.write(byteArray10);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream9);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream13 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream9);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream14 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream13);
        arArchiveOutputStream14.closeArchiveEntry();
        arArchiveOutputStream14.closeArchiveEntry();
        java.io.InputStream inputStream17 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream17, (int) (byte) 100);
        byte[] byteArray23 = new byte[] { (byte) 10, (byte) 0, (byte) -1 };
        int int24 = tarArchiveInputStream19.read(byteArray23);
        long long26 = tarArchiveInputStream19.skip((long) ' ');
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream27 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream19);
        long long29 = tarArchiveInputStream19.skip((long) (short) 1);
        int int30 = tarArchiveInputStream19.read();
        java.io.InputStream inputStream31 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream31, (int) (byte) 100);
        int int34 = tarArchiveInputStream33.available();
        java.io.InputStream inputStream35 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream37 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream35, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream38 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream37);
        cpioArchiveInputStream38.closeEntry();
        byte[] byteArray46 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int49 = cpioArchiveInputStream38.read(byteArray46, (int) (byte) 1, 0);
        int int50 = tarArchiveInputStream33.read(byteArray46);
        long long52 = tarArchiveInputStream33.skip((long) 0);
        int int53 = tarArchiveInputStream33.getRecordSize();
        java.io.InputStream inputStream54 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream56 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream54, (int) (byte) 100);
        java.io.OutputStream outputStream57 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream59 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream57, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream61 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream57, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream63 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream61, (int) (short) 10);
        byte[] byteArray64 = new byte[] {};
        tarArchiveOutputStream63.write(byteArray64);
        tarArchiveInputStream56.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream63);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream67 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream56);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream68 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream67);
        byte[] byteArray72 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        int int75 = arArchiveInputStream67.read(byteArray72, 0, (int) (short) -1);
        int int78 = tarArchiveInputStream33.read(byteArray72, (int) (byte) 100, (int) (short) 10);
        boolean boolean80 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray72, (int) (byte) 0);
        int int83 = tarArchiveInputStream19.read(byteArray72, (int) (byte) 10, 0);
        boolean boolean85 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray72, (-1));
        boolean boolean87 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray72, (int) (short) 10);
        try {
            arArchiveOutputStream14.write(byteArray72);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: no current CPIO entry");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray10), "[]");
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray23), "[10, 0, -1]");
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray46), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 512 + "'", int53 == 512);
        org.junit.Assert.assertNotNull(byteArray64);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray64), "[]");
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray72), "[10, 0, 1]");
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1) + "'", int83 == (-1));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

}
