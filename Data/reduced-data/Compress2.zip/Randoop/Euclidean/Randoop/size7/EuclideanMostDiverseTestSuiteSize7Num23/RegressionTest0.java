import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test0107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0107");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.jar.JarArchiveOutputStream jarArchiveOutputStream1 = new org.apache.commons.compress.archivers.jar.JarArchiveOutputStream(outputStream0);
        jarArchiveOutputStream1.setEncoding("UTF8");
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream4 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) jarArchiveOutputStream1);
        org.apache.commons.compress.archivers.cpio.CpioArchiveEntry cpioArchiveEntry7 = new org.apache.commons.compress.archivers.cpio.CpioArchiveEntry("", (long) 1);
        long long8 = cpioArchiveEntry7.getDeviceMaj();
        cpioArchiveEntry7.setDeviceMin((long) 10);
        short short11 = cpioArchiveEntry7.getFormat();
        boolean boolean12 = cpioArchiveEntry7.isDirectory();
        long long13 = cpioArchiveEntry7.getDeviceMaj();
        cpioArchiveEntry7.setMode((long) 10);
        try {
            cpioArchiveOutputStream4.putNextEntry(cpioArchiveEntry7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test0134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0134");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream3 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        java.io.OutputStream outputStream4 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, outputStream4);
        java.io.OutputStream outputStream6 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream8 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream6, 0);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream8);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream10 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream8);
        zipArchiveOutputStream10.closeEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy12 = org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE;
        java.lang.String str13 = unicodeExtraFieldPolicy12.toString();
        zipArchiveOutputStream10.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy12);
        zipArchiveOutputStream10.setFallbackToUTF8(true);
        zipArchiveOutputStream10.closeArchiveEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream18 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        java.lang.String str19 = zipArchiveOutputStream18.getEncoding();
        java.lang.String str20 = zipArchiveOutputStream18.getEncoding();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream21 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream18);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream22 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream21);
        java.io.InputStream inputStream23 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream23, 1);
        tarArchiveInputStream25.reset();
        java.io.InputStream inputStream27 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream27, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream30 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream29);
        java.io.OutputStream outputStream31 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream29, outputStream31);
        java.io.OutputStream outputStream33 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream35 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream33, 0);
        tarArchiveInputStream29.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream35);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream25, (java.io.OutputStream) tarArchiveOutputStream35);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream38 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream25);
        java.io.InputStream inputStream39 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream39, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream42 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream41);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream43 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream41);
        byte[] byteArray45 = new byte[] { (byte) 0 };
        int int46 = jarArchiveInputStream43.read(byteArray45);
        boolean boolean48 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray45, 512);
        boolean boolean50 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray45, (int) (byte) 10);
        int int53 = arArchiveInputStream38.read(byteArray45, (int) (short) 10, (int) ' ');
        int int54 = arArchiveInputStream38.read();
        java.io.InputStream inputStream55 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream57 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream55, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream58 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream57);
        byte[] byteArray59 = new byte[] {};
        int int62 = tarArchiveInputStream58.read(byteArray59, 0, (int) (byte) 100);
        int int65 = arArchiveInputStream38.read(byteArray59, 0, 2048);
        java.io.InputStream inputStream66 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream68 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream66, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream69 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream68);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream70 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream68);
        byte[] byteArray72 = new byte[] { (byte) 0 };
        int int73 = jarArchiveInputStream70.read(byteArray72);
        boolean boolean75 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray72, 512);
        boolean boolean77 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray72, (int) (byte) 10);
        boolean boolean79 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray72, (int) (short) 8);
        boolean boolean81 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray72, (int) (byte) 100);
        int int82 = arArchiveInputStream38.read(byteArray72);
        java.io.InputStream inputStream83 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream85 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream83, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream86 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream85);
        byte[] byteArray87 = new byte[] {};
        int int90 = tarArchiveInputStream86.read(byteArray87, 0, (int) (byte) 100);
        boolean boolean92 = org.apache.commons.compress.archivers.ar.ArArchiveInputStream.matches(byteArray87, (int) (short) 3);
        int int95 = arArchiveInputStream38.read(byteArray87, 10, (int) 'a');
        try {
            cpioArchiveOutputStream22.write(byteArray87, (int) 'a', 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(unicodeExtraFieldPolicy12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "not encodeable" + "'", str13.equals("not encodeable"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTF8" + "'", str19.equals("UTF8"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UTF8" + "'", str20.equals("UTF8"));
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray45), "[0]");
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray59), "[]");
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(byteArray72);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray72), "[0]");
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertNotNull(byteArray87);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray87), "[]");
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1) + "'", int90 == (-1));
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1) + "'", int95 == (-1));
    }

    @Test
    public void test0359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test0359");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream3 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        java.io.OutputStream outputStream4 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream2, outputStream4);
        java.io.OutputStream outputStream6 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream8 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream6, 0);
        tarArchiveInputStream2.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream8);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream10 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream8);
        zipArchiveOutputStream10.closeEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy12 = org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy.NOT_ENCODEABLE;
        java.lang.String str13 = unicodeExtraFieldPolicy12.toString();
        zipArchiveOutputStream10.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy12);
        zipArchiveOutputStream10.setFallbackToUTF8(true);
        zipArchiveOutputStream10.closeArchiveEntry();
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream18 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream19 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream21 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream10);
        java.io.InputStream inputStream22 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream22, 1);
        tarArchiveInputStream24.reset();
        java.io.InputStream inputStream26 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream28 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream26, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream28);
        java.io.OutputStream outputStream30 = null;
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream28, outputStream30);
        java.io.OutputStream outputStream32 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream34 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream32, 0);
        tarArchiveInputStream28.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream34);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) tarArchiveInputStream24, (java.io.OutputStream) tarArchiveOutputStream34);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream37 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream24);
        java.io.InputStream inputStream38 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream40 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream38, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream41 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream40);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream42 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream40);
        byte[] byteArray44 = new byte[] { (byte) 0 };
        int int45 = jarArchiveInputStream42.read(byteArray44);
        boolean boolean47 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray44, 512);
        boolean boolean49 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray44, (int) (byte) 10);
        int int52 = arArchiveInputStream37.read(byteArray44, (int) (short) 10, (int) ' ');
        java.io.InputStream inputStream53 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream55 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream53, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream56 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream55);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream57 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream55);
        byte[] byteArray59 = new byte[] { (byte) 0 };
        int int60 = jarArchiveInputStream57.read(byteArray59);
        boolean boolean62 = org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream.matches(byteArray59, 512);
        boolean boolean64 = org.apache.commons.compress.archivers.tar.TarArchiveInputStream.matches(byteArray59, (int) (byte) 10);
        boolean boolean66 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray59, (int) (short) 8);
        int int69 = arArchiveInputStream37.read(byteArray59, 0, 0);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream70 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) arArchiveInputStream37);
        byte[] byteArray74 = new byte[] { (byte) 0, (byte) 1, (byte) 100 };
        int int75 = arArchiveInputStream37.read(byteArray74);
        try {
            arArchiveOutputStream21.write(byteArray74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(unicodeExtraFieldPolicy12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "not encodeable" + "'", str13.equals("not encodeable"));
        org.junit.Assert.assertNotNull(byteArray44);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray44), "[0]");
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray59), "[0]");
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(byteArray74);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray74), "[0, 1, 100]");
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
    }

    @Test
    public void test0620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0620");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream3 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        org.apache.commons.compress.archivers.jar.JarArchiveInputStream jarArchiveInputStream4 = new org.apache.commons.compress.archivers.jar.JarArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        byte[] byteArray6 = new byte[] { (byte) 0 };
        int int7 = jarArchiveInputStream4.read(byteArray6);
        long long9 = jarArchiveInputStream4.skip(100L);
        long long11 = jarArchiveInputStream4.skip(10L);
        jarArchiveInputStream4.close();
        int int13 = jarArchiveInputStream4.read();
        org.apache.commons.compress.archivers.jar.JarArchiveEntry jarArchiveEntry14 = jarArchiveInputStream4.getNextJarEntry();
        org.apache.commons.compress.archivers.jar.JarArchiveEntry jarArchiveEntry15 = jarArchiveInputStream4.getNextJarEntry();
        java.io.OutputStream outputStream16 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream18 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream16, 0);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream19 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream(outputStream16);
        arArchiveOutputStream19.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream21 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) arArchiveOutputStream19);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream24 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream21, 40960, 512);
        java.lang.String str25 = tarArchiveOutputStream24.getName();
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream27 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream24, (int) '4');
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) jarArchiveInputStream4, (java.io.OutputStream) tarArchiveOutputStream24, 1);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream31 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream24, (int) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[0]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNull(jarArchiveEntry14);
        org.junit.Assert.assertNull(jarArchiveEntry15);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "tar" + "'", str25.equals("tar"));
    }

    @Test
    public void test0952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test0952");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream3 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream2);
        cpioArchiveInputStream3.closeEntry();
        byte[] byteArray11 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int14 = cpioArchiveInputStream3.read(byteArray11, (int) (byte) 1, 0);
        boolean boolean15 = cpioArchiveInputStream3.markSupported();
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream16 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) cpioArchiveInputStream3);
        long long18 = arArchiveInputStream16.skip((long) 0);
        java.io.OutputStream outputStream19 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream21 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream19, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream23 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream19, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream25 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream23, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream26 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream23);
        tarArchiveOutputStream23.closeArchiveEntry();
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream29 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream23, (short) 1);
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream30 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) cpioArchiveOutputStream29);
        java.io.InputStream inputStream31 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream31, (int) (byte) 100);
        java.io.OutputStream outputStream34 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream36 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream34, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream38 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream34, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream40 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream38, (int) (short) 10);
        byte[] byteArray41 = new byte[] {};
        tarArchiveOutputStream40.write(byteArray41);
        tarArchiveInputStream33.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream40);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream44 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream33);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream45 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream44);
        byte[] byteArray46 = new byte[] {};
        int int49 = arArchiveInputStream45.read(byteArray46, (int) (byte) 0, (int) 'a');
        arArchiveOutputStream30.write(byteArray46);
        boolean boolean52 = org.apache.commons.compress.archivers.zip.ZipArchiveInputStream.matches(byteArray46, 0);
        try {
            int int55 = arArchiveInputStream16.read(byteArray46, (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray11), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(byteArray41);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray41), "[]");
        org.junit.Assert.assertNotNull(byteArray46);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray46), "[]");
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test1349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1349");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream7 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        zipArchiveOutputStream7.setMethod((int) (short) 0);
        zipArchiveOutputStream7.setFallbackToUTF8(false);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream14 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) zipArchiveOutputStream7, (int) (short) 0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream15 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream14);
        tarArchiveOutputStream15.setBufferDebug(true);
        tarArchiveOutputStream15.closeEntry();
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream20 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream15, (int) (byte) 1);
        java.io.InputStream inputStream21 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream23 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream21, (int) (byte) 100);
        long long25 = tarArchiveInputStream23.skip((long) 100);
        int int26 = tarArchiveInputStream23.available();
        java.io.InputStream inputStream27 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream29 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream27, (int) (byte) 100);
        int int30 = tarArchiveInputStream29.available();
        java.io.InputStream inputStream31 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream33 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream31, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream34 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream33);
        cpioArchiveInputStream34.closeEntry();
        byte[] byteArray42 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int45 = cpioArchiveInputStream34.read(byteArray42, (int) (byte) 1, 0);
        int int46 = tarArchiveInputStream29.read(byteArray42);
        boolean boolean48 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray42, (int) (byte) 10);
        int int49 = tarArchiveInputStream23.read(byteArray42);
        java.io.InputStream inputStream50 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream52 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream50, (int) (byte) 100);
        int int53 = tarArchiveInputStream52.available();
        java.io.InputStream inputStream54 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream56 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream54, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream57 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream56);
        cpioArchiveInputStream57.closeEntry();
        byte[] byteArray65 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int68 = cpioArchiveInputStream57.read(byteArray65, (int) (byte) 1, 0);
        int int69 = tarArchiveInputStream52.read(byteArray65);
        java.io.InputStream inputStream70 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream72 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream70, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream73 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream72);
        cpioArchiveInputStream73.closeEntry();
        byte[] byteArray81 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int84 = cpioArchiveInputStream73.read(byteArray81, (int) (byte) 1, 0);
        int int87 = tarArchiveInputStream52.read(byteArray81, (int) '4', (int) '4');
        int int88 = tarArchiveInputStream23.read(byteArray81);
        tarArchiveOutputStream15.write(byteArray81, 100, 0);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream92 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream15);
        try {
            cpioArchiveOutputStream92.finish();
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: request to write '1' bytes exceeds size in header of '0' bytes for entry 'null'");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(byteArray42);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray42), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(byteArray65);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray65), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(byteArray81);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray81), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-1) + "'", int87 == (-1));
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

    @Test
    public void test1354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test1354");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream2 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream4 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream0, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream6 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4, (int) (short) 10);
        tarArchiveOutputStream4.closeEntry();
        tarArchiveOutputStream4.setDebug(false);
        org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream cpioArchiveOutputStream10 = new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        tarArchiveOutputStream4.closeEntry();
        tarArchiveOutputStream4.closeEntry();
        org.apache.commons.compress.archivers.ar.ArArchiveOutputStream arArchiveOutputStream13 = new org.apache.commons.compress.archivers.ar.ArArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream4);
        java.io.InputStream inputStream14 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream16 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream14, (int) (byte) 100);
        java.io.OutputStream outputStream17 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream19 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream17, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream21 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream17, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream23 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream21, (int) (short) 10);
        byte[] byteArray24 = new byte[] {};
        tarArchiveOutputStream23.write(byteArray24);
        tarArchiveInputStream16.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream23);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream27 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream16);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream28 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream27);
        int int29 = arArchiveInputStream28.read();
        java.io.OutputStream outputStream30 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream32 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream30, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream34 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream30, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream36 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream34, (int) (short) 10);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream zipArchiveOutputStream37 = new org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream34);
        org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream.UnicodeExtraFieldPolicy unicodeExtraFieldPolicy38 = null;
        zipArchiveOutputStream37.setCreateUnicodeExtraFields(unicodeExtraFieldPolicy38);
        zipArchiveOutputStream37.setMethod(100);
        org.apache.commons.compress.utils.IOUtils.copy((java.io.InputStream) arArchiveInputStream28, (java.io.OutputStream) zipArchiveOutputStream37);
        int int43 = arArchiveInputStream28.read();
        java.io.InputStream inputStream44 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream46 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream44, (int) (byte) 100);
        int int47 = tarArchiveInputStream46.available();
        java.io.InputStream inputStream48 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream50 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream48, (int) (byte) 100);
        org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream cpioArchiveInputStream51 = new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream((java.io.InputStream) tarArchiveInputStream50);
        cpioArchiveInputStream51.closeEntry();
        byte[] byteArray59 = new byte[] { (byte) 100, (byte) 100, (byte) 10, (byte) 10, (byte) 1, (byte) 100 };
        int int62 = cpioArchiveInputStream51.read(byteArray59, (int) (byte) 1, 0);
        int int63 = tarArchiveInputStream46.read(byteArray59);
        long long65 = tarArchiveInputStream46.skip((long) 0);
        int int66 = tarArchiveInputStream46.getRecordSize();
        java.io.InputStream inputStream67 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarArchiveInputStream69 = new org.apache.commons.compress.archivers.tar.TarArchiveInputStream(inputStream67, (int) (byte) 100);
        java.io.OutputStream outputStream70 = null;
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream72 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream70, (int) (byte) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream74 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream(outputStream70, (int) (short) 100);
        org.apache.commons.compress.archivers.tar.TarArchiveOutputStream tarArchiveOutputStream76 = new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream((java.io.OutputStream) tarArchiveOutputStream74, (int) (short) 10);
        byte[] byteArray77 = new byte[] {};
        tarArchiveOutputStream76.write(byteArray77);
        tarArchiveInputStream69.copyEntryContents((java.io.OutputStream) tarArchiveOutputStream76);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream80 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) tarArchiveInputStream69);
        org.apache.commons.compress.archivers.ar.ArArchiveInputStream arArchiveInputStream81 = new org.apache.commons.compress.archivers.ar.ArArchiveInputStream((java.io.InputStream) arArchiveInputStream80);
        byte[] byteArray85 = new byte[] { (byte) 10, (byte) 0, (byte) 1 };
        int int88 = arArchiveInputStream80.read(byteArray85, 0, (int) (short) -1);
        int int91 = tarArchiveInputStream46.read(byteArray85, (int) (byte) 100, (int) (short) 10);
        int int92 = arArchiveInputStream28.read(byteArray85);
        boolean boolean94 = org.apache.commons.compress.archivers.jar.JarArchiveInputStream.matches(byteArray85, (-1));
        try {
            arArchiveOutputStream13.write(byteArray85, (int) (byte) 10, 97);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: request to write '97' bytes exceeds size in header of '0' bytes for entry 'null'");
        } catch (java.io.IOException e) {
        }
        org.junit.Assert.assertNotNull(byteArray24);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray24), "[]");
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(byteArray59);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray59), "[100, 100, 10, 10, 1, 100]");
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 512 + "'", int66 == 512);
        org.junit.Assert.assertNotNull(byteArray77);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray77), "[]");
        org.junit.Assert.assertNotNull(byteArray85);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray85), "[10, 0, 1]");
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + (-1) + "'", int91 == (-1));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

}
