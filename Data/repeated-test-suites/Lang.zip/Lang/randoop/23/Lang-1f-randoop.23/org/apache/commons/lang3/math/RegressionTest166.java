package org.apache.commons.lang3.math;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest166 {

    public static boolean debug = false;

    @Test
    public void test00001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00001");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00002");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test00003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00003");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00004");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00005");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00006");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00007");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00008");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00009");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00010");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00011");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                   ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00012");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, (double) 0, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test00013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00013");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hi");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00014");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test00015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00015");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00016");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test00017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00017");
        long[] longArray4 = new long[] { 100L, (byte) 1, 0, 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[100, 1, 0, 1]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test00018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00018");
        byte[] byteArray0 = new byte[] {};
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
    }

    @Test
    public void test00019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00019");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hhi!ihi!!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00020");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00021");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) (byte) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test00022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00022");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00023");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, (int) (short) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test00024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) -1, (double) '#', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00025");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("HI!", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00026");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 100, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00027");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 100, (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00028");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00029");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
    }

    @Test
    public void test00030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00030");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) ' ', (int) (short) 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test00031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00031");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, 32L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test00032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00032");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00033");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00034");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00035");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00036");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 100L, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00037");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00038");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00039");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', (double) 32L, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test00040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00040");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00041");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00042");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00043");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) 'a', (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00044");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!hhi!ihi!!hi!", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00045");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test00046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00046");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 32, (int) (byte) -1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test00047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00047");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00048");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test00049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00049");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00050");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00051");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00052");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00053");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test00054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00054");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00055");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00056");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00057");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00058");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00059");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:           ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test00060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00060");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                           100#10#1#1#-1                                            ", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test00061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00061");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray5, " ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test00062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00062");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00063");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a-1a11a-1a11a-hi1a-1a11a-1a11a-", (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test00064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00064");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hhi!ihi!!hi!", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test00065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00065");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaa", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test00066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00066");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00067");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00068");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00069");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                         ...", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00070");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Hi!hhi!ihi!!hi!", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00071");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00072");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1ahi-");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00073");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1ahi-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1ahi-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00074");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ", (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00075");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00076");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00077");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#10#1#1#-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00078");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test00079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00079");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                !");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00080");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("AAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00081");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00082");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("\r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00083");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00084");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00085");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray0), "[]");
    }

    @Test
    public void test00086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00086");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00087");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0a3.0a100.0a100.0", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00088");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "#");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: #");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test00089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00089");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hhi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00090");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, (float) 1L, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test00091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00091");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a');
        try {
            float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test00092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00092");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("97a-1a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00093");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1a-1a11a-1a11a-hi1a-1a11a-1a11a-", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00094");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), (double) (-1L), (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test00095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00095");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97a-1a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00096");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 4, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test00097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00097");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00098");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00099");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97#-1#10#100", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00100");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                   ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00101");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test00102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00102");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00103");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) (short) 10, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test00105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00105");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 3, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test00106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00106");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00107");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00108");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!1040414");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00109");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00110");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00111");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("\r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00112");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00113");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                                ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                 ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#10#1#1#-1" + "'", str10.equals("100#10#1#1#-1"));
    }

    @Test
    public void test00114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00114");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:           ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10a1a1a-1" + "'", str9.equals("100a10a1a1a-1"));
    }

    @Test
    public void test00115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00115");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1ahi-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00116");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00117");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00118");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100a10a1a1a-11ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-11ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00119");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00120");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100a10a1a1a-11ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test00121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00121");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00122");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                               a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00123");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, (long) (-1), (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00124");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 2, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test00125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00125");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00126");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                !", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00127");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1ahi-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00128");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test00129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00129");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("97#-1#10#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00130");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  AAAAA   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00131");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00132");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00133");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, (long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00134");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test00135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00135");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00136");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00137");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00138");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00139");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00140");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("  1a-1a1  ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00141");
        int[] intArray5 = new int[] { '#', (byte) 10, ' ', ' ', 32 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[35, 10, 32, 32, 32]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test00142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00142");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1ahi-1ahi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00143");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: a is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00144");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#", 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test00145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00145");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0a3.0a100.0a100.0", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test00146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00146");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                               a", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00147");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00148");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0a0a100a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00149");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) (short) -1, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00150");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00151");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test00152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00152");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00153");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, 0L, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00154");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0 3.0 100.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0 3.0 100.0 100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00155");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, 100L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test00156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00156");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(1L, (long) '#', (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test00157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00157");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 28, (float) (short) -1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test00158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00158");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 10, 35.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test00159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00159");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Hi!h!i!!!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00160");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, (float) 5, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test00161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00161");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0          ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1.equals(100.0f));
    }

    @Test
    public void test00162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00162");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00163");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00164");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("AAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00165");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("#", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test00166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00166");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0a52.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0a52.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00167");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 10, (double) 2, 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00168");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, (long) (short) -1, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00169");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a3.0a100.0a100.01");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00170");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Hi!h!i!!!", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test00171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00171");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0                                !100.0", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test00172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00172");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00173");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0a52.0", (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test00174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00174");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("i!hhi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!hhi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00175");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Ha!HaHHa!HaHHa!hiHa!HaHHa!HaHHa!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00176");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) 100.0f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test00177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00177");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00178");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00179");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00180");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00181");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaa                                                                                               ", (double) 28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test00182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00182");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00183");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("HI!HHI!IHI!!HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!HHI!IHI!!HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00184");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00185");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "100.0          97#-1#10#97#-1#10#97");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0          97#-1#10#97#-1#10#97");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test00186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00186");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("AAAAA", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test00187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00187");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, (int) ' ', 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test00188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00188");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00189");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00190");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00191");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) '4', 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test00192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00192");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0                                !100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0                                !100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00193");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  AAAAA   ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00194");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00195");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (-1), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test00196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00196");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00197");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00198");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!10404141ahi-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00199");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100a10a1a1a-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00200");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("32", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test00201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00201");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00202");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaa                                                                                               class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test00203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00203");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97A-1A10A100                                                                                        ", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test00204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00204");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("!################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!################################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00205");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0a3.0a100.0a100.01");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00206");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00207");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00208");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00209");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray0), "[]");
    }

    @Test
    public void test00210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00210");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) (byte) -1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00211");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test00212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00212");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0          ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test00213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00213");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a10a1a1a-1                                                                                       ", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00214");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00215");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00216");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.0A3.0A100.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00217");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0", (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test00218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00218");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n", (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 32.0d, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test00220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00220");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 1, (int) (byte) 1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test00221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00221");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00222");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...........................i!hhi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...........................i!hhi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00223");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00224");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00225");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0          ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test00226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00226");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 97, (int) '#');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a-1a1" + "'", str10.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test00227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00227");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00228");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("  ######  ", (float) 18);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18.0f + "'", float2 == 18.0f);
    }

    @Test
    public void test00229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00229");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) 4, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test00230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00230");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00231");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, 5, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test00232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00232");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("I!hhii!hhii!hhii!1i!hhii!hhii!hhii!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: I!hhii!hhii!hhii!1i!hhii!hhii!hhii! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00233");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1a10a100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1a10a100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test00234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00234");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 0, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test00235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00235");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                               a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                               a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00236");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        try {
            byte byte3 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test00237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00237");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 4, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test00238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00238");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, (double) 28, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test00239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00239");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.0A3.0A100.0A100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00240");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8, (double) (-1.0f), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
    }

    @Test
    public void test00241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00241");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97#-1#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00242");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0a3.0a100.0a100.01 ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00243");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00244");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.0a3.0a100.0a100.01 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00245");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("97a-1a10a100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00246");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, (long) 2, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test00247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00247");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1040414041010.0a3.0a100.0a100.01", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00248");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100a10a1a1a-1                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-1                                                                                       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00249");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) 2, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test00250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00250");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("...aaaaaaaa100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...aaaaaaaa100#10#1#1#-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00251");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97#-1#10#100", (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test00252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00252");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, 1L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test00253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00253");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1a-1a14444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00254");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00255");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...........................i!hhi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".....\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00256");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00257");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1ahi-1ahi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 1ahi-1ahi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00258");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Ha!HaHHa!HaHHa!hiHa!HaHHa!HaHHa!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00259");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\r1", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00260");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("  1a-1a1  ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00261");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hhi!ihi!!hi!", 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00262");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a                                                                                               \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00263");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97A-1A10A100                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00264");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(18, 3, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test00265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00265");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("a                                                                                               ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00266");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00267");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.Class<?> wildcardClass9 = byteArray4.getClass();
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test00268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00268");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00269");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32L, (double) 5L, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test00270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00270");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00271");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00272");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (byte) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00273");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaa                                                                                               ", (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test00274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00274");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00275");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("iHi!hhi!ihi!!hi!Hi!hhi", (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test00276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00276");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00277");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) (byte) 0, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00278");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00279");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97L, (float) 28, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test00280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00280");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 8, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test00281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00281");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00282");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 3, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test00283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00283");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test00284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00284");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0          ", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test00285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00285");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100.0                                !100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0                                !100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00286");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("a");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00287");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!10404141ahi-", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00288");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 97L, (float) (byte) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test00289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00289");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(28.0f, 0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test00290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00290");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00291");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("        100#10#1#1#-1", (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test00292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00292");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00293");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("010353552");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test00294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00294");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00295");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                           100#10#1#1#-1                                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00296");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaa                                                                                               ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00297");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test00298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00298");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00299");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100a10a1a1a-1                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-1                                                        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00300");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 67, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 67");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
    }

    @Test
    public void test00301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00301");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaA");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00302");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97.0f, (double) 7, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test00303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00303");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("14-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00304");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                               a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00305");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (short) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test00306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00306");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("010353552");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00307");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 ?  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00308");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10L, (double) 67, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test00309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00309");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7, (double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test00310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00310");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), 8.0d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test00311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00311");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("5#0#10#2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5#0#10#2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00312");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00313");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00314");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) -1, (-1), 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test00315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00315");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0a3.0a100.0a100.01");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00316");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00317");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00318");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00319");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("  1a-1a1  ", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00320");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test00321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00321");
        short[] shortArray4 = new short[] { (short) 100, (byte) 10, (byte) 100, (short) 0 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        java.lang.Class<?> wildcardClass6 = shortArray4.getClass();
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[100, 10, 100, 0]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test00322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00322");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("i");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00323");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00324");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 10, (int) (byte) 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.Class<?> wildcardClass12 = floatArray4.getClass();
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test00325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00325");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100.0          97#-1#10#97#-1#10#971a-1a11a-1a11a-hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00326");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("404140410");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.04140416E8f + "'", float1 == 4.04140416E8f);
    }

    @Test
    public void test00327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00327");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("################################################################################################-1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00328");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10, 0.0f, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00329");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, (long) '#', (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test00330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00330");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00331");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97#-1#10#10097#-1#10#10097#-1#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00332");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100a10a1a1a-11a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-11a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00333");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0A3.0A100.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0A3.0A100.0A100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00334");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00335");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                               ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00336");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!", (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test00337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00337");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, 4.04140416E8f, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test00338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00338");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100#10#1#1#-1", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00339");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100.0                                !100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00340");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                               ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00341");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test00342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00342");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test00343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00343");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1ahi-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00344");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2, (float) 100, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test00345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00345");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi1a-1a11a-1a11a-", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00346");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("#", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test00347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00347");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00348");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                ", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test00349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00349");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, (int) (byte) 0, 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test00350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00350");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("\r1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"?1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00351");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0", (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00352");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("14-141", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test00353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00353");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00354");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...        100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00355");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00356");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100a10a1a1a-11ahi-1ahi!1ahi-1ahi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-11ahi-1ahi!1ahi-1ahi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00357");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 444444444444444444L + "'", long1.equals(444444444444444444L));
    }

    @Test
    public void test00358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 97, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test00359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00359");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00360");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', (int) (byte) 1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test00361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00361");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, 0.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test00362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00362");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) '#', (-1));
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test00363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00363");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00364");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00365");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ", (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00366");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 ?  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00367");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00368");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test00369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00369");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00370");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00371");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00372");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("              ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00373");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) ' ', (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test00374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00374");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0.001a0.001a0.3a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".001a0.001a0.3a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00375");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 35.0d, (double) 96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.0d + "'", double3 == 96.0d);
    }

    @Test
    public void test00376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00376");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100.0          97#-1#10#97#-1#10#971a-1a11a-1a11a-hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00377");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00378");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00379");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("!################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: !################################################################################################ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00380");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10#0#1#0#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10#0#1#0#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00381");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97#-1#10#", (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test00382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00382");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaa                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00383");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test00384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00384");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
    }

    @Test
    public void test00385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00385");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test00386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00386");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                   ...                         100#10#1#1#-1                                            ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00387");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00388");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!1040414");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!1040414\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00389");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) 1, (long) 51);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
    }

    @Test
    public void test00390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00390");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 7, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00391");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97A-1A10A100                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00392");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0 10 35 35 52");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00393");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) -1, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00394");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00395");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00396");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("010353552");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test00397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00397");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00398");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97A-1A10A100                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00399");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00400");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100a10a1a1a-11ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi-1ahi!1ahi", (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test00401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00401");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Ha!HaHHa!HaHHa!hiHa!HaHHa!HaHHa!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00402");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00403");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("## ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00404");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 3.0f + "'", float9 == 3.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 100.0f + "'", float10 == 100.0f);
    }

    @Test
    public void test00405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00405");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                               a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00406");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa## 1040414041010.0a3.0a", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test00407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00407");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00408");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("AAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00409");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test00410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00410");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0          97#-1#10#97#-1#10#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0          97#-1#10#97#-1#10#97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00411");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Aaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00412");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, (long) (short) 1, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test00413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00413");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) 3, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test00414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00414");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00415");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 51L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test00416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00416");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 51.0f, (double) (short) -1, 96.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 96.0d + "'", double3 == 96.0d);
    }

    @Test
    public void test00417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00417");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00418");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, (float) 0L, (float) 35);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00419");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00420");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("## ", (float) 51);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test00421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00421");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0                           ", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test00422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00422");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("a-1a1hh");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a-1a1hh\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00423");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 0, (float) 5L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test00424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00424");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 10, (long) (short) -1, (long) 'a');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00425");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("    ", (float) 51L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test00426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00426");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("97 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00427");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 22, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test00428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00428");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97#-1#10#10097#-1#10#1000414041010.0a3.0a100.0a100.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#10097#-1#10#1000414041010.0a3.0a100.0a100.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00429");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("97a-1a10a100                                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97a-1a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00430");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("i!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!hhi!ihi!!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00431");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0.001a0.001a0.3a0.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00432");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("A                                                                                               ", (long) 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test00433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00433");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test00434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00434");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00435");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(50, 22, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00436");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00437");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 16, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00438");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.Class<?> wildcardClass11 = byteArray4.getClass();
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test00439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00439");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00440");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00441");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 50, (float) 50, 51.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test00442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00442");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test00443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00443");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4.04140416E8f, (double) (byte) -1, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test00444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00444");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00445");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("     Aaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00446");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00447");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2L, 97L, 5L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test00448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00448");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0a0a100a100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00449");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a11a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00450");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00451");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("        100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00452");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00453");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "                               a");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                a");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
    }

    @Test
    public void test00454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00454");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("## ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00455");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00456");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00457");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00458");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("AAAAA", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00459");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("00.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00460");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00461");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00462");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00463");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("97#-1#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00464");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("4a4aa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00465");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00466");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Hi!h!i!!!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Hi!h!i!!!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00467");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00468");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100.0          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1.equals(100.0d));
    }

    @Test
    public void test00469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00469");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, 4.0f, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test00470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00470");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test00471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00471");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0                                !100.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00472");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test00473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00473");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("A                                                                                               ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00474");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(10.0f, (float) 32L, (float) 52L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test00475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00475");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100.0          97#-1#10#97#-1#10#971a-1a11a-1a11a-hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0          97#-1#10#97#-1#10#971a-1a11a-1a11a-hi1a-1a11a-1a11a-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00476");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, (float) 3, 97.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test00477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00477");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97#-1#10#10097#-1#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00478");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hA!hAhhA!hAhhA!HIhA!hAhhA!hAhhA!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a1a1a-1" + "'", str13.equals("100a10a1a1a-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test00479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00479");
        float[] floatArray2 = new float[] { (byte) -1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray2), "[-1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
    }

    @Test
    public void test00480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00480");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("04041004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test00481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00481");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("AAAAAHi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00482");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00483");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0...        100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00484");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1a-1a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00485");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) -1, (double) (-1), (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test00486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (byte) 0, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00488");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00489");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00490");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test00491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00491");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97a-1a10a100" + "'", str11.equals("97a-1a10a100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97a-1a10a100" + "'", str13.equals("97a-1a10a100"));
    }

    @Test
    public void test00492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00492");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, 0.0d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test00493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00493");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00494");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00495");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0a3.0a100.0a100.01 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 10.0a3.0a100.0a100.01  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00496");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 35, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00497");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test00498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00498");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("            !100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00499");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test00500");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1-#1#1#01#001        ...0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1-#1#1#01#001        ...0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00501");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                   ", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00502");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a10a1a1a-11a10a100", 51.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test00503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00503");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', 97.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test00504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00504");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test00505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00505");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".0a3.0a        100#10#1#1#-1a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00506");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00507");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00508");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a10a1a1a-1                                                        ", (double) 18.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test00509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00509");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (byte) 10, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test00510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00510");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1ahi-1ahi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00511");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00512");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1a-1a1" + "'", str9.equals("1a-1a1"));
    }

    @Test
    public void test00513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00513");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00514");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, (float) 1, (float) 444444444444444444L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.44444453E17f + "'", float3 == 4.44444453E17f);
    }

    @Test
    public void test00515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00515");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!            !100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00516");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 190, (long) 33, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 33L + "'", long3 == 33L);
    }

    @Test
    public void test00517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00517");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97a-1a10a10097a-1a10a10097a-1a10a10097a-1a11040414041097a-1a10a10097a-1a10a10097a-1a10a10097a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00518");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) (short) 1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test00519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00519");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97a-1a10a100                                                                                        ", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00520");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1a-1a14444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a14444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00521");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("32", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 32 + "'", byte2 == (byte) 32);
    }

    @Test
    public void test00522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00522");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaa## 1040414041010.0a3.0a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00523");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2.0f, 0.0d, (double) 96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test00524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00524");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), 35, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test00525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00525");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 4, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test00526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00526");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, 11, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test00527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00527");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("97#-1#10#", (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test00528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00528");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (short) 1, (long) 50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00529");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, (long) 97, (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test00530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00530");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("          97#-1#10#97#-1#10#97");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00531");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("  aaaaa   ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00532");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (byte) 32, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 18.0f + "'", float5 == 18.0f);
    }

    @Test
    public void test00533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00533");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test00534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00534");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test00535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00535");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Hi!h!i!!!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00536");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 67, (long) (byte) 10, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test00537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00537");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1ahi-.0a3.0a100.0a100.010.0a3.0a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00538");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 1, 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test00539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00539");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("!ih!!ihi!ihh!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!ih!!ihi!ihh!ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00540");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00541");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 67L, (double) 18L, (double) 11L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.0d + "'", double3 == 67.0d);
    }

    @Test
    public void test00542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00542");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 18, 1);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', (int) (byte) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 52 + "'", int13 == 52);
    }

    @Test
    public void test00543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00543");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaa...............................................................................................");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00544");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("97#-1#10#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 97#-1#10# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00545");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test00546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00546");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test00547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00547");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a0a100a100" + "'", str11.equals("0a0a100a100"));
    }

    @Test
    public void test00548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00548");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("97#-1#10#", (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test00549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00549");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4444444 + "'", int1 == 4444444);
    }

    @Test
    public void test00550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00550");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(15, (int) ' ', 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test00551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00551");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00552");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00553");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("10 0 1 0 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10 0 1 0 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00554");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100a1a0a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a1a0a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00555");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(15, 9, 316);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test00556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00556");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 22, 2L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 22L + "'", long3 == 22L);
    }

    @Test
    public void test00557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00557");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#############################################################################10.0 3.0 100.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00558");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0          \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00559");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaa## 1040414041010.0a3.0aA                                                                                               ", (long) 50);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test00560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00560");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97 10", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00561");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" 1AAAAAHi!hhi!ihi!!hi!", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test00562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00562");
        long[] longArray4 = new long[] { 100L, (byte) 1, 0, 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 0, (int) (byte) 1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (byte) 1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[100, 1, 0, 1]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test00563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00563");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00564");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n", (double) 51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test00565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00565");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 65, 0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00566");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) 96, (float) 50L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test00567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00567");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 2, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test00568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00568");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#10#1#1#-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00569");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00570");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00571");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test00572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00572");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("...aaaaaaaa100#10#1#1#-1", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test00573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00573");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00574");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 50, (long) 5, (long) 65);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test00575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00575");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...        100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00576");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00577");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52.0f, (double) 100, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test00578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00578");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10#0#1#0#10i!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00579");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!h!i!!!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!h!i!!!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00580");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1a10a100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00581");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), (double) 5.0f, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test00582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00582");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00583");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("00.0", (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00584");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\r1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1.equals(1.0f));
    }

    @Test
    public void test00585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00585");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00586");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1ahi-");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00587");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 1, (-1));
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "  1a");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:   1a");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test00588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00588");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 1, (float) '#', (float) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test00589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00589");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0 0 100 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 0 100 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00590");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00591");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, 4.44444453E17f, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.44444453E17f + "'", float3 == 4.44444453E17f);
    }

    @Test
    public void test00592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00592");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00593");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, (long) 96, (long) 51);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 96L + "'", long3 == 96L);
    }

    @Test
    public void test00594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00594");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 100 + "'", number1.equals(100));
    }

    @Test
    public void test00595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00595");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 5.0f, 18.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test00596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00596");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 32, 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00597");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("AAAAAHi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00598");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10a0a1a0a10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00599");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".0a3.0a        100#10#          97#-1#10#97#-1#10#97");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00600");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 316, (long) 51, 1L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test00601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00601");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test00602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00602");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10.0a3.0a100.0a100.01 ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00603");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("97 -1 10 100AAAAA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97 -1 10 100AAAAA\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00604");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("...............................................................................................");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00605");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97#-1#10#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00606");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00607");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 32, (int) ' ');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 3.0f + "'", float9 == 3.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test00608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00608");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00609");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("           10a0a1a0a10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00610");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.043.04100.04100.0", (long) 50);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test00611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00611");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("28a100a35a0a10", 51.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test00612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00612");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(5.0d, (double) 52, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test00613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00613");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("10.0#3.0#100.0#100.0", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test00614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00614");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("        ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test00615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00615");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00616");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0hi!", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00617");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("I!hhii!hhii!hhii!1i!hhii!hhii!hhii!", 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test00618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00618");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" 1AAAAAHi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 1AAAAAHi!hhi!ihi!!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00619");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0                           ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test00620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00620");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00621");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 22L, (float) '4', (float) 22);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test00622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00622");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("A                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A                                                                                               \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00623");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 32, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00624");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 8, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test00625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00625");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a10a1a1a-1                                                        100a10a1a1a-1                                                        ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00626");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 100, (int) (byte) 10);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 4, 4444444);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test00627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00627");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00628");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0.001a0.001a0.3a", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00629");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00630");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00631");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, (int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00632");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00633");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       ", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test00634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00634");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("###################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00635");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 52, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test00636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00636");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 51, 50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test00637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00637");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100.0                                !100.01A-1A14444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00638");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, 36, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00639");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "97A-1A10A100                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 97A-1A10A100                                                                                       ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test00640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00640");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, ".010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: .010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test00641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00641");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00642");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00643");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0a3.0a100.0a100.01 aaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 10.0a3.0a100.0a100.01 aaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00644");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 32, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test00645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00645");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00646");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00647");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("97 -1 10 100AAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00648");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("!################################################################################################10404140410          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!################################################################################################10404140410          \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00649");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("I!hhii!hhii!hhii!1i!hhii!hhii!hhii!", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00650");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) 5L, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test00651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00651");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(50, (int) (byte) -1, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00652");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test00653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00653");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("10.0a3.0a100.0a100.01 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a3.0a100.0a100.01 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00654");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10a0a1a0a10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00655");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4a4aa", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test00656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00656");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0#0#100#100" + "'", str8.equals("0#0#100#100"));
    }

    @Test
    public void test00657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00657");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 32, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test00658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00658");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 96, 444444444444444444L, (long) 22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 444444444444444444L + "'", long3 == 444444444444444444L);
    }

    @Test
    public void test00659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00659");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, 18, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test00660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00660");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#0.0#3.0##00.0##00.10.0 3.0 100.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00661");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00662");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test00663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00663");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("## !1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!", (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test00664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00664");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                   ...                         100#10#1#1#-1                                            ", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test00665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00665");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00666");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00667");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00668");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test00669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00669");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 50L, 4.44444453E17f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test00670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00670");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 32, (short) (byte) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test00671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00671");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("97#-1#10#");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00672");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), (long) 100, (long) 28);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test00673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00673");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test00674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00674");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(22, 100, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test00675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00675");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00676");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("04041004100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test00677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00677");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "...        100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ...        100#10#1#1#-1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test00678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00678");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...aaaaaaaa100#10#1#1#-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00679");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97#-1#10#10097#-1#10#1000414041010.0a3.0a100.0a100.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00680");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00681");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("10.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00682");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("               97#-1#10#97#-1#10#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#97#-1#10#97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00683");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 10, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a-1a1" + "'", str10.equals("1a-1a1"));
    }

    @Test
    public void test00684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00684");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1ahi-1ahi!-1.0a52.0", 51.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test00685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00685");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("00.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00686");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00687");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" iHi!hhi!ihi!!hi!Hi!hhi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00688");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00689");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 32, (short) (byte) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test00690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00690");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, 0, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00691");
        short[] shortArray5 = new short[] { (short) 10, (byte) 0, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (int) (short) 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[10, 0, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10404140410" + "'", str7.equals("10404140410"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test00692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00692");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ", (long) (short) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test00693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00693");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 0, (double) 1.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test00694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00694");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, 444444444444444444L, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test00695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00695");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("97#-1#10#10097#-1#10#10097#-1#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#10097#-1#10#10097#-1#10#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00696");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("         .        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00697");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("97A-1A10A100                                                                                                                       a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97A-1A10A100                                                                                                                       a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00698");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("    404140410     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00699");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14-141" + "'", str9.equals("14-141"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
    }

    @Test
    public void test00700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00700");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00701");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0                                !100.01A-1A144444444444444440A100.0A100.010.0A3.0A100.0A100.0", (double) 18L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test00702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00702");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00703");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97a-1a10a100" + "'", str11.equals("97a-1a10a100"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "974-14104100" + "'", str13.equals("974-14104100"));
    }

    @Test
    public void test00704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00704");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00705");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!            !100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!hhii!hhii!hhii!1i!hhii!hhii!hhii!            !100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00706");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("AAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00707");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.2.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.2.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00708");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(50L, (long) 50, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 50L + "'", long3 == 50L);
    }

    @Test
    public void test00709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00709");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test00710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00710");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 61, (double) 0, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 61.0d + "'", double3 == 61.0d);
    }

    @Test
    public void test00711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00711");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0" + "'", str11.equals("100.0"));
    }

    @Test
    public void test00712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00712");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1a10a100aaaaA");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00713");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 330, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test00714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00714");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("A                                                                                               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00715");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("97#-1#10#100100.0          97#-1#10#97#-1#10#97", (byte) 32);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 32 + "'", byte2 == (byte) 32);
    }

    @Test
    public void test00716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00716");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, 0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test00717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00717");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00718");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("!################################################################################################10404140410          ", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test00719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00719");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00720");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 32, (long) 9, (long) 50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 50L + "'", long3 == 50L);
    }

    @Test
    public void test00721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00721");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(18.0d, (double) 11L, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.0d + "'", double3 == 18.0d);
    }

    @Test
    public void test00722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00722");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 1, (int) (byte) 1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test00723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00723");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("52.0a18.0a35.0                  ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00724");
        float[] floatArray2 = new float[] { (byte) -1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray2), "[-1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a52.0" + "'", str5.equals("-1.0a52.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 52.0f + "'", float8 == 52.0f);
    }

    @Test
    public void test00725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00725");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 0, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "14-141" + "'", str9.equals("14-141"));
    }

    @Test
    public void test00726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00726");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 9.0f, (float) 301);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00727");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, (int) (short) 10, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test00728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00728");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00729");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 32, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00730");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("        hi97 -1 10 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00731");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00732");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a10a1a1a-1                                                                                       ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00733");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00734");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1a", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test00735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00735");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0                                                                                               ", (double) 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test00736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00736");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test00737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00737");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00738");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 51, (float) 100L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test00739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00739");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 65, (long) (short) 10, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 65L + "'", long3 == 65L);
    }

    @Test
    public void test00740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00740");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 32, 36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
    }

    @Test
    public void test00741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00741");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00742");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "0410435435452");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0410435435452");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
    }

    @Test
    public void test00743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00743");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0                                                                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00744");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, 0.0f, (float) 15);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test00745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00745");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("    ", (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test00746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00746");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(".0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00747");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 10, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test00748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00748");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("  1a-1a1  ", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00749");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00750");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(28, 0, 96);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00751");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 33L, (double) 18L, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test00752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00752");
        float[] floatArray2 = new float[] { (byte) -1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', (int) (short) -1, 316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray2), "[-1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a52.0" + "'", str5.equals("-1.0a52.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test00753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00753");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                               aA                               aA                               aA                               aA                               aA                               a", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test00754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00754");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) (byte) 10, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test00755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00755");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("4444444444444444444444410h0a3h0a100h0a100h0444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00756");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.Class<?> wildcardClass11 = byteArray5.getClass();
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10a1a1a-1" + "'", str9.equals("100a10a1a1a-1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test00757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00757");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 97L, (float) 9L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test00758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00758");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("97a-1a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00759");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10#0#1#0#10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00760");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 93, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 93");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
    }

    @Test
    public void test00761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00761");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#10#1#1#-1" + "'", str10.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test00762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00762");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0.0f, (double) 52L, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test00763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00763");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1040414041010.0a3.0a100.0a100.01", 60);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 60 + "'", int2 == 60);
    }

    @Test
    public void test00764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00764");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', 100, (int) (short) -1);
        try {
            byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test00765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00765");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 50L, (double) 10, 61.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 61.0d + "'", double3 == 61.0d);
    }

    @Test
    public void test00766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00766");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 2, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00767");
        float[] floatArray2 = new float[] { (byte) -1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', 36, 301);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray2), "[-1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a52.0" + "'", str5.equals("-1.0a52.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test00768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00768");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("         .        ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00769");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(51L, (long) 'a', 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
    }

    @Test
    public void test00770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00770");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 1, (double) 35L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test00771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00771");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0#10#35#35#52");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00772");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test00773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00773");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00774");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("00.0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0f + "'", number1.equals(0.0f));
    }

    @Test
    public void test00775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00775");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4a4aa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00776");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100a10a1a1a-14-141");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00777");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("323232323232323232323232323232323232323232323232323232323hi!1040414");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00778");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi97 -1 10 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi97 -1 10 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00779");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 1, 35, 316);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 316 + "'", int3 == 316);
    }

    @Test
    public void test00780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00780");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100#10#1#1#-1                                            I!hhii!hhii!hhii!1i!hhii!hhii!hhii");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00781");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi1a-1a11a-1a11a-40410     ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00782");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2L, (float) 7, (float) 21);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 21.0f + "'", float3 == 21.0f);
    }

    @Test
    public void test00783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00783");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00784");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0a100aaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00785");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 21, 330);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 21");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97#-1#10#100" + "'", str12.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test00786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00786");
        short[] shortArray2 = new short[] { (short) 0, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 16, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 100]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test00787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00787");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test00788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00788");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaa", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test00789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00789");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) -1, 36);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test00790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00790");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 51L, 0.0d, 28.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test00791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00791");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00792");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) -1, (float) 8, (float) 96L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test00793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00793");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00794");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) 'a', 316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
    }

    @Test
    public void test00795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00795");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test00796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00796");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97L, (double) 9.0f, (double) 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test00797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00797");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00798");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "hi1a-1a11a-1a11a");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi1a-1a11a-1a11a");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test00799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00799");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00800");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("         .        ", (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test00801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00801");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("               97#-1#10#97#-1#10#97");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"               97#-1#10#97#-1#10#97\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00802");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(301, (int) (short) 10, 4444444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test00803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00803");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("          10.001a0.001a0.3a0.0101404140001#01#1-#79001#01#1-#79", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test00804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00804");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, (int) (short) 100, 60);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test00805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00805");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100A10A1A1A-1                                                        100A10A1A1A-1                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00806");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00807");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("97a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00808");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00809");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 51L, (float) 316, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 316.0f + "'", float3 == 316.0f);
    }

    @Test
    public void test00810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00810");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00811");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("97a-1a10a100                                                                                       ", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test00812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00812");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) '4', (int) (short) -1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1-1.0a52.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1-1.0a52.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test00813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00813");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0 0 100 100", 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test00814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00814");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 11L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test00815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00815");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test00816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00816");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1ahi-.0a3.0a100.0a100.010.0a3.0a97a-1a10a10097a-1a10a10097a-1a10a10097a-1a11040414041097a-1a10a10097a-1a10a10097a-1a10a10097a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1ahi-.0a3.0a100.0a100.010.0a3.0a97a-1a10a10097a-1a10a10097a-1a10a10097a-1a11040414041097a-1a10a10097a-1a10a10097a-1a10a10097a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00817");
        short[] shortArray4 = new short[] { (short) 100, (byte) 10, (byte) 100, (short) 0 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray4), "[100, 10, 100, 0]");
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test00818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00818");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00819");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5L, (double) 18L, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test00820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00820");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test00821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00821");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               aaaaa                                                                                               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00822");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00823");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00824");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00825");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("A                                                                                               h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A                                                                                               h is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00826");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0A100.0A100.010.0A3.0A100.0A100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00827");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10.043.04100.04100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00828");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 32, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test00829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00829");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#0.0#3.0##00.0##00.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00830");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test00831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00831");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi1a-1a11a-1a11a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00832");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test00833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00833");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 32, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00834");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00835");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 65, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00836");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("97#10", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test00837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00837");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, 33, 316);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 316 + "'", int3 == 316);
    }

    @Test
    public void test00838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00838");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(28.0f, (float) 1, (float) 67L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 67.0f + "'", float3 == 67.0f);
    }

    @Test
    public void test00839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00839");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00840");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 35, (long) 60, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test00841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00841");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(52L, 100L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00842");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 32, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00843");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 22, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 3.0f + "'", float7 == 3.0f);
    }

    @Test
    public void test00844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00844");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00845");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 19, 301);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#10#1#1#-1" + "'", str10.equals("100#10#1#1#-1"));
    }

    @Test
    public void test00846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00846");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10a0a1a0a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00847");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("########");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00848");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: !");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test00849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00849");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 96, (long) 22, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 96L + "'", long3 == 96L);
    }

    @Test
    public void test00850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00850");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("...                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10                   ...#1#1#-197a-1a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00851");
        long[] longArray4 = new long[] { 100L, (byte) 1, 0, 1 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 0, (int) (byte) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 0, (int) (short) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[100, 1, 0, 1]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a1a0a1" + "'", str12.equals("100a1a0a1"));
    }

    @Test
    public void test00852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00852");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                1a-1a11a-1a11a-hi1a-1a11a-1a11a-0A100.0A100.010.0A3.0A100.0A100.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00853");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28, (double) 2.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test00854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00854");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(11, 11, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test00855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00855");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 32, (long) (short) 100, (long) 18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 18L + "'", long3 == 18L);
    }

    @Test
    public void test00856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00856");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("04100", (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4100L + "'", long2 == 4100L);
    }

    @Test
    public void test00857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00857");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("...........................i!hhi", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00858");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1ahi-1ahi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00859");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 52, 11L, (long) 21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
    }

    @Test
    public void test00860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00860");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("97a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00861");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 32, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00862");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" 1", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test00863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00863");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 51L, 67.0d, 96.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test00864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00864");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100a10a1a1a-1                                     ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test00865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00865");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 28, (long) 3, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test00866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00866");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', (int) (byte) 1, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a0a100a100" + "'", str11.equals("0a0a100a100"));
    }

    @Test
    public void test00867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00867");
        long[] longArray2 = new long[] { 'a', (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (byte) 100, (int) (short) -1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', (int) (short) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray2), "[97, 10]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97a10" + "'", str9.equals("97a10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 97L + "'", long10 == 97L);
    }

    @Test
    public void test00868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00868");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 28, (long) 316, (long) 21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 316L + "'", long3 == 316L);
    }

    @Test
    public void test00869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00869");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test00870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00870");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00871");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a10a100", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test00872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00872");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa                                                                                               class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00873");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(11, 2, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test00874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00874");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hhi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00875");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00876");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("################################################################################################", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00877");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaa...............................................................................................");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00878");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00879");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0                                !100.0100a10a1a1a-14-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00880");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2L, (long) (byte) 0, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00881");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 32, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test00882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00882");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a10a1a1a-1                                     ", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test00883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00883");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!I!!!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00884");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 4.44444453E17f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4444445274066125E17d + "'", double2 == 4.4444445274066125E17d);
    }

    @Test
    public void test00885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00885");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', (int) '4', 4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 16, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test00886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00886");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A1", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test00887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00887");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100a10a1a1a-11a10a100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00888");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00889");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1a-1a1    1a-1aaaaaa97 -1 10 100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00890");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((-1L), (long) 301, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test00891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00891");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444444444444444410h0a3h0a100h0a100h0444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444410h0a3h0a100h0a100h0444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00892");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32L, (double) 100L, (double) 22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test00893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00893");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00894");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 10, 330, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test00895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00895");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("!################################################################################################10404140410          !", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00896");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4444444, 0.0d, (double) (byte) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4444444.0d + "'", double3 == 4444444.0d);
    }

    @Test
    public void test00897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00897");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1040414041010.0a3.0a100.0a100.01");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00898");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a-1a11a-1a11a-hi1a-1a11a-1a11a-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00899");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100A10A1A1A-1                                                                                       ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test00900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00900");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00901");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Hi!1040414", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test00902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00902");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00903");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(67, 93, 93);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test00904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00904");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 50L, (float) 316, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test00905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00905");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00906");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 1, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.043.04100.04100.0" + "'", str12.equals("10.043.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0#3.0#100.0#100.0" + "'", str14.equals("10.0#3.0#100.0#100.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10.0 3.0 100.0 100.0" + "'", str17.equals("10.0 3.0 100.0 100.0"));
    }

    @Test
    public void test00907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00907");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(50, (int) ' ', 330);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test00908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00908");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', (int) (byte) 100, 3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10.0 3.0 100.0 100.0" + "'", str13.equals("10.0 3.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.043.04100.04100.0" + "'", str15.equals("10.043.04100.04100.0"));
    }

    @Test
    public void test00909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00909");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Hi!1040414");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00910");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) '#', (-1));
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "14-141" + "'", str13.equals("14-141"));
    }

    @Test
    public void test00911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00911");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(28.0f, (float) 35L, (float) 60);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test00912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00912");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97 10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00913");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test00914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00914");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, (double) 33, (double) 22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test00915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00915");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                               aA                               aA                               aA                               aA                               aA                               a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aA                               aA                               aA                               aA                               aA                               a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00916");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test00917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00917");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 7, 316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 0 + "'", byte7 == (byte) 0);
    }

    @Test
    public void test00918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00918");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("A");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00919");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H-1.0hI!H!I!!!hI!H!I!!!hI!H!I!!!hI!H!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00920");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("50a2a0", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test00921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00921");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("A                                                                                               h", (byte) 32);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 32 + "'", byte2 == (byte) 32);
    }

    @Test
    public void test00922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00922");
        short[] shortArray5 = new short[] { (short) 10, (byte) 0, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[10, 0, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10404140410" + "'", str7.equals("10404140410"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a0a1a0a10" + "'", str10.equals("10a0a1a0a10"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 10 + "'", short13 == (short) 10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a0a1a0a10" + "'", str15.equals("10a0a1a0a10"));
    }

    @Test
    public void test00923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00923");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(32, 16, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 32 + "'", int3 == 32);
    }

    @Test
    public void test00924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00924");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 32, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00925");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100 10 1 1 -1", (double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test00926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00926");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...        100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00927");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("1ahi-1ahi!-1.0a5.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00928");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (short) 1, 4L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test00929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00929");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 51, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00930");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 32, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test00931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00931");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(10.0f, (float) 3, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test00932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00932");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) '#', (-1));
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
    }

    @Test
    public void test00933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00933");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 93, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 93 + "'", int3 == 93);
    }

    @Test
    public void test00934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00934");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00935");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" iHi!hhi!ihi!!hi!Hi!hhi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" iHi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00936");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00937");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("52.0a18.0a35.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52.0a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00938");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "AAAAA");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: AAAAA");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100a10a1a1a-1" + "'", str17.equals("100a10a1a1a-1"));
    }

    @Test
    public void test00939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00939");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 96, 67);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray5, '#');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a10a35a35a52" + "'", str9.equals("0a10a35a35a52"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0#10#35#35#52" + "'", str16.equals("0#10#35#35#52"));
    }

    @Test
    public void test00940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00940");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.Class<?> wildcardClass10 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test00941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00941");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ');
        try {
            byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test00942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00942");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("class [Ljava.lang.String;class [Ljava.lang.String;");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Ljava.lang.String;class [Ljava.lang.String;\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00943");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00944");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, (long) 60, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test00945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00945");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4444a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00946");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100#10#1#1#-1 I!hhii!hhii!hhii!1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100#10#1#1#-1 I!hhii!hhii!hhii!1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00947");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1097a-1a10a10097a-1a10a10097a-1a10a10097a-1a140414041ahi-.0a3.0a100.0a100.010.0a3.0a97a-1a10a10097a-1a10a10097a-1a10a10097a-1a110");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00948");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00949");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(20, 0, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test00950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00950");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) (byte) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00951");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, 4444444, 4444444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test00952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00952");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                      1ahi-1ahi!97A-1A10A100                                                                                        1ahi-1ahi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test00953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00953");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (short) -1, 301);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
    }

    @Test
    public void test00954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00954");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 51L, (float) 67L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test00955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00955");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                     100.1100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00956");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("I!HHI!IHI!!HI!", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test00957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00957");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test00958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00958");
        long[] longArray5 = new long[] { 22, 5, (byte) 1, (byte) 0, (-1L) };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray5, ' ', (int) (byte) 32, 347);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray5), "[22, 5, 1, 0, -1]");
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 22L + "'", long6 == 22L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test00959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00959");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1a-1a1hh0hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00960");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100a10a1a1a-1                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a10a1a1a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00961");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                         ...");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                          ...");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100#10#1#1#-1" + "'", str15.equals("100#10#1#1#-1"));
    }

    @Test
    public void test00962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00962");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("             41", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test00963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00963");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 32, (byte) 32, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00964");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("             41", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test00965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00965");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0                                                                                               ", (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test00966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00966");
        short[] shortArray5 = new short[] { (short) 10, (byte) 0, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 10, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[10, 0, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10404140410" + "'", str7.equals("10404140410"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
    }

    @Test
    public void test00967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00967");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97 -1 10 100" + "'", str12.equals("97 -1 10 100"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "97a-1a10a100" + "'", str14.equals("97a-1a10a100"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "97#-1#10#100" + "'", str16.equals("97#-1#10#100"));
    }

    @Test
    public void test00968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00968");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 97, (float) 22, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test00969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00969");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(93, 51, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test00970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00970");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00971");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(28.0f, 4.04140416E8f, 2.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test00972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00972");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0 10 35                                a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 10 35   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00973");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 3.0f + "'", float8 == 3.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str10.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
    }

    @Test
    public void test00974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00974");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                     aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test00975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00975");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi", 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

    @Test
    public void test00976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00976");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test00977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00977");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a10a1a1a-1                                                        100a10a1a1a-1                                                        ", (double) 15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15.0d + "'", double2 == 15.0d);
    }

    @Test
    public void test00978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00978");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test00979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00979");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 41, 5L, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 41L + "'", long3 == 41L);
    }

    @Test
    public void test00980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00980");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 32, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test00981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00981");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test00982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00982");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(2L, (long) 2, 11L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test00983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00983");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  1a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  1a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00984");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test00985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00985");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\r00.097#-1#10#97#-1#10#971A-1A11A-1A11A-HI1A-1A11A-1A11A-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"00.097#-1#10#97#-1#10#971A-1A11A-1A11A-HI1A-1A11A-1A11A-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00986");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00987");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 15, (long) 61, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 61L + "'", long3 == 61L);
    }

    @Test
    public void test00988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00988");
        int[] intArray5 = new int[] { 28, (short) 100, 35, 0, (byte) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[28, 100, 35, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "28a100a35a0a10" + "'", str7.equals("28a100a35a0a10"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "28410043540410" + "'", str10.equals("28410043540410"));
    }

    @Test
    public void test00989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00989");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 330, (long) 18, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 330L + "'", long3 == 330L);
    }

    @Test
    public void test00990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00990");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100a10a1a1a-11ahi-1ahi!1ahi-1ahi");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test00991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00991");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 32, (byte) 32, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test00992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00992");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"?\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00993");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "97#-1#10#97#-1#10#97");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 97#-1#10#97#-1#10#97");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100a10a1a1a-1" + "'", str17.equals("100a10a1a1a-1"));
    }

    @Test
    public void test00994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00994");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("      ... 100#10#1#1#-197a-1a10a100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test00995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00995");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                               aA                               aA                               aA                               aA                               aA                               a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test00996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00996");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-197a-1a10a100#1#1#10#... 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test00997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00997");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(50L, 0L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test00998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00998");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("97#-1#10#10097#-1#10#10097#-1#10#100", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test00999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test00999");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 100, (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 301, 36);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 33, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test01000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01000");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 50L, (double) 35L, 33.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.0d + "'", double3 == 33.0d);
    }

    @Test
    public void test01001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01001");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100a10a1a1a-1                                     ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01002");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 100, 0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test01003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01003");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01004");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10041041414-", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test01005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01005");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Aaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01006");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "hi!1040414");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!1040414");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100a10a1a1a-1" + "'", str14.equals("100a10a1a1a-1"));
    }

    @Test
    public void test01007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01007");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) 11L, (double) 41L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.0d + "'", double3 == 41.0d);
    }

    @Test
    public void test01008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01008");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!ih!!ihi!ihh!ih");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01009");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                     ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01010");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(21, (int) (byte) 100, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 21 + "'", int3 == 21);
    }

    @Test
    public void test01011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01011");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 347, (double) 96, (double) 330);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 347.0d + "'", double3 == 347.0d);
    }

    @Test
    public void test01012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01012");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ahiahi!", (double) 18.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 18.0d + "'", double2 == 18.0d);
    }

    @Test
    public void test01013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01013");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "                                                                                       0.001A0.001A0.3A                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                                                                        0.001A0.001A0.3A                                                                                       ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test01014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01014");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100A10A1A1A-1                                                                                       ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01015");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 96, 32);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test01016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01016");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa## 1040414041010.0a3.0aA                                                                                               ", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test01017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01017");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0a10a35a35a52");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01018");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 18, (float) 316L, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 9.0f + "'", float3 == 9.0f);
    }

    @Test
    public void test01019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01019");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 60, (float) 190, (float) 18);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 190.0f + "'", float3 == 190.0f);
    }

    @Test
    public void test01020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01020");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 32, (short) (byte) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01021");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 347, 0.0f, (float) 41);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test01022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01022");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01023");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(35L, (long) (short) 100, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test01024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01024");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) '#', (int) (byte) 1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a-1a1" + "'", str10.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "14-141" + "'", str16.equals("14-141"));
    }

    @Test
    public void test01025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01025");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                    100.1100.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test01027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01027");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(2.0d, 18.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test01028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01028");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test01029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01029");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0                                !100.0", 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test01030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01030");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hh1a-1a1hh");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01031");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97 -1 10 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01032");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 31, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test01033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(8.0d, (double) 51, (double) 93);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.0d + "'", double3 == 93.0d);
    }

    @Test
    public void test01034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01034");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("04100", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4100L + "'", long2 == 4100L);
    }

    @Test
    public void test01035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01035");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(310, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 310 + "'", int3 == 310);
    }

    @Test
    public void test01036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01036");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test01037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01037");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#####", 2.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test01038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01038");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test01039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01039");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 50, 36);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 61, 316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 61");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32" + "'", str5.equals("32"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 32L + "'", long6 == 32L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test01040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01040");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 36, 0.0d, (double) 43);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test01041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01041");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa001#001#0#0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (long) 330);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 330L + "'", long2 == 330L);
    }

    @Test
    public void test01042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01042");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test01043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01043");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(61, 31, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 61 + "'", int3 == 61);
    }

    @Test
    public void test01044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01044");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test01045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01045");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 1, (int) (byte) 1);
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "97#-1#10#100" + "'", str18.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "974-14104100" + "'", str20.equals("974-14104100"));
    }

    @Test
    public void test01046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01046");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test01047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01047");
        long[] longArray4 = new long[] { 5, 0, 10, 2 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, 'a', (int) (short) 10, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[5, 0, 10, 2]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test01048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01048");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("97a-1a10a100                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97a-1a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01049");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100a10a1a1a-11a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01050");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 32, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test01051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01051");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 203, (float) 61, (float) 316);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 61.0f + "'", float3 == 61.0f);
    }

    @Test
    public void test01052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01052");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                               HI!HHI!IHI!!HI!                                   ...                         100#10#1#1#-1                                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01053");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(1.0d, (double) 41L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.0d + "'", double3 == 41.0d);
    }

    @Test
    public void test01054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01054");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01055");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1a-1a1");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1a-1a1");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100a10a1a1a-1" + "'", str9.equals("100a10a1a1a-1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test01056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01056");
        short[] shortArray5 = new short[] { (short) 10, (byte) 0, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a', (int) (short) 100, 0);
        short short14 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[10, 0, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10404140410" + "'", str7.equals("10404140410"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 10 + "'", short9 == (short) 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 10 + "'", short14 == (short) 10);
    }

    @Test
    public void test01057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01057");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("## ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01058");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("ihh!i", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test01059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01059");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("97#-1#10#100...        100#10#1#1#-197a-1a10a100                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 97#-1#10#100...        100#10#1#1#-197a-1a10a100                                                                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01060");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("97A-1A10A100                                                                                        ", 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test01061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01061");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(18, 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test01062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01062");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100A10A1A1A-1                                                                                       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01063");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 ?  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01064");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0          ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01065");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, 3.0f, (float) 34);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test01066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01066");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...AAAAAAAA100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01067");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 199, (float) 203);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test01068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01068");
        short[] shortArray1 = new short[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) 'a', 35);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 0, (int) (short) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test01069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01069");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test01070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01070");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01071");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 32L + "'", long9 == 32L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
    }

    @Test
    public void test01072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01072");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Clas...", (double) 4100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4100.0d + "'", double2 == 4100.0d);
    }

    @Test
    public void test01073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01073");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) 32, (short) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01074");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" iHi!hhi!ihi!!hi!Hi!hhi", (float) 60);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 60.0f + "'", float2 == 60.0f);
    }

    @Test
    public void test01075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01075");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("32  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01076");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) 52L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test01077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01077");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("A10A1A1A-1                                                        100A10A1A1A");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01078");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 60, 11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 9, 203);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test01079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01079");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("###                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01080");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 10, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test01081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01081");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97#-1#10#100100.0          97#-1#10#97#-1#10#97");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01082");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.001A0.001A0.3A");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01083");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaA\n", 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test01084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01084");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("5a0a10a2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5a0a10a2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01085");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.097#-1#10#97", (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test01086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test01087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01087");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
    }

    @Test
    public void test01088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01088");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  ", 28L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test01089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01089");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H10.0a3.0a100.0a100.01I!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H-1.0HI!H!I!!!HI!H!I!!!HI!H!I!!!HI!H!-197a-1a10a100#1#1#10#... 100", 4.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test01090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01090");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 9, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test01091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01091");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 'a', (float) 35, (float) 19);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 19.0f + "'", float3 == 19.0f);
    }

    @Test
    public void test01092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01092");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a-14-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: a-14- is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01093");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaa97 -1 10 100", (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test01094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01094");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.01ahi-1ahi!-1.0a52.0", (float) 31);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.0f + "'", float2 == 31.0f);
    }

    @Test
    public void test01095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01095");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, '#', 19, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a10a35a35a52" + "'", str9.equals("0a10a35a35a52"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test01096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01096");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 50L, 100.0d, (double) 96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test01097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01097");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.001a0.001a0.3a", (float) 43);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 43.0f + "'", float2 == 43.0f);
    }

    @Test
    public void test01098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01098");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(5.0d, (double) 10, (double) 4.44444453E17f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test01099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01099");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, (float) 0, (float) 4100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4100.0f + "'", float3 == 4100.0f);
    }

    @Test
    public void test01100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01100");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100#10#1#1#-1" + "'", str13.equals("100#10#1#1#-1"));
    }

    @Test
    public void test01101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01101");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hI!H!I!!!.................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01102");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("001a001a0a0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01103");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test01104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01104");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("!!!i!h!iH", (long) 51);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test01105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01105");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 5, 0L, (long) 12);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test01106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01106");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("a10a1a1a-1                                                        100a10a1a1a-1                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a10a1a1a-1                                                        100a10a1a1a-1                                                        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01107");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, 35.0f, (float) 310);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 310.0f + "'", float3 == 310.0f);
    }

    @Test
    public void test01108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01108");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0                                !100.0100.0                                !100.0100.0                                !100.0100.0                                !100.0100.0                                !100.0100.0                                !100.0100.0                                !100.0100.0                     ...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01109");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1  10a0a1a0a10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01110");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1-1.0a52.0", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test01111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01111");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01112");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 347, (long) (short) -1, (long) 347);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test01113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01113");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 32, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test01114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01114");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01115");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.010.001a0.001a0.3a0.01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01116");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(15, 67, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test01117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01117");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi0      ... iHi!hhi!ihi!!hi!Hi!hhi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01118");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 94, (float) (byte) 10, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test01119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01119");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test01120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01120");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test01121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01121");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                   ...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01122");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01123");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test01124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01124");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 21, (double) 96, (double) 316);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 316.0d + "'", double3 == 316.0d);
    }

    @Test
    public void test01125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01125");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0a3.0a100.0a100.01 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0a3.0a100.0a100.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01126");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("              ", (double) 43);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.0d + "'", double2 == 43.0d);
    }

    @Test
    public void test01127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01127");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01128");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 1, (-1));
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str23 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-                                !a-14-");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100a10a1a1a-1" + "'", str19.equals("100a10a1a1a-1"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100#10#1#1#-1" + "'", str21.equals("100#10#1#1#-1"));
    }

    @Test
    public void test01129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01129");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 22, (float) (-1), 190.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 190.0f + "'", float3 == 190.0f);
    }

    @Test
    public void test01130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01130");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0                            ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test01131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01131");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test01132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01132");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa140410     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa140410     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01133");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                a", 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test01134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01134");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, (int) 'a', 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test01135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01135");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01136");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("52.0 18.0 35.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01137");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.043.04100.04100.0" + "'", str12.equals("10.043.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0#3.0#100.0#100.0" + "'", str14.equals("10.0#3.0#100.0#100.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10.0 3.0 100.0 100.0" + "'", str17.equals("10.0 3.0 100.0 100.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str19.equals("10.0a3.0a100.0a100.0"));
    }

    @Test
    public void test01138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01138");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("HI");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HI\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01139");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaA\n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 43.0f, (double) 61, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 43.0d + "'", double3 == 43.0d);
    }

    @Test
    public void test01141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01141");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01142");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 34, (float) 1, (float) 67L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test01143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01143");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01144");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01145");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test01146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01146");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test01147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01147");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 17, (long) 136, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 136L + "'", long3 == 136L);
    }

    @Test
    public void test01148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01148");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01149");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 0, 21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test01150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01150");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) 15, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test01151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01151");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01152");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, 0, 18);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test01153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01153");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi!hi!hhi!ihi!!hi! is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01154");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test01156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01156");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1A10A100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01157");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0410435435452");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 410435435452L + "'", long1 == 410435435452L);
    }

    @Test
    public void test01158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01158");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi97 -1 10 100", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test01159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01159");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01160");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100 10 1 1 -1" + "'", str14.equals("100 10 1 1 -1"));
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) 100 + "'", byte15 == (byte) 100);
    }

    @Test
    public void test01161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01161");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01162");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1a10a100aaaaA", 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test01163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01163");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaa## 1040414041010.0a3.0aA                                                                                               ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01164");
        short[] shortArray2 = new short[] { (short) 0, (short) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 100]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0#100" + "'", str5.equals("0#100"));
    }

    @Test
    public void test01165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01165");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("###################################100101#");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01166");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10, (double) 21, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test01167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01167");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0!100.0 1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01168");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32L, (float) 100, (float) 17);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test01169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01169");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 32, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01170");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("\r1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"?1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01171");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("     0hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01172");
        long[] longArray2 = new long[] { 'a', (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (byte) 100, (int) (short) -1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 45, 190);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 45");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray2), "[97, 10]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
    }

    @Test
    public void test01173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01173");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(43, 67, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test01174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01174");
        float[] floatArray2 = new float[] { (byte) -1, '4' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 13, (int) (short) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray2), "[-1.0, 52.0]");
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0a52.0" + "'", str5.equals("-1.0a52.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test01175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01175");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 301, 0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 301L + "'", long3 == 301L);
    }

    @Test
    public void test01176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01176");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("            !");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01177");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 32, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01178");
        long[] longArray4 = new long[] { 100L, '4', 'a', 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 15, 873);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[100, 52, 97, 100]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 52L + "'", long5 == 52L);
    }

    @Test
    public void test01179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01179");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4444444, (double) 17, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4444444.0d + "'", double3 == 4444444.0d);
    }

    @Test
    public void test01180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01180");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test01181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01181");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 136L, (float) 5L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test01182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01182");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "hi1a-1a11a-1a11a");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi1a-1a11a-1a11a");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
    }

    @Test
    public void test01183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01183");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, '#');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', 2, 1);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray5, '4', 28, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a10a35a35a52" + "'", str9.equals("0a10a35a35a52"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#10#35#35#52" + "'", str11.equals("0#10#35#35#52"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0#10#35#35#52" + "'", str13.equals("0#10#35#35#52"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test01184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01184");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 9, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test01185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01185");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(".0a100.01i10.0a3.0a100.0a100.01i10.0a3.0a100.0a100.01i10.0a3.0a100.0a100.01i10.0a3.0a100.0a100.01i10.0a3.0a100.0a100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01186");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 32, (byte) 10, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test01187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01187");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01188");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) 28, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test01189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01189");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1ahi-1ahi!97A-1A10A100                                                                                        1ahi-1ahi!97A-1A10A100                                                                                        1ahi-1ahi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01190");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("14-141");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"14-141\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01191");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("97#-1#10#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01192");
        long[] longArray4 = new long[] { 5, 0, 10, 2 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray4, '#');
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 31, 203);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 31");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[5, 0, 10, 2]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5#0#10#2" + "'", str7.equals("5#0#10#2"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test01193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01193");
        float[] floatArray1 = new float[] { (byte) -1 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 0, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0" + "'", str5.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test01194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01194");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 32, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test01195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01195");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 100, (long) 93, (long) 330);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 93L + "'", long3 == 93L);
    }

    @Test
    public void test01196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01196");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01197");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 10, (int) (byte) 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 22, 7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 60, 21);
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 43, 199);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 43");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 100.0f + "'", float11 == 100.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10.043.04100.04100.0" + "'", str17.equals("10.043.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test01198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test01199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01199");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        100a10a1a1a-1                                                        ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01200");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("97#10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test01201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01201");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Aaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01202");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "              1A10A100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:               1A10A100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test01203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01203");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test01204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01204");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...        100#10#1#1#-197a-1a10a100                                                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: ...        100#10#1#1#-197a-1a10a100                                                                                         is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01205");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.097#-1#10#100-1.0A52.0                            !100.01A-1A144444444444444440A100.0A100.010.0A3.0A100.0A100.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01206");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 471, (double) 4L, (double) 22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 471.0d + "'", double3 == 471.0d);
    }

    @Test
    public void test01207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01207");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A11A1-A1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01208");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("i!hhi1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"i!hhi1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01209");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 199, (long) 36, (long) (short) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 199L + "'", long3 == 199L);
    }

    @Test
    public void test01210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01210");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10404140410i!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01211");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test01212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01212");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0A10A1A1A");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0A10A1A1A\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01213");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01214");
        long[] longArray2 = new long[] { 'a', (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (byte) 100, (int) (short) -1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray2), "[97, 10]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97410" + "'", str9.equals("97410"));
    }

    @Test
    public void test01215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01215");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                                    ", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test01216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01216");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("...        100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01218");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("97#-1#10#10097#-1#10#1000414041010.0a3.0a100.0a100.01");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#10097#-1#10#1000414041010.0a3.0a100.0a100.01\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01219");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100, (double) 59, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test01220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01220");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("i!hhii!hhii!hhii!1i!hhii!hhii!hhii!            !100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01221");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) (byte) 1, (short) (byte) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test01222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01222");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 0, (int) (short) -1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0" + "'", str6.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100.0" + "'", str8.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
    }

    @Test
    public void test01223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01223");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(100L, (long) (byte) 100, 3L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test01224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01224");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(4.04140416E8f, 52.0f, (float) 4444444);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test01225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01225");
        short[] shortArray1 = new short[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) 'a', 35);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 0, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
    }

    @Test
    public void test01226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01226");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(".010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01227");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01228");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("             41");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01229");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01230");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a", (double) 316.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 316.0d + "'", double2 == 316.0d);
    }

    @Test
    public void test01231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01231");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("   ", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test01232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01232");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97a-1a10a100" + "'", str10.equals("97a-1a10a100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "97 -1 10 100" + "'", str13.equals("97 -1 10 100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test01233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01233");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01234");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 32);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test01235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01235");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4444444444444447E189d + "'", double1 == 4.4444444444444447E189d);
    }

    @Test
    public void test01236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01236");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 32, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01237");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) (short) 32, (long) 11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test01238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01238");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.25a0.1-!iha1-iha1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01239");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1ahi-");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01240");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(".010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01241");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, (float) 444444444444444444L, (float) 301L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test01242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01242");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("97#-1#10#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01243");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("A                                                                                               ", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test01244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01244");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test01245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01245");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(3L, (long) (short) 10, (long) 46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 46L + "'", long3 == 46L);
    }

    @Test
    public void test01246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01246");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("97a-1a10a10", (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test01247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01247");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, 35.0f, 18.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test01248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01248");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1110a100.097#-1#10#10097#-1#10#10097#-1#10#1000...", 4.4444444444444447E189d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4444444444444447E189d + "'", double2 == 4.4444444444444447E189d);
    }

    @Test
    public void test01249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01249");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test01250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01250");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100#10#1#...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01251");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...1                                                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01252");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("        ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01253");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 32, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01254");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("###################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"######\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01255");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4101a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a1001a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4101a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01256");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01257");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.0#3.0#100.0#100.00a0a100a100", (double) 41L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.0d + "'", double2 == 41.0d);
    }

    @Test
    public void test01258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01258");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test01259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01259");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Hi!hhi!ihi!!hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01260");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 316, (float) 4100L, 51.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test01261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01261");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 32, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test01262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01262");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test01263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01263");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(136L, 65L, (long) (short) 32);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 136L + "'", long3 == 136L);
    }

    @Test
    public void test01264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01264");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA001#001#0#0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (long) 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test01265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01265");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test01266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01266");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 94, 208);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 94");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a18.0a35.0" + "'", str6.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0a18.0a35.0" + "'", str8.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 18.0f + "'", float9 == 18.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
    }

    @Test
    public void test01267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01267");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 50, 28.0d, (double) 5L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.0d + "'", double3 == 50.0d);
    }

    @Test
    public void test01268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01268");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("1a53552                            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a53552\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01269");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01270");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hia-aa-aa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hia-aa-aa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01271");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("97A-1A10A100                                                                                                                       a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01272");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("          0.001HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01273");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 61);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test01274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01274");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 97, 301L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 301L + "'", long3 == 301L);
    }

    @Test
    public void test01275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01275");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4L, (double) 316, (double) 31);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 316.0d + "'", double3 == 316.0d);
    }

    @Test
    public void test01276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01276");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test01277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01277");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(43.0d, 100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test01278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01278");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a18.0a35.0" + "'", str6.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52.0a18.0a35.0" + "'", str9.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 18.0f + "'", float10 == 18.0f);
    }

    @Test
    public void test01279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01279");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-197a-1a10a100#1#1#10#... 100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01280");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1040414041010.0a3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01281");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(5L, (long) 96, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test01282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01282");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 32, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01283");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#', 28, (-1));
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test01284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01284");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 136, (long) 9, (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test01285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01285");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4444444, (double) 36, 22.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.0d + "'", double3 == 22.0d);
    }

    @Test
    public void test01286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01286");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1040414041010.0a3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01287");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n", 96.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.0d + "'", double2 == 96.0d);
    }

    @Test
    public void test01288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01288");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 471, 301);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 471 + "'", int3 == 471);
    }

    @Test
    public void test01289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01289");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 316, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test01290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01290");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 16, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 16.0f + "'", float3 == 16.0f);
    }

    @Test
    public void test01291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01291");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3L, 16.0f, 310.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test01292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01292");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(17, 11, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test01293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01293");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("!IH-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01294");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 18, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100.0" + "'", str7.equals("100.0"));
    }

    @Test
    public void test01295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01295");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("  1a-1a1                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01296");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(8, (int) 'a', 30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test01297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01297");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01298");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                   ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01299");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 22L, (float) 4L, (float) 65);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test01300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01300");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10404140410          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.040414041E10d + "'", double1.equals(1.040414041E10d));
    }

    @Test
    public void test01301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01301");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 ?  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01302");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test01303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01303");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 16.0f, (double) (byte) 10, (double) 41L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.0d + "'", double3 == 41.0d);
    }

    @Test
    public void test01304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01304");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("I!HHI!IHI!!HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"I!HHI!IHI!!HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01305");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test01306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01306");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aaaaa...............................................................................................");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaa...............................................................................................\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01307");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test01308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01308");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaahi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1a-1a1hh0hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1", 30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test01309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01309");
        short[] shortArray3 = new short[] { (byte) 1, (short) -1, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 97, (int) '#');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 2, (int) (short) -1);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (short) 1, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray3), "[1, -1, 1]");
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1a-1a1" + "'", str6.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) -1 + "'", short8 == (short) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a-1a1" + "'", str10.equals("1a-1a1"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test01310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01310");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 7, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test01311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01311");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                               aA                               aA                               aA                               aA                               aA                               a", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test01312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01312");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("  1a-1a1    1a-1a1    1a-1a1         1a-1a1    1a-1a1    1a-1a1    ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01313");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("97#-#10#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01314");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 16, 97L, 65L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 16L + "'", long3 == 16L);
    }

    @Test
    public void test01315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01315");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(".0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.010.0a3.0a100.0a100.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01316");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 ?  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01317");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("14-141", (float) 61L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 61.0f + "'", float2 == 61.0f);
    }

    @Test
    public void test01318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01318");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                         ...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01319");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 35 35 52" + "'", str9.equals("0 10 35 35 52"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0410435435452" + "'", str11.equals("0410435435452"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a10a35a35a52" + "'", str14.equals("0a10a35a35a52"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0410435435452" + "'", str16.equals("0410435435452"));
    }

    @Test
    public void test01320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01320");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray5, '4', 0, (-1));
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a10a1a1a-1" + "'", str13.equals("100a10a1a1a-1"));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test01321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01321");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1ahi-1ahi!.0#18.0#35.0", 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 28 + "'", int2 == 28);
    }

    @Test
    public void test01322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01322");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test01323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01323");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("###########     Aaaaa###########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01324");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, (float) 35, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test01325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01325");
        int[] intArray5 = new int[] { (short) 0, 10, '#', '#', '4' };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray5, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ');
        java.lang.Class<?> wildcardClass14 = intArray5.getClass();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray5), "[0, 10, 35, 35, 52]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 10 35 35 52" + "'", str9.equals("0 10 35 35 52"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0410435435452" + "'", str11.equals("0410435435452"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 10 35 35 52" + "'", str13.equals("0 10 35 35 52"));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test01326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01326");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 41, 59);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 41");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
    }

    @Test
    public void test01327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01327");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("A                                                                                               h");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01328");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01329");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (short) 1, (int) (byte) 1);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 2, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97#-1#10#100" + "'", str10.equals("97#-1#10#100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test01330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01330");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 2, 0.0f, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test01331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01331");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 32, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 32 + "'", byte3 == (byte) 32);
    }

    @Test
    public void test01332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01332");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a18.0a35.0" + "'", str6.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52.0a18.0a35.0" + "'", str8.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 18.0f + "'", float9 == 18.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "52.0 18.0 35.0" + "'", str11.equals("52.0 18.0 35.0"));
    }

    @Test
    public void test01333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01333");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100a1a0a1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01334");
        long[] longArray2 = new long[] { 'a', (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (byte) 100, (int) (short) -1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a', 347, 873);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 347");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray2), "[97, 10]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test01335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01335");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01336");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test01337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01337");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test01338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01338");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(301L, (long) 11, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 301L + "'", long3 == 301L);
    }

    @Test
    public void test01339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(13, 60, 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test01340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01340");
        long[] longArray1 = new long[] { ' ' };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', (int) (byte) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 7, 43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[32]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32" + "'", str10.equals("32"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32" + "'", str14.equals("32"));
    }

    @Test
    public void test01341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01341");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01342");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01343");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01344");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444        4444444444444444444444#a ", (double) 45);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.0d + "'", double2 == 45.0d);
    }

    @Test
    public void test01345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01345");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01346");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("   HI!HHI!IHI!!HI!100#10#1#1#-1                                            I!hhii!hhii!hhii!1i!hhii!hhii!hhii", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test01347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01347");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test01348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01348");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0#3.0#100.0#100.010.043.04100.04100.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01349");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", 873);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 873 + "'", int2 == 873);
    }

    @Test
    public void test01350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01350");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1a-1a11a-1a11a-hi1a-1a11a-1a11a-100.0                                !100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01351");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 60, 3L, 18L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3L + "'", long3 == 3L);
    }

    @Test
    public void test01352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01352");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 31, 0.0f, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test01353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01353");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 32, (short) (byte) 32, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test01354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01354");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("          0.001HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.001HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!HI!HHI!IHI!!HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01355");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(41L, (long) 7, (long) 2262);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2262L + "'", long3 == 2262L);
    }

    @Test
    public void test01356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01356");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 32, (short) -1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01357");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("i!", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test01358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01358");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Aaaaahi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1a-1a1hh0hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!10404141ahi-hi!1", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test01359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01359");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.4444447E9f + "'", float1.equals(4.4444447E9f));
    }

    @Test
    public void test01360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01360");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.5a0.1-!iha1-iha1!h!iH!!!i!h!iH!!!i!h!iH!!!i!h!iH0.1-h!iH!!!i!h!iH!!!i!h!iH!!!i!h!iH");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01361");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("52.0a18.0a35.0                  ", (float) 28L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test01362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01362");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("i!hhi1", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test01363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01363");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                ", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test01364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01364");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("!################################################################################################10404140410          !");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01365");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (long) 43);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43L + "'", long2 == 43L);
    }

    @Test
    public void test01366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01366");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 20, (float) 17, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 20.0f + "'", float3 == 20.0f);
    }

    @Test
    public void test01367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01367");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("            !100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"            !100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01368");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("22A5A1A0A-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"22A5A1A0A-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01369");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 13, (double) 310.0f, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test01370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01370");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test01371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01371");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test01372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01372");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2262L, (double) 35L, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test01373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01373");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97#-1#10#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97#-1#10#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01374");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 32, 11);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 8, 2262);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a18.0a35.0" + "'", str6.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 18.0f + "'", float7 == 18.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test01375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01375");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, 4444444, 136);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4444444 + "'", int3 == 4444444);
    }

    @Test
    public void test01376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01376");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100#10#1#...aaaaaaaaaaaaaaahiaaaaaaaaaaaaaaaa", (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test01377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01377");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("I!hhi1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"I!hhi1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01378");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), (float) 18, (float) 28L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test01379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01379");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test01380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01380");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(" 1;g\r00.097#-1#10#97#-1#10#971A-1A11A-1A11A-HI1A-1A11A-1A11A-aaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:  1;g?00.097#-1#10#97#-1#10#971A-1A11A-1A11A-HI1A-1A11A-1A11A-aaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01381");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 32, 316);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 0 + "'", byte10 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 0 + "'", byte11 == (byte) 0);
    }

    @Test
    public void test01382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01382");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1040414041010.0a3", 50L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test01383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01383");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 190, 190);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100#10#1#1#-1" + "'", str10.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100#10#1#1#-1" + "'", str12.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test01384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01384");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                           100#10#1#1#-1                                            ", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test01385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01385");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("97410");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test01386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01386");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 96, (long) 136);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 136L + "'", long3 == 136L);
    }

    @Test
    public void test01387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01387");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test01388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01388");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  ######    ######  10h0a3h0a100h0a100h0  ######    ######  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01389");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) 35, 444444444444444444L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 444444444444444444L + "'", long3 == 444444444444444444L);
    }

    @Test
    public void test01390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01390");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 0);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 97, 12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test01391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01391");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1a1    1a-1aaaaaa97 -1 10 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01392");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("11A1-A1 ...", 33L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test01393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01393");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test01394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01394");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(22L, (long) 2262, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 22L + "'", long3 == 22L);
    }

    @Test
    public void test01395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01395");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01396");
        long[] longArray2 = new long[] { 'a', (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', (int) (byte) 100, (int) (short) -1);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray2), "[97, 10]");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test01397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01397");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("00.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.010.0#3.0#100.0#100.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01398");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("40414041010.0a3.0a100.0a100.01  aaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"40414041010.0a3.0a100.0a100.01  aaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01399");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!1040414               97#-1#10#97#-1#10#97!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01400");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.097#-1#10#97#-1#10#971a-1a11a-1a11a-hi1a-1a11a-1a11a-", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test01401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01401");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................aaaaa...............................................................................................", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test01402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01402");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01403");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 96, 21);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0" + "'", str6.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test01404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01404");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("HI!HHI!IHI!!HI!100#10#1#1#-1I!hhii!hhii!hh...HI!HHI!IHI!!HI!100#10#1#1#-1I!hhii!hhii!hh...HI!HHI!IHI!!HI!100#10#1#1#-1I!hhii!hhii!hh....", 215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 215 + "'", int2 == 215);
    }

    @Test
    public void test01405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01405");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01406");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 96, (long) 46, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 96L + "'", long3 == 96L);
    }

    @Test
    public void test01407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01407");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("HI0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01408");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(52L, 41L, (long) 301);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 301L + "'", long3 == 301L);
    }

    @Test
    public void test01409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01409");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0                                !100.01A-1A14444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01410");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hI!H!I!!!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01411");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("44444444444444444444444444444444444-197a-1a10a100#1#1#10#... 100444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01412");
        long[] longArray4 = new long[] { 5, 0, 10, 2 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '4', 213, 0);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray4), "[5, 0, 10, 2]");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test01413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01413");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1A-1A14444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01414");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("HIHHIIHIHI100#10#1#1#-1 Ihhiihhiihhii1ihhiihhiihhii");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01415");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 4, 67);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a0a100a100" + "'", str8.equals("0a0a100a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0#0#100#100" + "'", str12.equals("0#0#100#100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 100 + "'", byte13 == (byte) 100);
    }

    @Test
    public void test01416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01416");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(5.0d, (double) 41L, 93.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.0d + "'", double3 == 93.0d);
    }

    @Test
    public void test01417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01417");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("A10A1A1A-1                                                        100A10A1A1A");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01418");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01419");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaa## 1040414041010.0a3.0aA                                                                                               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaa## 1040414041010.0a3.0aA                                                                                                is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01420");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.001A0.001A0.3A             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01421");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("hh1a-1a1hh");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hh1a-1a1hh\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01422");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test01423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01423");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("              1A10A100", (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test01424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01424");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("97#-1#10#10097#-1#10#100", (long) (short) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test01425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01425");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("!##################################################4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444!##################################################", (long) 301);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 301L + "'", long2 == 301L);
    }

    @Test
    public void test01426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01426");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#0.0#3.0##00.0##00.01a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01427");
        float[] floatArray3 = new float[] { 52.0f, 18, '#' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 19, 1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray3), "[52.0, 18.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a18.0a35.0" + "'", str6.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 52.0f + "'", float7 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "52.0a18.0a35.0" + "'", str9.equals("52.0a18.0a35.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "52.0 18.0 35.0" + "'", str11.equals("52.0 18.0 35.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test01428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01428");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 100, (int) (byte) 10);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (-1), 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0" + "'", str11.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0" + "'", str13.equals("100.0"));
    }

    @Test
    public void test01429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01429");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 32, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01430");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(4100L, 35L, (long) 208);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test01431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01431");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 1.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test01432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01432");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 100, (int) (byte) 10);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 51, 873);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0" + "'", str11.equals("100.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test01433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01433");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) -1, 208, 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test01434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01434");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1097#10.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01435");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 7, (int) (byte) 1);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0" + "'", str6.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0" + "'", str13.equals("100.0"));
    }

    @Test
    public void test01436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01436");
        double[] doubleArray1 = new double[] { 100.0f };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', (int) (byte) 100, (int) (byte) 10);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 301, 36);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray1, 'a', 203, 471);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 203");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[100.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100.0" + "'", str4.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test01437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01437");
        short[] shortArray5 = new short[] { (short) 10, (byte) 0, (byte) 1, (short) 0, (short) 10 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, '4');
        java.lang.Class<?> wildcardClass12 = shortArray5.getClass();
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[10, 0, 1, 0, 10]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10404140410" + "'", str7.equals("10404140410"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 10 + "'", short8 == (short) 10);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 0 + "'", short9 == (short) 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10404140410" + "'", str11.equals("10404140410"));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test01438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01438");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                       0.001A0.001A0.3A                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01439");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0          97-11097-110971a-1a11a-1a11a-hi1a-1a11a-1a11a-", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test01440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01440");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("97a-1a10a100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01441");
        int[] intArray2 = new int[] { (short) -1, (byte) -1 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray2, '4', (int) (short) 100, 22);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray2), "[-1, -1]");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test01442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01442");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01 I10.0a3.0a100.0a100.01  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01443");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100a10a1a1a-11a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01444");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;hi!10404141ahi-10.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.010.0A3.0A100.0A100.0100.0          class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;class [Ljava.lang.String;10.043.04100.04100.0                         ...1ahi-");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01445");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1 HI!HHI!IHI!!HI! ... 100#10#1#1#-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01446");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '4', 215, 199);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test01447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01447");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 61, (long) (short) 1, (long) 67);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 67L + "'", long3 == 67L);
    }

    @Test
    public void test01448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01448");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 32, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test01449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01449");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100L, 0.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test01450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01450");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...                           0.001", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test01451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01451");
        byte[] byteArray4 = new byte[] { (byte) 0, (byte) 0, (byte) 100, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 1, (int) (short) 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[0, 0, 100, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 0 + "'", byte6 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0 0 100 100" + "'", str9.equals("0 0 100 100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0a0a100a100" + "'", str11.equals("0a0a100a100"));
    }

    @Test
    public void test01452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01452");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih!!!I!H!Ih", (float) 96);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.0f + "'", float2 == 96.0f);
    }

    @Test
    public void test01453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01453");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), (long) 7, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test01454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01454");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 32, (short) (byte) 1, (short) 32);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 32 + "'", short3 == (short) 32);
    }

    @Test
    public void test01455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01455");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("28.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01456");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(53, (int) (short) 1, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 65 + "'", int3 == 65);
    }

    @Test
    public void test01457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01457");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test01458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01458");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 17, (long) 15, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 17L + "'", long3 == 17L);
    }

    @Test
    public void test01459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01459");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("97#-1#10#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01460");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(34, (int) (byte) 1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test01461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01461");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#', (int) (short) 10, (int) (byte) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        float float15 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 0, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10.043.04100.04100.0" + "'", str12.equals("10.043.04100.04100.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10.0#3.0#100.0#100.0" + "'", str14.equals("10.0#3.0#100.0#100.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 100.0f + "'", float15 == 100.0f);
    }

    @Test
    public void test01462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01462");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 96, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test01463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01463");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1a53552                            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01464");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("      ... 100#10#1#1#-197a-1a10a100");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test01465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01465");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("AAAAA## 1040414041010.0A3.0A", 2262);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2262 + "'", int2 == 2262);
    }

    @Test
    public void test01466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01466");
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 10, (byte) 1, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray5, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "A        .0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: A        .0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray5), "[100, 10, 1, 1, -1]");
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100#10#1#1#-1" + "'", str8.equals("100#10#1#1#-1"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test01467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01467");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(387, (int) 'a', 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test01468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01468");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("52.0A18.0A35.0                  A-1A1HH0", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test01469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01469");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("########\n########");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test01470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01470");
        float[] floatArray4 = new float[] { 10L, 3, 100.0f, 100L };
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a', 59, 215);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 59");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[10.0, 3.0, 100.0, 100.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 3.0f + "'", float5 == 3.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0a3.0a100.0a100.0" + "'", str7.equals("10.0a3.0a100.0a100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 100.0f + "'", float9 == 100.0f);
    }

    @Test
    public void test01471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01471");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("10i!# #i#                                                      00a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       100a10a1a1a-1                                                                                       ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01472");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test01473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01473");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("## ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test01474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01474");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444        4444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01475");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("hi!1040414aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: hi!1040414aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01476");
        int[] intArray4 = new int[] { 'a', (-1), (byte) 10, (byte) 100 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', 0, 0);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', 45, 310);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 45");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray4), "[97, -1, 10, 100]");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test01477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01477");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 208, 2L, (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test01478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01478");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hI!H!I!!!.................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................AAAAA...............................................................................................");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test01479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01479");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '#', 50.0d, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test01480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01480");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444i", (long) 67);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 67L + "'", long2 == 67L);
    }

    @Test
    public void test01481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01481");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97410");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test01482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01482");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 190, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test01483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01483");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("## !1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!1!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test01484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01484");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1 \r  1A-1A1    1A-1A1    1A-1A1    1A-1A1    1A-1A1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01485");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 316L, (double) 53L, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 316.0d + "'", double3 == 316.0d);
    }

    @Test
    public void test01486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01486");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444100A10A1A1A-1                                                                                       4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 34 + "'", int2 == 34);
    }

    @Test
    public void test01487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01487");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 136L, (double) 17, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.0d + "'", double3 == 17.0d);
    }

    @Test
    public void test01488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01488");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 115, (long) 31, 199L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 199L + "'", long3 == 199L);
    }

    @Test
    public void test01489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01489");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("97#-1#10#100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test01490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01490");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#0.0#3.0##00.0##00.", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01491");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(51.0f, 0.0f, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test01492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01492");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 \r  1a-1a1    1a-1a1    1a-1a1    1a-1a1    1a-1a1 ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test01493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01493");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 11, 4.04140416E8f, 4100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 11.0f + "'", float3 == 11.0f);
    }

    @Test
    public void test01494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01494");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                   1AHI-1AHI!97A-1A10A100                                                                                        1AHI-1AHI!", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test01495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01495");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                   5#0#10#25#0#10#25#0#10#25#0#10#25#0#10#25#0#10                   ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01496");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("28.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test01497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01497");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(2, 5, 65);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 65 + "'", int3 == 65);
    }

    @Test
    public void test01498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01498");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi1a-1a11a-1a11a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi1a-1a11a-1a11a-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test01499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01499");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!10404141ahi-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test01500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01500");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("100a10a1a1a-1                                                                                       ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

}
