package org.apache.commons.lang3.math;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest166 {

    public static boolean debug = false;

    @Test
    public void test000001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000001");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000002");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000003");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test000004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000004");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + (-1.0f) + "'", number1.equals((-1.0f)));
    }

    @Test
    public void test000005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000005");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000006");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000007");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) (-1), (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test000008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000008");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test000009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000009");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000010");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000011");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000012");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test000013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000013");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444hi!4444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000014");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444hi!4444", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test000015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000015");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000016");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 100.0f, (double) 10, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test000017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000017");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test000018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000018");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000019");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000020");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test000021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000021");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000022");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) -1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000023");
        float[] floatArray0 = new float[] {};
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray0), "[]");
    }

    @Test
    public void test000024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000024");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("\r");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000025");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(100.0f, 0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000026");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray0), "[]");
    }

    @Test
    public void test000027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000027");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000028");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test000029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000029");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) ' ', 10L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test000030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000030");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100.0 100.0 97.0 -1.0 0.0 -1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000031");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("\r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"?\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000032");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000033");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
    }

    @Test
    public void test000034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000034");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test000035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000035");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("\r444HI!4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000036");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000037");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("444hi!4444", "", (int) '#');
        java.lang.Object[] objArray14 = new java.lang.Object[] { double7, '#', (short) 100, 0.0f };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(objArray14, "hi!", (int) (byte) 0, (int) (short) 1);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(objArray14, "444hi!4444", (int) (byte) 100, 100);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[100.0, #, 100, 0.0]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[100.0, #, 100, 0.0]");
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100.0" + "'", str18.equals("100.0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test000038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000038");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhh");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000039");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', (float) 100, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000040");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\r444hi!4444", (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test000041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000041");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) 10L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test000042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000042");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000043");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.Class<?> wildcardClass5 = floatArray1.getClass();
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test000044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000044");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (byte) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test000045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000045");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) '#', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test000046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000046");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test000047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000047");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000048");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test000049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000049");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000050");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test000051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000051");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000052");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000053");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000054");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) (-1), 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test000055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000055");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test000056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000056");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0 + "'", number1.equals(0));
    }

    @Test
    public void test000057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000057");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000058");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, (long) (short) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test000059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000059");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000060");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("      0.1-", (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test000061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000061");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test000062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000062");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000063");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" # # ", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test000064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000064");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1a10a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000065");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000066");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(1.0f, (float) 10L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000067");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0a100.0a97.0a-1.0a0.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0a100.0a97.0a-1.0a0.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000068");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000069");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test000070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000070");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000071");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000072");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0      -1.0      -1.0      -1.0      -1.0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      -1.0      -1.0      -1.0      -1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000073");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, 0.0d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test000074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000074");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test000075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000075");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000076");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("\r", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test000077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000077");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test000078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000078");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" ", (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test000079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000079");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) 0, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
    }

    @Test
    public void test000080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000080");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0 100.0 97.0 -1.0 0.0 -1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000081");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, (int) '4', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test000082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000082");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass8 = longArray6.getClass();
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test000083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000083");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test000084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000084");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhh");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000085");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000086");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000087");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(198, 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test000088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000088");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000089");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000090");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test000091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000091");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000092");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test000093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000093");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("######################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000094");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test000095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000095");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000096");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("3a100a1a32a32a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3a100a1a32a32a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000097");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, (float) (byte) 100, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000098");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #", 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test000099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000099");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000100");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, (-1.0d), (double) 5);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test000101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000101");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000102");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test000103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000103");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0      -1.0      -1.0      -1.0      -1.0      ", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test000104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000104");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0L, (float) 0, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000105");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, (double) 10.0f, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test000106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000106");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\r444hi!4444", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000107");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test000108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000108");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000109");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) '4', (float) 32, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000110");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, (float) 100, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000111");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000112");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000113");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) -1, (float) '4', (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000114");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444HI!4444", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test000115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000115");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000116");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0                                                                                                ", (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test000117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000117");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, 0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test000118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000118");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0 0", 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test000119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000119");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test000120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000120");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("  # #  # #", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test000121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000121");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000122");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000123");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000124");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "\r444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ?444HI!4444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
    }

    @Test
    public void test000125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000125");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                       ", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test000126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000126");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("# #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000127");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000128");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000129");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000130");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, 5.0d, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test000131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000131");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("  # #  # #");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000132");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000133");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 4, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test000134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000134");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test000135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000135");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("# a 4 #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" a 4 #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000136");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, (double) (-1L), (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000137");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000138");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000139");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000140");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0d), (double) 3, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000141");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000142");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) (short) -1, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000143");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000144");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', (int) 'a', 198);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test000145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000145");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4441");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4441.0d + "'", double1.equals(4441.0d));
    }

    @Test
    public void test000146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(87, (-1), 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test000147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000147");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test000148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000148");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000149");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, 198, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 198 + "'", int3 == 198);
    }

    @Test
    public void test000150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000150");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000151");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 35, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a10a100" + "'", str12.equals("-1a10a10a100"));
    }

    @Test
    public void test000152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000152");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, (int) (byte) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test000153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000153");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000154");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000155");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000156");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, 0.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000157");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000158");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000159");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("######################################################################################################################################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000160");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000161");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.", (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test000162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000162");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000163");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000164");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" -1.  # #  # #");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000165");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444", (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test000166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000166");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
    }

    @Test
    public void test000167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000167");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10, (double) (-1.0f), 4441.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000168");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000169");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52L, (float) 1L, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test000170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000170");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000171");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test000172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000172");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444hi!4444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000173");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("  # #  # #", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test000174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000174");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000175");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(30, (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000176");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test000177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000177");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray4, " # # ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  # # ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test000178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000178");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0            -1.0            ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000179");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1.equals(4L));
    }

    @Test
    public void test000180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000180");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test000181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000181");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000182");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000183");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0                                                                                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000184");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 198, (long) 0, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test000185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000185");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("\r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"?\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000186");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0      -1.0      -1.0      -1.0      -1.0      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000187");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000188");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test000189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000189");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000190");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 100, (long) 30);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000191");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', (int) (short) 100, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test000192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000192");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10, (double) 100, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test000193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000193");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000194");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3A100A1A32A32A10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000195");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test000196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000196");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test000197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000197");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0-1.0-1.0-1.0-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000198");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                   ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000199");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000200");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1), 32.0f, (float) 20);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000201");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000202");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0#35#0#32#32#100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000203");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0      -1.0      -1.0      -1.0      -1.0      ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000204");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("# #", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test000205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000205");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("\n", 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test000206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000206");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 10, (double) 51, (double) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test000207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000207");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1a10a10a100\r");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000208");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444hi!4444##-1a10a10a100\r#hi!##hi!", (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test000209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000209");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                .0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                .0.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000210");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000211");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000212");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1a10a10a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000213");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("100\r#hi!##hi!a10a10a444hi!4444##-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000214");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ', (int) (byte) 0, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000215");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000216");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: -1.0                                                                                                 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000217");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) 51, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000218");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) -1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000219");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                .0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000220");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test000221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000221");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3a100a1a32a32a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000222");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a100.0a97.0a-1.0a0.0a-1.0" + "'", str11.equals("100.0a100.0a97.0a-1.0a0.0a-1.0"));
    }

    @Test
    public void test000223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000223");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                              ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000224");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("a4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: a4a4# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000225");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000226");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test000227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000227");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0f), 32.0f, 35.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 35.0f + "'", float3 == 35.0f);
    }

    @Test
    public void test000228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000228");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" -1.  # #  # #class [F", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000229");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("     ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test000230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000230");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000231");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3A100A1A32A32A10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000232");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.Class<?> wildcardClass13 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a100.0a97.0a-1.0a0.0a-1.0" + "'", str11.equals("100.0a100.0a97.0a-1.0a0.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test000233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000233");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("32.04-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000234");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000235");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 100, (float) 32, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test000236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000236");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 100L, (float) 3, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000237");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000238");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.min(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000239");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000240");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, (int) 'a', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test000241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000241");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100? # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000242");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000243");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) -1, (double) 51, (double) 35);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000244");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("     ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test000245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000245");
        java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3410041432432410");
        org.junit.Assert.assertNotNull(bigDecimal1);
    }

    @Test
    public void test000246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000246");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "3a100a1a32a32a10");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 3a100a1a32a32a10");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test000247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000247");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 1, (int) (byte) -1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) (byte) 1, 1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test000248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000248");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("3a100a1a32a32a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000249");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0# #", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test000250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000250");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, (long) 44, (long) 87);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
    }

    @Test
    public void test000251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000251");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) 97, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test000252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000252");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0#100.0#97.0#-1.0#0.0#-1.0", (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test000253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000253");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("  # #  # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  # #  # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000254");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000255");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(51, 20, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test000256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000256");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                0.1-", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test000257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000257");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                                                                                                                                                                                                                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000258");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0                                                                                                ", 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test000259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000259");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 123, (float) 97, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test000260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000260");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) 'a', (int) (byte) 10);
        java.lang.Class<?> wildcardClass13 = longArray6.getClass();
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test000261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000261");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1.equals(0L));
    }

    @Test
    public void test000262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000262");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 116, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000263");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test000264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000264");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 3, 100.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000265");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000266");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-14104104100", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.41041041E10d) + "'", double2 == (-1.41041041E10d));
    }

    @Test
    public void test000267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000267");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000268");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1), 0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test000269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000269");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, (float) 3, (float) '#');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test000270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000270");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, (float) (short) -1, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000271");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) ' ', (double) 10L, (double) 32L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test000272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000272");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("32.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000273");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) ' ', 51.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test000274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000274");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("# #  # #");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000275");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-14104104100", (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.41041041E10d) + "'", double2 == (-1.41041041E10d));
    }

    @Test
    public void test000276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000276");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                .0.0", (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test000277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000277");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
    }

    @Test
    public void test000278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000278");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000279");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000280");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("\r444HI!4444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000281");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".0", (long) 123);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 123L + "'", long2 == 123L);
    }

    @Test
    public void test000282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000282");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0#0.0.00#0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000283");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 5, (double) 5.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test000284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000284");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000285");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                 ", (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test000286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000286");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a10a100\r");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000287");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000288");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 116, 97);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1 10 10 100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1 10 10 100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test000289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000289");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("a   0.1-", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000290");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, (int) (short) 0, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000291");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 0L, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test000292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000292");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                                                                                                                                                                                                                       ", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test000293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000293");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.Class<?> wildcardClass10 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test000294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000294");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test000295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000295");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000296");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000297");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000298");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000299");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("       # #", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test000300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000300");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000301");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(20, (int) '4', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000302");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000303");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 100, (int) (short) 1);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', (int) (byte) -1, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test000304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000304");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000305");
        long[] longArray1 = new long[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        java.lang.Class<?> wildcardClass5 = longArray1.getClass();
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[100]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test000306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000306");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1.equals(100.0f));
    }

    @Test
    public void test000307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000307");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000308");
        long[] longArray1 = new long[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (short) 10, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[100]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test000309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000309");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0-1.0# #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000310");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000311");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("3410041432432410", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3410041432432410L + "'", long2 == 3410041432432410L);
    }

    @Test
    public void test000312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000312");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000313");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1 10 10 100", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000314");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test000315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000315");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3a100a1a32a32a10");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3a100a1a32a32a10");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test000316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), 0.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000317");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 116, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 116 + "'", int3 == 116);
    }

    @Test
    public void test000318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000318");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1a10a10a100\r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000319");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("32.04hi!0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"32.04hi!0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000320");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3A100A1A32A32A10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000321");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "\r");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ?");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test000322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000322");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0  # #  # #  # #  # #  # #  # #  # #  # #  #", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000323");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("3410041432432410              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000324");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("3a100a1a32a32a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000325");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("      0  # #  # #  # #  # #  # #  # #  # #  # #  # ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000326");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("       0.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000327");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("# #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000328");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("           100.0#100.0#97.0#-1.0#0.0#-1.0           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000329");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 51, 10.0f, (float) 87);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test000330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000330");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000331");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 4L, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000332");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0            -1.0            ", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test000333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000333");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000334");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444", 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test000335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000335");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(20, (int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test000336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000336");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1a10a10a100\r");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000337");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000338");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000339");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000340");
        short[] shortArray5 = new short[] { (short) 1, (byte) 0, (short) 100, (short) 0, (byte) 100 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray5, '#', (int) (byte) 0, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray5), "[1, 0, 100, 0, 100]");
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 0 + "'", short6 == (short) 0);
    }

    @Test
    public void test000341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000341");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000342");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        try {
            float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test000343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000343");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4441", 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4441 + "'", int2 == 4441);
    }

    @Test
    public void test000344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000344");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, (float) 123, (float) 493);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 493.0f + "'", float3 == 493.0f);
    }

    @Test
    public void test000345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000345");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0", (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test000346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000346");
        double[] doubleArray2 = new double[] { ' ', (-1.0d) };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) -1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray2), "[32.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.04-1.0" + "'", str4.equals("32.04-1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
    }

    @Test
    public void test000347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000347");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000348");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000349");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#  # #  # #  # #  # #  # #  # #  # #  # #  0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000350");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000351");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000352");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000353");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test000354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000354");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000355");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (byte) -1, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test000356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000356");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" -1.  # #  # #class [F                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000358");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test000359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000359");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("444HI!4444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000360");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 5, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test000361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000361");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 44, 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 87 + "'", int3 == 87);
    }

    @Test
    public void test000362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000362");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000363");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4, (float) 3, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test000364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000364");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0#0.0.00#0     ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000365");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000366");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhh", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test000367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000367");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1L), (double) (short) 10, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test000368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000368");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0#0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000369");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" -1.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test000370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000370");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test000371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000371");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, (double) 5, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test000372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000372");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000373");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000374");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("           100.0a100.0a97.0a-1.0a0.0a-1.0           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000375");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 116, (float) 52L, 493.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 493.0f + "'", float3 == 493.0f);
    }

    @Test
    public void test000376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000376");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("class [F");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [F\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000377");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a 4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000378");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0#0.0.00#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000379");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test000380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000380");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("class [Fa4a4#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000381");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 3410041432432410L, (float) 87, (float) 3410041432432410L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 87.0f + "'", float3 == 87.0f);
    }

    @Test
    public void test000382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000382");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 100, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000383");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("       # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000384");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                     \n-1.  # #  # #class [F                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000385");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      4HI!4444444HI!4444444HI!4444444HI!4444444HI!444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# #  # #  # #  # #  # #  # #  # #  # #  # #  0      4HI!4444444HI!4444444HI!4444444HI!4444444HI!444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000386");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000387");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("\r444hi!4444", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000388");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0#0.0.00#0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000389");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0a35a0a32a32a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a35a0a32a32a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000390");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hi!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000391");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 35, (float) (byte) 1, 87.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 87.0f + "'", float3 == 87.0f);
    }

    @Test
    public void test000392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000392");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000393");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000394");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("class [Fa4a4# -1.  #     -1.0      -1.0      444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Fa4a4# -1.  #     -1.0      -1.0      444HI!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000395");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0  # #  # #  # #  # #  # #  # #  # #  # #  #", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test000396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000396");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000397");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" # # ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000398");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000399");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                ", (long) 123);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 123L + "'", long2 == 123L);
    }

    @Test
    public void test000400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000400");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 10, (double) '4', (double) 10L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test000401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000401");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', 123L, (long) 4441);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test000402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000402");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      -1.0      -1.0      -1.0      -1.0", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000403");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000404");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1a10a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000405");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000406");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35, 100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test000407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000407");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000408");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("100\r#hi!##hi!a10a10a444hi!4444##-1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000409");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                               100.0", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000410");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 0, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

    @Test
    public void test000411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000411");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000412");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a10a100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000413");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                0.1-");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000414");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) (byte) -1, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test000415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000415");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000416");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000417");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("32.0#-1.0\n-1.  # #  # #class [F");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000418");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 32, 20);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 35, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test000419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000419");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                   -14104104100", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.41041041E10d) + "'", double2 == (-1.41041041E10d));
    }

    @Test
    public void test000420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000420");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(44, 97, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test000421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000421");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000422");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1 10 10 100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000423");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000424");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test000425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000425");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000426");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000427");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', (int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test000428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000428");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', (int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test000429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000429");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 32L, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000430");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test000431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000431");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32, (float) 32L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000432");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 3, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
    }

    @Test
    public void test000433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000433");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0 00 00 00 00 00 00 00 00 00 0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000434");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort(" # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000435");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.1-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000436");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3.0f, (double) 5, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test000437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000437");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000438");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 123, (double) (-1.0f), (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test000439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000439");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (-1L), (long) 44);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test000440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000440");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 5, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test000441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000441");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000442");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000443");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000444");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444hi!4444", 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test000445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000445");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000446");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000447");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000448");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("a4a4#");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000449");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 35, (long) 44);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000450");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 97, (float) 493);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000451");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3a100a1a32a32a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000452");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0#0.0.00#0     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#0.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000453");
        float[] floatArray0 = new float[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        try {
            float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test000454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000454");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ", (float) 493);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 493.0f + "'", float2 == 493.0f);
    }

    @Test
    public void test000455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000455");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000456");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.1-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000457");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" #  # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000458");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(5.0f, (float) 116, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test000459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000459");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test000460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000460");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000461");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("a   0.1-", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test000462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000462");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("3", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 3 + "'", short2 == (short) 3);
    }

    @Test
    public void test000463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000463");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("#a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4#");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000464");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(3, 0, 493);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000465");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000466");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000467");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 9\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000468");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0  # #  # #  # #  # #  # #  # #  # #  # #  #");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000469");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 116, (float) (short) 0, (float) 5);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000470");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000471");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1 10 10 100" + "'", str12.equals("-1 10 10 100"));
    }

    @Test
    public void test000472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000472");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-14104104100", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.41041039E10f) + "'", float2 == (-1.41041039E10f));
    }

    @Test
    public void test000473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000473");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("     ", 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test000474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000474");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("444HI!4444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000475");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("class [Jclass [Ljava.lang.String;class [Dclass [Ljava.lang.String;");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000476");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test000477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000477");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) (short) 0, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test000478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000478");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("\r444HI!4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000479");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("A4A4#", (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test000480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000480");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("############################################# ######\n4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000481");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                    \r444hi!4444                    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000482");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000483");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0      -1.0      444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      -1.0      444HI!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000484");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000485");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test000486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 3, (float) 'a', (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test000487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000487");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(" -1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1.equals((-1.0f)));
    }

    @Test
    public void test000488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000488");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 51, (double) 198, (double) 3410041432432410L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test000489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000489");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000490");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                     \n-1.  # #  # #class [F                                      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000491");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(9, 116, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 116 + "'", int3 == 116);
    }

    @Test
    public void test000492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000492");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaa\r");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000493");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             ", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test000494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000494");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("3a100a1a32a32a1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test000495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000495");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000496");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 3, (long) '4', (long) 87);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 87L + "'", long3 == 87L);
    }

    @Test
    public void test000497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000497");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("class [Fa4a4# -1.  # #  # #", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test000498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000498");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("444hi!4444##-1a10a10a100\r#hi!##hi!", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test000499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000499");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 100, 493.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 493.0f + "'", float3 == 493.0f);
    }

    @Test
    public void test000500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test000500");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(30, 3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test000501() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000501");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000502() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000502");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 0, (int) (byte) 0);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', (int) '4', 9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a100.0a97.0a-1.0a0.0a-1.0" + "'", str11.equals("100.0a100.0a97.0a-1.0a0.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test000503() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000503");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 3, (float) (byte) 0, (float) 51);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000504() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000504");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test000505() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000505");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 50, (float) 123L, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test000506() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000506");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000507() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000507");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (-1.41041041E10d), (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test000508() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000508");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000509() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000509");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 35, (int) (byte) 1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 10, 198);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test000510() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000510");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000511() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000511");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test000512() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000512");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000513() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000513");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0      -1.0      -1.0      -1.0      -1.0      ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000514() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000514");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000515() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000515");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("class [Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class [Fa4a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000516() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000516");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" a a ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000517() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000517");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0 0.0 -1.0 97.0 100.0 100.0", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test000518() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000518");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 51, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 51");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 52.0f + "'", float11 == 52.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test000519() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000519");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("100\r#hi!##hi!a10a10a444hi!4444##-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000520() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000520");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
    }

    @Test
    public void test000521() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000521");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000522() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000522");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000523() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000523");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000524() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000524");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000525() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000525");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000526() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000526");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000527() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000527");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 198L, (double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test000528() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000528");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000529() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000529");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0a100.0a97.0a-1.0a0.0a-1.0", (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test000530() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000530");
        long[] longArray6 = new long[] { 10, 10, 100, 198, 1L, (short) 100 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[10, 10, 100, 198, 1, 100]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 198L + "'", long7 == 198L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1041041004198414100" + "'", str9.equals("1041041004198414100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10#10#100#198#1#100" + "'", str11.equals("10#10#100#198#1#100"));
    }

    @Test
    public void test000531() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000531");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 87, 51);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', (int) (short) 1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test000532() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000532");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(123L, (long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test000533() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000533");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4-1.4444444444class4[F44444444444444444444444444444444444444444444444444444444444444444.4444444444class4[F");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 4-1.4444444444class4[F44444444444444444444444444444444444444444444444444444444444444444.4444444444class4[F is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000534() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000534");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(50, 9, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test000535() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000535");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000536() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000536");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) -1, (float) 4L, (float) 32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000537() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000537");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 3, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test000538() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000538");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" -1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test000539() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000539");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 3, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a100.0a97.0a-1.0a0.0a-1.0" + "'", str11.equals("100.0a100.0a97.0a-1.0a0.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test000540() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000540");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" -1.  # #  # #CLASS [F");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000541() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000541");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test000542() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000542");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1L, (double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test000543() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000543");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(15, (int) (short) -1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test000544() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000544");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000545() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000545");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 52L, (float) 32L, (float) 54);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000546() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000546");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0  # #  # #  # #  # #  # #  # #  # #  # #  #", 5.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test000547() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000547");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("3410041432432410", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3410041432432410L + "'", long2 == 3410041432432410L);
    }

    @Test
    public void test000548() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000548");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test000549() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000549");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000550() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000550");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1.equals(4.0d));
    }

    @Test
    public void test000551() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000551");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000552() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000552");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0            -1.0            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: -1.0            -1.0             is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000553() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000553");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("# #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000554() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000554");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("      0  # #  # #  # #  # #  # #  # #  # #  # #  # ", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test000555() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000555");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000556() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000556");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000557() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000557");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3410041432432410L, 100.0d, (double) 87);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 87.0d + "'", double3 == 87.0d);
    }

    @Test
    public void test000558() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000558");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(5.0d, (double) 54, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test000559() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000559");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 3, 15, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test000560() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000560");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("3");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1.equals(3.0d));
    }

    @Test
    public void test000561() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000561");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, 116);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test000562() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000562");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(" # # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" # # \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000563() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000563");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000564() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000564");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, 4441.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test000565() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000565");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000566() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000566");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', (int) (short) 10, 198);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test000567() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000567");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI! #  # #  # #  # ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000568() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000568");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(35.0f, (float) 44L, (float) 510);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
    }

    @Test
    public void test000569() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000569");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-14104104100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-14104104100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000570() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000570");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000571() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000571");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 116, 97);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test000572() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000572");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                .0.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000573() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000573");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(35, 12, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test000574() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000574");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 0, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test000575() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000575");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 51, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
    }

    @Test
    public void test000576() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000576");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("A4A4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000577() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000577");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("     0#00.0.0#0", 123L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 123L + "'", long2 == 123L);
    }

    @Test
    public void test000578() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000578");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000579() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000579");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 'a', (long) 32, (long) 123);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 123L + "'", long3 == 123L);
    }

    @Test
    public void test000580() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000580");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1.0      -1.0      444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000581() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000581");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000582() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000582");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1a10a10a100# #  # #");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000583() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000583");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("# #class [Fa4a4#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000584() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000584");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, (float) 0, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000585() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000585");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 510, 0.0f, (float) 87);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
    }

    @Test
    public void test000586() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000586");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0a35a0a32a32a100");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000587() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000587");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test000588() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000588");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test000589() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000589");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000590() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000590");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("     0#00.0.0#0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000591() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000591");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0                                                                                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1.equals(0.0f));
    }

    @Test
    public void test000592() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000592");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000593() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000593");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("444hi!4444", "", (int) '#');
        java.lang.Object[] objArray14 = new java.lang.Object[] { double7, '#', (short) 100, 0.0f };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(objArray14, "hi!", (int) (byte) 0, (int) (short) 1);
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(objArray14, '4', 20, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertEquals(java.util.Arrays.deepToString(objArray14), "[100.0, #, 100, 0.0]");
        org.junit.Assert.assertEquals(java.util.Arrays.toString(objArray14), "[100.0, #, 100, 0.0]");
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100.0" + "'", str18.equals("100.0"));
    }

    @Test
    public void test000594() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000594");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000595() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000595");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("     -1.0      -1.0      444HI!4444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000596() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000596");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, 1.0f, 30.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 30.0f + "'", float3 == 30.0f);
    }

    @Test
    public void test000597() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000597");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                     \n-1.  # #  # #class [F                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                     ?-1.  # #  # #class [F                                      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000598() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000598");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("- 1 . 0        - 1 . 0       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: - 1 . 0        - 1 . 0        is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000599() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000599");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("0#35#0#32#32#100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000600() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000600");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 100, (float) 123L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000601() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000601");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("  # #  # #  # # 1.0      -1.0 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  # #  # #  # # 1.0      -1.0 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000602() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000602");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(87, 12, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 87 + "'", int3 == 87);
    }

    @Test
    public void test000603() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000603");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000604() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000604");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!444", (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test000605() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000605");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("############### ######\n4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000606() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000606");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 3410041432432410L, (double) 87L, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.41004143243241E15d + "'", double3 == 3.41004143243241E15d);
    }

    @Test
    public void test000607() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000607");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-14104104100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000608() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000608");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', 5.0f, (float) ' ');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test000609() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000609");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("32.0a-1.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000610() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000610");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000611() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000611");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', (int) (short) 1, (int) (short) 0);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 9, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test000612() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000612");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1.041.0452.0435.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000613() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000613");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 30, 1.0f, (float) 87);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 87.0f + "'", float3 == 87.0f);
    }

    @Test
    public void test000614() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000614");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000615() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000615");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, 3.0d, (double) (short) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test000616() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000616");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0 00 00 00 00 00 00 00 00 00 0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000617() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000617");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("           100.0#100.0#97.0#-1.0#0.0#-1.0           ", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test000618() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000618");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test000619() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000619");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 51, (long) 94, (long) 116);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 51L + "'", long3 == 51L);
    }

    @Test
    public void test000620() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000620");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#  # #  # #  # #  # #  # #  # #  # #  # #  0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000621() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000621");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, 50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test000622() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000622");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000623() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000623");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                                                                                                                                                                                                                        3a100a1a32a32a10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000624() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000624");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000625() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000625");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("4");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1.equals(4.0f));
    }

    @Test
    public void test000626() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000626");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000627() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000627");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(50, (int) (byte) 10, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 54 + "'", int3 == 54);
    }

    @Test
    public void test000628() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000628");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000629() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000629");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("   ", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test000630() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000630");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000631() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000631");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, 5.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000632() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000632");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("  # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0   # #  # #  # # 1.0      -1.0 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000633() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000633");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        java.lang.Class<?> wildcardClass14 = longArray6.getClass();
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3 100 1 32 32 10" + "'", str11.equals("3 100 1 32 32 10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3#100#1#32#32#10" + "'", str13.equals("3#100#1#32#32#10"));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test000634() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000634");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000635() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000635");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000636() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000636");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaa\r");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000637() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000637");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000638() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000638");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) 0, 87L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000639() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000639");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', 15, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 15");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a10" + "'", str7.equals("1a10"));
    }

    @Test
    public void test000640() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000640");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, 510.0f, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 510.0f + "'", float3 == 510.0f);
    }

    @Test
    public void test000641() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000641");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("32.0#-1.0\n-1.  # #  # #class [F");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"32.0#-1.0?-1.  # #  # #class [F\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000642() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000642");
        double[] doubleArray1 = new double[] { 198 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4');
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[198.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "198.0" + "'", str4.equals("198.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "198.0" + "'", str6.equals("198.0"));
    }

    @Test
    public void test000643() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000643");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000644() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000644");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10#10#100#198#1#100", 102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102 + "'", int2 == 102);
    }

    @Test
    public void test000645() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000645");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("############################################# ######\n4444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"############################################ ######?4444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000646() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000646");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("#################################################################################################################################################################################################################################################444HI!4444##################################################################################################################################################################################################################################################", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test000647() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000647");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1.equals(1));
    }

    @Test
    public void test000648() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000648");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 1, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a10a10a100" + "'", str8.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test000649() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000649");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("444hi!4444##-1a10a10a100\r#hi!##hi!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000650() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000650");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 1L, (float) (short) 10, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test000651() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000651");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 15, (long) 5, (long) 50);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test000652() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000652");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("3410041432432410              ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000653() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000653");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0                                                                                                ", 510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 510 + "'", int2 == 510);
    }

    @Test
    public void test000654() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000654");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("A4A4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000655() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000655");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, 44L, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test000656() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000656");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\r-1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test000657() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000657");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000658() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000658");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 50, (int) '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test000659() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000659");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) (byte) 0, (long) 116);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 116L + "'", long3 == 116L);
    }

    @Test
    public void test000660() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000660");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000661() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000661");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 16, (long) 510, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 510L + "'", long3 == 510L);
    }

    @Test
    public void test000662() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000662");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("  # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000663() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000663");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(12, 20, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000664() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000664");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("a4a4#", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test000665() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000665");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                                                    3#100#1#32#32#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000666() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000666");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000667() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000667");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(16.0d, (double) (-1.41041039E10f), (double) 510.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4104103936E10d) + "'", double3 == (-1.4104103936E10d));
    }

    @Test
    public void test000668() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000668");
        double[] doubleArray2 = new double[] { ' ', (-1.0d) };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray2), "[32.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.04-1.0" + "'", str4.equals("32.04-1.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test000669() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000669");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test000670() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000670");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444hcl ss#[F", (double) 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test000671() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000671");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(198.0d, (double) (short) 100, (double) 52L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test000672() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000672");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10.0############### ######\n4444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"10.0############### ######?4444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000673() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000673");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000674() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000674");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                0.1-", (float) 198);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 198.0f + "'", float2 == 198.0f);
    }

    @Test
    public void test000675() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000675");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, 1, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000676() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000676");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 116, (float) '#', (float) 47);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 116.0f + "'", float3 == 116.0f);
    }

    @Test
    public void test000677() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000677");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 493, (double) 9, (-1.4104103936E10d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4104103936E10d) + "'", double3 == (-1.4104103936E10d));
    }

    @Test
    public void test000678() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000678");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000679() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000679");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test000680() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000680");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, (float) 16, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 16.0f + "'", float3 == 16.0f);
    }

    @Test
    public void test000681() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000681");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("#...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000682() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000682");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000683() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000683");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1", (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test000684() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000684");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000685() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000685");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0-1.0# #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Sign character in wrong position");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000686() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000686");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(142, (int) (byte) -1, 198);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 198 + "'", int3 == 198);
    }

    @Test
    public void test000687() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000687");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(87L, 4L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 87L + "'", long3 == 87L);
    }

    @Test
    public void test000688() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000688");
        java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1.equals(97L));
    }

    @Test
    public void test000689() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000689");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000690() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000690");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.0#1.0#52.0#35.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000691() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000691");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ');
        java.lang.Class<?> wildcardClass9 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test000692() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000692");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000693() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000693");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1 10 10 100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1 10 10 100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test000694() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000694");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) (byte) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000695() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000695");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(3410041432432410L, 5L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3410041432432410L + "'", long3 == 3410041432432410L);
    }

    @Test
    public void test000696() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000696");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ', 35, 58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a100.0a97.0a-1.0a0.0a-1.0" + "'", str11.equals("100.0a100.0a97.0a-1.0a0.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
    }

    @Test
    public void test000697() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000697");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 87, (int) '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        java.lang.Class<?> wildcardClass17 = longArray6.getClass();
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3#100#1#32#32#10" + "'", str16.equals("3#100#1#32#32#10"));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test000698() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000698");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000699() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000699");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) 5, (long) 58);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test000700() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000700");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4", (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test000701() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000701");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 3, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000702() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000702");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0 00 00 00 00 00 00 00 00 00 0", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test000703() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000703");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(112, 51, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 112 + "'", int3 == 112);
    }

    @Test
    public void test000704() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000704");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000705() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000705");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000706() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000706");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(51, 198, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 198 + "'", int3 == 198);
    }

    @Test
    public void test000707() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000707");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 29, (double) (-1L), (double) (short) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.0d + "'", double3 == 29.0d);
    }

    @Test
    public void test000708() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000708");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("100.0a100.0a97.0a-1.0a0.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000709() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000709");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...-14104104100", (float) 4L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test000710() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000710");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test000711() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000711");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444", 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test000712() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000712");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\r-1.0", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test000713() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000713");
        long[] longArray1 = new long[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray1, '#', 5, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[100]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test000714() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000714");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000715() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000715");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 44);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.0d + "'", double2 == 44.0d);
    }

    @Test
    public void test000716() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000716");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000717() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000717");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 58, 97L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test000718() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000718");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000719() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000719");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, " # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 3410041432432410");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:  # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 3410041432432410");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#100" + "'", str8.equals("-1#10#10#100"));
    }

    @Test
    public void test000720() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000720");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, (int) (short) -1, 4430);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4430 + "'", int3 == 4430);
    }

    @Test
    public void test000721() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000721");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000722() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000722");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\r444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000723() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000723");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(30.0f, (float) 142, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test000724() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000724");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000725() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000725");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000726() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000726");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1.41041039E10f), (double) 1, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4104103936E10d) + "'", double3 == (-1.4104103936E10d));
    }

    @Test
    public void test000727() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000727");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32L, (double) 20, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.0d + "'", double3 == 20.0d);
    }

    @Test
    public void test000728() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000728");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:           ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test000729() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000729");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("#################################################################################################################################################################################################################################################444HI!4444##################################################################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000730() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000730");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000731() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000731");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ", (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test000732() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000732");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("           100.0#100.0#97.0#-1.0#0.0#-1.0           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000733() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000733");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000734() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000734");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000735() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000735");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(100.0d, (double) 5.0f, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test000736() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000736");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" -1.  # #  # #class [F                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000737() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000737");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("class [Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"clas\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000738() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000738");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000739() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000739");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0-1.0-1.0-1.0-1.03#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000740() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000740");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3410041432432410L, (double) 97, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test000741() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000741");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(32.0d, 20.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test000742() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000742");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4.0f, (double) '#', 198.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 198.0d + "'", double3 == 198.0d);
    }

    @Test
    public void test000743() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000743");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000744() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000744");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 87, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 0, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test000745() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000745");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#a4#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000746() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000746");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 100, (int) (byte) -1, 493);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test000747() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000747");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000748() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000748");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000749() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000749");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" # #  # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000750() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000750");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2, 510, 112);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test000751() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000751");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("\n-1.  # #  # #class [F", (float) 116);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 116.0f + "'", float2 == 116.0f);
    }

    @Test
    public void test000752() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000752");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000753() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000753");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 4, (float) 58);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 58.0f + "'", float3 == 58.0f);
    }

    @Test
    public void test000754() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000754");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test000755() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000755");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                .0.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000756() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000756");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("class [Fa4a4# -1.  # #  # #", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test000757() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000757");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 35, 116L, (long) 42);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test000758() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000758");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-14-14140", (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test000759() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000759");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 100L, (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000760() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000760");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000761() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000761");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("0#0", 102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102 + "'", int2 == 102);
    }

    @Test
    public void test000762() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000762");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 0.0f + "'", number1.equals(0.0f));
    }

    @Test
    public void test000763() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000763");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#  # #  # #  # #  # #  # #  # #  # #  # #  0", (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test000764() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000764");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 3, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test000765() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000765");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaa\raaa\raaa\raaa\raaa\raaa\raaa\raaa\raaa\raaa\raaa\raaa\raaahi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000766() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000766");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("0", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test000767() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000767");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10#10#100#198#1#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000768() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000768");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".0");
        org.junit.Assert.assertNotNull(number1);
    }

    @Test
    public void test000769() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000769");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("     \n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000770() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000770");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("           100.0A100.0A97.0A-1.0A0.0A-1.0           ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000771() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000771");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 31001323210", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test000772() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000772");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(58.0f, (float) (byte) 0, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000773() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000773");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000774() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000774");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000775() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000775");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" -1.  # #  # #class [F                                                                 .  # #  # #class [F", 42L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 42L + "'", long2 == 42L);
    }

    @Test
    public void test000776() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000776");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000777() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000777");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000778() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000778");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 4L, 0.0f, (float) 30);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000779() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000779");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("00140140141-...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000780() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000780");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0.", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test000781() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000781");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(123, (int) (byte) 1, 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test000782() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000782");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("############################################################################################################## #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000783() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000783");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444hi!4444##-1a10a10a100\r#hi!##hi!", (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test000784() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000784");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("A4A4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test000785() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000785");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, 58.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000786() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000786");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                  # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # #                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000787() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000787");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("############################################################################################################## #", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test000788() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000788");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# #  # #  # #  # #  # #  # #  # #  # #  # #  0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000789() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000789");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 10, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a10a100" + "'", str12.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test000790() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000790");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100.0#100.0#97.0#-1.0#0.0#-1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000791() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000791");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', (int) (short) 3, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.0" + "'", str8.equals("0.0"));
    }

    @Test
    public void test000792() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000792");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000793() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000793");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 102, 0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 102.0f + "'", float3 == 102.0f);
    }

    @Test
    public void test000794() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000794");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000795() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000795");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000796() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000796");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0#1#32#32#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#1#32#32#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000797() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000797");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0      ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test000798() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000798");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 116L, (double) 87.0f, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 116.0d + "'", double3 == 116.0d);
    }

    @Test
    public void test000799() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000799");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                     \n-1.  # #  # #class [F                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.  # #  # #class [F\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000800() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000800");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8, (float) 5L, (float) 5L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test000801() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000801");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 100, (short) 1, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000802() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000802");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000803() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000803");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 54, (long) (short) -1, 198L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test000804() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000804");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                                                                                                                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000805() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000805");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) -1, (byte) 1, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "1.041.0452.0435.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1.041.0452.0435.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, -1, 1, 0]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-14-14140" + "'", str7.equals("-14-14140"));
    }

    @Test
    public void test000806() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000806");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000807() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000807");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("###1.041.0452.0435.0", (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test000808() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000808");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 0, (long) 58, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 58L + "'", long3 == 58L);
    }

    @Test
    public void test000809() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000809");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test000810() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000810");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000811() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000811");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...-14104104100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000812() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000812");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("3 100 1 32 32 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3 100 1 32 32 10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000813() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000813");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("F[#ss lch444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test000814() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000814");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000815() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000815");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("hhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhhhhhhi!hhhh");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000816() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000816");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("3410041432432410", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test000817() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000817");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("3a100a1a32a32a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000818() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000818");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 100, (-1));
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a', (int) 'a', 112);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test000819() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000819");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000820() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000820");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("4                                                      ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test000821() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000821");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("a 4");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000822() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000822");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                               100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"       \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000823() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000823");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 51, 1);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 58, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 58");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0" + "'", str8.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + (-1.0f) + "'", float14 == (-1.0f));
    }

    @Test
    public void test000824() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000824");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10", 198L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198L + "'", long2 == 198L);
    }

    @Test
    public void test000825() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000825");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: -1a10a10a100? # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # #  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000826() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000826");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 3, 0, 54);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 54 + "'", int3 == 54);
    }

    @Test
    public void test000827() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000827");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.", (double) 112);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 112.0d + "'", double2 == 112.0d);
    }

    @Test
    public void test000828() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000828");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("     \n");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     ?\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000829() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000829");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(94, 51, 510);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 510 + "'", int3 == 510);
    }

    @Test
    public void test000830() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000830");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000831() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000831");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test000832() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000832");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0            -1.0            ", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test000833() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000833");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" -1.  # #  # #class [F", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000834() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000834");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(123, 540, 198);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 123 + "'", int3 == 123);
    }

    @Test
    public void test000835() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000835");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000836() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000836");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000837() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000837");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0#35#0#32#32#10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#35#0#32#32#10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000838() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000838");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000839() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000839");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, (float) 'a', (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test000840() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000840");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4, 16.0d, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test000841() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000841");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000842() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000842");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 16, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test000843() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000843");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("100.0#100.0#97.0#-1.0#0.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000844() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000844");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000845() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000845");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test000846() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000846");
        double[] doubleArray1 = new double[] { 198 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', 0, 123);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[198.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "198.0" + "'", str4.equals("198.0"));
    }

    @Test
    public void test000847() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000847");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi", (float) 510);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 510.0f + "'", float2 == 510.0f);
    }

    @Test
    public void test000848() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000848");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 4441, 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str12.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.04100.0497.04-1.040.04-1.0" + "'", str14.equals("100.04100.0497.04-1.040.04-1.0"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test000849() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000849");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("  # #  # #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000850() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000850");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              ", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test000851() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000851");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##h is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000852() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000852");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, 0);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
    }

    @Test
    public void test000853() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000853");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0#35#0#32#32#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000854() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000854");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3a100a1a32a32a1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3a100a1a32a32a1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000855() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000855");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("s [Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s [Fa4a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000856() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000856");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 198, (float) (short) -1, (float) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000857() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000857");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100? # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000858() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000858");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1a10a10a100\r");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100?\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000859() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000859");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000860() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000860");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.Class<?> wildcardClass11 = byteArray4.getClass();
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test000861() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000861");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (byte) 0, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3 100 1 32 32 10" + "'", str11.equals("3 100 1 32 32 10"));
    }

    @Test
    public void test000862() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000862");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("- 1 . 0        - 1 . 0       ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000863() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000863");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 100, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000864() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000864");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000865() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000865");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaa0a35a0a32a32a100", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000866() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000866");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test000867() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000867");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.  # #  # #class [F", (double) 3410041432432410L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.41004143243241E15d + "'", double2 == 3.41004143243241E15d);
    }

    @Test
    public void test000868() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000868");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000869() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000869");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000870() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000870");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000871() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000871");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000872() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000872");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000873() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000873");
        double[] doubleArray2 = new double[] { ' ', (-1.0d) };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray2), "[32.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.04-1.0" + "'", str4.equals("32.04-1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32.0a-1.0" + "'", str6.equals("32.0a-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test000874() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000874");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0" + "'", str8.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0" + "'", str10.equals("-1.0"));
    }

    @Test
    public void test000875() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000875");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" -1.  # #  # #CLASS [Fa -1.  # #  # #CLASS [F");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000876() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000876");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("     0#00.0.0#0", (double) 4430);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4430.0d + "'", double2 == 4430.0d);
    }

    @Test
    public void test000877() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000877");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("######################################################################################################################################################################################################31001323210");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#####################################################################################################################################################################################################31001323210\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000878() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000878");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("0.5340.2540.140.1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000879() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000879");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000880() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000880");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("32.04-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000881() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000881");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 122, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000882() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000882");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000883() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000883");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 504, (double) 0, (double) 102);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test000884() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000884");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("0.03410041432432410                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000885() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000885");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3410041432432410             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000886() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000886");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("333333.-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000887() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000887");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35L, (double) 464, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test000888() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000888");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) (byte) 10, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test000889() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000889");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100", (double) 16.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.0d + "'", double2 == 16.0d);
    }

    @Test
    public void test000890() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000890");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(".");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000891() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000891");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test000892() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000892");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.41041039E10f), (float) 504, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.41041039E10f) + "'", float3 == (-1.41041039E10f));
    }

    @Test
    public void test000893() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000893");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1041041004198414100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.04104097E18f + "'", float1.equals(1.04104097E18f));
    }

    @Test
    public void test000894() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000894");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                              ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000895() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000895");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("-1.0                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000896() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000896");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 493, (float) 4, (float) 510);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test000897() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000897");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("3410041432432410                            444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3410041432432410                            444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000898() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000898");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', (int) (byte) 1, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test000899() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000899");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.0            -1.0            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0            -1.0            \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000900() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000900");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" #  # #  # #  # #  # #  # #  # #  # # # a 4 ", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test000901() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000901");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3 100 1 32 32 100#0.0.00#0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000902() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000902");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 464, 0.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000903() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000903");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("class#[Fa4a4#", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test000904() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000904");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(".0.0", (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test000905() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000905");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2053, (float) (byte) 100, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test000906() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000906");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2053, 112, 2053);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 112 + "'", int3 == 112);
    }

    @Test
    public void test000907() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000907");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0#35#0#32#32#10");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000908() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000908");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (short) 3, (double) (byte) 10, (double) 112);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test000909() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000909");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(142, 9, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test000910() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000910");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 142, (float) 198, 5.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 198.0f + "'", float3 == 198.0f);
    }

    @Test
    public void test000911() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000911");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test000912() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000912");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 97, 97L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test000913() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000913");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100-1a10a10a100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000914() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000914");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "aaa\r");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: aaa?");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a10a10a100" + "'", str8.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test000915() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000915");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"  #  # #  # #  # #  # #  # #  # #  # #  # #  0      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000916() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000916");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("             a a             ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000917() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000917");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1. # # # #class [F 0.1-");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000918() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000918");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000919() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000919");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, 0);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) '4', 50);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 12, 102);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test000920() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000920");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray4, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 122, 0);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', (int) (byte) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.0a1.0a52.0a35.0" + "'", str7.equals("1.0a1.0a52.0a35.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test000921() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000921");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "-1 10 10 100");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1 10 10 100");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a10a100" + "'", str12.equals("-1a10a10a100"));
    }

    @Test
    public void test000922() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000922");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 32, 20);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray4, '#');
        java.lang.Class<?> wildcardClass16 = floatArray4.getClass();
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.0#1.0#52.0#35.0" + "'", str15.equals("1.0#1.0#52.0#35.0"));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test000923() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000923");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test000924() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000924");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 4L, 4.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000925() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000925");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 2, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test000926() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000926");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test000927() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000927");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 113, 116.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000928() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000928");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("00140140141-...", (float) 496);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 496.0f + "'", float2 == 496.0f);
    }

    @Test
    public void test000929() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000929");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 122, 32);
        java.lang.Class<?> wildcardClass18 = shortArray1.getClass();
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

    @Test
    public void test000930() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000930");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, (double) 1, (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test000931() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000931");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 2053, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "cl ss#[F");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: cl ss#[F");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test000932() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000932");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 489, 116.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000933() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000933");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 16, 540);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 16");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str12.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.04100.0497.04-1.040.04-1.0" + "'", str14.equals("100.04100.0497.04-1.040.04-1.0"));
    }

    @Test
    public void test000934() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000934");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("A4-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0\r444hi!4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000935() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000935");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000936() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000936");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0444HI!4444444HI!", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test000937() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000937");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("97", (long) 4430);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test000938() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000938");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 87, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 12, 2053);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
    }

    @Test
    public void test000939() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000939");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa3a100a1a32a32a1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (float) 4441);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4441.0f + "'", float2 == 4441.0f);
    }

    @Test
    public void test000940() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000940");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("     -1.0      -1.0      444HI!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"     -1.0      -1.0      444HI!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000941() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000941");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 493, 0.0f, (float) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000942() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000942");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000943() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000943");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test000944() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000944");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test000945() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000945");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("class [Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: class [Fa4a4# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000946() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000946");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("...103#...                                                                                            ", 493.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 493.0f + "'", float2 == 493.0f);
    }

    @Test
    public void test000947() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000947");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 87, (int) '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        long long17 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "3#100#1#32#32#10" + "'", str16.equals("3#100#1#32#32#10"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "3a100a1a32a32a10" + "'", str19.equals("3a100a1a32a32a10"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "3a100a1a32a32a10" + "'", str21.equals("3a100a1a32a32a10"));
    }

    @Test
    public void test000948() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000948");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test000949() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000949");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 0, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000950() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000950");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test000951() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000951");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!", (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test000952() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000952");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
    }

    @Test
    public void test000953() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000953");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4441, 197, 102);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 102 + "'", int3 == 102);
    }

    @Test
    public void test000954() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000954");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("\n", 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test000955() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000955");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("\r#hi!##hi!a10a10a444hi!4444##");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000956() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000956");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 4, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3a100a1a32a32a10" + "'", str9.equals("3a100a1a32a32a10"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test000957() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000957");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(29, 4430, 116);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4430 + "'", int3 == 4430);
    }

    @Test
    public void test000958() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000958");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("     -1.0      -1.0      444HI!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test000959() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000959");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 97 + "'", short2 == (short) 97);
    }

    @Test
    public void test000960() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000960");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("############################################# ######\n4444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000961() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000961");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 5, 47);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test000962() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000962");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 87, 123L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test000963() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000963");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      ", 122);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 122 + "'", int2 == 122);
    }

    @Test
    public void test000964() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000964");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', (int) (byte) 100, 504);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000965() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000965");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("3410041432432410                ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test000966() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000966");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test000967() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000967");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(" -1.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000968() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000968");
        double[] doubleArray1 = new double[] { 198 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '#', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[198.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
    }

    @Test
    public void test000969() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000969");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" -1.  # #  # #class [F      0.1-", (float) 540);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 540.0f + "'", float2 == 540.0f);
    }

    @Test
    public void test000970() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000970");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 97, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test000971() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000971");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test000972() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000972");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(".32.04hi!0..", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test000973() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000973");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 540.0f, (double) ' ', (double) 32);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 540.0d + "'", double3 == 540.0d);
    }

    @Test
    public void test000974() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000974");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("# a 4 #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" a 4 #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000975() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000975");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                                                                                                                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000976() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000976");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#100.0a100.0a97.0a-1.0a0.0a-1.0#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test000977() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000977");
        long[] longArray1 = new long[] { 10L };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[10]");
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test000978() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000978");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000979() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000979");
        int[] intArray6 = new int[] { (byte) 0, 35, (short) 0, ' ', 32, (short) 100 };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 0, (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 123, 5);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', (int) '4', 5);
        int int21 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int22 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(intArray6, '4', 30, 464);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray6), "[0, 35, 0, 32, 32, 100]");
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0 35 0 32 32 100" + "'", str16.equals("0 35 0 32 32 100"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 100 + "'", int21 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test000980() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000980");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test000981() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000981");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 123, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test000982() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000982");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.04100.0497.04-1.040.04-1.0" + "'", str11.equals("100.04100.0497.04-1.040.04-1.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test000983() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000983");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("class [F", (double) 198);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
    }

    @Test
    public void test000984() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000984");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0", (double) 87L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 87.0d + "'", double2 == 87.0d);
    }

    @Test
    public void test000985() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000985");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("class#[Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"class#[Fa4a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000986() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000986");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      hi!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test000987() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000987");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4441, (double) 35, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4441.0d + "'", double3 == 4441.0d);
    }

    @Test
    public void test000988() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000988");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("  # #  # #  # # 1.0      -1.0 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# #  # #  # # 1.0      -1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test000989() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000989");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaa\r");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test000990() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000990");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("# #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 3410041432432410", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test000991() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000991");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 10, (float) 17, (float) 44L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 44.0f + "'", float3 == 44.0f);
    }

    @Test
    public void test000992() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000992");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("a 4", (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test000993() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000993");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) 15, (float) 42L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000994() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000994");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 504, (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000995() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000995");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 16, (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000996() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000996");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("333333.-");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test000997() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000997");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 3410041432432410L, (float) 198);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.41004136E15f + "'", float3 == 3.41004136E15f);
    }

    @Test
    public void test000998() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000998");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 504, (float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test000999() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test000999");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 29, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) '4', (int) ' ');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', (int) ' ', 58);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test001000() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001000");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n", 489);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 489 + "'", int2 == 489);
    }

    @Test
    public void test001001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001001");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1a10a10a100##################0.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a10a10a100##################0.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001002");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("00140140141-...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"00140140141-...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001003");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 123, (double) 496.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test001004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001004");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test001005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001005");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\r#hi!##hi!a10a10a444hi!4444##\r#hi!##hi!a10a10a444hi!4444##\r#hi!##hi!a10a10a444hi!4444##\r#hi!##hi!a10a10a444hi!4444444AA4", (double) (-1.41041039E10f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4104103936E10d) + "'", double2 == (-1.4104103936E10d));
    }

    @Test
    public void test001006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001006");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!a#a#a#a#a#a#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001007");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001008");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" -1. ", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test001009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001009");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                     \n-1.  # #  # #class [F                                      ", (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test001010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001010");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 0L, (double) 97.0f, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test001011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001011");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(".0######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1", 4441);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4441 + "'", int2 == 4441);
    }

    @Test
    public void test001012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001012");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test001013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001013");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test001014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001014");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001015");
        double[] doubleArray1 = new double[] { 198 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ', 1, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[198.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 198.0d + "'", double3 == 198.0d);
    }

    @Test
    public void test001016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001016");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001017");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4');
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.Class<?> wildcardClass9 = floatArray1.getClass();
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.0" + "'", str7.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test001018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001018");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 120, 2053);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 120");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test001019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001019");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("1a10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001020");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" ", (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test001021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001021");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 87.0f, (double) 30.0f, 44.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 87.0d + "'", double3 == 87.0d);
    }

    @Test
    public void test001022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001022");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("\n");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001023");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 540, 3410041432432410L, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test001024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001024");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (-1.0d), (double) 29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test001025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001025");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" a \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001026");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
    }

    @Test
    public void test001027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001027");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("-14-14140", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test001028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001028");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test001029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001029");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 29, (float) (short) -1, (float) 3);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test001030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001030");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("3#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001031");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#################################################################################################################################################################################################################################################444hi!4444##################################################################################################################################################################################################################################################3", 4441.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4441.0f + "'", float2 == 4441.0f);
    }

    @Test
    public void test001032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001032");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 3410041432432410", 540);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 540 + "'", int2 == 540);
    }

    @Test
    public void test001033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001033");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("      0.1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:       0.1- is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001034");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test001035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001035");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.  # #  # #class [F");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001036");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4L, (double) (short) 0, (double) 87);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test001037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001037");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 496.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 496.0d + "'", double2 == 496.0d);
    }

    @Test
    public void test001038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001038");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5L, (float) 120, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 120.0f + "'", float3 == 120.0f);
    }

    @Test
    public void test001039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001039");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444444444444444444444-1.0444444444444444444444444444444444444444444444444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001040");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(17, (int) (byte) 0, (int) (short) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test001041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001041");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                      #a4#                                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001042");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001043");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 3, (short) 97, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001044");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) 97, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test001045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001045");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                          0a0                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                                           0a0                                           is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001046");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test001047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001047");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) 464, 32L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 464L + "'", long3 == 464L);
    }

    @Test
    public void test001048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001048");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("class#[Fa4a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: class#[Fa4a4# is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001049");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("3A100A1A32A32A", (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test001050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001050");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("##########");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001051");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 50, 2053);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 50");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
    }

    @Test
    public void test001052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001052");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 51, (int) (short) -1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 2, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test001053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001053");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test001054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001054");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(5L, (long) 91, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 91L + "'", long3 == 91L);
    }

    @Test
    public void test001055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001055");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0-1.0# #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Sign character in wrong position");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001056");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (short) 97);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 97 + "'", short2 == (short) 97);
    }

    @Test
    public void test001057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001057");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0#35#0#32#32#100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#35#0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001058");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("######################################################################################################################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001059");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test001060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001060");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444hi!4444##-1a10a10a100\r#hi!##hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001061");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 464L, (float) 1968, 44.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1968.0f + "'", float3 == 1968.0f);
    }

    @Test
    public void test001062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001062");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0435404324324100");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.354043243241E14d + "'", double1.equals(4.354043243241E14d));
    }

    @Test
    public void test001063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001063");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#   a   4   # aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa - 1 a 10 a 10 a 100 \r   #   #    #   #    #   #    #   #    #   #    #   #    #   #    #   #    #   #         0 . 1 -   #   #    #   #    #   #    #   #    #   #    #   #    #   #    #   #    #   #   1 . 0        - 1 . 0        - 1 . 0        - 1 . 0        - 1 . 0        - 1 . 0        - 1 . 0        - 1 . 0        - 1 . 0    \r 444 hi ! 4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001064");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3-1. # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001065");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', (int) (short) 1, (int) (byte) -1);
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', (int) (short) 3, 1968);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test001066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001066");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test001067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001067");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-14104104100", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001068");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10                                          0a0                                          ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001069");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) 2053);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001070");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("2.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"2.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.02.0416.045.0410.04102.0487.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001071");
        double[] doubleArray2 = new double[] { ' ', (-1.0d) };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', 10, 54);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray2), "[32.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.04-1.0" + "'", str4.equals("32.04-1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32.0#-1.0" + "'", str6.equals("32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test001072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001072");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444HI!4444##HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!#HI!##HI!", (double) 3410041432432410L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.41004143243241E15d + "'", double2 == 3.41004143243241E15d);
    }

    @Test
    public void test001073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001073");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("#  # #       0.1- # #  # #  # #  # #  # # ", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test001074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001074");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001075");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 9, (double) 10L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test001076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001076");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "                                        0#0.0.00#0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:                                         0#0.0.00#0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a10a10a100" + "'", str8.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1 10 10 100" + "'", str11.equals("-1 10 10 100"));
    }

    @Test
    public void test001077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test001078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001078");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1a10aaaaaa", (double) (-1.41041039E10f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4104103936E10d) + "'", double2 == (-1.4104103936E10d));
    }

    @Test
    public void test001079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001079");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             -1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0", 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test001080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001080");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##h44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444hi!444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001081");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 42, (float) 464L, (float) 510L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 42.0f + "'", float3 == 42.0f);
    }

    @Test
    public void test001082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001082");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(4L, (long) 29, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
    }

    @Test
    public void test001083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001083");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0                                                .0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001084");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1a10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1a10aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001085");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(35.0d, (double) (byte) -1, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test001086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test001087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001087");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 0.1-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001088");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001089");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#  # #  # #  # #  # #  # #  # #  # #  # #  0      hi!4444");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001090");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("001a1a891a001a01a01");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001091");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 3, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001092");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("444hi!4444", (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test001093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001093");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100                             444444444444444444444444444444444444444444444444444444444444444444444class [Fa4a4# -1.  # #  # #", (long) 120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 120L + "'", long2 == 120L);
    }

    @Test
    public void test001094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001094");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 450, (double) (byte) 1, (-1.41041041E10d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.41041041E10d) + "'", double3 == (-1.41041041E10d));
    }

    @Test
    public void test001095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001095");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 87, (float) 5, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 5.0f + "'", float3 == 5.0f);
    }

    @Test
    public void test001096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001096");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(116, 496, 198);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 116 + "'", int3 == 116);
    }

    @Test
    public void test001097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001097");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0.0320.03410041432432410                #0.03410041432432410                \n0.03410041432432410                  # #  # #class [F");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001098");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (short) 3, 94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test001099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001099");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("32.0#-1.0 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001100");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 11, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3410041432432410" + "'", str10.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
    }

    @Test
    public void test001101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001101");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(" #  # #  # #", (long) 450);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 450L + "'", long2 == 450L);
    }

    @Test
    public void test001102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001102");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" #  # #  # #  # #  # #  # #  # #  # # # a 4 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001103");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(100, (int) (short) 0, 110);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test001104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001104");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.  # #  # #class [F", (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test001105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001105");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("...    3410041432432410              3410041432432410              3410041432432410              ", (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test001106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001106");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("5340.2540.140.1###");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"5340.2540.140.1###\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001107");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "     ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:      ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a10a100" + "'", str12.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
    }

    @Test
    public void test001108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001108");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', (int) ' ', 51);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test001109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001109");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  ?444hi!4444######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001110");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 120, 51.0d, 5.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 120.0d + "'", double3 == 120.0d);
    }

    @Test
    public void test001111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001111");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.                                                  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.                                                  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a10a10a100" + "'", str12.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test001112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001112");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("... # #...");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001113");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 3, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test001114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001114");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("444hi!4444##-1a10a10a100\r#hi!##hi!", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test001115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001115");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(".0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001116");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 197, 123L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test001117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001117");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 15, (double) 120.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 120.0d + "'", double3 == 120.0d);
    }

    @Test
    public void test001118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001118");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("                    \r444hi!4444                    ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001119");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 0" + "'", str4.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#0" + "'", str7.equals("0#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "040" + "'", str9.equals("040"));
    }

    @Test
    public void test001120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001120");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4');
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "3410041432432410                            444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 3410041432432410                            444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1a10a10a100" + "'", str8.equals("-1a10a10a100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-14104104100" + "'", str10.equals("-14104104100"));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test001121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001121");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("############### ######\n4444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001122");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                     \n-1.  # #  # #class [F                                      ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                     ?-1.  # #  # #class [F                                      \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 4430, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4430 + "'", int3 == 4430);
    }

    @Test
    public void test001124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001124");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1111110.111111110.1111111444HI!4444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001125");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001126");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 98, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 98.0f + "'", float3 == 98.0f);
    }

    @Test
    public void test001127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001127");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0444HI!4444444HI!");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001128");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.0#-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001129");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35.0f, (double) 51L, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test001130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001130");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 10L, (float) 450);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001131");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("A4A4#                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A4A4#                                                                                                    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001132");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001133");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              3410041432432410              ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001134");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 9, (long) 110, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test001135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001135");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test001136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001136");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (short) 97, (float) 510);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001137");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 29, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) '4', (int) ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
    }

    @Test
    public void test001138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001138");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) 'a', (int) (byte) 10);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 121, 450);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 121");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test001139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001139");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("3A1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaA1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A-1.0 0.0 -1.0 97.0 100.0 100.03A100A1A32A32A", (short) 97);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 97 + "'", short2 == (short) 97);
    }

    @Test
    public void test001140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001140");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) 11, (long) 16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test001141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001141");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001142");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1--1. # # # #class [F 0.1-", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test001143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001143");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001144");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      10101001981100", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.01010019811E13d + "'", double2 == 1.01010019811E13d);
    }

    @Test
    public void test001145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001145");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(2053, 504, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test001146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001146");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                     .32.04hi!0..", (double) 54);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54.0d + "'", double2 == 54.0d);
    }

    @Test
    public void test001147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001147");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test001148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001148");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 10, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001149");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 100.0f, (float) 91L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test001150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001150");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 29, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', (int) '4', (int) ' ');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test001151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001151");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-1.0      ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001152");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 30, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
    }

    @Test
    public void test001153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001153");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001154");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("...          ...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001155");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001156");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong(".0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      .0.0      ", 44L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44L + "'", long2 == 44L);
    }

    @Test
    public void test001157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001157");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # #", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test001158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001158");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("####################################################################################################", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test001159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001159");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001160");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100\r#hi!##hi!a10a10a444hi!4444##-1", 504);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 504 + "'", int2 == 504);
    }

    @Test
    public void test001161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001161");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001162");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001163");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 97, (float) 4L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test001164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001164");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("3a100a1a32a32a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3a100a1a32a32a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001165");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 9, (double) 5, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test001166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001166");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 30, (float) 'a', 540.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 540.0f + "'", float3 == 540.0f);
    }

    @Test
    public void test001167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001167");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0 0...103#...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0 0...103#...\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001168");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3410041432432410                            ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001169");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1111110.111111110.1111111444HI!4444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001170");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) (byte) 10, (long) 102);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 102L + "'", long3 == 102L);
    }

    @Test
    public void test001171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001171");
        long[] longArray1 = new long[] { (byte) 100 };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a');
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray1, '4', 94, 94);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', 102, 2100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 102");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray1), "[100]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100" + "'", str3.equals("100"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test001172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001172");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
    }

    @Test
    public void test001173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001173");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 116, 97);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', 113, 0);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) '4', 250);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test001174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001174");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32, (double) 1.0f, (double) 11);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test001175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001175");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test001176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001176");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001177");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 120L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 120.0d + "'", double2 == 120.0d);
    }

    @Test
    public void test001178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001178");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0#0.0.00#0     0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#0.0.00#0     0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001179");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444!IH4444444!IH4444444!IH4444444!IH4444444!IH4      0  # #  # #  # #  # #  # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001180");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001181");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0#100.0#97.0#-1.0#0.0#-1.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0#100.0#97.0#-1.0#0.0#-1.0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001182");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("     -1.0      -1.0      444HI!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001183");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#  # # ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001184");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) '#', (long) (short) -1, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test001185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001185");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("00140140141-...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001186");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(44L, 1L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test001187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001187");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("...!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001188");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" -1.  # #  # #CLASS [F");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001189");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 98, 32.0d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.0d + "'", double3 == 98.0d);
    }

    @Test
    public void test001190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001190");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) -1, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test001191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001191");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...103#...                                                                                            ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001192");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1a10", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test001193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001193");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 250, (float) 30L, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 30.0f + "'", float3 == 30.0f);
    }

    @Test
    public void test001194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001194");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("333333.--1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0", (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test001195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001195");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("32#32#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001196");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test001197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001197");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(".0.0                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001198");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 120, (float) 123, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001199");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("03#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001200");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.  #    ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001201");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("#  # #  # #  # #  # #  # #  # #  # #  # #  0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001202");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test001203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001203");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(32.0d, (double) 9L, (double) 58L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test001204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001204");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 450, (long) (short) 100, 2053L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2053L + "'", long3 == 2053L);
    }

    @Test
    public void test001205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001205");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("0-1.0##", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test001206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001206");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("###############################################################################################################");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001207");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 498, (double) (-1L), 1.01010019811E13d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test001208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001208");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 2053);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2053.0f + "'", float2 == 2053.0f);
    }

    @Test
    public void test001209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001209");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.0444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001210");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) -1, (byte) 1, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray4, ".0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          .0      -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, -1, 1, 0]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#-1#1#0" + "'", str7.equals("-1#-1#1#0"));
    }

    @Test
    public void test001211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001211");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 30, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 17 + "'", int3 == 17);
    }

    @Test
    public void test001212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001212");
        int[] intArray0 = new int[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, '4');
        try {
            int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray0), "[]");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test001213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001213");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a   0.1-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001214");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 97, (short) (byte) 1, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 97 + "'", short3 == (short) 97);
    }

    @Test
    public void test001215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001215");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0\r444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0?444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001216");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0\r444hi!4444", (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test001217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001217");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                0.1-", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test001218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001218");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (-1), 495);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 0" + "'", str4.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#0" + "'", str7.equals("0#0"));
    }

    @Test
    public void test001219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001219");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("A4-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0\r444hi!4444", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test001220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001220");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                                                                                                                                                                                                                                                                                                                                                                                             3410041432432410                ", (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.41004136E15f + "'", float2 == 3.41004136E15f);
    }

    @Test
    public void test001221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001221");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("...432410");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001222");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(102.0f, 52.0f, (float) 9L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 102.0f + "'", float3 == 102.0f);
    }

    @Test
    public void test001223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001223");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test001224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001224");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"         \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001225");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # 3 100 1 32 32 10 # # ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001226");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                              HI!4444");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001227");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("0.0", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test001228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001228");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test001229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001229");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("3410041432432410                ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001230");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444-1.0      -1.0      -1.0      -1.0      -1.0      444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001231");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((-1), 464, 53);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test001232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001232");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 35, (double) (short) 1, (double) 498);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 498.0d + "'", double3 == 498.0d);
    }

    @Test
    public void test001233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001233");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(48, (int) (short) 1, 495);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 495 + "'", int3 == 495);
    }

    @Test
    public void test001234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001234");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test001235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001235");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("\r#hi!##hi!a10a10a444hi!4444##444hi!4432#32#444h");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#hi!##hi!a10a10a444hi!4444##444hi!4432#32#444h\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001236");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 0, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test001237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001237");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 100, (-1));
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 1 + "'", short11 == (short) 1);
    }

    @Test
    public void test001238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001238");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 42L, (float) 42L, (float) 116);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 42.0f + "'", float3 == 42.0f);
    }

    @Test
    public void test001239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001239");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#100.0a100.0a97.0a-1.0a0.0a-1.0#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0a100.0a97.0a-1.0a0.0a-1.0#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001240");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4441, 112, 142);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4441 + "'", int3 == 4441);
    }

    @Test
    public void test001241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001241");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001242");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001243");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("#a4#aaaaaaaaaaaaaaaaaaaaaa....0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4#aaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001244");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.  # #  # #class [F                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0   -1. # # # #class [F 0.1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test001245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001245");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 495, (long) 250, (long) 1968);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1968L + "'", long3 == 1968L);
    }

    @Test
    public void test001246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001246");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("3410041432432410                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3410041432432410                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001247");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 120, 0.0f, (float) 51L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 120.0f + "'", float3 == 120.0f);
    }

    @Test
    public void test001248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001248");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                                                                                                                                                                                                                                       ", (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test001249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001249");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3 100 1 32 32 10" + "'", str11.equals("3 100 1 32 32 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test001250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001250");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # # a 4 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001251");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("############################################# ######\n", (double) 98.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.0d + "'", double2 == 98.0d);
    }

    @Test
    public void test001252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001252");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                   4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                   4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001253");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 52, (int) (short) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3410041432432410" + "'", str10.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3 100 1 32 32 10" + "'", str12.equals("3 100 1 32 32 10"));
    }

    @Test
    public void test001254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001254");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '4', 123, 489);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 123");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.04100.0497.04-1.040.04-1.0" + "'", str11.equals("100.04100.0497.04-1.040.04-1.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.04100.0497.04-1.040.04-1.0" + "'", str13.equals("100.04100.0497.04-1.040.04-1.0"));
    }

    @Test
    public void test001255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001255");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0      ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test001256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001256");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("A4-1.0            -1.0            100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.0 100.0\r444hi!4444", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test001257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001257");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("444hi!4444############################################################################################################################################################################################################################################################################################################################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!######################################################################################################################################################################################################hi!############################################################################################################################################################################################################################################################################################################################################################################################################hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444hi!4444############################################################################################################################################################################################################################################################################################################################################################################################################hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!######################################################################################################################################################################################################hi!############################################################################################################################################################################################################################################################################################################################################################################################################hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001258");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 50, 0.0d, 3.41004143243241E15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test001259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001259");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100L, (double) 'a', (double) 113);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 113.0d + "'", double3 == 113.0d);
    }

    @Test
    public void test001260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001260");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) 'a', 250, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 250 + "'", int3 == 250);
    }

    @Test
    public void test001261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001261");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4441, 6, 58);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4441 + "'", int3 == 4441);
    }

    @Test
    public void test001262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001262");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # 3a100a1a32a32a10");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001263");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#', (int) (byte) 0, 102);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 10 + "'", short4 == (short) 10);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 10 + "'", short6 == (short) 10);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
    }

    @Test
    public void test001264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001264");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001265");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("A4A4#                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A4A4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001266");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                                                                                                                                                                                                                                                                        3a100a1a32a32a10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3a100a1a32a32a10\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001267");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001268");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(35L, (long) '4', (long) 540);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 540L + "'", long3 == 540L);
    }

    @Test
    public void test001269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001269");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("############################################# ######\n", (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test001270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001270");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                            0#0                                                            ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001271");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                              ", 9.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0d + "'", double2 == 9.0d);
    }

    @Test
    public void test001272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001272");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("-1.0", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test001273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001273");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("#a4##a4##a4#...", (double) 30L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test001274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001274");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.0 0.0 -1.0 97.0 100.0 100.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.0 0.0 -1.0 97.0 100.0 100.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001275");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("##########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001276");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4430, (float) 4141, 3.41004136E15f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.41004136E15f + "'", float3 == 3.41004136E15f);
    }

    @Test
    public void test001277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001277");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("3 100 1 32 32 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001278");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" # #  # #  # # 1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test001279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001279");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test001280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001280");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.44444443E11f + "'", float1.equals(4.44444443E11f));
    }

    @Test
    public void test001281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001281");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("hhhhi!hhhhhhhhi!hhhhclass [Fa4a4#");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001282");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001283");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 142, (double) 35.0f, (double) 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test001284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001284");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#0.1- #");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001285");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("3A100A1A32A32A1", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test001286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001286");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test001287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001287");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 110, (double) 5L, 112.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
    }

    @Test
    public void test001288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001288");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("# # # # # # 1.0 -1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001289");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(112.0d, (double) 2053.0f, (double) 6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test001290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001290");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001291");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(16.0d, (double) 87.0f, (double) 2053);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2053.0d + "'", double3 == 2053.0d);
    }

    @Test
    public void test001292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001292");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-1.0-1.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001293");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 0, (byte) 10, (byte) 100, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray6, "hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: hi!#hi!#hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#444hi!4444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray6), "[1, 0, 10, 100, -1, 10]");
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test001294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001294");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test001295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) 30, (long) 504);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test001296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001296");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', 2, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3a100a1a32a32a10" + "'", str9.equals("3a100a1a32a32a10"));
    }

    @Test
    public void test001297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001297");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      ", (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test001298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001298");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 120, (double) 32.0f, (double) 4.44444443E11f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test001299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001299");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 97, (short) 100, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test001300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001300");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444aa4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444aa4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001301");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0100.097.0-1.00.0-1.0100.0100.097.32.04-1.0100.198.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0100.097.0-1.00.0-1.0100.0100.097.32.04-1.0100.198.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001302");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("  #  # #  # #  # #  # #  # #  # #  # #  # #  0      ", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001303");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                              ", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test001304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001304");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1111110.111111110.1111111444HI!4444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001305");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001306");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" -1.  # #  # #CLASS [F#####################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" -1.  # #  # #CLASS [F#####################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001307");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001308");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001309");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.0      -1.0      -1.0      -1.0      -1.0      444HI!4444                                                                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001310");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.Class<?> wildcardClass9 = shortArray2.getClass();
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 0" + "'", str4.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#0" + "'", str7.equals("0#0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test001311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001311");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test001312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001312");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("3A100A1A32A32A1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001313");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 540L, (double) 12, 50.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 540.0d + "'", double3 == 540.0d);
    }

    @Test
    public void test001314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001314");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2053, (double) 489, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test001315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001315");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001316");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("F[ ssalc# #  # #  .1-\n", (long) 4430);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4430L + "'", long2 == 4430L);
    }

    @Test
    public void test001317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001317");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("              1.01.052.035.0              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001318");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("# #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 3 100 1 32 32 10");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001319");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001320");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test001321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001321");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 495, (int) ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3 100 1 32 32 10" + "'", str11.equals("3 100 1 32 32 10"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test001322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001322");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 493, 0L, 52L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test001323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001323");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 510, (long) 20, (long) 53);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 20L + "'", long3 == 20L);
    }

    @Test
    public void test001324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001324");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 16, (long) 498, (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 498L + "'", long3 == 498L);
    }

    @Test
    public void test001325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001325");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("...-14104104100-1a10a10a100##################0.1-##################1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001326");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 540.0f, (double) 35.0f, (double) 42.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 540.0d + "'", double3 == 540.0d);
    }

    @Test
    public void test001327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001327");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 32, 20);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 12, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test001328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001328");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 113, (long) (short) 0, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test001329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001329");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 52, (float) 52, (float) 493);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 493.0f + "'", float3 == 493.0f);
    }

    @Test
    public void test001330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001330");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(97.0d, 198.0d, (double) 4.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 198.0d + "'", double3 == 198.0d);
    }

    @Test
    public void test001331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001331");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001332");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                             4444444444444444444444444444444444444444444444444444444444444444444444444444440#35#0#32#32#100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001333");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) (short) 97, (float) 116);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001334");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("444IIII344HH4443243244HIIIIIIIIIIIIII344HH4443243244HIIIIIIIIIIIIII344HH4443243244HIIIIIIIIIIIIII", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test001335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001335");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("040100.0a100.0a97.0a-1.0a0.0a-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"040100.0a100.0a97.0a-1.0a0.0a-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001336");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4-1.4444444444class4[F44444444444444444444444444444444444444444444444444444444444444444.4444444444class4[F", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test001337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001337");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0                                                                                                ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1.equals(0.0d));
    }

    @Test
    public void test001338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001338");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(498, 51, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
    }

    @Test
    public void test001339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001339");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# -1.0#", 450);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 450 + "'", int2 == 450);
    }

    @Test
    public void test001340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001340");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test001341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001341");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 32, 504);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0" + "'", str8.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0" + "'", str10.equals("-1.0"));
    }

    @Test
    public void test001342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001342");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, (float) 4430, (float) 12);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test001343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001343");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!4444");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001344");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                              HI!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                              HI!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001345");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 97, (short) (byte) 10, (short) 97);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001346");
        double[] doubleArray2 = new double[] { ' ', (-1.0d) };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray2), "[32.0, -1.0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "32.04-1.0" + "'", str4.equals("32.04-1.0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "32.0#-1.0" + "'", str6.equals("32.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
    }

    @Test
    public void test001347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001347");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0      -1.0      -1.0      -1.0      -1.0", (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test001348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001348");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 10L, 2053.0f, (float) 51L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2053.0f + "'", float3 == 2053.0f);
    }

    @Test
    public void test001349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001349");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 116, 97);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 53, 113);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 53");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test001350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001350");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(9.0d, 198.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.0d + "'", double3 == 9.0d);
    }

    @Test
    public void test001351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001351");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4############################################################################################################### #A4A4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001352");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 510L, (double) 116, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test001353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001353");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray1, ' ', 110, 4430);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 110");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test001354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001354");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#');
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 122, 32);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 11, 464);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test001355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001355");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(510L, 29L, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 510L + "'", long3 == 510L);
    }

    @Test
    public void test001356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001356");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aa4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001357");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (-1), 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test001358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001358");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray1, '#', 42, 53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 42");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test001359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 116, (long) 1968, 116L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1968L + "'", long3 == 1968L);
    }

    @Test
    public void test001360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001360");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("-1");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1.equals((-1.0f)));
    }

    @Test
    public void test001361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001361");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                                                                                                                                                                                                                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                                                                                                                                                                                                                                                    \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001362");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, '4');
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 87, (int) '#');
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 20, 121);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 20");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3410041432432410" + "'", str9.equals("3410041432432410"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test001363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001363");
        long[] longArray6 = new long[] { 3, 100, (byte) 1, 32L, 32L, 10L };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, '#');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 493, (-1));
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(longArray6), "[3, 100, 1, 32, 32, 10]");
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3 100 1 32 32 10" + "'", str11.equals("3 100 1 32 32 10"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3#100#1#32#32#10" + "'", str13.equals("3#100#1#32#32#10"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test001364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001364");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) 0, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 25 + "'", int3 == 25);
    }

    @Test
    public void test001365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001365");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 25, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test001366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001366");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test001367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001367");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!  \r444hi!4444                                                                                                                                                                                                                                                                                                                                                                                                                                                                             3410041432432410               ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100? # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!  ?444hi!4444                                                                                                                                                                                                                                                                                                                                                                                                                                                                             3410041432432410\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001368");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444444444444440.");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4444444444444446E45d + "'", double1 == 4.4444444444444446E45d);
    }

    @Test
    public void test001369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001369");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', (int) (byte) 10, 0);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 87, 51);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 110, (int) (short) 3);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test001370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001370");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 51L, 0.0d, 3.41004143243241E15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test001371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001371");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(98, 16, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 98 + "'", int3 == 98);
    }

    @Test
    public void test001372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001372");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 32, 20);
        float float14 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 52.0f + "'", float14 == 52.0f);
    }

    @Test
    public void test001373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001373");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray6, 'a', 464, 493);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 464");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test001374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001374");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber(" -1.  0 0  0 0class [F                                                                 .  0 0  0 0class [F");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001375");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\r40#\r44");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001376");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("-1.\r-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001377");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 444 + "'", int1.equals(444));
    }

    @Test
    public void test001378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001378");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, '4', 493, 16);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1#10#10#100" + "'", str8.equals("-1#10#10#100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test001379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001379");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n      0.1-# #  # #  # #  # #  # #  # #  # #  # #  # #  0      \n", (double) 2053);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2053.0d + "'", double2 == 2053.0d);
    }

    @Test
    public void test001380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001380");
        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 10, (byte) 10, (byte) 100 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', 0, (int) (short) 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray4), "[-1, 10, 10, 100]");
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1 10 10 100" + "'", str13.equals("-1 10 10 100"));
    }

    @Test
    public void test001381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001381");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001382");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001383");
        double[] doubleArray1 = new double[] { 198 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray1, ' ');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray1, '4', 6, 2100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray1), "[198.0]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.0d + "'", double2 == 198.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "198.0" + "'", str4.equals("198.0"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 198.0d + "'", double5 == 198.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "198.0" + "'", str7.equals("198.0"));
    }

    @Test
    public void test001384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001384");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 1, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test001385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001385");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih444444444444444444444444444444444441h1h1hh19811hh4444444hih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001386");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("cl ss#[F");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001387");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((-1.0f), (float) 97L, (float) (short) 97);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test001388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001388");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("\r444hi!4444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001389");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 87, 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.Class<?> wildcardClass17 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test001390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001390");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("                                                                                                                                                                       # a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                                                                                                                                                       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001391");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#################################################################################################################################################################################################################################################444HI!4444##################################################################################################################################################################################################################################################3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"################################################################################################################################################################################################################################################444HI!4444##################################################################################################################################################################################################################################################3\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001392");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 10, (long) 15, (long) 44);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 44L + "'", long3 == 44L);
    }

    @Test
    public void test001393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001393");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test001394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001394");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(20.0d, (double) 122, (double) 504);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 504.0d + "'", double3 == 504.0d);
    }

    @Test
    public void test001395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001395");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 198, (long) 56, (long) 29);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 198L + "'", long3 == 198L);
    }

    @Test
    public void test001396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001396");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#', 17, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001397");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0#0.0.00#0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001398");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte(" #  # #  # #");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001399");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test001400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001400");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("32.04-1.0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001401");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                     -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                                        0#0.0.00#0                     -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  ?444hi!4444######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001402");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test001403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001403");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("CLASS [fA4A4# -1.  #     -1.0      -1.0      444hi!4444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001404");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0  \r444hi!4444######1.0-1.0-1.0-1.0-1.0-1.0-1.0-1. ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001405");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0#0.0.00#0     0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#0.0.00#0     0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001406");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4##a4#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001407");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(20, 113, 444);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 444 + "'", int3 == 444);
    }

    @Test
    public void test001408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001408");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) (-1), (float) 51L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 51.0f + "'", float3 == 51.0f);
    }

    @Test
    public void test001409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001409");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("\r#hi!##hi!a10a10a444hi!4444##");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001410");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" a#a4a4a4a#", (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test001411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001411");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1 10 10 100", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test001412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001412");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#a4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100##################0.1-##################1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100##################0.1-##################1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001413");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat(" -1.  # #  # #class [f      0.1-");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001414");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.041.0452.0435.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001415");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("-1.  # #  # #");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.  # #  # #\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001416");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("...!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444hi!4444...", (long) 91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 91L + "'", long2 == 91L);
    }

    @Test
    public void test001417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001417");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0100.097.0-1.00.0-1.0100.0100.097.32.04-1.0100.0100.097.0-1.00.0-1.0100.0100.097.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test001418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001418");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.                                                  444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444#a4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100##################0.1-##################1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0444hi!4444");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0 100.0 97.0 -1.0 0.0 -1.0100.0 100.0 97.32.04-1.0100.                                                  444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444444HI!4444#a4#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100##################0.1-##################1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0-1.0444hi!4444\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001419");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444444444444444444444444444444444444440.# #", (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test001420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001420");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("3A100A1A32A32A");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001421");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("0a35a0a32a32a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0a35a0a32a32a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001422");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, (long) 121, 44L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 121L + "'", long3 == 121L);
    }

    @Test
    public void test001423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001423");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("\r-1.0", (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test001424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001424");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("3#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001425");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                    \r444hi!4444                    ", (float) 42L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test001426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001426");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits(" -1.  # #  # #class [f      0.1-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001427");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test001428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001428");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(98, 2100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test001429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001429");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 142, (double) 4L, (double) 510.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test001430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001430");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', 1, (int) (byte) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 87, (int) ' ');
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte15 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "0.1-");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 0.1-");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[-1]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1" + "'", str7.equals("-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) -1 + "'", byte14 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte15 + "' != '" + (byte) -1 + "'", byte15 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "-1" + "'", str17.equals("-1"));
    }

    @Test
    public void test001431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001431");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("# #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # #  # # ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001432");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test001433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001433");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', (int) (short) 1, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, '#', 8, 6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ', 116, 16);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray1), "[100]");
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test001434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001434");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("A23A23A1A001A3", (float) 121);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 121.0f + "'", float2 == 121.0f);
    }

    @Test
    public void test001435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001435");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("444hi!4444 3410041432432410");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test001436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001436");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("...    3410041432432410              3410041432432410              3410041432432410");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"..\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001437");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 466, 4441.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test001438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001438");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray1, '#');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a', 5, 444);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1" + "'", str9.equals("1"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
    }

    @Test
    public void test001439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001439");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 97, (long) 116, (long) 20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 116L + "'", long3 == 116L);
    }

    @Test
    public void test001440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001440");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("32.0#-1.0 ", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test001441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001441");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 97.0f, 4.0d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test001442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001442");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 50, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.0d + "'", double3 == 50.0d);
    }

    @Test
    public void test001443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001443");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.Class<?> wildcardClass10 = shortArray2.getClass();
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 0" + "'", str4.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a0" + "'", str7.equals("0a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0#0" + "'", str9.equals("0#0"));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test001444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001444");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("0a0aaaaaaaaaaaaa0a0aaaaaaaaaaaaa##");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001445");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("3410041432432410 444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"3410041432432410 444hi!4444##hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!#hi!##hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001446");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-1), 58L, 2053L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test001447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001447");
        float[] floatArray1 = new float[] { (-1) };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(floatArray1, '#');
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray1, 'a', 51, 1);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ', 0, 110);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[-1.0]");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0" + "'", str3.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + (-1.0f) + "'", float4 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0" + "'", str6.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.0" + "'", str8.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test001448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001448");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("0A35A0A32A32A100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001449");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(540.0f, (float) 50, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001450");
        int[] intArray1 = new int[] { (byte) 1 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray1, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray1, '4');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray1, '4', 0, 0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(intArray1), "[1]");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test001451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001451");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 58, 464L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test001452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001452");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(414, 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 414 + "'", int3 == 414);
    }

    @Test
    public void test001453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001453");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 97, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test001454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001454");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0 100.0 97.0 -1.0 0.0 -1.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001455");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 98, (double) 53, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test001456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001456");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("\n-1.  # #  # #     \n", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test001457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001457");
        float[] floatArray4 = new float[] { 1, (byte) 1, '4', 35.0f };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray4, '4', 123, 0);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray4);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray4, ' ', 91, 113);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 91");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray4), "[1.0, 1.0, 52.0, 35.0]");
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 52.0f + "'", float12 == 52.0f);
    }

    @Test
    public void test001458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001458");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("#  # #       0.1- # #  # #  # #  # #  # #");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001459");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test001460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001460");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("\n");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test001461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001461");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("3a100a1a32a32a10", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test001462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001462");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001463");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 100, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test001464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001464");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt(".0.0      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test001465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001465");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 3, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test001466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001466");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1.  # #  # #class [F                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1.  # #  # #class [F                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0                                               100.0   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001467");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("32.0#-1.0", (float) 123L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 123.0f + "'", float2 == 123.0f);
    }

    @Test
    public void test001468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001468");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(414, 53, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 53 + "'", int3 == 53);
    }

    @Test
    public void test001469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001469");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#', 3, 540);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str9.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str12.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test001470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001470");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 58L, (float) 450L, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test001471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001471");
        short[] shortArray2 = new short[] { (short) 1, (short) 10 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[1, 10]");
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1#10" + "'", str5.equals("1#10"));
    }

    @Test
    public void test001472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001472");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("# a 4 #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1a10a10a100\r # #  # #  # #  # #  # #  # #  # #  # #  # #       0.1- # #  # #  # #  # #  # #  # #  # #  # #  # # 1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!      -1hi!  \r444hi!4444                                                                                                                                                                                                                                                                                                                                                                                                                                                                             3410041432432410               ", 94);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 94 + "'", int2 == 94);
    }

    @Test
    public void test001473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001473");
        float[] floatArray1 = new float[] { (short) 0 };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray1, ' ');
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray1, '4', 8, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(floatArray1), "[0.0]");
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.0" + "'", str4.equals("0.0"));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test001474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001474");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aa4");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test001475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001475");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("-1.0      -1.0      444HI!                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0                                                                                                .0.0", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test001476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001476");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001477");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("           100.0#100.0#97.0#-1.0#0.0#-1.0           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"           100.0#100.0#97.0#-1.0#0.0#-1.0           \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001478");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat(" #  # #  # #  # #  # #  # #  # #  # #  # #  0      ", (float) 110);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 110.0f + "'", float2 == 110.0f);
    }

    @Test
    public void test001479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001479");
        double[] doubleArray6 = new double[] { (short) 100, (byte) 100, 'a', (-1), 0.0d, (-1) };
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray6, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray6);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray6, ' ');
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(doubleArray6), "[100.0, 100.0, 97.0, -1.0, 0.0, -1.0]");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#100.0#97.0#-1.0#0.0#-1.0" + "'", str9.equals("100.0#100.0#97.0#-1.0#0.0#-1.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100.0 100.0 97.0 -1.0 0.0 -1.0" + "'", str15.equals("100.0 100.0 97.0 -1.0 0.0 -1.0"));
    }

    @Test
    public void test001480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001480");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0435404324324100", 4430.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.354043243241E14d + "'", double2 == 4.354043243241E14d);
    }

    @Test
    public void test001481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001481");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("2.0416.045.0410.04102.0487.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test001482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001482");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198.0198############### ######\n44444444444444444444444444444444444                                                      \n     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001483");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("...", 47);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 47 + "'", int2 == 47);
    }

    @Test
    public void test001484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001484");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) -1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test001485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001485");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4430, 47, 122);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 47 + "'", int3 == 47);
    }

    @Test
    public void test001486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001486");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(112, 4419, 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 20 + "'", int3 == 20);
    }

    @Test
    public void test001487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001487");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(5.0d, (double) 32L, 198.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 198.0d + "'", double3 == 198.0d);
    }

    @Test
    public void test001488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001488");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test001489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001489");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("a#a4a4a4a#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001490");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "-1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.00.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.0      -1.00.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
    }

    @Test
    public void test001491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001491");
        short[] shortArray2 = new short[] { (short) 0, (byte) 0 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray2, ' ');
        short short16 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(shortArray2, 'a');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(shortArray2, '4', 498, 0);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(shortArray2), "[0, 0]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0 0" + "'", str4.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#0" + "'", str7.equals("0#0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a0" + "'", str9.equals("0a0"));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 0" + "'", str13.equals("0 0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0 0" + "'", str15.equals("0 0"));
        org.junit.Assert.assertTrue("'" + short16 + "' != '" + (short) 0 + "'", short16 == (short) 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0a0" + "'", str18.equals("0a0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test001492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001492");
        byte[] byteArray1 = new byte[] { (byte) 100 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (short) 1, 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "    -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message:     -1.0      -1.0      -1.0      -1.0      444hi!4444                                                                                                                                          ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertEquals(java.util.Arrays.toString(byteArray1), "[100]");
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
    }

    @Test
    public void test001493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001493");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4441", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test001494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001494");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test001495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001495");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#hi!##hi!a10a10a444hi!4444## #hi!##hi!a10a10a444hi!4444## #hi!##hi!a10a10a444hi!4444## #hi!##hi!a10a10a444hi!4444444AA4", (float) 30);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test001496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001496");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(" -1.  # #  # #class [F                                                                 .  # #  # #class [F           100.0#100.0#97.0#-1.0#0.0#-1.0           ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test001497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001497");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("0#0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test001498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001498");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1A10AAAAAA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test001499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001499");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#  # #  # #  # #  # #  # #  # #  # #  # #  0                                          ", (float) 102L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 102.0f + "'", float2 == 102.0f);
    }

    @Test
    public void test001500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001500");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("-1.0-1.0-1.0-1.0-1.03#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#103#100#1#32#32#10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

}
